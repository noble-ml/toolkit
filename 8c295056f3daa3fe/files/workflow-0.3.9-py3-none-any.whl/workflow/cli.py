from __future__ import annotations

import argparse
import os
import sys
import time

from . import _ui
from ._version import __version__
from .errors import WorkflowError


def _devices(a) -> None:
    from .core import device
    c = _ui.console()
    c.print(_ui._line(("Workflow devices", f"bold {_ui.BONE}"), (f"  auto → {device.get('auto')}", _ui.ASH)))
    c.print()
    rows = [(d["name"], d["info"]) for d in device.available()]
    for name, (ok, why) in (("cuda", device.cuda_status()), ("mps", device.mps_status())):
        if not ok:
            rows.append((name, "unavailable: " + why))
    _ui.table(["device", "info"], rows, console_=c)


def _info(a) -> None:
    from . import nbm
    meta = nbm.read_meta(a.file)
    model = nbm.load(a.file)
    c = _ui.console()
    c.print(_ui._line((os.path.basename(a.file), f"bold {_ui.BONE}"),
                      (f"  workflow {meta['workflow_version']} · {meta.get('precision', 'fp32')} · created {meta['created']}", _ui.ASH)))
    if meta.get("classes"):
        c.print(_ui._line(("classes  ", _ui.ASH), (", ".join(meta["classes"]), _ui.BONE)))
    tr = meta.get("training")
    if tr:
        c.print(_ui._line(("training ", _ui.ASH), (f"epoch {tr['epoch']}", _ui.BONE), (f" of {tr.get('epochs')} · best epoch {tr.get('best_epoch')}", _ui.ASH)))
    c.print()
    model.summary()


def _quantize(a) -> None:
    from . import nbm
    precision = a.type.lower()
    out = a.output or f"{os.path.splitext(a.file)[0]}-{precision}.nbm"
    if os.path.exists(out) and not a.overwrite:
        raise WorkflowError(f"{out} already exists.", "Workflow does not overwrite files unless asked.", "pass --overwrite or choose another -o.")
    model = nbm.load(a.file)
    calib = None
    if a.calibration:
        try:
            import felix
        except ImportError:
            raise WorkflowError("calibration needs Felix.", "calibration images are read from a Felix dataset.", "install felix, or quantise without --calibration.") from None
        ds = felix.load(a.calibration)
        calib = ds.val if hasattr(ds, "val") and len(ds.val) else ds
    elif precision == "int8" and not (model.quant and model.quant.ranges):
        from .errors import warn
        warn("no calibration data: only the weights are quantised to int8; activations stay float.",
             "int8 activations need their value ranges, which come from sample images.",
             "pass --calibration data.felix (or train with QAT) for a fully int8 model.")
    t0 = time.time()
    path = model.export(format="nbm", output=out, precision=precision, calibration=calib)
    c = _ui.console()
    before, after = os.path.getsize(a.file), os.path.getsize(path)
    c.print(_ui._line(("Workflow quantize ", f"bold {_ui.BONE}"), (f"{a.file} → {path}", _ui.ASH)))
    c.print(_ui._line(("  ", None), (precision, f"bold {_ui.BONE}"),
                      (f" · {before / 2**20:.1f} MB → {after / 2**20:.1f} MB · "
                       f"{'calibrated on ' + a.calibration if a.calibration else ('ranges from QAT' if model.quant and model.quant.ranges else 'weights only')}"
                       f" · {time.time() - t0:.1f}s", _ui.ASH)))


def _export(a) -> None:
    from . import nbm
    out = a.output or f"{os.path.splitext(a.file)[0]}{'-' + a.precision if a.precision != 'fp32' else ''}.{a.format}"
    if os.path.exists(out) and not a.overwrite:
        raise WorkflowError(f"{out} already exists.", "Workflow does not overwrite files unless asked.", "pass --overwrite or choose another -o.")
    model = nbm.load(a.file)
    calib = None
    if a.calibration:
        import felix
        ds = felix.load(a.calibration)
        calib = ds.val if hasattr(ds, "val") and len(ds.val) else ds
    path = model.export(format=a.format, output=out, precision=a.precision, calibration=calib, img_size=a.img_size)
    c = _ui.console()
    c.print(_ui._line(("Workflow export ", f"bold {_ui.BONE}"), (f"{a.file} → {path}", _ui.ASH),
                      (f"  {a.precision} · {os.path.getsize(path) / 2**20:.1f} MB", _ui.ASH)))


def _eval(a) -> None:
    from . import nbm
    from .evaluate import evaluate
    model = nbm.load(a.file)
    ds = None
    if a.dataset:
        try:
            import felix
        except ImportError:
            raise WorkflowError("evaluating on a dataset needs Felix.", "datasets are read through Felix.", "install felix.") from None
        full = felix.load(a.dataset)
        ds = getattr(full, a.split) if hasattr(full, "splits") else full
    res = evaluate(model, dataset=ds, device=a.device, img_size=a.img_size)
    if a.save:
        res.save(a.save)


def _predict(a) -> None:
    from .inference import inference
    inference(a.source if len(a.source) > 1 else a.source[0], a.file, a.output, all=a.all, split=a.split,
              confidence=a.confidence, iou=a.iou, img_size=a.img_size, device=a.device)


def _init(a) -> None:
    from . import notebook
    path = notebook.create(a.path, dataset=a.dataset, img_size=a.img_size, epochs=a.epochs, device=a.device, overwrite=a.overwrite)
    c = _ui.console()
    c.print(_ui._line(("wrote ", _ui.ASH), (path, f"bold {_ui.BONE}"),
                      (f"  ·  small detector · {a.img_size}px · {a.epochs} epochs · benchmarks before and after · saving", _ui.ASH)))
    lib = os.path.join(os.path.dirname(path) or ".", "library.md")
    c.print(_ui._line(("wrote ", _ui.ASH), (lib, f"bold {_ui.BONE}"),
                      ("  ·  every layer, block and tool: what it builds inside, what you choose", _ui.ASH)))
    data_note = f"uses {a.dataset}" if os.path.exists(a.dataset) else f"makes a practice dataset at {a.dataset} on first run"
    c.print(_ui._line(("data  ", _ui.ASH), (data_note, _ui.BONE)))
    c.print(_ui._line(("open  ", _ui.ASH), (f"jupyter lab {path}", _ui.BONE), ("   (or VS Code / Colab)", _ui.ASH)))


def _script(a) -> None:
    from . import scripts
    preset = a.preset
    if preset is None:
        if not sys.stdin.isatty():
            raise WorkflowError("no preset chosen.", "the script type is needed to generate it.", "pass --preset " + "|".join(scripts.PRESETS))
        c = _ui.console()
        for name, (_, doc) in scripts.PRESETS.items():
            c.print(_ui._line((f"  {name:<8}", _ui.BONE), (doc, _ui.ASH)))
        preset = input("preset: ").strip()
    out = a.output or f"infer_{preset}.py"
    scripts.generate(preset, a.file, out, a.overwrite)
    c = _ui.console()
    c.print(_ui._line(("wrote ", _ui.ASH), (out, f"bold {_ui.BONE}"), (f"  ({preset} preset)", _ui.ASH)))
    hint = {"image": "python {o} photo.jpg", "folder": "python {o} photos/", "video": "python {o} clip.mp4", "webcam": "python {o}"}[preset]
    c.print(_ui._line(("run   ", _ui.ASH), (hint.format(o=out), _ui.BONE)))


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="workflow", description="Workflow CNN framework.")
    p.add_argument("--version", action="version", version=f"workflow {__version__}")
    sub = p.add_subparsers(dest="cmd", metavar="command")
    s = sub.add_parser("init", help="create a starter notebook (small model, benchmarks, saving) and library.md")
    s.add_argument("path", nargs="?", default="workflow.ipynb", help="notebook to create (default workflow.ipynb)")
    s.add_argument("--dataset", default="practice_shapes.felix", help="Felix dataset to train on (made in the notebook if missing)")
    s.add_argument("--img-size", type=int, default=256)
    s.add_argument("--epochs", type=int, default=30)
    s.add_argument("--device", default="auto")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("info", help="summarise a .nbm model")
    s.add_argument("file")
    sub.add_parser("devices", help="list cpu / cuda / mps and what 'auto' picks")
    s = sub.add_parser("quantize", help="post-training quantisation: workflow quantize MODEL int8|fp16|fp32")
    s.add_argument("file")
    s.add_argument("type", choices=["int8", "fp16", "fp32"])
    s.add_argument("-o", "--output", help="output .nbm (default: MODEL-TYPE.nbm)")
    s.add_argument("--calibration", metavar="DATASET", help="Felix dataset whose images calibrate int8 activation ranges")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("export", help="export to ONNX or a precision-converted .nbm")
    s.add_argument("file")
    s.add_argument("--format", choices=["onnx", "nbm"], default="onnx")
    s.add_argument("--precision", choices=["fp32", "fp16", "int8"], default="fp32")
    s.add_argument("-o", "--output")
    s.add_argument("--calibration", metavar="DATASET")
    s.add_argument("--img-size", type=int)
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("eval", help="architecture numbers, or accuracy with --dataset")
    s.add_argument("file")
    s.add_argument("--dataset", help="Felix dataset (folder or .felix)")
    s.add_argument("--split", choices=["train", "val", "test"], default="test")
    s.add_argument("--device")
    s.add_argument("--img-size", type=int)
    s.add_argument("--save", help="write results to .json or .csv")
    s = sub.add_parser("predict", help="workflow predict <model_path> <image_path>: detect objects, save to results/",
                       description="Run a model on an image (or a video, a folder, or a Felix dataset) and save original/, "
                                   "annotated/ and predictions.json to results/.",
                       usage="workflow predict model_path path [path ...] [options]")
    s.add_argument("file", metavar="model_path", help="the .nbm model, e.g. detector.nbm")
    s.add_argument("source", metavar="path", nargs="+",
                   help="an image (or a video, a folder, or a Felix dataset: one random test image unless --all)")
    s.add_argument("-o", "--output", default="results/", help="folder for original/, annotated/ and predictions.json")
    s.add_argument("--split", choices=["train", "val", "test"], help="which split of a Felix dataset (default: test)")
    s.add_argument("--all", action="store_true", help="run every image of a dataset or folder (default: one, picked at random)")
    s.add_argument("--confidence", type=float, default=0.25)
    s.add_argument("--iou", type=float, default=0.45)
    s.add_argument("--img-size", type=int)
    s.add_argument("--device")
    s = sub.add_parser("script", help="generate an inference script (image, folder, video, webcam)")
    s.add_argument("file")
    s.add_argument("--preset", choices=["image", "folder", "video", "webcam"])
    s.add_argument("-o", "--output")
    s.add_argument("--overwrite", action="store_true")
    return p


COMMANDS = {"init": _init, "info": _info, "devices": _devices, "quantize": _quantize, "export": _export, "eval": _eval,
            "predict": _predict, "script": _script}


def main(argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except Exception:
            pass
    p = build_parser()
    a = p.parse_args(argv)
    try:
        if a.cmd in COMMANDS:
            COMMANDS[a.cmd](a)
        else:
            _ui.banner(__version__, [("init", "starter notebook: small model, benchmarks, saving"), ("info", "summarise a .nbm model"), ("predict", "images, videos, folders or a dataset → results/"),
                                     ("eval", "speed and size, or accuracy with --dataset"),
                                     ("quantize", "post-training int8 / fp16"), ("export", "ONNX or .nbm at any precision"),
                                     ("script", "inference script: image, folder, video, webcam"),
                                     ("devices", "list cpu / cuda / mps")])
    except WorkflowError as e:
        _ui.error(str(e))
        return 1
    except KeyboardInterrupt:
        _ui.error("interrupted")
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
