"""The training loop behind ``model.train``."""
from __future__ import annotations

import math
import os
import time
from typing import Dict, List, Optional

from . import _ui, data, detect, nbm
from .core import Tensor, backward, clear_tape, no_grad
from .errors import DataError, WorkflowError
from .metrics import DetectionMetrics


class Optimizer:
    """AdamW (default) or SGD with momentum; weight decay applies to weights, not biases / BatchNorm."""

    def __init__(self, params: Dict[str, Tensor], kind: str = "adamw", weight_decay: float = 5e-4):
        if kind not in ("adamw", "sgd"):
            raise WorkflowError(f"unknown optimizer {kind!r}.", "Workflow ships 'adamw' and 'sgd'.", "use optimizer='adamw' or optimizer='sgd'.")
        self.kind, self.wd, self.t = kind, weight_decay, 0
        self.params = params
        self.m = {k: Tensor.zeros(p.shape, p.dev) for k, p in params.items()}
        self.v = {k: Tensor.zeros(p.shape, p.dev) for k, p in params.items()} if kind == "adamw" else {}

    def step(self, lr: float) -> None:
        self.t += 1
        for k, p in self.params.items():
            g, p.grad = p.grad, None
            if g is None:
                continue
            wd = self.wd if len(p.shape) > 1 else 0.0
            if self.kind == "adamw":
                p.dev.be.adamw(p, g, self.m[k], self.v[k], lr, 0.9, 0.999, 1e-8, wd, self.t)
            else:
                p.dev.be.sgd(p, g, self.m[k], lr, 0.937, wd)

    def load(self, m, v, step) -> bool:
        if set(m) != set(self.m) or any(tuple(m[k].shape) != tuple(self.m[k].shape) for k in m):
            return False
        for k in m:
            self.m[k] = m[k].to(self.params[k].dev)
            if k in v and k in self.v:
                self.v[k] = v[k].to(self.params[k].dev)
        self.t = step
        return True


def clip_gradients(params: Dict[str, Tensor], max_norm: float) -> float:
    total = math.sqrt(sum(p.dev.be.sumsq(p.grad) for p in params.values() if p.grad is not None))
    if total > max_norm:
        for p in params.values():
            if p.grad is not None:
                p.dev.be.scale(p.grad, max_norm / total)
    return total


class EMA:
    """Exponential moving average of all model state, with a ramped decay so short runs aren't held back."""

    def __init__(self, state: Dict[str, Tensor], params, decay=0.9999, tau=2000, updates=0):
        self.decay, self.tau, self.updates, self.trainable = decay, tau, updates, set(params)
        self.shadow = {k: t.clone() for k, t in state.items()}

    def update(self, state: Dict[str, Tensor]) -> None:
        self.updates += 1
        d = self.decay * (1 - math.exp(-self.updates / self.tau))
        for k, t in state.items():
            t.dev.be.ema(self.shadow[k], t, d if k in self.trainable else 0.0)     # buffers are copied


def split_targets(targets: List[float], n: int) -> List[List[List[float]]]:
    """Flat rows [image, class, x1, y1, x2, y2] → per image [[class, x1, y1, x2, y2], ...]."""
    out = [[] for _ in range(n)]
    for i in range(0, len(targets), 6):
        out[int(targets[i])].append(targets[i + 1:i + 6])
    return out


def run_eval(model, batches, size, names, conf=0.001, iou=0.6, progress=None, loss_weights=None):
    """Evaluate on batches of (images, targets). Returns (metrics, milliseconds per image). Never changes weights.
    ``progress`` is an optional (panel, row) to advance per batch. With ``loss_weights`` the metrics also hold the
    validation loss (``loss``, ``box``, ``obj``, ``cls``), computed exactly like the training loss."""
    metrics = DetectionMetrics(model.head().classes, names)
    t_total, n_img = 0.0, 0
    loss_sum, parts_sum, n_batches = 0.0, {"box": 0.0, "obj": 0.0, "cls": 0.0}, 0
    with no_grad():
        for x, targets in batches:
            if progress is not None:
                panel, row = progress
                row.n, row.status = n_img, "running"
                row.label = f"image {n_img:,}/{row.total:,}"
                panel.refresh()
            t0 = time.perf_counter()
            outs = model(x, train=False)
            dets = detect.decode(outs, size, conf, iou)
            t_total += time.perf_counter() - t0
            n_img += x.shape[0]
            for d, g in zip(dets, split_targets(targets, x.shape[0])):
                metrics.update(d, g)
            if loss_weights is not None:
                total, parts = detect.loss(outs, targets, size, loss_weights)
                for o in outs:
                    o.grad = None
                loss_sum += total
                n_batches += 1
                for k in parts_sum:
                    parts_sum[k] += parts[k]
    result = metrics.compute()
    if loss_weights is not None and n_batches:
        result["loss"] = loss_sum / n_batches
        result.update({k: v / n_batches for k, v in parts_sum.items()})
    return result, 1000 * t_total / max(1, n_img)


def fit(model, train, validation, epochs, batch_size, lr, device, img_size, optimizer, patience, save_every,
        output, quantization, augment, ema, loss_weights, quiet):
    ds = data.as_dataset(train)
    if hasattr(ds, "splits"):                       # a whole Felix dataset: use its own splits
        val_ds = validation if validation is not None else (ds.val if len(ds.val) else None)
        ds = ds.train
    else:
        val_ds = validation
    if val_ds is not None:
        val_ds = data.as_dataset(val_ds)
    if len(ds) == 0:
        raise DataError("the training split is empty.", "there are no image/annotation pairs to learn from.",
                        "pass a dataset with images (Felix datasets under 10 pairs have no automatic splits).")
    head = model.head()
    names = ds.classes or model.class_names or [str(i) for i in range(head.classes)]
    if len(names) != head.classes:
        raise DataError("the dataset and the model disagree on the number of classes.",
                        f"the dataset has {len(names)} classes ({', '.join(names[:6])}{'…' if len(names) > 6 else ''}) "
                        f"but the model ends with wf.head(classes={head.classes}).",
                        f"build the model with wf.head(classes={len(names)}).")
    model.class_names = list(names)
    if device is not None:
        model.device(device)
    elif not model._device_chosen:
        model.device("auto")
    dev = model.device()
    size = (img_size, img_size) if isinstance(img_size, int) else tuple(img_size) if img_size else (model.input[1], model.input[2])
    model.check((model.input[0], *size))
    if quantization is not None:
        quantization.attach(model)

    tb = data.Batches(ds, size, batch_size, dev, shuffle=True, augment=augment, drop_last=len(ds) >= batch_size)
    vb = data.Batches(val_ds, size, batch_size, dev) if val_ds is not None and len(val_ds) else None
    nb = len(tb)
    params = {k: t for k, t in model.state().items() if t.rg}
    opt = Optimizer(params, optimizer)
    st = model._train_state or {}
    start = int(st.get("epoch", 0))
    if epochs <= start:
        if not quiet:
            print(f"note: this model is already trained to epoch {start} (target {epochs}); nothing to do. "
                  f"Pass a larger epochs= to continue.")
        return model.history
    inference_state = dict(model.state())
    if st.get("raw"):                                # continue from the raw weights; the loaded ones are the EMA
        model.load_state({k: v for k, v in st["raw"].items()}, source="training state")
        params = {k: t for k, t in model.state().items() if t.rg}
        opt = Optimizer(params, optimizer)
    if st.get("m") and not opt.load(st["m"], st.get("v", {}), int(st.get("step", 0))) and not quiet:
        print("note: the saved optimizer state does not fit this model; starting a fresh optimizer")
    ema_m = None
    if ema:
        ema_m = EMA(model.state(), params, updates=int(st.get("ema_updates", 0)))
        if st.get("raw"):
            ema_m.shadow = {k: inference_state[k].to(dev).clone() for k in ema_m.shadow}

    best_fit, best_epoch = st.get("best_fitness") if st.get("best_fitness") is not None else float("-inf"), int(st.get("best_epoch") or start)
    os.makedirs(output, exist_ok=True)
    config = {"lr": lr, "batch_size": batch_size, "img_size": list(size), "optimizer": optimizer, "ema": bool(ema),
              "augment": bool(augment), "schedule": "warmup+cosine", "device": str(dev),
              "quantization": quantization.describe() if quantization is not None else None}
    history = model.history
    warm = min(max(100, 3 * nb), max(1, epochs * nb // 2))
    gstep = start * nb

    def checkpoint(epoch, is_best):
        weights = ema_m.shadow if ema_m else model.state()
        extra = {f"opt.m.{k}": v for k, v in opt.m.items()}
        extra.update({f"opt.v.{k}": v for k, v in opt.v.items()})
        if ema_m:
            extra.update({f"raw.{k}": v for k, v in model.state().items()})
        meta = {"epoch": epoch, "epochs": epochs, "best_fitness": best_fit if best_fit > float("-inf") else None,
                "best_epoch": best_epoch, "history": list(history), "config": config, "step": opt.t,
                "ema_updates": ema_m.updates if ema_m else 0}
        paths = [os.path.join(output, "last.nbm")] + ([os.path.join(output, "best.nbm")] if is_best else [])
        if save_every and epoch % save_every == 0:
            paths.append(os.path.join(output, f"epoch_{epoch}.nbm"))
        for p in paths:
            nbm.save(model, p, weights=weights, train=extra, classes=model.class_names, detection=model.detection_config(),
                     training=meta, precision=model.precision, quantization=model.quant.meta(model) if model.quant else None)

    panel = _ui.Panel("", quiet=quiet)
    panel.title = panel.join("Workflow train", f"{len(ds):,} train" + (f" / {len(val_ds):,} val" if vb else ""), str(dev))
    panel.sub = panel.join("Trainer running", f"epochs {start + 1}→{epochs}", f"batch {batch_size}", f"img {size[1]}",
                           quantization.describe() if quantization is not None else "fp32")
    row = panel.row("train", epochs * nb)
    row.n = start * nb
    panel.log_header = ("epoch   train loss   val loss   mAP50   mAP50-95" if vb is not None else "epoch   train loss")

    def log_epoch(r, best):
        line = f"{r['epoch']:>5}   {r['loss']:>10.3f}"
        if "val_loss" in r:
            line += f"   {r['val_loss']:>8.3f}   {r['map50']:>5.3f}   {r['map50_95']:>8.3f}"
        panel.log.append((line + ("  ← best" if best else ""), best))

    for past in model.history:                     # continuing: show the epochs already trained
        log_epoch(past, False)
    completed, interrupted, rec = start, False, None
    try:
        with panel:
            for epoch in range(start, epochs):
                t0, sums, seen, lr_t = time.time(), {"loss": 0.0, "box": 0.0, "obj": 0.0, "cls": 0.0}, 0, lr
                for it, (x, targets) in enumerate(tb):
                    prog = (epoch + it / nb) / epochs
                    lr_t = lr * (0.01 + 0.99 * (1 + math.cos(math.pi * prog)) / 2) * min(1.0, (gstep + 1) / warm)
                    clear_tape()
                    outs = model(x, train=True)
                    total, parts = detect.loss(outs, targets, size, loss_weights)
                    if not math.isfinite(total):
                        raise WorkflowError("training stopped: the loss became NaN or infinite.",
                                            "the weights diverged, usually from a learning rate that is too high or broken boxes in the dataset.",
                                            f"lower lr (currently {lr}), and check the dataset with `felix info`.")
                    backward()
                    clip_gradients(params, 10.0)
                    opt.step(lr_t)
                    if ema_m:
                        ema_m.update(model.state())
                    gstep += 1
                    seen += 1
                    sums["loss"] += total
                    for k in parts:
                        sums[k] += parts[k]
                    row.n, row.status = gstep, "running"
                    row.label = f"epoch {epoch + 1}/{epochs} · step {it + 1}/{nb}" if panel.uni else f"epoch {epoch + 1}/{epochs}"
                    row.stats = panel.join(f"loss {sums['loss'] / seen:.3f}", f"box {sums['box'] / seen:.3f}",
                                           f"obj {sums['obj'] / seen:.3f}", f"cls {sums['cls'] / seen:.3f}", f"lr {lr_t:.1e}")
                    panel.refresh()
                rec = {"epoch": epoch + 1, "lr": lr_t, "seconds": time.time() - t0, **{k: v / max(1, seen) for k, v in sums.items()}}
                fitness = -rec["loss"]
                if vb is not None:
                    live = model.swap_state(ema_m.shadow) if ema_m else None
                    m, _ = run_eval(model, vb, size, names, loss_weights=loss_weights)
                    if ema_m:
                        model.swap_state(live)
                    rec.update({k: m[k] for k in ("map50", "map50_95", "precision", "recall", "f1")})
                    rec.update({"val_loss": m["loss"], "val_box": m["box"], "val_obj": m["obj"], "val_cls": m["cls"]})
                    fitness = 0.1 * m["map50"] + 0.9 * m["map50_95"]
                rec["fitness"] = fitness
                history.append(rec)
                completed = epoch + 1
                is_best = fitness >= best_fit
                if is_best:
                    best_fit, best_epoch = fitness, completed
                    panel.log = [(t.replace("  ← best", ""), False) for t, _ in panel.log]
                log_epoch(rec, is_best)
                checkpoint(completed, is_best)
                row.foot = panel.join(
                    f"val loss {rec['val_loss']:.3f} · mAP50 {rec['map50']:.3f} · mAP50-95 {rec['map50_95']:.3f}"
                    if "map50" in rec else "no validation data", f"best epoch {best_epoch}",
                    f"{len(ds) / max(1e-9, rec['seconds']):,.0f} img/s", f"saved → {output}")
                if patience is not None and completed - best_epoch >= patience:
                    panel.note(f"early stopping: no improvement for {patience} epochs (best was epoch {best_epoch}).")
                    break
            row.done()
    except KeyboardInterrupt:
        interrupted = True
        clear_tape()
    if interrupted:
        checkpoint(completed, False)
        print(f"\ninterrupted: model state saved to {os.path.join(output, 'last.nbm')} (epoch {completed})")
    model._train_state = {"epoch": completed, "epochs": epochs, "best_fitness": best_fit if best_fit > float("-inf") else None,
                          "best_epoch": best_epoch, "config": config, "step": opt.t, "m": opt.m, "v": opt.v,
                          "ema_updates": ema_m.updates if ema_m else 0,
                          "raw": {k: t.clone() for k, t in model.state().items()} if ema_m else None}
    if ema_m:
        model.swap_state(ema_m.shadow)              # the model now holds the averaged (inference) weights
    return history
