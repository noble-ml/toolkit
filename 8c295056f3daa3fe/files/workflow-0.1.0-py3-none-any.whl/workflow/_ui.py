"""Noir console UI built on rich: bone-white on black, one blood-red accent.

(Same look as Felix; kept as a copy so Workflow has no hard dependency on Felix internals.)
"""
from __future__ import annotations

import sys
import time

from rich.console import Console, Group
from rich.live import Live
from rich.text import Text

BONE, ASH, SOOT, BLOOD = "#d9d4c7", "#8a8a8a", "#3d3d3d", "#c1121f"
_BAR = 24


def fmt_dur(s: float) -> str:
    if s < 60:
        return f"{s:.0f}s"
    if s < 3600:
        return f"{s / 60:.0f} min"
    return f"{s / 3600:.1f} h"


def fmt_n(n) -> str:
    return f"{int(n):,}"


def console(stream=None, stderr=False) -> Console:
    return Console(file=stream, stderr=stderr, highlight=False, emoji=False, markup=False)


def _line(*parts):
    t = Text(no_wrap=True, overflow="ellipsis")
    for text, style in parts:
        t.append(text, style=style)
    return t


def error(msg: str):
    console(stderr=True).print(_line(("workflow ", f"bold {BONE}"), ("error  ", BLOOD), (msg, BONE)))


def banner(version: str, commands):
    c = console()
    c.print()
    c.print(_line(("workflow ", f"bold {BONE}"), (version, ASH)))
    c.print()
    for name, desc in commands:
        c.print(_line((f"  {name:<9}", BONE), (desc, ASH)))
    c.print()


def table(headers, rows, right=(), console_=None):
    """Borderless table: dim header, bone first column. ``right`` = indexes of right-aligned columns."""
    c = console_ or console()
    cols = list(zip(headers, *rows)) if rows else [(h,) for h in headers]
    widths = [max(len(str(x)) for x in col) for col in cols]
    def cell(v, i, w, style):
        t = str(v)
        return ((t.rjust(w) if i in right else t.ljust(w)) + "  ", style)
    c.print(_line(*[cell(h, i, w, ASH) for i, (h, w) in enumerate(zip(headers, widths))]))
    for r in rows:
        c.print(_line(*[cell(v, i, w, BONE if i < 2 else ASH) for i, (v, w) in enumerate(zip(r, widths))]))


class Row:
    def __init__(self, panel, name, total):
        self.panel, self.name, self.total = panel, name, max(0, int(total))
        self.n, self.status, self.label, self.stats, self.foot = 0, "queued", "", "", ""

    def advance(self, n=1):
        self.n += n
        self.status = "running"
        self.panel.refresh()

    def done(self):
        self.n, self.status = self.total, "done"


class Panel:
    def __init__(self, title, sub="", stream=None, quiet=False):
        self.console = console(stream)
        self.uni = not self.console.options.ascii_only
        self.title, self.sub, self.rows, self.notes, self.quiet = title, sub, [], [], quiet
        self._live, self._last, self._t0 = None, 0.0, time.time()

    # -- helpers used by callers
    @property
    def sep(self):
        return " · " if self.uni else " | "

    def join(self, *parts):
        return self.sep.join(p for p in parts if p)

    def row(self, name, total):
        r = Row(self, name, total)
        self.rows.append(r)
        return r

    def note(self, text):
        self.notes.append(text)

    @property
    def elapsed(self):
        return time.time() - self._t0

    def table(self, headers, rows):
        """Borderless noir table printed under the panel."""
        widths = [max(len(str(x)) for x in col) for col in zip(headers, *rows)]
        self.console.print()
        self.console.print(_line(*[(str(h).ljust(w) + "  ", ASH) for h, w in zip(headers, widths)]))
        for r in rows:
            self.console.print(_line(*[(str(v).ljust(w) + "  ", BONE if i == 1 else ASH)
                                       for i, (v, w) in enumerate(zip(r, widths))]))

    # -- rendering
    def _render(self):
        parts = self.title.split(self.sep)
        out = [_line((parts[0], f"bold {BONE}"), *[(self.sep + p, ASH) for p in parts[1:]])]
        if self.sub:
            out.append(_line((self.sub, ASH)))
        for n in self.notes:
            out.append(_line(("note ", BLOOD), (n, BONE)))
        if self.rows:
            out.append(Text(""))
        w = max([len(r.name) for r in self.rows] or [0])
        full, empty = ("━", "─") if self.uni else ("=", "-")
        for r in self.rows:
            head = r.name.ljust(w) + "  "
            if r.status == "queued":
                out.append(_line((head, BONE), (r.label or "waiting", ASH)))
                continue
            pct = r.n / r.total if r.total else 1.0
            k = int(round(min(1.0, pct) * _BAR))
            bar = BLOOD if r.status == "failed" else BONE
            out.append(_line((head, BONE), (full * k, bar), (empty * (_BAR - k), SOOT),
                             (f"  {pct * 100:5.1f}%", BONE),
                             (("  " + r.label) if r.label else "", ASH),
                             (f"  {r.status}", BLOOD if r.status in ("failed", "running") else ASH)))
            detail = self.join(r.stats, r.foot)
            if detail:
                out.append(_line((" " * len(head) + detail, ASH)))
        return Group(*out)

    def refresh(self, force=False):
        if self._live is None:
            return
        now = time.time()
        if force or now - self._last >= 0.1:
            self._last = now
            self._live.update(self._render(), refresh=True)

    def __enter__(self):
        if not self.quiet and self.console.is_terminal:
            self._live = Live(self._render(), console=self.console, auto_refresh=False,
                              vertical_overflow="visible")
            self._live.start()
        return self

    def __exit__(self, et, ev, tb):
        if et:
            for r in self.rows:
                if r.status != "done":
                    r.status = "failed"
        if self.quiet:
            return False
        if self._live is not None:
            self._live.update(self._render(), refresh=True)
            self._live.stop()
            self._live = None
        else:  # piped / CI: print the final frame once
            self.console.print(self._render())
        return False
