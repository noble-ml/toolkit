"""Image preprocessing (letterbox), batched inference and result assembly."""
from __future__ import annotations

import os
from typing import List, Sequence, Tuple, Union

import torch

from ..errors import WorkflowError
from . import decoder
from .results import Results


def to_pil(src):
    from PIL import Image
    if isinstance(src, (str, os.PathLike)):
        try:
            return Image.open(src).convert("RGB"), os.fspath(src)
        except FileNotFoundError:
            raise WorkflowError(f"image not found: {os.fspath(src)!r}") from None
    if isinstance(src, Image.Image):
        return src.convert("RGB"), None
    if isinstance(src, torch.Tensor):
        t = src.detach().cpu()
        if t.dim() == 3 and t.shape[0] in (1, 3):
            t = t.permute(1, 2, 0)
        if t.dtype != torch.uint8:
            t = (t.float().clamp(0, 1) * 255).round().to(torch.uint8)
        return Image.fromarray(t.numpy()).convert("RGB"), None
    if hasattr(src, "shape") and hasattr(src, "dtype"):  # numpy array, HxWx3 RGB (convert BGR frames first)
        return Image.fromarray(src).convert("RGB"), None
    raise WorkflowError(f"cannot read an image from {type(src).__name__}; pass a path, PIL image, "
                        "RGB numpy array or tensor")


def letterbox(img, size: Tuple[int, int], fill: int = 114):
    """Resize keeping aspect ratio and pad to ``size`` = (H, W). Returns (image, scale, (pad_x, pad_y))."""
    from PIL import Image
    th, tw = size
    w, h = img.size
    s = min(tw / w, th / h)
    nw, nh = max(1, round(w * s)), max(1, round(h * s))
    px, py = (tw - nw) // 2, (th - nh) // 2
    canvas = Image.new("RGB", (tw, th), (fill, fill, fill))
    canvas.paste(img.resize((nw, nh), Image.BILINEAR), (px, py))
    return canvas, s, (px, py)


def to_tensor(img) -> torch.Tensor:
    """PIL RGB → uint8 (3, H, W) tensor without needing numpy."""
    w, h = img.size
    return torch.frombuffer(bytearray(img.tobytes()), dtype=torch.uint8).view(h, w, 3).permute(2, 0, 1)


@torch.inference_mode()
def predict(model, source, conf=0.25, iou=0.45, imgsz=None, max_det=300, half=None, batch_size=16):
    single = not isinstance(source, (list, tuple))
    sources = [source] if single else list(source)
    if not sources:
        return []
    if imgsz is None:
        size = (model.input[1], model.input[2])
    else:
        size = (imgsz, imgsz) if isinstance(imgsz, int) else tuple(imgsz)
    model.shapes(input=(model.input[0], *size))  # clear ShapeError if this size doesn't fit the architecture
    dev = model.device()
    half = dev.type == "cuda" if half is None else half
    was_training = model.training
    model.eval()
    out: List[Results] = []
    try:
        for i in range(0, len(sources), batch_size):
            chunk = [to_pil(s) for s in sources[i:i + batch_size]]
            boxed = [letterbox(im, size) for im, _ in chunk]
            x = torch.stack([to_tensor(b[0]) for b in boxed]).to(dev).float() / 255
            with torch.autocast(dev.type, dtype=torch.float16, enabled=bool(half) and dev.type == "cuda"):
                raw = model(x)
            boxes, obj, cls = decoder.decode(model.detections(raw), size)
            dets = decoder.postprocess(boxes, obj, cls, conf, iou, max_det)
            for (im, path), (_, s, (px, py)), d in zip(chunk, boxed, dets):
                d = d.clone()
                d[:, [0, 2]] = ((d[:, [0, 2]] - px) / s).clamp(0, im.width)
                d[:, [1, 3]] = ((d[:, [1, 3]] - py) / s).clamp(0, im.height)
                out.append(Results(im, d, model.class_names, path))
    finally:
        model.train(was_training)
    return out[0] if single else out
