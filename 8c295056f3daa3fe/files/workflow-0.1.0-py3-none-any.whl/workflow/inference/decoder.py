"""Turning raw head outputs into boxes: grids, decoding and non-maximum suppression."""
from __future__ import annotations

from typing import List, Sequence, Tuple

import torch
import torch.nn.functional as F


def box_iou(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Pairwise IoU of (N,4) and (M,4) xyxy boxes → (N,M)."""
    area_a = (a[:, 2] - a[:, 0]).clamp(min=0) * (a[:, 3] - a[:, 1]).clamp(min=0)
    area_b = (b[:, 2] - b[:, 0]).clamp(min=0) * (b[:, 3] - b[:, 1]).clamp(min=0)
    lt = torch.max(a[:, None, :2], b[None, :, :2])
    rb = torch.min(a[:, None, 2:], b[None, :, 2:])
    wh = (rb - lt).clamp(min=0)
    inter = wh[..., 0] * wh[..., 1]
    return inter / (area_a[:, None] + area_b[None] - inter).clamp(min=1e-9)


def grid(shapes: Sequence[Tuple[int, int]], img_hw: Tuple[int, int], device) -> Tuple[torch.Tensor, ...]:
    """Cell centres, strides and level index for every prediction cell: (cx, cy, sx, sy, level)."""
    H, W = img_hw
    cx, cy, sx, sy, lv = [], [], [], [], []
    for i, (h, w) in enumerate(shapes):
        ys, xs = torch.meshgrid(torch.arange(h, device=device), torch.arange(w, device=device), indexing="ij")
        cx.append((xs.reshape(-1).float() + 0.5) * (W / w))
        cy.append((ys.reshape(-1).float() + 0.5) * (H / h))
        sx.append(torch.full((h * w,), W / w, device=device))
        sy.append(torch.full((h * w,), H / h, device=device))
        lv.append(torch.full((h * w,), i, device=device, dtype=torch.long))
    return tuple(torch.cat(t) for t in (cx, cy, sx, sy, lv))


def flatten(outputs: Sequence[torch.Tensor]) -> torch.Tensor:
    """List of (N, 5+C, h, w) level maps → (N, A, 5+C) float32."""
    return torch.cat([o.float().flatten(2).transpose(1, 2) for o in outputs], dim=1)


def decode(outputs: Sequence[torch.Tensor], img_hw: Tuple[int, int]):
    """Raw level maps → (boxes xyxy in pixels (N,A,4), confidence logits (N,A), class logits (N,A,C))."""
    p = flatten(outputs)
    cx, cy, sx, sy, _ = grid([(o.shape[-2], o.shape[-1]) for o in outputs], img_hw, p.device)
    d = F.softplus(p[..., :4])
    boxes = torch.stack([cx - d[..., 0] * sx, cy - d[..., 1] * sy, cx + d[..., 2] * sx, cy + d[..., 3] * sy], dim=-1)
    return boxes, p[..., 4], p[..., 5:]


def nms(boxes: torch.Tensor, scores: torch.Tensor, iou_thr: float) -> torch.Tensor:
    """Greedy non-maximum suppression; returns indices of kept boxes (highest score first)."""
    n = boxes.shape[0]
    if n == 0:
        return torch.empty(0, dtype=torch.long, device=boxes.device)
    order = scores.argsort(descending=True)
    b = boxes[order].float().cpu()
    iou = box_iou(b, b)
    gone = torch.zeros(n, dtype=torch.bool)
    keep: List[int] = []
    for i in range(n):
        if gone[i]:
            continue
        keep.append(i)
        gone |= iou[i] > iou_thr
    return order[torch.tensor(keep, device=order.device)]


def postprocess(boxes, obj_logits, cls_logits, conf: float = 0.25, iou: float = 0.45,
                max_det: int = 300, max_nms: int = 1000) -> List[torch.Tensor]:
    """Per image: score = confidence × class probability, threshold, class-aware NMS.

    Returns a list of (K, 6) tensors ``[x1, y1, x2, y2, score, class]``.
    """
    scores = obj_logits.sigmoid()[..., None] * cls_logits.sigmoid()
    out = []
    for b in range(boxes.shape[0]):
        s, c = scores[b].max(1)
        keep = s > conf
        bx, s, c = boxes[b][keep], s[keep], c[keep]
        if s.numel() > max_nms:
            top = s.topk(max_nms).indices
            bx, s, c = bx[top], s[top], c[top]
        if s.numel():
            offset = c.float()[:, None] * (bx.max() + 1)      # separate classes so NMS is class-aware
            idx = nms(bx + offset, s, iou)[:max_det]
            out.append(torch.cat([bx[idx], s[idx, None], c[idx, None].float()], dim=1))
        else:
            out.append(torch.zeros(0, 6, device=boxes.device))
    return out
