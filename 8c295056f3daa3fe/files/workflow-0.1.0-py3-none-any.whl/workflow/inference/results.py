from __future__ import annotations

import os
from typing import Dict, Iterator, List, Optional, Sequence

import torch

from ..errors import WorkflowError

_PALETTE = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#46c8c8",
            "#f032e6", "#9acd32", "#008080", "#9a6324", "#800000", "#808000"]


class Results:
    """Detections for one image.

    ``xyxy`` (N, 4) pixel boxes in the original image, ``confidences`` (N,), ``class_ids`` (N,) ints
    and ``classes`` (list of N class names, or the ids as strings if the model has no names).
    """

    def __init__(self, image, detections: torch.Tensor, names: Optional[Sequence[str]] = None,
                 path: Optional[str] = None):
        self.image, self.path = image, path
        self.names = list(names) if names else None
        d = detections.detach().cpu()
        self.xyxy = d[:, :4].clone()
        self.confidences = d[:, 4].clone()
        self.class_ids = d[:, 5].long()

    @property
    def classes(self) -> List[str]:
        return [self._name(i) for i in self.class_ids.tolist()]

    @property
    def xywh(self) -> torch.Tensor:
        b = self.xyxy
        return torch.stack([b[:, 0], b[:, 1], b[:, 2] - b[:, 0], b[:, 3] - b[:, 1]], dim=1)

    def _name(self, i: int) -> str:
        return self.names[i] if self.names and i < len(self.names) else str(i)

    def __len__(self) -> int:
        return self.xyxy.shape[0]

    def __iter__(self) -> Iterator[Dict]:
        for b, c, k in zip(self.xyxy.tolist(), self.confidences.tolist(), self.class_ids.tolist()):
            yield {"xyxy": b, "confidence": c, "class_id": k, "class": self._name(k)}

    def to_dict(self) -> List[Dict]:
        return list(self)

    def __repr__(self) -> str:
        counts: Dict[str, int] = {}
        for c in self.classes:
            counts[c] = counts.get(c, 0) + 1
        what = ", ".join(f"{n} {k}" for k, n in counts.items()) or "nothing"
        return f"Results({len(self)} detections: {what})"

    # ------------------------------------------------------------------ drawing
    def plot(self):
        """The image with boxes and labels drawn (a PIL image)."""
        from PIL import ImageDraw, ImageFont
        im = self.image.convert("RGB").copy()
        d = ImageDraw.Draw(im)
        lw = max(2, round(min(im.size) / 200))
        size = max(11, round(min(im.size) / 40))
        try:
            font = ImageFont.load_default(size)
        except TypeError:
            font = ImageFont.load_default()
        for b, c, k in zip(self.xyxy.tolist(), self.confidences.tolist(), self.class_ids.tolist()):
            col = _PALETTE[k % len(_PALETTE)]
            d.rectangle(b, outline=col, width=lw)
            text = f"{self._name(k)} {c:.2f}"
            tb = d.textbbox((0, 0), text, font=font)
            tw, th = tb[2] - tb[0] + 6, tb[3] - tb[1] + 6
            y0 = b[1] - th if b[1] - th >= 0 else b[1]
            d.rectangle([b[0], y0, b[0] + tw, y0 + th], fill=col)
            d.text((b[0] + 3, y0 + 2 - tb[1]), text, fill="white", font=font)
        return im

    def show(self) -> None:
        self.plot().show()

    def save(self, path) -> str:
        path = os.fspath(path)
        if not path.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".webp")):
            raise WorkflowError(f"cannot save an image as {os.path.splitext(path)[1] or path!r}; use .png or .jpg")
        self.plot().save(path)
        return path
