"""Detection metrics: mAP50, mAP50-95, precision, recall, F1, per-class AP, confusion matrix."""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

import torch

from ..inference.decoder import box_iou

IOU_THRS = torch.linspace(0.5, 0.95, 10)


def _match(iou: torch.Tensor, thr: float) -> List[tuple]:
    """Greedy one-to-one matching of (G, K) IoUs above ``thr``, best first. Returns [(gt, pred)]."""
    gi, pi = (iou >= thr).nonzero(as_tuple=True)
    if gi.numel() == 0:
        return []
    order = iou[gi, pi].argsort(descending=True)
    used_g, used_p, out = set(), set(), []
    for g, p in zip(gi[order].tolist(), pi[order].tolist()):
        if g not in used_g and p not in used_p:
            used_g.add(g); used_p.add(p); out.append((g, p))
    return out


def _ap(recall: torch.Tensor, precision: torch.Tensor) -> float:
    """COCO-style 101-point interpolated average precision."""
    mrec = torch.cat([torch.zeros(1), recall, torch.ones(1)])
    mpre = torch.cat([torch.ones(1), precision, torch.zeros(1)])
    mpre = torch.flip(torch.cummax(torch.flip(mpre, [0]), 0).values, [0])
    x = torch.linspace(0, 1, 101)
    idx = torch.searchsorted(mrec, x)
    return mpre[idx.clamp(max=len(mpre) - 1)].mean().item()


class DetectionMetrics:
    """Accumulate per-image predictions and ground truth, then ``compute()``.

    Predictions are (K, 6) ``[x1, y1, x2, y2, score, class]``; ground truth (G, 5) ``[class, x1, y1, x2, y2]``.
    """

    def __init__(self, num_classes: int, names: Optional[Sequence[str]] = None):
        self.nc = num_classes
        self.names = list(names) if names else [str(i) for i in range(num_classes)]
        self.tp: List[torch.Tensor] = []
        self.conf: List[torch.Tensor] = []
        self.pcls: List[torch.Tensor] = []
        self.tcls: List[torch.Tensor] = []
        self.confusion = torch.zeros(num_classes + 1, num_classes + 1)

    def update(self, pred: torch.Tensor, gt: torch.Tensor) -> None:
        pred, gt = pred.detach().cpu().float(), gt.detach().cpu().float()
        self.tcls.append(gt[:, 0].long())
        K = pred.shape[0]
        tp = torch.zeros(K, len(IOU_THRS), dtype=torch.bool)
        if K:
            self.conf.append(pred[:, 4])
            self.pcls.append(pred[:, 5].long())
            if gt.shape[0]:
                iou = box_iou(gt[:, 1:5], pred[:, :4]) * (gt[:, 0][:, None] == pred[:, 5][None])
                for t, thr in enumerate(IOU_THRS.tolist()):
                    for _, p in _match(iou, thr):
                        tp[p, t] = True
            self.tp.append(tp)
        self._confusion(pred, gt)

    def _confusion(self, pred, gt, conf=0.25, iou_thr=0.45):
        det = pred[pred[:, 4] > conf] if pred.shape[0] else pred
        matched_g, matched_p = set(), set()
        if gt.shape[0] and det.shape[0]:
            iou = box_iou(gt[:, 1:5], det[:, :4])
            for g, p in _match(iou, iou_thr):
                self.confusion[int(det[p, 5]), int(gt[g, 0])] += 1
                matched_g.add(g); matched_p.add(p)
        for p in range(det.shape[0]):
            if p not in matched_p:
                self.confusion[int(det[p, 5]), self.nc] += 1      # false positive on background
        for g in range(gt.shape[0]):
            if g not in matched_g:
                self.confusion[self.nc, int(gt[g, 0])] += 1       # missed object

    def compute(self) -> Dict:
        tcls = torch.cat(self.tcls) if self.tcls else torch.zeros(0, dtype=torch.long)
        n_gt = torch.bincount(tcls, minlength=self.nc)
        zero = {"precision": 0.0, "recall": 0.0, "f1": 0.0, "map50": 0.0, "map50_95": 0.0, "conf": 0.0,
                "per_class": {n: {"ap50": 0.0, "ap50_95": 0.0, "instances": int(n_gt[i])} for i, n in enumerate(self.names)},
                "confusion_matrix": self.confusion.clone()}
        if not self.conf:
            return zero
        tp, conf, pcls = torch.cat(self.tp), torch.cat(self.conf), torch.cat(self.pcls)
        order = conf.argsort(descending=True)
        tp, conf, pcls = tp[order], conf[order], pcls[order]
        ap = torch.zeros(self.nc, len(IOU_THRS))
        px = torch.linspace(0, 1, 1000)
        P = torch.zeros(self.nc, 1000)
        R = torch.zeros(self.nc, 1000)
        for c in range(self.nc):
            m = pcls == c
            if n_gt[c] == 0 or not m.any():
                continue
            tpc = tp[m].float().cumsum(0)
            fpc = (~tp[m]).float().cumsum(0)
            recall = tpc / n_gt[c]
            precision = tpc / (tpc + fpc)
            for t in range(len(IOU_THRS)):
                ap[c, t] = _ap(recall[:, t], precision[:, t])
            cs = conf[m]                                    # descending; interpolate at thresholds px
            idx = torch.searchsorted(-cs, -px, right=True).clamp(max=len(cs)) - 1
            valid = idx >= 0
            R[c][valid] = recall[idx[valid], 0]
            P[c][valid] = precision[idx[valid], 0]
        present = n_gt > 0
        f1 = 2 * P * R / (P + R + 1e-16)
        best = f1[present].mean(0).argmax().item() if present.any() else 0
        per = {n: {"ap50": ap[i, 0].item(), "ap50_95": ap[i].mean().item(), "instances": int(n_gt[i])}
               for i, n in enumerate(self.names)}
        return {"precision": P[present, best].mean().item(), "recall": R[present, best].mean().item(),
                "f1": f1[present, best].mean().item(), "conf": px[best].item(),
                "map50": ap[present, 0].mean().item(), "map50_95": ap[present].mean().item(),
                "per_class": per, "confusion_matrix": self.confusion.clone()}
