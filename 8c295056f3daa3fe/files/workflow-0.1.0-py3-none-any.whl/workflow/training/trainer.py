"""The training loop behind ``Model.train``."""
from __future__ import annotations

import math
import os
import time
from typing import Dict, List, Optional

import torch

from .. import _ui
from ..errors import WorkflowError
from ..inference import decoder
from ..serialization import nbm
from . import data
from .callbacks import Checkpointer, EarlyStopping
from .loss import detection_loss
from .metrics import DetectionMetrics


class History(list):
    """One dict per finished epoch (loss parts, learning rate, validation metrics)."""

    @property
    def last(self) -> Optional[Dict]:
        return self[-1] if self else None

    @property
    def best(self) -> Optional[Dict]:
        scored = [h for h in self if h.get("fitness") is not None]
        return max(scored, key=lambda h: h["fitness"]) if scored else None


class ModelEMA:
    """Exponential moving average of the weights (ramped decay, so short runs aren't held back)."""

    def __init__(self, model, decay=0.9999, tau=2000, updates=0, state=None):
        self.decay, self.tau, self.updates = decay, tau, updates
        src = state if state is not None else model.state_dict()
        self.shadow = {k: v.detach().clone() for k, v in src.items()}

    @torch.no_grad()
    def update(self, model):
        self.updates += 1
        d = self.decay * (1 - math.exp(-self.updates / self.tau))
        for k, v in model.state_dict().items():
            s = self.shadow[k]
            if s.dtype.is_floating_point:
                s.mul_(d).add_(v.detach(), alpha=1 - d)
            else:
                s.copy_(v)


def _cpu(sd):
    return {k: v.detach().cpu().clone() for k, v in sd.items()}


@torch.inference_mode()
def run_eval(model, loader, size, names, conf=0.001, iou=0.6, device=None):
    """Evaluate ``model`` on a loader of (images, targets). Returns (metrics dict, ms per image)."""
    dev = device or model.device()
    nc = model.head().classes
    metrics = DetectionMetrics(nc, names)
    was = model.training
    model.eval()
    t_total, n_img = 0.0, 0
    try:
        for imgs, targets in loader:
            x = imgs.to(dev).float() / 255
            t0 = time.perf_counter()
            raw = model(x)
            boxes, obj, cls = decoder.decode(model.detections(raw), size)
            dets = decoder.postprocess(boxes, obj, cls, conf, iou, 300)
            _sync(dev)
            t_total += time.perf_counter() - t0
            n_img += x.shape[0]
            for d, t in zip(dets, targets):
                metrics.update(d, t)
    finally:
        model.train(was)
    return metrics.compute(), 1000 * t_total / max(1, n_img)


def _sync(dev):
    if dev.type == "cuda":
        torch.cuda.synchronize(dev)
    elif dev.type == "mps":
        torch.mps.synchronize()


def fit(model, dataset, epochs, batch_size, save_every, lr, imgsz, device, workers, patience, save_dir,
        amp, ema, augment, val, quiet) -> History:
    ds = data.as_dataset(dataset)
    train_ds = data.split(ds, "train")
    val_ds = data.split(ds, "val") if val else None
    if len(train_ds) == 0:
        raise WorkflowError("the training split is empty")
    head = model.head()
    names = ds.classes or model.class_names or [str(i) for i in range(head.classes)]
    if len(names) != head.classes:
        raise WorkflowError(
            f"the dataset has {len(names)} classes {names} but the model's BBoxHead was built with "
            f"classes={head.classes}; rebuild the head with classes={len(names)}")
    model.class_names = list(names)
    if device is not None:
        model.device(device)
    elif not model._device_set:
        model.device("auto")
    dev = model.device()
    size = (imgsz, imgsz) if isinstance(imgsz, int) else tuple(imgsz) if imgsz else (model.input[1], model.input[2])
    model.shapes(input=(model.input[0], *size))
    use_amp = dev.type == "cuda" if amp is None else bool(amp) and dev.type == "cuda"
    if amp and dev.type != "cuda":
        print("note: mixed precision (amp) is only used on CUDA; training in fp32")

    tl = data.loader(train_ds, size, batch_size, True, augment, workers, dev)
    vl = data.loader(val_ds, size, batch_size, False, False, workers, dev) if val_ds is not None and len(val_ds) else None
    nb = len(tl)

    decay = [p for p in model.parameters() if p.ndim > 1]
    plain = [p for p in model.parameters() if p.ndim <= 1]
    opt = torch.optim.AdamW([{"params": decay, "weight_decay": 5e-4}, {"params": plain, "weight_decay": 0.0}], lr=lr)
    st = model._train_state or {}
    start = int(st.get("epoch", 0))
    inference_w = {k: v.detach().clone() for k, v in model.state_dict().items()}
    if st.get("raw") is not None:
        model.load_state_dict(st["raw"])
    if st.get("optimizer") is not None:
        try:
            opt.load_state_dict(st["optimizer"])
        except (ValueError, KeyError):
            print("note: the saved optimizer state does not fit this model; starting a fresh optimizer")
    if epochs <= start:
        print(f"note: the model was already trained to epoch {start} (target {epochs}); nothing to do")
        model.load_state_dict(inference_w)
        return model.history
    ema_m = ModelEMA(model, updates=int(st.get("ema_updates", 0)),
                     state=inference_w if st.get("raw") is not None else None) if ema else None
    scaler = None
    if use_amp:
        scaler = (torch.amp.GradScaler("cuda") if hasattr(torch.amp, "GradScaler") else torch.cuda.amp.GradScaler())

    stopper = EarlyStopping(patience)
    stopper.best = st.get("best_fitness", float("-inf"))
    stopper.best_epoch = int(st.get("best_epoch", start))
    ckpt = Checkpointer(save_dir, save_every)
    os.makedirs(save_dir, exist_ok=True)
    config = {"lr": lr, "batch_size": batch_size, "imgsz": list(size), "ema": bool(ema), "amp": use_amp,
              "augment": augment, "optimizer": "AdamW", "schedule": "warmup+cosine", "lrf": 0.01}
    history: History = model.history
    total_iters, warm = epochs * nb, min(max(100, 3 * nb), epochs * nb // 2 or 1)
    gstep = start * nb

    def save_all(epoch, is_best):
        weights = _cpu(ema_m.shadow if ema_m else model.state_dict())
        train = {"optimizer": opt.state_dict(), "ema_updates": ema_m.updates if ema_m else 0}
        if ema_m:
            train["raw"] = _cpu(model.state_dict())
        meta_train = {"epoch": epoch, "epochs": epochs, "best_fitness": stopper.best, "best_epoch": stopper.best_epoch,
                      "history": list(history), "config": config}
        for p in ckpt.paths(epoch, is_best):
            nbm.save(model, p, weights=weights, train=train, classes=model.class_names,
                     detection=model.detection_config(), training=meta_train)

    panel = _ui.Panel("", quiet=quiet)
    panel.title = panel.join("Workflow train", f"{len(train_ds):,} train" + (f" / {len(vl.dataset):,} val" if vl else ""),
                             f"{dev}")
    panel.sub = panel.join("Trainer running", f"epochs {start + 1}→{epochs}", f"batch {batch_size}",
                           f"imgsz {size[1]}", "amp" if use_amp else "fp32")
    row = panel.row("train", epochs * nb)
    row.n = start * nb
    interrupted, completed = False, start
    t_run = time.time()
    try:
        with panel:
            for epoch in range(start, epochs):
                model.train(True)
                t0, sums, seen = time.time(), {"loss": 0.0, "box": 0.0, "obj": 0.0, "cls": 0.0}, 0
                for it, (imgs, targets) in enumerate(tl):
                    prog = (epoch + it / nb) / epochs
                    lr_t = lr * (0.01 + 0.99 * (1 + math.cos(math.pi * prog)) / 2) * min(1.0, (gstep + 1) / warm)
                    for g in opt.param_groups:
                        g["lr"] = lr_t
                    x = imgs.to(dev, non_blocking=True).float() / 255
                    with torch.autocast(dev.type, dtype=torch.float16, enabled=use_amp):
                        outs = model.detections(model(x))
                    loss, parts = detection_loss(outs, targets, size)
                    if not torch.isfinite(loss):
                        raise WorkflowError("the loss became NaN/inf; lower lr= or check the dataset's boxes")
                    opt.zero_grad(set_to_none=True)
                    if scaler:
                        scaler.scale(loss).backward()
                        scaler.unscale_(opt)
                        torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
                        scaler.step(opt)
                        scaler.update()
                    else:
                        loss.backward()
                        torch.nn.utils.clip_grad_norm_(model.parameters(), 10.0)
                        opt.step()
                    if ema_m:
                        ema_m.update(model)
                    gstep += 1
                    seen += 1
                    sums["loss"] += loss.item()
                    for k in parts:
                        sums[k] += parts[k]
                    row.n, row.status = gstep, "running"
                    row.label = f"epoch {epoch + 1}/{epochs} · step {it + 1}/{nb}" if panel.uni else f"epoch {epoch + 1}/{epochs}"
                    row.stats = panel.join(f"loss {sums['loss'] / seen:.3f}", f"box {sums['box'] / seen:.3f}",
                                           f"obj {sums['obj'] / seen:.3f}", f"cls {sums['cls'] / seen:.3f}",
                                           f"lr {lr_t:.1e}")
                    panel.refresh()
                rec = {"epoch": epoch + 1, "lr": lr_t, "seconds": time.time() - t0,
                       **{k: v / max(1, seen) for k, v in sums.items()}}
                fitness = -rec["loss"]
                if vl is not None:
                    live = {k: v.detach().clone() for k, v in model.state_dict().items()} if ema_m else None
                    if ema_m:
                        model.load_state_dict(ema_m.shadow)
                    m, _ = run_eval(model, vl, size, names, device=dev)
                    if ema_m:
                        model.load_state_dict(live)
                    rec.update({"map50": m["map50"], "map50_95": m["map50_95"], "precision": m["precision"],
                                "recall": m["recall"], "f1": m["f1"]})
                    fitness = 0.1 * m["map50"] + 0.9 * m["map50_95"]
                rec["fitness"] = fitness
                history.append(rec)
                best = stopper.step(epoch + 1, fitness)
                completed = epoch + 1
                save_all(completed, best)
                ips = len(train_ds) / max(1e-9, rec["seconds"])
                row.foot = panel.join(
                    (f"val mAP50 {rec['map50']:.3f} · mAP50-95 {rec['map50_95']:.3f} · P {rec['precision']:.2f} R {rec['recall']:.2f}"
                     if "map50" in rec else "no validation split"),
                    f"best epoch {stopper.best_epoch}", f"{ips:,.0f} img/s", f"saved → {save_dir}")
                if stopper.should_stop(completed):
                    panel.note(f"early stopping: no improvement for {patience} epochs (best at epoch {stopper.best_epoch}).")
                    break
            row.done()
    except KeyboardInterrupt:
        interrupted = True
    if interrupted:
        save_all(completed, False)
        print(f"\ninterrupted: model state saved to {os.path.join(save_dir, 'last.nbm')} (epoch {completed})")
    # final state: inference weights are the EMA weights, raw weights/optimizer are kept for continuing
    model._train_state = {"epoch": completed, "epochs": epochs, "optimizer": opt.state_dict(),
                          "best_fitness": stopper.best, "best_epoch": stopper.best_epoch,
                          "ema_updates": ema_m.updates if ema_m else 0,
                          "raw": _cpu(model.state_dict()) if ema_m else None, "config": config}
    if ema_m:
        model.load_state_dict(ema_m.shadow)
    return history
