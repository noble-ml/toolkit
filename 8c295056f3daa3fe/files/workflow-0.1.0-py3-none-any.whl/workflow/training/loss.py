"""Detection loss: size-based level assignment, GIoU box loss, BCE confidence and class losses."""
from __future__ import annotations

from typing import Dict, Sequence, Tuple

import torch
import torch.nn.functional as F

from ..inference import decoder

CENTER_RADIUS = 1.5   # positive cells lie within this many strides of the object's centre
LEVEL_RANGE = 8       # level k handles objects up to LEVEL_RANGE × its stride (and above the previous level's)


def giou(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    """Elementwise generalized IoU of (K,4) xyxy boxes."""
    iw = (torch.min(a[:, 2], b[:, 2]) - torch.max(a[:, 0], b[:, 0])).clamp(min=0)
    ih = (torch.min(a[:, 3], b[:, 3]) - torch.max(a[:, 1], b[:, 1])).clamp(min=0)
    inter = iw * ih
    area_a = (a[:, 2] - a[:, 0]) * (a[:, 3] - a[:, 1])
    area_b = (b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])
    union = area_a + area_b - inter + 1e-9
    cw = torch.max(a[:, 2], b[:, 2]) - torch.min(a[:, 0], b[:, 0])
    ch = torch.max(a[:, 3], b[:, 3]) - torch.min(a[:, 1], b[:, 1])
    hull = cw * ch + 1e-9
    return inter / union - (hull - union) / hull


def assign(targets: torch.Tensor, shapes, img_hw, cx, cy, sx, sy, lvl, device):
    """Match ground truths to prediction cells for one image.

    ``targets`` (G, 5) = [class, x1, y1, x2, y2] in pixels. Returns (positive mask (A,), index of the
    matched ground truth per cell (A,)). Each object is handled by the pyramid level whose stride suits
    its size; cells near its centre (and inside it) are positive; overlaps go to the smaller object.
    """
    A, G = cx.shape[0], targets.shape[0]
    box = targets[:, 1:5]
    gw, gh = box[:, 2] - box[:, 0], box[:, 3] - box[:, 1]
    gmax = torch.max(gw, gh)
    strides = torch.tensor([img_hw[1] / w for _, w in shapes], device=device)
    hi = strides * LEVEL_RANGE
    lo = torch.cat([hi.new_zeros(1), hi[:-1]])
    big = float("inf")
    hi_a, lo_a = hi.clone(), lo
    hi_a[-1] = big
    in_range = (gmax[None] > lo_a[lvl][:, None]) & (gmax[None] <= hi_a[lvl][:, None])
    s = (sx + sy) / 2
    gcx, gcy = (box[:, 0] + box[:, 2]) / 2, (box[:, 1] + box[:, 3]) / 2
    inside = (cx[:, None] > box[:, 0]) & (cx[:, None] < box[:, 2]) & (cy[:, None] > box[:, 1]) & (cy[:, None] < box[:, 3])
    near = ((cx[:, None] - gcx).abs() < CENTER_RADIUS * s[:, None]) & ((cy[:, None] - gcy).abs() < CENTER_RADIUS * s[:, None])
    m = in_range & inside & near
    # always give each object at least its centre cell on its own level
    g_lvl = torch.searchsorted(hi[:-1].contiguous(), gmax) if len(shapes) > 1 else torch.zeros_like(gmax, dtype=torch.long)
    hs = torch.tensor([h for h, _ in shapes], device=device)
    ws = torch.tensor([w for _, w in shapes], device=device)
    offs = torch.cat([torch.zeros(1, dtype=torch.long, device=device), (hs * ws).cumsum(0)[:-1]])
    ix = (gcx / (img_hw[1] / ws[g_lvl])).long().clamp(min=0).minimum(ws[g_lvl] - 1)
    iy = (gcy / (img_hw[0] / hs[g_lvl])).long().clamp(min=0).minimum(hs[g_lvl] - 1)
    m[offs[g_lvl] + iy * ws[g_lvl] + ix, torch.arange(G, device=device)] = True
    cost = (gw * gh)[None].expand(A, G).clone()
    cost[~m] = big
    best, gi = cost.min(1)
    return torch.isfinite(best), gi


def detection_loss(outputs: Sequence[torch.Tensor], targets: Sequence[torch.Tensor], img_hw: Tuple[int, int],
                   weights=(5.0, 1.0, 1.0)) -> Tuple[torch.Tensor, Dict[str, float]]:
    """Total loss and its (box, obj, cls) parts. ``targets[i]`` is (G_i, 5) = [class, x1, y1, x2, y2]."""
    shapes = [(o.shape[-2], o.shape[-1]) for o in outputs]
    p = decoder.flatten(outputs)                       # (N, A, 5+C) float32
    dev = p.device
    cx, cy, sx, sy, lvl = decoder.grid(shapes, img_hw, dev)
    d = F.softplus(p[..., :4])
    boxes = torch.stack([cx - d[..., 0] * sx, cy - d[..., 1] * sy, cx + d[..., 2] * sx, cy + d[..., 3] * sy], -1)
    obj, cls = p[..., 4], p[..., 5:]
    N, A = obj.shape
    C = cls.shape[-1]
    pos = torch.zeros(N, A, dtype=torch.bool, device=dev)
    tbox = torch.zeros(N, A, 4, device=dev)
    tcls = torch.zeros(N, A, dtype=torch.long, device=dev)
    for b in range(N):
        t = targets[b].to(dev)
        if t.shape[0] == 0:
            continue
        pm, gi = assign(t, shapes, img_hw, cx, cy, sx, sy, lvl, dev)
        pos[b] = pm
        tbox[b][pm] = t[gi[pm], 1:5]
        tcls[b][pm] = t[gi[pm], 0].long()
    npos = pos.sum().clamp(min=1).float()
    if pos.any():
        box_loss = (1 - giou(boxes[pos], tbox[pos])).sum() / npos
        cls_loss = F.binary_cross_entropy_with_logits(cls[pos], F.one_hot(tcls[pos], C).float(), reduction="sum") / npos
    else:
        box_loss = cls_loss = obj.sum() * 0
    obj_loss = F.binary_cross_entropy_with_logits(obj, pos.float(), reduction="sum") / npos
    total = weights[0] * box_loss + weights[1] * obj_loss + weights[2] * cls_loss
    return total, {"box": box_loss.item(), "obj": obj_loss.item(), "cls": cls_loss.item()}
