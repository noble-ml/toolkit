"""Felix datasets as training/validation tensors (letterboxed, with light augmentation)."""
from __future__ import annotations

import os
import random
import sys
from typing import List, Optional, Tuple

import torch

from ..errors import WorkflowError
from ..inference.predictor import letterbox, to_tensor


def as_dataset(obj):
    """Accept a Felix dataset/subset object or a path to a dataset folder / .felix file."""
    if isinstance(obj, (str, os.PathLike)):
        try:
            import felix
        except ImportError:
            raise WorkflowError("training needs Felix for datasets: install the `felix` package") from None
        return felix.load(obj)
    for attr in ("stems", "annotation", "image"):
        if not hasattr(obj, attr):
            raise WorkflowError(f"expected a Felix dataset (fx.load(...)) or its path, got {type(obj).__name__}")
    return obj


def split(ds, name: str):
    """A named split of a Felix Dataset (``train``/``val``/``test``); subsets are returned unchanged."""
    return getattr(ds, name) if hasattr(ds, name) and hasattr(ds, "splits") else ds


class DetectionData(torch.utils.data.Dataset):
    def __init__(self, ds, size: Tuple[int, int], augment: bool = False):
        self.ds, self.size, self.augment = ds, size, augment
        self.stems = list(ds.stems)

    def __len__(self):
        return len(self.stems)

    def __getitem__(self, i):
        stem = self.stems[i]
        ann = self.ds.annotation(stem)
        img = self.ds.image(stem).convert("RGB")
        w, h = img.size
        boxed, s, (px, py) = letterbox(img, self.size)
        rows = []
        for o in ann.get("objects") or []:
            x, y, bw, bh = o["bbox"]
            rows.append([o["class_id"], x * s + px, y * s + py, (x + bw) * s + px, (y + bh) * s + py])
        t = torch.tensor(rows, dtype=torch.float32).reshape(-1, 5)
        x = to_tensor(boxed)
        if self.augment:
            if random.random() < 0.5:                                  # horizontal flip
                x = x.flip(-1)
                W = self.size[1]
                t[:, [1, 3]] = W - t[:, [3, 1]]
            if random.random() < 0.8:                                  # brightness / contrast jitter
                f = x.float() * random.uniform(0.75, 1.25) + random.uniform(-20, 20)
                x = f.clamp(0, 255).to(torch.uint8)
        return x, t


def collate(batch):
    return torch.stack([b[0] for b in batch]), [b[1] for b in batch]


def default_workers() -> int:
    # spawn-based platforms (Windows, macOS) need a __main__ guard in user scripts: default to in-process
    return 0 if sys.platform in ("win32", "darwin") else min(4, os.cpu_count() or 1)


def loader(ds, size, batch_size, shuffle, augment, workers: Optional[int], device) -> torch.utils.data.DataLoader:
    workers = default_workers() if workers is None else workers
    return torch.utils.data.DataLoader(
        DetectionData(ds, size, augment), batch_size=batch_size, shuffle=shuffle, drop_last=shuffle,
        num_workers=workers, collate_fn=collate, persistent_workers=workers > 0,
        pin_memory=device.type == "cuda")
