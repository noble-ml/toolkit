from __future__ import annotations

import os
from typing import Optional


class EarlyStopping:
    """Stop when the fitness has not improved for ``patience`` epochs (``None`` disables)."""

    def __init__(self, patience: Optional[int]):
        self.patience, self.best, self.best_epoch = patience, float("-inf"), 0

    def step(self, epoch: int, fitness: float) -> bool:
        """Record an epoch; returns True if it is a new best."""
        improved = fitness >= self.best
        if improved:
            self.best, self.best_epoch = fitness, epoch
        return improved

    def should_stop(self, epoch: int) -> bool:
        return self.patience is not None and epoch - self.best_epoch >= self.patience


class Checkpointer:
    """Decides which ``.nbm`` files to write after an epoch: last, best and every ``save_every``."""

    def __init__(self, directory: str, save_every: Optional[int]):
        self.dir, self.every = directory, save_every

    def paths(self, epoch: int, is_best: bool):
        out = [os.path.join(self.dir, "last.nbm")]
        if is_best:
            out.append(os.path.join(self.dir, "best.nbm"))
        if self.every and epoch % self.every == 0:
            out.append(os.path.join(self.dir, f"epoch_{epoch}.nbm"))
        return out
