from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn

from ..errors import ShapeError, WorkflowError
from ..layers import MaxPool2D
from ..op import Op, positive_int
from ._util import cbs


class SPPF(Op):
    """Fast spatial pyramid pooling: three chained max-pools concatenated with the input.

    ``wf.SPPF(channels, out_channels=None, kernel_size=5)``

    Requires input channels == ``channels`` and an odd ``kernel_size`` ≥ 3; keeps the resolution.
    """

    def __init__(self, channels: int, out_channels: Optional[int] = None, kernel_size: int = 5):
        super().__init__()
        positive_int(channels, "channels")
        out_channels = channels if out_channels is None else positive_int(out_channels, "out_channels")
        if not isinstance(kernel_size, int) or kernel_size < 3 or kernel_size % 2 == 0:
            raise WorkflowError(f"kernel_size must be an odd integer >= 3, got {kernel_size!r}")
        hidden = max(1, channels // 2)
        self.channels, self.out_channels = channels, out_channels
        self.cv1, self.cv2 = cbs(channels, hidden), cbs(hidden * 4, out_channels)
        self.pool = MaxPool2D(kernel_size, stride=1, padding=kernel_size // 2)

    def forward(self, x):
        x = self.cv1(x)
        y1 = self.pool(x)
        y2 = self.pool(y1)
        return self.cv2(torch.cat((x, y1, y2, self.pool(y2)), dim=1))

    def expected_channels(self):
        return self.channels

    def infer(self, shape):
        if shape[0] != self.channels:
            raise ShapeError(f"expects {self.channels} channels but received {shape[0]} (shape {shape})")
        return (self.out_channels, shape[1], shape[2])
