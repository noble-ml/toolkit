"""Shared pieces for composite blocks."""
from __future__ import annotations

import torch.nn as nn

from ..errors import ShapeError, WorkflowError
from ..layers import BatchNorm2D, Conv2D, SiLU
from ..op import Op, link, name_list, positive_int


def cbs(c_in: int, c_out: int, kernel: int = 1, stride: int = 1) -> nn.Sequential:
    """Conv → BatchNorm → SiLU with 'same'-style padding (kernel // 2)."""
    ops = [Conv2D(c_in, c_out, kernel, stride=stride, padding=kernel // 2), BatchNorm2D(c_out), SiLU()]
    link(ops)
    return nn.Sequential(*ops)


class _Neck(Op):
    """Multi-input, multi-output feature fusion (FPN, PAN).

    Inputs are named, ordered from the largest feature map to the smallest, and
    every input gets one explicitly named output of ``channels`` channels at the
    same resolution. Weights are created when the input channels become known
    (during the Model's shape inference).
    """

    def __init__(self, inputs, channels: int, outputs=None):
        super().__init__()
        kind = type(self).__name__
        self.inputs = name_list(inputs, f"{kind} inputs", minimum=2)
        positive_int(channels, "channels")
        self.channels = channels
        if outputs is None:
            raise WorkflowError(f"{kind} needs outputs=(...): one name per input ({len(self.inputs)} names), "
                                f"e.g. outputs={tuple(f'n{i}' for i in range(len(self.inputs)))}")
        self.outputs = name_list(outputs, f"{kind} outputs")
        if len(self.outputs) != len(self.inputs):
            raise WorkflowError(f"{kind} has {len(self.inputs)} inputs {self.inputs} but {len(self.outputs)} "
                                f"output names {self.outputs}; give one output name per input")
        self._built = None

    def _make(self, in_channels):  # pragma: no cover
        raise NotImplementedError

    def _check(self, shapes):
        """Subclass hook for extra size rules."""

    def infer(self, *shapes):
        chans = tuple(s[0] for s in shapes)
        if self._built is None:
            self._make(chans)
            self._built = chans
        elif self._built != chans:
            raise ShapeError(f"was built for input channels {self._built} but received {chans}")
        for i in range(len(shapes) - 1):
            (_, h, w), (_, h2, w2) = shapes[i], shapes[i + 1]
            if not (h2 < h and w2 < w):
                raise ShapeError(
                    f"inputs must be ordered from the largest feature map to the smallest, but '{self.inputs[i]}' "
                    f"is {h}x{w} and '{self.inputs[i + 1]}' is {h2}x{w2}")
        self._check(shapes)
        return tuple((self.channels, s[1], s[2]) for s in shapes)
