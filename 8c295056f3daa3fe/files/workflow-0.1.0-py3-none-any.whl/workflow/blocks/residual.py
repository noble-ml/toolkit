from __future__ import annotations

from typing import Optional, Sequence, Union

import torch.nn as nn

from ..errors import ShapeError
from ..op import Op, Shape, chain_infer, check_ops, link


class Residual(Op):
    """``output = branch(x) + shortcut(x)``.

    The shortcut is the block's own input (identity) unless ``shortcut=`` gives
    projection ops. Branch and shortcut must produce the same shape.
    """

    def __init__(self, *ops: Op, shortcut: Optional[Union[Op, Sequence[Op]]] = None):
        super().__init__()
        branch = check_ops(ops, "Residual")
        proj = None
        if shortcut is not None:
            proj = check_ops([shortcut] if isinstance(shortcut, Op) else shortcut, "Residual shortcut")
        link(branch)
        self.branch = nn.Sequential(*branch)
        self.shortcut = None
        if proj is not None:
            link(proj)
            self.shortcut = nn.Sequential(*proj)

    def forward(self, x):
        y = self.branch(x)
        return y + (x if self.shortcut is None else self.shortcut(x))

    def expected_channels(self):
        for op in self.branch:
            c = op.expected_channels()
            if c is not None:
                return c
        return None

    def sub_ops(self):
        return list(self.branch) + (list(self.shortcut) if self.shortcut is not None else [])

    def infer(self, shape: Shape) -> Shape:
        out = chain_infer(list(self.branch), shape)
        if self.shortcut is None:
            carried = shape
        else:
            try:
                carried = chain_infer(list(self.shortcut), shape)
            except ShapeError as e:
                raise e.at("shortcut") from None
        if out != carried:
            hint = ("make the branch keep the input shape (matching channels, stride 1), "
                    "or pass shortcut=wf.Conv2D(...) to project the input"
                    if self.shortcut is None else "adjust the shortcut so both paths produce the same shape")
            raise ShapeError(f"the branch outputs {out} but the shortcut carries {carried}; they must match "
                             f"to be added. To fix: {hint}")
        return out
