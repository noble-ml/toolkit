from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn

from ..errors import ShapeError, WorkflowError
from ..op import Op, positive_int
from .bottleneck import Bottleneck
from ._util import cbs


class CSP(Op):
    """Cross-stage-partial block: split into two paths, run ``n`` Bottlenecks on one, concatenate, fuse.

    ``wf.CSP(channels, out_channels=None, n=1, expansion=0.5, shortcut=True)``

    Requires input channels == ``channels``; outputs ``out_channels`` (default ``channels``) at the
    same resolution.
    """

    def __init__(self, channels: int, out_channels: Optional[int] = None, n: int = 1,
                 expansion: float = 0.5, shortcut: bool = True):
        super().__init__()
        positive_int(channels, "channels")
        out_channels = channels if out_channels is None else positive_int(out_channels, "out_channels")
        positive_int(n, "n")
        if not 0 < expansion <= 1:
            raise WorkflowError(f"expansion must be in (0, 1], got {expansion!r}")
        hidden = max(1, round(out_channels * expansion))
        self.channels, self.out_channels = channels, out_channels
        self.cv1, self.cv2 = cbs(channels, hidden), cbs(channels, hidden)
        self.m = nn.Sequential(*[Bottleneck(hidden, expansion=1.0, shortcut=shortcut) for _ in range(n)])
        self.cv3 = cbs(2 * hidden, out_channels)

    def forward(self, x):
        return self.cv3(torch.cat((self.m(self.cv1(x)), self.cv2(x)), dim=1))

    def expected_channels(self):
        return self.channels

    def infer(self, shape):
        if shape[0] != self.channels:
            raise ShapeError(f"expects {self.channels} channels but received {shape[0]} (shape {shape})")
        return (self.out_channels, shape[1], shape[2])
