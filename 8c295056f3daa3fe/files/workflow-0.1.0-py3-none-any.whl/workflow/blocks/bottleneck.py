from __future__ import annotations

import torch.nn as nn

from ..errors import ShapeError, WorkflowError
from ..layers import BatchNorm2D, Conv2D, SiLU
from ..op import Op, Shape, chain_infer, link, positive_int


class Bottleneck(Op):
    """1x1 reduce → 3x3 expand (each Conv-BN-SiLU), added back to the input.

    Keeps the shape. ``expansion`` sets the hidden width (``channels * expansion``).
    """

    def __init__(self, channels: int, expansion: float = 0.5, shortcut: bool = True):
        super().__init__()
        positive_int(channels, "channels")
        if not 0 < expansion <= 1:
            raise WorkflowError(f"expansion must be in (0, 1], got {expansion!r}")
        hidden = max(1, round(channels * expansion))
        ops = [Conv2D(channels, hidden, 1), BatchNorm2D(hidden), SiLU(),
               Conv2D(hidden, channels, 3, padding=1), BatchNorm2D(channels), SiLU()]
        link(ops)
        self.channels, self.shortcut = channels, bool(shortcut)
        self.body = nn.Sequential(*ops)

    def forward(self, x):
        y = self.body(x)
        return x + y if self.shortcut else y

    def expected_channels(self):
        return self.channels

    def sub_ops(self):
        return list(self.body)

    def infer(self, shape: Shape) -> Shape:
        if shape[0] != self.channels:
            raise ShapeError(f"expects {self.channels} channels but received {shape[0]} (shape {shape})")
        return chain_infer(list(self.body), shape)
