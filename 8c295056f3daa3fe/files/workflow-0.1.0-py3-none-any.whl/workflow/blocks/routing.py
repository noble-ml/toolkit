from __future__ import annotations

import torch

from ..errors import ShapeError
from ..op import Op, name_list


class Add(Op):
    """Elementwise sum of explicitly named tensors (identical shapes)."""

    def __init__(self, inputs):
        super().__init__()
        self.inputs = name_list(inputs, "Add inputs", minimum=2)

    def forward(self, *xs):
        out = xs[0]
        for x in xs[1:]:
            out = out + x
        return out

    def infer(self, *shapes):
        for n, s in zip(self.inputs[1:], shapes[1:]):
            if s != shapes[0]:
                raise ShapeError(f"cannot add '{self.inputs[0]}' {shapes[0]} and '{n}' {s}: shapes must be identical")
        return shapes[0]


class Concat(Op):
    """Concatenate explicitly named tensors along channels (same height and width)."""

    def __init__(self, inputs):
        super().__init__()
        self.inputs = name_list(inputs, "Concat inputs", minimum=2)

    def forward(self, *xs):
        return torch.cat(xs, dim=1)

    def infer(self, *shapes):
        _, h, w = shapes[0]
        for n, s in zip(self.inputs[1:], shapes[1:]):
            if s[1:] != (h, w):
                raise ShapeError(f"cannot concatenate '{self.inputs[0]}' ({h}x{w}) with '{n}' ({s[1]}x{s[2]}): "
                                 "height and width must match (channels may differ)")
        return (sum(s[0] for s in shapes), h, w)
