from __future__ import annotations

import torch.nn as nn

from ..errors import ShapeError
from ..op import window_size
from ._util import _Neck, cbs


class PAN(_Neck):
    """Bottom-up path aggregation (typically fed with FPN outputs).

    ``wf.PAN(inputs=("n3", "n4", "n5"), channels=128, outputs=("m3", "m4", "m5"))``

    Inputs whose channels differ from ``channels`` are projected with a 1x1 Conv-BN-SiLU. Starting
    from the finest level, each level is downsampled by a stride-2 3x3 Conv-BN-SiLU and added to
    the next level, which then gets a 3x3 Conv-BN-SiLU. Each input must be half the size of the
    previous one (rounded up).
    """

    def _make(self, in_channels):
        self.lateral = nn.ModuleList([cbs(c, self.channels, 1) if c != self.channels else nn.Identity()
                                      for c in in_channels])
        self.down = nn.ModuleList([cbs(self.channels, self.channels, 3, stride=2) for _ in in_channels[1:]])
        self.smooth = nn.ModuleList([cbs(self.channels, self.channels, 3) for _ in in_channels])

    def _check(self, shapes):
        for i in range(1, len(shapes)):
            (_, h, w), (_, h2, w2) = shapes[i - 1], shapes[i]
            dh, dw = window_size(h, 3, 2, 1), window_size(w, 3, 2, 1)
            if (dh, dw) != (h2, w2):
                raise ShapeError(
                    f"downsampling '{self.inputs[i - 1]}' ({h}x{w}) by stride 2 gives {dh}x{dw}, but "
                    f"'{self.inputs[i]}' is {h2}x{w2}; each input must be half the size of the previous one")

    def forward(self, *xs):
        xs = [layer(x) for layer, x in zip(self.lateral, xs)]
        outs = [self.smooth[0](xs[0])]
        for i in range(1, len(xs)):
            outs.append(self.smooth[i](xs[i] + self.down[i - 1](outs[-1])))
        return tuple(outs)
