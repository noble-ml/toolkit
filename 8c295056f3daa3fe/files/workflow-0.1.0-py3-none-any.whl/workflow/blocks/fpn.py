from __future__ import annotations

import torch.nn as nn
import torch.nn.functional as F

from ._util import _Neck, cbs


class FPN(_Neck):
    """Top-down feature pyramid.

    ``wf.FPN(inputs=("p3", "p4", "p5"), channels=128, outputs=("n3", "n4", "n5"))``

    Each input gets a 1x1 Conv-BN-SiLU to ``channels``; from the coarsest level down, the merged
    map is upsampled (nearest) and added to the next finer level; every level then gets a 3x3
    Conv-BN-SiLU. Outputs keep their input's resolution and are returned in input order.
    """

    def _make(self, in_channels):
        self.lateral = nn.ModuleList([cbs(c, self.channels, 1) for c in in_channels])
        self.smooth = nn.ModuleList([cbs(self.channels, self.channels, 3) for _ in in_channels])

    def forward(self, *xs):
        lat = [layer(x) for layer, x in zip(self.lateral, xs)]
        for i in range(len(lat) - 2, -1, -1):
            lat[i] = lat[i] + F.interpolate(lat[i + 1], size=lat[i].shape[-2:], mode="nearest")
        return tuple(layer(x) for layer, x in zip(self.smooth, lat))
