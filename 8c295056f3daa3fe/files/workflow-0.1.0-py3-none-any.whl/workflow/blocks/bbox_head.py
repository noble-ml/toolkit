from __future__ import annotations

import math

import torch.nn as nn

from ..errors import ShapeError, WorkflowError
from ..layers import Conv2D
from ..op import Op, name_list, positive_int
from ._util import cbs


class BBoxHead(Op):
    """Anchor-free bounding-box detection head.

    ``wf.BBoxHead(inputs=("m3", "m4", "m5"), classes=3, outputs=("d3", "d4", "d5"))``

    For every named input level it applies two 3×3 Conv-BN-SiLU layers and a 1×1 conv, producing one
    raw map per level with ``4 + 1 + classes`` channels:

    * channels 0-3: distances (left, top, right, bottom) from the cell centre to the box edges, in
      units of that level's stride, passed through softplus when decoded;
    * channel 4: confidence (objectness) logit;
    * channels 5…: one logit per class.

    Each level's stride is inferred at decode time from the image and map sizes, so any input size works.
    ``classes`` is part of the architecture and must match the dataset when training. ``channels`` sets the
    width of the head's convs (default: the input level's own channels). ``outputs`` is required: one
    name per input.
    """

    def __init__(self, inputs, classes: int, outputs=None, channels=None):
        super().__init__()
        self.inputs = name_list(inputs, "BBoxHead inputs", minimum=1)
        positive_int(classes, "classes")
        if channels is not None:
            positive_int(channels, "channels")
        if outputs is None:
            raise WorkflowError(f"BBoxHead needs outputs=(...): one name per input ({len(self.inputs)} names), "
                                f"e.g. outputs={tuple(f'd{i}' for i in range(len(self.inputs)))}")
        self.outputs = name_list(outputs, "BBoxHead outputs")
        if len(self.outputs) != len(self.inputs):
            raise WorkflowError(f"BBoxHead has {len(self.inputs)} inputs but {len(self.outputs)} output names; "
                                "give one output name per input")
        self.classes, self.width = classes, channels
        self._built = None

    def _make(self, in_channels):
        stems, preds = [], []
        for c in in_channels:
            w = self.width or c
            pred = Conv2D(w, 5 + self.classes, 1)
            pred.bias.data[:4] = 1.0                                   # softplus(1) ≈ 1.3 strides
            pred.bias.data[4:] = -math.log((1 - 0.01) / 0.01)           # start at ~1% confidence
            stems.append(nn.Sequential(cbs(c, w, 3), cbs(w, w, 3)))
            preds.append(pred)
        self.stems, self.preds = nn.ModuleList(stems), nn.ModuleList(preds)

    def infer(self, *shapes):
        chans = tuple(s[0] for s in shapes)
        if self._built is None:
            self._make(chans)
            self._built = chans
        elif self._built != chans:
            raise ShapeError(f"was built for input channels {self._built} but received {chans}")
        return tuple((5 + self.classes, s[1], s[2]) for s in shapes)

    def forward(self, *xs):
        return tuple(p(s(x)) for s, p, x in zip(self.stems, self.preds, xs))
