"""Operation base class.

Every Workflow operation (layer or block) derives from :class:`Op`. The base
class records the arguments of each constructor call, which gives every
operation ``spec()`` (a JSON-able description used by ``.nbm``) and
``Op.from_spec()`` (rebuild it from that description) with no per-class code.
"""
from __future__ import annotations

import functools
import inspect
from typing import Any, Dict, List, Optional, Sequence, Tuple

import torch.nn as nn

from .errors import SerializationError, ShapeError, WorkflowError

Shape = Tuple[int, int, int]  # (channels, height, width); the batch is never part of a shape
_REGISTRY: Dict[str, type] = {}


# ----------------------------------------------------------------- argument helpers
def positive_int(value: Any, name: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise WorkflowError(f"{name} must be a positive integer, got {value!r}")
    return value


def pair(value: Any, name: str, minimum: int = 1) -> Tuple[int, int]:
    """int or (int, int) → (int, int), with a lower bound."""
    if isinstance(value, int) and not isinstance(value, bool):
        value = (value, value)
    if (isinstance(value, (tuple, list)) and len(value) == 2
            and all(isinstance(v, int) and not isinstance(v, bool) for v in value)):
        if min(value) < minimum:
            raise WorkflowError(f"{name} must be >= {minimum}, got {tuple(value)}")
        return (value[0], value[1])
    raise WorkflowError(f"{name} must be an int or a pair of ints, got {value!r}")


def name_list(value: Any, what: str, minimum: int = 1) -> Tuple[str, ...]:
    """Validate a tuple of distinct tensor names."""
    if isinstance(value, str) or not isinstance(value, (tuple, list)) or not all(isinstance(v, str) for v in value):
        raise WorkflowError(f"{what} must be a tuple of names, e.g. ('p3', 'p4'), got {value!r}")
    if len(value) < minimum:
        raise WorkflowError(f"{what} needs at least {minimum} names, got {len(value)}")
    if len(set(value)) != len(value):
        raise WorkflowError(f"{what} contains duplicates: {tuple(value)}")
    return tuple(value)


def window_size(size: int, k: int, s: int, p: int, d: int = 1) -> int:
    """Output length of a sliding window (convolution / pooling) along one axis."""
    return (size + 2 * p - d * (k - 1) - 1) // s + 1


# ----------------------------------------------------------------- spec capture
def _capture(init):
    sig = inspect.signature(init)

    @functools.wraps(init)
    def wrapper(self, *a, **k):
        if "_args" not in self.__dict__:  # outermost constructor call wins
            try:
                bound = sig.bind(self, *a, **k)
            except TypeError:
                pass  # let the real __init__ raise Python's own error
            else:
                object.__setattr__(self, "_args", dict(list(bound.arguments.items())[1:]))
        init(self, *a, **k)

    return wrapper


def _enc(v: Any) -> Any:
    if isinstance(v, Op):
        return v.spec()
    if isinstance(v, (list, tuple)):
        return [_enc(i) for i in v]
    if isinstance(v, dict):
        return {k: _enc(i) for k, i in v.items()}
    return v


def _dec(v: Any) -> Any:
    if isinstance(v, dict) and "op" in v and "args" in v:
        return Op.from_spec(v)
    if isinstance(v, list):
        return [_dec(i) for i in v]
    if isinstance(v, dict):
        return {k: _dec(i) for k, i in v.items()}
    return v


class Op(nn.Module):
    """Base class of all operations.

    Subclasses implement ``forward`` and ``infer``. Operations that read named
    tensors set ``inputs`` (tuple of names); operations that produce several
    tensors set ``outputs`` (tuple of names, one per tensor).
    """

    inputs: Optional[Tuple[str, ...]] = None
    outputs: Optional[Tuple[str, ...]] = None
    absorbs_bias = False  # True for BatchNorm: a conv right before it needs no bias

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)
        if "__init__" in cls.__dict__:
            cls.__init__ = _capture(cls.__dict__["__init__"])
        if not cls.__name__.startswith("_"):
            _REGISTRY[cls.__name__] = cls

    # -- to be provided by subclasses
    def infer(self, *shapes: Shape):
        """Output shape(s) for the given input shape(s). Raise ShapeError on mismatch."""
        raise NotImplementedError(f"{type(self).__name__}.infer")

    def expected_channels(self) -> Optional[int]:
        """Input channels this op requires, or None if it accepts any."""
        return None

    def sub_ops(self) -> Sequence["Op"]:
        """Operations nested inside this one (containers only)."""
        return ()

    # -- serialization
    def spec(self) -> Dict[str, Any]:
        return {"op": type(self).__name__, "args": _enc(self.__dict__.get("_args", {}))}

    @staticmethod
    def from_spec(spec: Dict[str, Any]) -> "Op":
        cls = _REGISTRY.get(spec.get("op"))
        if cls is None:
            raise SerializationError(f"unknown operation {spec.get('op')!r} (file from a newer Workflow?)")
        args = _dec(spec.get("args", {}))
        params = list(inspect.signature(cls.__init__).parameters.values())[1:]
        has_var = any(p.kind is p.VAR_POSITIONAL for p in params)
        pos: List[Any] = []
        kw: Dict[str, Any] = {}
        for p in params:
            if p.name not in args:
                continue
            v = args[p.name]
            if p.kind is p.VAR_POSITIONAL:
                pos.extend(v)
            elif p.kind is p.VAR_KEYWORD:
                kw.update(v)
            elif p.kind is p.KEYWORD_ONLY or not has_var:
                kw[p.name] = v
            else:
                pos.append(v)
        return cls(*pos, **kw)


def chain_infer(ops: Sequence[Op], shape: Shape) -> Shape:
    """Run shape inference through single-input ops, annotating errors with the op."""
    for i, op in enumerate(ops):
        try:
            shape = op.infer(shape)
        except ShapeError as e:
            raise e.at(f"op {i + 1} {type(op).__name__}") from None
    return shape


def link(ops: Sequence[Op]) -> None:
    """Sequence rule: a Conv2D directly followed by BatchNorm2D has no bias; any other has one."""
    for i, op in enumerate(ops):
        setter = getattr(op, "set_bias", None)
        if setter is not None:
            nxt = ops[i + 1] if i + 1 < len(ops) else None
            setter(not (nxt is not None and nxt.absorbs_bias))


def check_ops(ops: Sequence[Any], owner: str) -> List[Op]:
    """Validate a list of operations that live inside a container."""
    ops = list(ops)
    if not ops:
        raise WorkflowError(f"{owner} needs at least one operation")
    for o in ops:
        if not isinstance(o, Op):
            raise WorkflowError(f"{owner} can only contain Workflow operations, got {o!r}")
        if o.inputs or o.outputs:
            raise WorkflowError(
                f"{owner} cannot contain {type(o).__name__}: operations that use named inputs/outputs "
                "must be placed directly in a Stage")
    return ops
