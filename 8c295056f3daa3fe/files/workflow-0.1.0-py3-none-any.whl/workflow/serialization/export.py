"""Export a model to TorchScript (``.pt``) or ONNX (``.onnx``)."""
from __future__ import annotations

import os
import warnings
from typing import Optional, Sequence

import torch

from ..errors import WorkflowError


def export(model, path, size: Optional[Sequence[int]] = None, device: str = "cpu",
           dynamic: bool = False, opset: int = 17) -> str:
    """Trace ``model`` with a dummy batch and write ``path`` (.pt TorchScript or .onnx)."""
    path = os.fspath(path)
    ext = os.path.splitext(path)[1].lower()
    if ext not in (".pt", ".onnx"):
        raise WorkflowError(f"cannot export to {ext or path!r}; use .pt (TorchScript) or .onnx")
    c, h, w = model.input
    if size:
        h, w = (size[0], size[0]) if len(size) == 1 else (size[0], size[1])
    model = model.eval().device(device)
    example = torch.zeros(1, c, h, w, device=model.device())
    with torch.inference_mode():
        if ext == ".pt":
            with warnings.catch_warnings():  # torch.jit is deprecated upstream but still the portable .pt format
                warnings.simplefilter("ignore")
                torch.jit.trace(model, example, strict=False).save(path)
        else:
            names = list(model.output_shapes)
            axes = {"images": {0: "batch", 2: "height", 3: "width"} if dynamic else {0: "batch"}}
            axes.update({n: {0: "batch"} for n in names})
            kw = dict(input_names=["images"], output_names=names, dynamic_axes=axes, opset_version=opset)
            try:
                with warnings.catch_warnings():  # the TorchScript exporter is deprecated but needs no extra packages
                    warnings.simplefilter("ignore")
                    try:
                        torch.onnx.export(model, example, path, dynamo=False, **kw)
                    except TypeError:  # newer torch without the legacy exporter
                        torch.onnx.export(model, example, path, **kw)
            except ModuleNotFoundError as e:
                raise WorkflowError(f"ONNX export needs an extra package ({e.name}); install it with "
                                    "`pip install onnx onnxscript`") from None
    return path
