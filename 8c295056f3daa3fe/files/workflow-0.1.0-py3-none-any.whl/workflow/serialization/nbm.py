"""The ``.nbm`` (Noble Model) format.

A zip archive:

* ``meta.json``  - format version, architecture spec, input, classes, detection and training metadata
* ``weights.pt`` - the state dict (loaded with ``weights_only=True``; no code execution)

Training state (optimizer, scheduler, epoch) will live in ``train.pt`` in the same file.
"""
from __future__ import annotations

import io
import json
import os
import zipfile
from datetime import datetime, timezone
from typing import Any, Dict

import torch

from .._version import __version__
from ..errors import SerializationError

FORMAT = 1
EXT = ".nbm"


def save(model, path, weights=None, train=None, **meta: Any) -> str:
    """Write ``path``. ``weights`` overrides the model's state dict; ``train`` adds ``train.pt`` (optimizer etc.)."""
    path = os.fspath(path)
    if not path.lower().endswith(EXT):
        raise SerializationError(f"model files use the {EXT} extension, got {path!r}")
    doc = {"format": "nbm", "version": FORMAT, "workflow_version": __version__,
           "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "arch": json.loads(json.dumps(model.spec())), "classes": None, "detection": None, "training": None}
    doc.update({k: v for k, v in meta.items() if v is not None})
    buf = io.BytesIO()
    torch.save({k: v.detach().cpu() for k, v in (weights if weights is not None else model.state_dict()).items()}, buf)
    tmp = path + ".part"
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
            z.writestr("meta.json", json.dumps(doc, indent=1))
            z.writestr("weights.pt", buf.getvalue())
            if train is not None:
                tb = io.BytesIO()
                torch.save(train, tb)
                z.writestr("train.pt", tb.getvalue())
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return path


def _open(path):
    path = os.fspath(path)
    if not os.path.isfile(path) or not zipfile.is_zipfile(path):
        raise SerializationError(f"{path} is not a {EXT} file")
    return zipfile.ZipFile(path)


def read_meta(path) -> Dict[str, Any]:
    with _open(path) as z:
        try:
            doc = json.loads(z.read("meta.json"))
        except KeyError:
            raise SerializationError(f"{path} is not a {EXT} file (no meta.json)") from None
    if doc.get("format") != "nbm":
        raise SerializationError(f"{path} is not a {EXT} file")
    if doc.get("version", 0) > FORMAT:
        raise SerializationError(f"{path} was written by a newer Workflow (format {doc['version']}); upgrade Workflow")
    return doc


def read_weights(path):
    with _open(path) as z:
        return torch.load(io.BytesIO(z.read("weights.pt")), map_location="cpu", weights_only=True)


def read_train(path):
    """The optimizer / raw-weights state saved by training, or None."""
    with _open(path) as z:
        if "train.pt" not in z.namelist():
            return None
        return torch.load(io.BytesIO(z.read("train.pt")), map_location="cpu", weights_only=True)


def restore(model, path) -> None:
    """Load weights plus class names and training state from ``path`` into ``model``."""
    meta = read_meta(path)
    model.load_state_dict(read_weights(path))
    model.class_names = meta.get("classes")
    tr = meta.get("training")
    if tr:
        from ..training.trainer import History
        model.history = History(tr.get("history", []))
        extra = read_train(path) or {}
        model._train_state = {"epoch": tr["epoch"], "epochs": tr.get("epochs"), "best_fitness": tr.get("best_fitness"),
                              "best_epoch": tr.get("best_epoch"), "config": tr.get("config"),
                              "optimizer": extra.get("optimizer"), "raw": extra.get("raw"),
                              "ema_updates": extra.get("ema_updates", 0)}


def load(path, device=None):
    """Rebuild the model stored in ``path`` (architecture, weights, class names, training state)."""
    from ..model import Model
    model = Model.from_spec(read_meta(path)["arch"])
    restore(model, path)
    return model.device(device) if device else model
