from __future__ import annotations

import torch.nn as nn

from ..op import Op, Shape


class _Same(Op):
    """Elementwise ops keep the shape."""

    def infer(self, shape: Shape) -> Shape:
        return shape


class ReLU(_Same, nn.ReLU):
    def __init__(self):
        super().__init__()


class LeakyReLU(_Same, nn.LeakyReLU):
    """Leaky ReLU; ``slope`` is the gradient for negative inputs (default 0.1)."""

    def __init__(self, slope: float = 0.1):
        super().__init__(negative_slope=slope)


class SiLU(_Same, nn.SiLU):
    def __init__(self):
        super().__init__()


class Sigmoid(_Same, nn.Sigmoid):
    def __init__(self):
        super().__init__()
