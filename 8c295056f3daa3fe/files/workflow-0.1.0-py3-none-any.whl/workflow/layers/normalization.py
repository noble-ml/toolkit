from __future__ import annotations

import torch.nn as nn

from ..errors import ShapeError
from ..op import Op, Shape, positive_int


class BatchNorm2D(Op, nn.BatchNorm2d):
    """Batch normalization over channels (eps 1e-3, momentum 0.03)."""

    absorbs_bias = True

    def __init__(self, channels: int):
        positive_int(channels, "channels")
        super().__init__(channels, eps=1e-3, momentum=0.03)

    def expected_channels(self) -> int:
        return self.num_features

    def infer(self, shape: Shape) -> Shape:
        if shape[0] != self.num_features:
            raise ShapeError(f"expects {self.num_features} channels but received {shape[0]} (shape {shape})")
        return shape
