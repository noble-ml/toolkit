from __future__ import annotations

import torch.nn as nn

from ..errors import ShapeError, WorkflowError
from ..op import Op, Shape, pair, positive_int, window_size


def _pool_args(kernel_size, stride, padding):
    k = pair(kernel_size, "kernel_size")
    s = k if stride is None else pair(stride, "stride")
    p = pair(padding, "padding", minimum=0)
    if p[0] * 2 > k[0] or p[1] * 2 > k[1]:
        raise WorkflowError(f"padding {p} must be at most half of kernel_size {k}")
    return k, s, p


def _pool_infer(self, shape: Shape) -> Shape:
    c, h, w = shape
    oh = window_size(h, self.kernel_size[0], self.stride[0], self.padding[0])
    ow = window_size(w, self.kernel_size[1], self.stride[1], self.padding[1])
    if oh < 1 or ow < 1:
        raise ShapeError(f"pooling window {self.kernel_size} does not fit an input of {h}x{w}")
    return (c, oh, ow)


class MaxPool2D(Op, nn.MaxPool2d):
    """Max pooling. ``stride`` defaults to ``kernel_size``."""

    def __init__(self, kernel_size, stride=None, padding=0):
        super().__init__(*_pool_args(kernel_size, stride, padding))

    infer = _pool_infer


class AvgPool2D(Op, nn.AvgPool2d):
    """Average pooling. ``stride`` defaults to ``kernel_size``."""

    def __init__(self, kernel_size, stride=None, padding=0):
        super().__init__(*_pool_args(kernel_size, stride, padding))

    infer = _pool_infer


class Upsample(Op, nn.Upsample):
    """Nearest-neighbour upsampling by an integer factor."""

    def __init__(self, scale_factor: int = 2):
        positive_int(scale_factor, "scale_factor")
        super().__init__(scale_factor=scale_factor, mode="nearest")
        self.factor = scale_factor

    def infer(self, shape: Shape) -> Shape:
        c, h, w = shape
        return (c, h * self.factor, w * self.factor)
