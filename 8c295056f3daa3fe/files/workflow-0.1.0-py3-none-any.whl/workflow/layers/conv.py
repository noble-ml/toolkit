from __future__ import annotations

import torch.nn as nn

from ..errors import ShapeError
from ..op import Op, Shape, pair, positive_int, window_size


class Conv2D(Op, nn.Conv2d):
    """2-D convolution (single group).

    Bias is automatic: none when directly followed by BatchNorm2D in the same
    sequence, otherwise a learnable bias.
    """

    def __init__(self, in_channels: int, out_channels: int, kernel_size, stride=1, padding=0, dilation=1):
        positive_int(in_channels, "in_channels")
        positive_int(out_channels, "out_channels")
        super().__init__(
            in_channels, out_channels,
            pair(kernel_size, "kernel_size"), pair(stride, "stride"),
            pair(padding, "padding", minimum=0), pair(dilation, "dilation"))

    def set_bias(self, on: bool) -> None:
        if not on and self.bias is not None:
            self.register_parameter("bias", None)

    def expected_channels(self) -> int:
        return self.in_channels

    def infer(self, shape: Shape) -> Shape:
        c, h, w = shape
        if c != self.in_channels:
            raise ShapeError(f"expects {self.in_channels} input channels but received {c} (shape {shape})")
        oh = window_size(h, self.kernel_size[0], self.stride[0], self.padding[0], self.dilation[0])
        ow = window_size(w, self.kernel_size[1], self.stride[1], self.padding[1], self.dilation[1])
        if oh < 1 or ow < 1:
            raise ShapeError(
                f"kernel {self.kernel_size} (dilation {self.dilation}, padding {self.padding}) "
                f"does not fit an input of {h}x{w}")
        return (self.out_channels, oh, ow)
