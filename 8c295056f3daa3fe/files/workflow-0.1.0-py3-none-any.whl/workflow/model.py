from __future__ import annotations

import json
from typing import Dict, Optional, Sequence, Tuple, Union

import torch
import torch.nn as nn

from . import _ui
from .engine import device as _device
from .engine import graph, parameters
from .errors import SerializationError, ShapeError, WorkflowError
from .op import Shape
from .stage import RESERVED, Stage

DEFAULT_SIZE = 640


def _input_shape(stages: Sequence[Stage], input) -> Shape:
    if input is not None:
        if (not isinstance(input, (tuple, list)) or len(input) != 3
                or not all(isinstance(v, int) and not isinstance(v, bool) and v > 0 for v in input)):
            raise WorkflowError(f"input must be (channels, height, width) of positive ints, got {input!r}")
        return tuple(input)
    for op in stages[0].ops:
        c = op.expected_channels()
        if c is not None:
            return (c, DEFAULT_SIZE, DEFAULT_SIZE)
    raise WorkflowError("cannot infer the input channels from the first stage; pass input=(C, H, W)")


class Model(nn.Module):
    """A CNN built from named stages.

    ``input=(C, H, W)`` sets the shape used for validation and ``summary()``.
    If omitted, channels come from the first convolution and the size is 640x640.
    The shape is only used to check the architecture; the model runs on any size.
    """

    def __init__(self, *stages: Stage, input: Optional[Tuple[int, int, int]] = None):
        super().__init__()
        if not stages:
            raise WorkflowError("a Model needs at least one Stage")
        for i, s in enumerate(stages):
            if not isinstance(s, Stage):
                raise WorkflowError(f"Model item {i + 1} is {s!r}; Models are built from wf.Stage(...)")
        self._plan = graph.compile_plan(stages)  # also rejects duplicate names
        self.input: Shape = _input_shape(stages, input)
        self.stages = nn.ModuleDict({s.name: s for s in stages})
        self._shapes, self._records = graph.infer(self._plan, self.input)
        self._dev = torch.device("cpu")
        self._device_set = False
        self._channels_last = False
        self.class_names: Optional[list] = None
        self._train_state = None
        from .training.trainer import History
        self.history = History()

    # ------------------------------------------------------------------ execution
    def forward(self, x: torch.Tensor):
        return self._run(x, keep=False)

    def features(self, x: torch.Tensor) -> Dict[str, torch.Tensor]:
        """Every published tensor by name (stage names and named outputs)."""
        env = self._run(x, keep=True)
        env.pop(RESERVED, None)
        return env

    def _run(self, x: torch.Tensor, keep: bool):
        if x.dim() != 4:
            raise ShapeError(f"the model expects a batch of images (N, C, H, W), got a {x.dim()}-D tensor")
        if not torch.jit.is_tracing() and x.shape[1] != self.input[0]:
            raise ShapeError(f"the model expects {self.input[0]} input channels but received {x.shape[1]}")
        if self._channels_last:
            x = x.contiguous(memory_format=torch.channels_last)
        env = {RESERVED: x}
        for st in self._plan.steps:
            out = st.stage.run(env, st.src)
            if len(st.publishes) == 1:
                env[st.publishes[0]] = out
            else:
                env.update(zip(st.publishes, out))
            if not keep:
                for n in st.free:
                    env.pop(n, None)
        if keep:
            return env
        outs = self._plan.outputs
        return env[outs[0]] if len(outs) == 1 else {n: env[n] for n in outs}

    # ------------------------------------------------------------------ analysis
    @property
    def output_shapes(self) -> Dict[str, Shape]:
        return {n: self._shapes[n] for n in self._plan.outputs}

    def shapes(self, input: Optional[Shape] = None) -> Dict[str, Shape]:
        """Shape of every published tensor (same names as ``features``), optionally for another input shape."""
        shapes = self._shapes if input is None else graph.infer(self._plan, tuple(input))[0]
        return {n: s for n, s in shapes.items() if n != RESERVED}

    def analyze(self, input: Optional[Shape] = None):
        """Parameters, MACs/FLOPs and memory estimates (see ``workflow.engine.profiler``)."""
        from .engine import profiler
        return profiler.analyze(self, tuple(input) if input is not None else self.input)

    def summary(self, input: Optional[Shape] = None, show: bool = True) -> Dict[str, object]:
        """Per-operation shapes, parameters and MACs. Returns the totals."""
        a = self.analyze(input)
        rows, prev = [], None
        for o in a.ops:
            out = o.out_shapes[0] if len(o.out_shapes) == 1 else " ".join(map(str, o.out_shapes))
            n = o.trainable + o.non_trainable
            rows.append((o.stage if o.stage != prev else "", f"{o.index}", type(o.op).__name__, str(out),
                         f"{n:,}" if n else "–", f"{o.macs / 1e6:,.1f}M" if o.macs else "–"))
            prev = o.stage
        totals = {"input": a.input, "outputs": a.outputs, "trainable": a.trainable,
                  "non_trainable": a.non_trainable, "total": a.params, "macs": a.macs, "flops": a.flops,
                  "param_bytes": a.param_bytes, "activation_bytes": a.act_bytes, "peak_bytes": a.peak_bytes}
        if show:
            c = _ui.console()
            mb = lambda b: f"{b / 2**20:,.1f} MB"
            c.print(_ui._line(("Model summary", f"bold {_ui.BONE}"), ("  input " + str(a.input), _ui.ASH)))
            c.print()
            _ui.table(["stage", "#", "operation", "output", "params", "MACs"], rows, right=(4, 5), console_=c)
            c.print()
            c.print(_ui._line((f"{a.params:,} params", f"bold {_ui.BONE}"),
                              (f"  {a.trainable:,} trainable · {a.non_trainable:,} non-trainable", _ui.ASH)))
            c.print(_ui._line((f"{a.flops / 1e9:,.2f} GFLOPs", f"bold {_ui.BONE}"),
                              (f"  ({a.macs / 1e9:,.2f} G MACs, 2 FLOPs per MAC, per image)", _ui.ASH)))
            c.print(_ui._line(("memory ", _ui.ASH), (f"weights {mb(a.param_bytes)}", _ui.BONE),
                              (f" · activations {mb(a.act_bytes)}/img (training) · inference peak "
                               f"{mb(a.peak_bytes)}/img · fp32", _ui.ASH)))
            c.print(_ui._line(("outputs ", _ui.ASH), (", ".join(f"{n} {s}" for n, s in a.outputs.items()), _ui.BONE)))
        return totals

    # ------------------------------------------------------------------ graph drawing
    def plot(self, detail: str = "ops", show: bool = True):
        """Draw the computation graph; returns a PIL image (and opens it unless ``show=False``
        or running in a notebook, where the returned image is displayed automatically)."""
        from .engine import diagram
        img = diagram.render_png(diagram.build(self, detail), scale=2)
        if show and "get_ipython" not in dir(__import__("builtins")):
            img.show()
        return img

    def export_graph(self, path, detail: str = "ops", scale: int = 2) -> str:
        """Write the computation graph as ``.png`` or ``.svg``. ``detail="stages"`` gives a compact view."""
        from .engine import diagram
        return diagram.export(self, path, detail, scale)

    # ------------------------------------------------------------------ device
    def device(self, name: Optional[str] = None):
        """``model.device()`` returns the current device; ``model.device("auto"|"cuda"|"mps"|"cpu")`` moves the model."""
        if name is None:
            return self._dev
        dev = _device.resolve(name)
        _device.configure(dev)
        self.to(dev)
        self._channels_last = dev.type == "cuda"  # tensor-core friendly layout
        if self._channels_last:
            self.to(memory_format=torch.channels_last)
        self._dev = dev
        self._device_set = True
        return self

    # ------------------------------------------------------------------ serialization
    def spec(self) -> Dict[str, object]:
        return {"input": list(self.input), "stages": [s.spec() for s in self.stages.values()]}

    @staticmethod
    def from_spec(spec: Dict[str, object]) -> "Model":
        return Model(*[Stage.from_spec(s) for s in spec["stages"]], input=tuple(spec["input"]))

    def save(self, path: Union[str, "os.PathLike"]) -> str:
        """Write a ``.nbm`` file: architecture, weights, class names and (if trained) the training state."""
        from .serialization import nbm
        train, tr = None, None
        st = self._train_state
        if st:
            train = {"optimizer": st.get("optimizer"), "ema_updates": st.get("ema_updates", 0)}
            if st.get("raw") is not None:
                train["raw"] = st["raw"]
            tr = {"epoch": st["epoch"], "epochs": st.get("epochs"), "best_fitness": st.get("best_fitness"),
                  "best_epoch": st.get("best_epoch"), "history": list(self.history), "config": st.get("config")}
        return nbm.save(self, path, train=train, classes=self.class_names,
                        detection=self.detection_config(), training=tr)

    def load(self, path: Union[str, "os.PathLike"]) -> "Model":
        """Load weights, class names and training state from a ``.nbm`` into this model. The architecture
        must match; use ``wf.load(path)`` to rebuild the architecture from the file instead."""
        from .serialization import nbm
        meta = nbm.read_meta(path)
        if meta["arch"] != json.loads(json.dumps(self.spec())):
            raise SerializationError(
                f"{path} holds a different architecture than this model. "
                "Use `wf.load(path)` to rebuild the model stored in the file.")
        nbm.restore(self, path)
        return self

    # ------------------------------------------------------------------ detection
    def head(self):
        """The model's BBoxHead (it must be the last operation of the last stage)."""
        from .blocks import BBoxHead
        last = list(self.stages.values())[-1].ops[-1]
        if not isinstance(last, BBoxHead):
            raise WorkflowError("this model has no BBoxHead: end the last stage with "
                                "wf.BBoxHead(inputs=(...), classes=N, outputs=(...)) to train or predict")
        return last

    def detection_config(self):
        try:
            h = self.head()
        except WorkflowError:
            return None
        return {"classes": h.classes, "outputs": list(h.outputs), "box": "ltrb-softplus-stride", "bbox_format": "xyxy"}

    def detections(self, out):
        """The head's per-level raw maps from a forward result."""
        if isinstance(out, dict):
            return [out[n] for n in self.head().outputs]
        return [out]

    def predict(self, source, conf: float = 0.25, iou: float = 0.45, imgsz=None, max_det: int = 300,
                device: Optional[str] = None, half: Optional[bool] = None):
        """Detect objects in an image path, PIL image, RGB array/tensor, or a list of them.
        Returns a ``Results`` (a list of them for a list input)."""
        from .inference import predictor
        self.head()
        if device is not None:
            self.device(device)
        elif not self._device_set:
            self.device("auto")
        return predictor.predict(self, source, conf, iou, imgsz, max_det, half)

    def train(self, dataset=None, epochs: int = 100, batch_size: int = 16, save_every: Optional[int] = 5, *,
              lr: float = 1e-3, imgsz=None, device: Optional[str] = None, workers: Optional[int] = None,
              patience: Optional[int] = 30, save_dir: str = "runs/train", amp: Optional[bool] = None,
              ema: bool = True, augment: bool = True, val: bool = True, quiet: bool = False, mode=None):
        """Train on a Felix dataset (object or path). ``epochs`` is the **total** target, so a model loaded
        from a ``.nbm`` trained to epoch 80 continues towards ``epochs=150``.

        Called with a bool (or nothing) it keeps torch's meaning (``model.train(False)`` == ``eval()``)."""
        if mode is not None:
            return super().train(mode)
        if dataset is None:
            return super().train(True)
        if isinstance(dataset, bool):
            return super().train(dataset)
        from .training import trainer
        return trainer.fit(self, dataset, epochs, batch_size, save_every, lr, imgsz, device, workers, patience,
                           save_dir, amp, ema, augment, val, quiet)

    def benchmark(self, dataset=None, **kw):
        """No dataset: architecture benchmark (parameters, FLOPs, memory, latency, FPS).
        With a dataset (e.g. ``dataset.test``): evaluation (precision, recall, mAP, F1, per-class AP, confusion matrix)."""
        from .engine import benchmark
        if dataset is None:
            return benchmark.architecture(self, **kw)
        return benchmark.evaluate(self, dataset, **kw)
