"""Workflow exceptions. Everything user-facing derives from WorkflowError."""
from __future__ import annotations


class WorkflowError(Exception):
    """Base class for all Workflow errors."""


class ShapeError(WorkflowError):
    """A tensor shape does not fit an operation. Carries a location path."""

    def __init__(self, msg: str, path=()):
        self.msg, self.path = msg, list(path)
        super().__init__((" → ".join(self.path) + ": " if self.path else "") + msg)

    def at(self, label: str) -> "ShapeError":
        """Return a copy with ``label`` prepended to the location path."""
        return ShapeError(self.msg, [label, *self.path])


class RoutingError(WorkflowError):
    """Invalid stage/feature references (unknown, duplicate, circular, ambiguous)."""


class DeviceError(WorkflowError):
    """A requested device is not available."""


class SerializationError(WorkflowError):
    """A .nbm file is invalid or does not match the model."""
