from __future__ import annotations

import argparse
import os
import sys
import time

from . import _ui
from ._version import __version__
from .errors import WorkflowError


def _devices() -> None:
    from .engine import device
    pick = device.resolve("auto")
    c = _ui.console()
    c.print(_ui._line(("Workflow devices", f"bold {_ui.BONE}"), (f"  auto → {pick}", _ui.ASH)))
    c.print()
    _ui.table(["device", "info"], [(d["name"], d["info"]) for d in device.available()], console_=c)


def _info(path: str) -> None:
    from .serialization import nbm
    meta = nbm.read_meta(path)
    model = nbm.load(path)
    c = _ui.console()
    classes = meta.get("classes")
    c.print(_ui._line((f"{os.path.basename(path)}", f"bold {_ui.BONE}"),
                      (f"  workflow {meta['workflow_version']} · created {meta['created']}"
                       + (f" · {len(classes)} classes" if classes else ""), _ui.ASH)))
    tr = meta.get("training")
    if classes:
        c.print(_ui._line(("classes  ", _ui.ASH), (", ".join(classes), _ui.BONE)))
    if tr:
        c.print(_ui._line(("training ", _ui.ASH), (f"epoch {tr['epoch']}", _ui.BONE),
                          (f" of {tr.get('epochs')} · best epoch {tr.get('best_epoch')}", _ui.ASH)))
    c.print()
    model.summary()


def _script(a) -> None:
    from .inference import scripts
    preset = a.preset
    if preset is None:
        if not sys.stdin.isatty():
            raise WorkflowError("choose a preset with --preset: " + ", ".join(scripts.PRESETS))
        c = _ui.console()
        for name, (_, doc) in scripts.PRESETS.items():
            c.print(_ui._line((f"  {name:<8}", _ui.BONE), (doc, _ui.ASH)))
        preset = input("preset: ").strip()
    out = a.output or f"infer_{preset}.py"
    scripts.generate(preset, a.file, out, a.overwrite)
    c = _ui.console()
    c.print(_ui._line(("wrote ", _ui.ASH), (out, f"bold {_ui.BONE}"), (f"  ({preset} preset)", _ui.ASH)))
    hint = {"image": "python {o} photo.jpg", "folder": "python {o} photos/", "video": "python {o} clip.mp4",
            "webcam": "python {o}"}[preset]
    c.print(_ui._line(("run   ", _ui.ASH), (hint.format(o=out), _ui.BONE)))


def _benchmark(a) -> None:
    from .serialization import nbm
    model = nbm.load(a.file)
    if a.dataset is None:
        res = model.benchmark(imgsz=a.imgsz, device=a.device)
    else:
        try:
            import felix
        except ImportError:
            raise WorkflowError("evaluating needs Felix for datasets: install the `felix` package") from None
        ds = felix.load(a.dataset)
        sub = getattr(ds, a.split) if hasattr(ds, a.split) else ds
        res = model.benchmark(sub, imgsz=a.imgsz, device=a.device, batch_size=a.batch_size)
    if a.save:
        res.save(a.save)
    if a.confusion and hasattr(res, "plot_confusion_matrix"):
        res.plot_confusion_matrix(a.confusion)


def _export(a) -> None:
    from .serialization import export, nbm
    out = a.output or os.path.splitext(a.file)[0] + "." + a.format
    if os.path.splitext(out)[1].lower() not in (".pt", ".onnx"):
        raise WorkflowError(f"cannot export to {os.path.splitext(out)[1] or out!r}; use .pt (TorchScript) or .onnx")
    if os.path.exists(out) and not a.overwrite:
        raise WorkflowError(f"{out} already exists (pass --overwrite)")
    panel = _ui.Panel("")
    panel.title = panel.join("Workflow export", f"{a.file} → {out}" if panel.uni else f"{a.file} -> {out}")
    panel.sub = panel.join("Exporter running", "TorchScript" if out.endswith(".pt") else f"ONNX opset {a.opset}")
    row = panel.row("export", 1)
    t0 = time.time()
    with panel:
        model = nbm.load(a.file)
        row.label = "tracing"
        row.advance(0)
        export.export(model, out, size=a.size, device=a.device, dynamic=a.dynamic, opset=a.opset)
        row.done()
        row.stats = panel.join(f"input {model.input}" if not a.size else f"input size {a.size}",
                               f"{os.path.getsize(out) / 2**20:.1f} MB")
        row.foot = panel.join(f"took {time.time() - t0:.1f}s", f"written to {out}")


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="workflow", description="Workflow CNN framework.")
    p.add_argument("--version", action="version", version=f"workflow {__version__}")
    sub = p.add_subparsers(dest="cmd", metavar="command")
    s = sub.add_parser("info", help="show a .nbm model's summary")
    s.add_argument("file")
    sub.add_parser("devices", help="list available devices (and what 'auto' picks)")
    s = sub.add_parser("script", help="generate an inference script (image, folder, video, webcam)")
    s.add_argument("file")
    s.add_argument("--preset", choices=["image", "folder", "video", "webcam"])
    s.add_argument("-o", "--output", help="script path (default: infer_<preset>.py)")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("benchmark", help="architecture benchmark, or evaluation with --dataset")
    s.add_argument("file")
    s.add_argument("--dataset", help="Felix dataset (folder or .felix) to evaluate on")
    s.add_argument("--split", choices=["train", "val", "test"], default="test")
    s.add_argument("--imgsz", type=int)
    s.add_argument("--batch-size", type=int, default=16)
    s.add_argument("--device")
    s.add_argument("--save", help="write results to .json or .csv")
    s.add_argument("--confusion", help="save the confusion matrix image (evaluation only)")
    s = sub.add_parser("export", help="convert a .nbm to TorchScript (.pt) or ONNX (.onnx)")
    s.add_argument("file")
    s.add_argument("-o", "--output", help="output path (default: next to the .nbm)")
    s.add_argument("--format", choices=["pt", "onnx"], default="pt", help="used when -o is not given")
    s.add_argument("--size", type=int, nargs="+", metavar="N", help="input size: N or H W (default: the model's)")
    s.add_argument("--device", default="cpu", help="device to trace on (default: cpu)")
    s.add_argument("--dynamic", action="store_true", help="ONNX: allow variable height/width")
    s.add_argument("--opset", type=int, default=17, help="ONNX opset (default 17)")
    s.add_argument("--overwrite", action="store_true")
    return p


def main(argv=None) -> int:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except Exception:
            pass
    p = build_parser()
    a = p.parse_args(argv)
    try:
        if a.cmd == "info":
            _info(a.file)
        elif a.cmd == "devices":
            _devices()
        elif a.cmd == "export":
            _export(a)
        elif a.cmd == "script":
            _script(a)
        elif a.cmd == "benchmark":
            _benchmark(a)
        else:
            _ui.banner(__version__, [("info", "summarise a .nbm model"), ("export", ".nbm → .pt / .onnx"),
                                     ("script", "inference script: image, folder, video, webcam"),
                                     ("benchmark", "speed, or accuracy with --dataset"),
                                     ("devices", "list cpu / cuda / mps")])
    except WorkflowError as e:
        _ui.error(str(e))
        return 1
    except KeyboardInterrupt:
        _ui.error("interrupted")
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
