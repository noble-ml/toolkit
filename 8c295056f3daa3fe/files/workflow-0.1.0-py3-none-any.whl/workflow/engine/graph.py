"""Routing validation, execution planning and shape inference.

``compile_plan`` checks names and references and decides what every stage reads
and when each tensor can be freed. ``infer`` runs shape inference over the plan.
"""
from __future__ import annotations

import difflib
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from ..errors import RoutingError, ShapeError
from ..op import Shape
from ..stage import RESERVED, Stage


@dataclass
class Step:
    stage: Stage
    src: Optional[str]            # tensor name fed to the stage's first op (None: it names its inputs)
    publishes: Tuple[str, ...]
    free: Tuple[str, ...] = ()    # names that are dead after this step


@dataclass
class Plan:
    steps: List[Step]
    outputs: Tuple[str, ...]


@dataclass
class Record:
    stage: str
    index: int                    # 1-based position inside the stage
    op: object
    inputs: Tuple[str, ...]
    in_shapes: Tuple[Shape, ...]
    out_shapes: Tuple[Shape, ...]


def compile_plan(stages: Sequence[Stage]) -> Plan:
    seen: Dict[str, int] = {}
    for i, s in enumerate(stages):
        if s.name in seen:
            raise RoutingError(f"duplicate stage name '{s.name}' (stages {seen[s.name] + 1} and {i + 1}); "
                               "every stage needs a unique name")
        seen[s.name] = i
    pubs = _published(stages)
    srcs, implicit = _sources(stages)
    _check_refs(stages, pubs, implicit)
    steps = [Step(s, srcs[i], s.publishes()) for i, s in enumerate(stages)]
    outputs = steps[-1].publishes
    last: Dict[str, int] = {}
    for i, st in enumerate(steps):
        for n in st.publishes:
            last[n] = i
        for n in ([st.src] if st.src else []) + [n for _, op in enumerate(st.stage.ops) for n in (op.inputs or ())]:
            last[n] = i
    for i, st in enumerate(steps):
        st.free = tuple(n for n, j in last.items() if j == i and n not in outputs)
    return Plan(steps, outputs)


def _published(stages: Sequence[Stage]) -> Dict[str, int]:
    pubs: Dict[str, int] = {}
    for i, s in enumerate(stages):
        for n in s.publishes():
            if n == RESERVED:
                raise RoutingError(f"Stage '{s.name}' publishes '{n}', which is reserved for the model input")
            if n in pubs:
                raise RoutingError(f"the name '{n}' is published by both stage '{stages[pubs[n]].name}' and "
                                   f"stage '{s.name}'; published names must be unique")
            pubs[n] = i
    return pubs


def _sources(stages: Sequence[Stage]):
    srcs: List[Optional[str]] = []
    implicit: List[bool] = []  # does stage i depend on stage i-1 through the automatic flow?
    for i, s in enumerate(stages):
        if s.input is not None:
            srcs.append(s.input); implicit.append(False)
        elif s.ops[0].inputs:
            srcs.append(None); implicit.append(False)
        elif i == 0:
            srcs.append(RESERVED); implicit.append(False)
        else:
            prev = stages[i - 1].publishes()
            if len(prev) > 1:
                raise RoutingError(
                    f"Stage '{s.name}' follows stage '{stages[i - 1].name}', which publishes several outputs "
                    f"{prev}. Say which one it reads: Stage('{s.name}', ..., input='{prev[0]}') or give its "
                    f"first operation inputs=(...). Workflow never picks a feature map by position.")
            srcs.append(prev[0]); implicit.append(True)
    return srcs, implicit


def _check_refs(stages: Sequence[Stage], pubs: Dict[str, int], implicit: List[bool]) -> None:
    multi = {s.name: s.publishes() for s in stages if len(s.publishes()) > 1 or s.publishes()[0] != s.name}
    deps: List[set] = [set() for _ in stages]
    for i, s in enumerate(stages):
        if implicit[i]:
            deps[i].add(i - 1)
        for name, where in s.refs():
            if name == RESERVED:
                continue
            if name not in pubs:
                if name in multi:
                    raise RoutingError(f"{where} refers to '{name}', but stage '{name}' publishes several "
                                       f"outputs {multi[name]}; refer to one of them by name")
                avail = [RESERVED] + [n for n, j in pubs.items() if j < i]
                close = difflib.get_close_matches(name, avail, n=1, cutoff=0.4)
                raise RoutingError(f"{where} refers to unknown name '{name}'"
                                   + (f" (did you mean '{close[0]}'?)" if close else "")
                                   + f". Names available here: {', '.join(avail)}")
            deps[i].add(pubs[name])
    cycle = _find_cycle(deps)
    if cycle:
        path = " → ".join(stages[i].name for i in cycle)
        raise RoutingError(f"circular dependency between stages (each one needs the next): {path}. "
                           "A stage can only use outputs of stages defined before it.")
    for i, s in enumerate(stages):
        for name, where in s.refs():
            if name != RESERVED and pubs[name] > i:
                raise RoutingError(f"{where} refers to '{name}', which is produced by stage "
                                   f"'{stages[pubs[name]].name}' later in the model. Stages run in the order "
                                   "they are listed; move that stage earlier.")


def _find_cycle(deps: List[set]) -> Optional[List[int]]:
    color = [0] * len(deps)  # 0 new, 1 on stack, 2 done
    stack: List[int] = []

    def visit(n: int) -> Optional[List[int]]:
        color[n] = 1
        stack.append(n)
        for m in sorted(deps[n]):
            if color[m] == 1:
                return stack[stack.index(m):] + [m]
            if color[m] == 0:
                found = visit(m)
                if found:
                    return found
        stack.pop()
        color[n] = 2
        return None

    for n in range(len(deps)):
        if color[n] == 0:
            found = visit(n)
            if found:
                return found
    return None


def _is_multi(out) -> bool:
    return bool(out) and isinstance(out[0], tuple)


def infer(plan: Plan, input_shape: Shape) -> Tuple[Dict[str, Shape], List[Record]]:
    """Propagate shapes through the plan. Returns (shape of every published name, per-op records)."""
    shapes: Dict[str, Shape] = {RESERVED: tuple(input_shape)}
    records: List[Record] = []
    for st in plan.steps:
        shape = shapes[st.src] if st.src else None
        outs: Tuple[Shape, ...] = ()
        for i, op in enumerate(st.stage.ops):
            names = tuple(op.inputs) if op.inputs else ((st.src,) if i == 0 else ("·",))
            ins = tuple(shapes[n] for n in op.inputs) if op.inputs else (shape,)
            try:
                out = op.infer(*ins)
            except ShapeError as e:
                src = f" (output of '{st.src}')" if i == 0 and st.src and not op.inputs else ""
                raise e.at(f"op {i + 1} {type(op).__name__}{src}").at(f"Stage '{st.stage.name}'") from None
            multi = _is_multi(out)
            outs = tuple(out) if multi else (out,)
            declared = tuple(op.outputs) if op.outputs else None
            where = f"Stage '{st.stage.name}', op {i + 1} {type(op).__name__}"
            if declared is not None and len(declared) != len(outs):
                raise RoutingError(f"{where} declares {len(declared)} outputs {declared} but produces {len(outs)}")
            if declared is None and multi:
                raise RoutingError(f"{where} produces {len(outs)} outputs; name them with outputs=(...)")
            records.append(Record(st.stage.name, i + 1, op, names, tuple(s for s in ins if s), outs))
            shape = None if multi else out
        for n, sh in zip(st.publishes, outs):
            shapes[n] = sh
    return shapes, records
