"""Computation-graph drawing (PNG / SVG) with no external tools.

``build`` turns a Model into a list of drawing primitives; ``render_png`` (Pillow) and
``render_svg`` draw them. The picture shows stages as cards, every operation as a row,
sequential flow as arrows, blocks with their real branches (residual shortcuts, CSP/SPPF
splits and merges), and named routing as coloured edges between stages with the tensor names.
"""
from __future__ import annotations

import html
import os
from typing import List, Tuple

from ..blocks import CSP, SPPF, Bottleneck, Residual
from ..errors import WorkflowError
from ..layers import AvgPool2D, BatchNorm2D, Conv2D, MaxPool2D, Upsample
from ..stage import RESERVED

BG, CARD, STROKE = "#0b0b0b", "#141414", "#3d3d3d"
BONE, ASH, RED = "#d9d4c7", "#8a8a8a", "#c1121f"
M, ROW, GAP, HEAD, CGAP, PAD, LANE = 28, 26, 8, 38, 36, 12, 14


class Scene:
    def __init__(self):
        self.items: List[tuple] = []
        self.w = self.h = 0

    def rect(self, x, y, w, h, fill=CARD, stroke=STROKE, r=6, sw=1):
        self.items.append(("rect", x, y, w, h, fill, stroke, r, sw))

    def text(self, x, y, s, size=12, color=BONE, anchor="start", bold=False):
        self.items.append(("text", x, y, s, size, color, anchor, bold))

    def line(self, pts, color=ASH, w=1.2, arrow=False, dash=False):
        self.items.append(("line", list(pts), color, w, arrow, dash))

    def circle(self, x, y, r, fill=CARD, stroke=ASH):
        self.items.append(("circle", x, y, r, fill, stroke))


def _tw(s, size):  # monospace width estimate shared by layout and SVG
    return 0.6 * size * len(s)


def _shape(s):
    return "(" + ", ".join(map(str, s)) + ")"


def label(op) -> str:
    if isinstance(op, Conv2D):
        k, s, p, d = op.kernel_size, op.stride, op.padding, op.dilation
        t = f"Conv2D {op.in_channels}→{op.out_channels} k{k[0]}" + (f"x{k[1]}" if k[0] != k[1] else "")
        t += f" s{s[0]}" if s != (1, 1) else ""
        t += f" p{p[0]}" if p != (0, 0) else ""
        return t + (f" d{d[0]}" if d != (1, 1) else "")
    if isinstance(op, BatchNorm2D):
        return f"BatchNorm2D {op.num_features}"
    if isinstance(op, (MaxPool2D, AvgPool2D)):
        return f"{type(op).__name__} k{op.kernel_size[0] if isinstance(op.kernel_size, tuple) else op.kernel_size}"
    if isinstance(op, Upsample):
        return f"Upsample ×{op.factor}"
    return type(op).__name__


def _cbs(seq, name="Conv·BN·SiLU") -> str:
    c = next(m for m in seq if isinstance(m, Conv2D))
    k = c.kernel_size[0]
    return f"{name} {c.in_channels}→{c.out_channels} k{k}" + (f" s{c.stride[0]}" if c.stride[0] > 1 else "")


def describe(op):
    """(pre rows, parallel paths, merge label, post rows) for blocks with real branching, else None."""
    if isinstance(op, Residual):
        branch = [label(o) for o in op.branch]
        short = [label(o) for o in op.shortcut] if op.shortcut is not None else []
        return [], [branch, short], "add", []
    if isinstance(op, Bottleneck):
        return [], [[label(o) for o in op.body], []] if op.shortcut else [[label(o) for o in op.body]], "add", []
    if isinstance(op, CSP):
        n = len(op.m)
        return [], [[_cbs(op.cv1), f"Bottleneck ×{n}"], [_cbs(op.cv2)]], "concat", [_cbs(op.cv3)]
    if isinstance(op, SPPF):
        k = op.pool.kernel_size[0]
        return [_cbs(op.cv1)], [[], [f"MaxPool k{k}"], [f"MaxPool k{k} ×2"], [f"MaxPool k{k} ×3"]], "concat", [_cbs(op.cv2)]
    return None


_INTERNAL = {"FPN": ["1×1 lateral per input", "top-down: upsample + add", "3×3 smooth per level"],
             "PAN": ["1×1 lateral (if needed)", "bottom-up: stride-2 conv + add", "3×3 smooth per level"],
             "BBoxHead": ["per level: 2× (3×3 Conv·BN·SiLU)", "1×1 conv → box(4) obj(1) classes"]}


def build(model, detail: str = "ops") -> Scene:
    if detail not in ("ops", "stages"):
        raise WorkflowError("detail must be 'ops' or 'stages'")
    S = Scene()
    recs = {}
    for r in model._records:
        recs.setdefault(r.stage, []).append(r)
    shapes = model._shapes
    widest = max([len(label(r.op)) for rs in recs.values() for r in rs] + [28])
    CW = max(440, int(_tw("x" * widest, 12) + 150))
    x0, cx = M, M + CW / 2
    anchors, wants = {}, []            # name -> (x, y);  (name, x, y) consumers
    y = M

    # model input
    S.rect(cx - 110, y, 220, 30, CARD, STROKE, 15)
    S.text(cx, y + 15, f"input  {_shape(model.input)}", 12, BONE, "middle")
    anchors[RESERVED] = (cx + 110, y + 15)
    y += 30
    prev_single = RESERVED

    for st in model._plan.steps:
        name, rs = st.stage.name, recs[st.stage.name]
        top = y + CGAP
        S.line([(cx, y), (cx, top)], ASH, 1.4, arrow=True)
        idx = len(S.items)
        cy = top + HEAD
        pubs = st.publishes
        right = ", ".join(pubs) if len(pubs) > 1 else _shape(shapes[pubs[0]])
        S.text(x0 + PAD, top + HEAD / 2, name, 14, BONE, bold=True)
        S.text(x0 + CW - PAD, top + HEAD / 2, ("→ " if len(pubs) > 1 else "") + right, 11, ASH, "end")
        if len(pubs) == 1:
            anchors[pubs[0]] = (x0 + CW, top + HEAD / 2)
        explicit = st.stage.input is not None and st.stage.input != prev_single
        if explicit or (st.src is None and False):
            wants.append((st.stage.input, x0 + CW, top + HEAD / 2))
        ix, iw = x0 + PAD, CW - 2 * PAD
        if detail == "ops":
            for k, r in enumerate(rs):
                cy += GAP if k else GAP // 2
                cy += _draw_op(S, r, ix, cy, iw, anchors, wants)
        else:
            plain: List[str] = []
            for r in rs + [None]:
                if r is None or r.op.inputs:
                    if plain:
                        S.rect(ix, cy + GAP // 2, iw, 20, CARD, STROKE, 5)
                        S.text(ix + 8, cy + GAP // 2 + 10, _fit(" · ".join(plain), iw - 16), 10, ASH)
                        cy += 20 + GAP
                        plain = []
                    if r is not None:
                        cy += GAP // 2
                        cy += _draw_op(S, r, ix, cy, iw, anchors, wants)
                else:
                    plain.append(type(r.op).__name__)
        h = cy + PAD - top
        S.items.insert(idx, ("rect", x0, top, CW, h, CARD, STROKE, 8, 1))
        y = top + h
        prev_single = pubs[0] if len(pubs) == 1 else None
    out = ", ".join(f"{n} {_shape(s)}" for n, s in model.output_shapes.items())
    S.line([(cx, y), (cx, y + 22)], ASH, 1.4, arrow=True)
    S.text(cx, y + 36, "output  " + out, 11, BONE, "middle")
    y += 52

    lanes: List[List[Tuple[float, float]]] = []
    for name, tx, ty in sorted(wants, key=lambda w: w[2]):
        if name not in anchors:
            continue
        px, py = anchors[name]
        lo, hi = min(py, ty) - 4, max(py, ty) + 4
        lane = next((i for i, iv in enumerate(lanes) if all(hi < a or lo > b for a, b in iv)), None)
        if lane is None:
            lanes.append([])
            lane = len(lanes) - 1
        lanes[lane].append((lo, hi))
        lx = x0 + CW + 18 + lane * LANE
        S.line([(px, py), (lx, py), (lx, ty), (tx, ty)], RED, 1.4, arrow=True)
        S.text(px + 6, py - 6, name, 10, RED)
    S.w = int(x0 + CW + 18 + max(1, len(lanes)) * LANE + 70)
    S.h = int(y + M)
    return S


def _fit(s, w, size=10):
    n = int(w / (0.6 * size))
    return s if len(s) <= n else s[: max(1, n - 1)] + "…"


def _draw_op(S, r, x, y, w, anchors, wants) -> float:
    op = r.op
    desc = describe(op)
    nin, nout = len(op.inputs or ()), len(op.outputs or ())
    if desc is None:
        h = max(ROW, 14 * (nin + nout) + 12)
        S.rect(x, y, w, h, "#101010", STROKE, 5)
        S.text(x + 10, y + 13, label(op), 12, BONE)
        notes = _INTERNAL.get(type(op).__name__, [])
        if notes and (nin or nout):
            for i, t in enumerate(notes):
                S.text(x + 10, y + 28 + 12 * i, t, 9, ASH)
            h = max(h, 30 + 12 * len(notes) + 4)
            S.items[-len(notes) - 2] = ("rect", x, y, w, h, "#101010", STROKE, 5, 1)
        if not (nin or nout):
            out = r.out_shapes[0] if len(r.out_shapes) == 1 else None
            if out:
                S.text(x + w - 10, y + 13, _shape(out), 11, ASH, "end")
        k = 0
        for n in op.inputs or ():
            py = y + 12 + 14 * k
            S.circle(x + w, py, 3, RED, RED)
            S.text(x + w - 9, py, n, 10, RED, "end")
            wants.append((n, x + w, py))
            k += 1
        for n, sh in zip(op.outputs or (), r.out_shapes):
            py = y + 12 + 14 * k
            S.circle(x + w, py, 3, BONE, BONE)
            S.text(x + w - 9, py, f"{n} {_shape(sh)}", 10, BONE, "end")
            anchors[n] = (x + w, py)
            k += 1
        return h
    pre, paths, merge, post = desc
    top = y
    S.text(x + 10, y + 13, label(op), 12, BONE, bold=True)
    S.text(x + w - 10, y + 13, _shape(r.out_shapes[0]), 11, ASH, "end")
    cy = y + 26
    cxm = x + w / 2
    for t in pre:
        cy += _row(S, cxm, cy, w - 40, t) + 6
    n = len(paths)
    colw = (w - 16) / n
    tops = cy + 14
    ends, hmax = [], 0
    for i, rows in enumerate(paths):
        px = x + 8 + colw * (i + 0.5)
        S.line([(cxm, cy), (cxm, cy + 7), (px, cy + 7), (px, tops)], ASH, 1.1)
        yy = tops
        for t in rows:
            yy += _row(S, px, yy, colw - 10, t) + 8
        if not rows:
            S.text(px + 4, yy + 8, "skip", 9, ASH)
            yy += 18
        ends.append((px, yy))
        hmax = max(hmax, yy)
    by = hmax + 4
    for px, yy in ends:
        S.line([(px, yy - (8 if yy > tops else 0)), (px, by), (cxm, by), (cxm, by + 8)], ASH, 1.1)
    S.circle(cxm, by + 16, 10, CARD, ASH)
    S.text(cxm, by + 16, "+" if merge == "add" else "©", 11, BONE, "middle")
    cy = by + 28
    for t in post:
        S.line([(cxm, cy - 2), (cxm, cy + 4)], ASH, 1.1)
        cy += 4 + _row(S, cxm, cy + 4, w - 40, t)
    h = cy + 8 - top
    S.items.insert(len(S.items) - 0, ("rect", x, top, w, h, "#101010", STROKE, 5, 1))
    # move the container rect below its content
    S.items.insert(next(i for i in range(len(S.items)) if S.items[i][0] == "text" and S.items[i][1] == x + 10 and S.items[i][2] == top + 13), S.items.pop())
    return h


def _row(S, cx, y, w, text) -> float:
    w = max(80, w)
    S.rect(cx - w / 2, y, w, 22, CARD, STROKE, 4)
    S.text(cx, y + 11, _fit(text, w - 8), 10, BONE, "middle")
    return 22


# ----------------------------------------------------------------- renderers
def _fonts(size):
    from PIL import ImageFont
    for name in ("Menlo.ttc", "DejaVuSansMono.ttf", "Consolas.ttf", "LiberationMono-Regular.ttf",
                 "/System/Library/Fonts/Menlo.ttc", "/System/Library/Fonts/Monaco.ttf", "cour.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


def render_png(scene: Scene, scale: int = 2):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        raise WorkflowError("drawing graphs needs Pillow (`pip install Pillow`)") from None
    S = scale
    img = Image.new("RGB", (scene.w * S, scene.h * S), BG)
    d = ImageDraw.Draw(img)
    cache = {}
    for it in scene.items:
        k = it[0]
        if k == "rect":
            _, x, y, w, h, fill, stroke, r, sw = it
            d.rounded_rectangle([x * S, y * S, (x + w) * S, (y + h) * S], r * S, fill=fill, outline=stroke, width=max(1, int(sw * S / 1.5)))
        elif k == "circle":
            _, x, y, r, fill, stroke = it
            d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S], fill=fill, outline=stroke, width=S)
        elif k == "line":
            _, pts, color, w, arrow, dash = it
            P = [(a * S, b * S) for a, b in pts]
            d.line(P, fill=color, width=max(1, int(w * S)), joint="curve")
            if arrow:
                (x1, y1), (x2, y2) = P[-2], P[-1]
                dx, dy = x2 - x1, y2 - y1
                n = max(1e-6, (dx * dx + dy * dy) ** 0.5)
                ux, uy = dx / n, dy / n
                a = 5 * S
                d.polygon([(x2, y2), (x2 - ux * a * 1.6 - uy * a, y2 - uy * a * 1.6 + ux * a),
                           (x2 - ux * a * 1.6 + uy * a, y2 - uy * a * 1.6 - ux * a)], fill=color)
        else:
            _, x, y, s, size, color, anchor, bold = it
            f = cache.setdefault(size, _fonts(int(size * S * 1.0)))
            tw = d.textlength(s, font=f)
            bb = f.getbbox("Ag")
            px = x * S - (tw if anchor == "end" else tw / 2 if anchor == "middle" else 0)
            py = y * S - (bb[1] + bb[3]) / 2
            d.text((px, py), s, font=f, fill=color)
            if bold:
                d.text((px + 0.7 * S, py), s, font=f, fill=color)
    return img


def render_svg(scene: Scene) -> str:
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{scene.w}" height="{scene.h}" viewBox="0 0 {scene.w} {scene.h}">',
         f'<rect width="100%" height="100%" fill="{BG}"/>',
         '<defs>' + ''.join(f'<marker id="a{c[1:]}" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">'
                            f'<path d="M0,0 L8,4 L0,8 z" fill="{c}"/></marker>' for c in (ASH, RED)) + '</defs>']
    for it in scene.items:
        k = it[0]
        if k == "rect":
            _, x, y, w, h, fill, stroke, r, sw = it
            o.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
        elif k == "circle":
            _, x, y, r, fill, stroke = it
            o.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}"/>')
        elif k == "line":
            _, pts, color, w, arrow, dash = it
            p = " ".join(f"{a},{b}" for a, b in pts)
            m = f' marker-end="url(#a{color[1:]})"' if arrow else ""
            o.append(f'<polyline points="{p}" fill="none" stroke="{color}" stroke-width="{w}"{m}/>')
        else:
            _, x, y, s, size, color, anchor, bold = it
            o.append(f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" text-anchor="{anchor}" '
                     f'dominant-baseline="central" font-family="Menlo,Consolas,DejaVu Sans Mono,monospace"'
                     f'{" font-weight=\'bold\'" if bold else ""}>{html.escape(s)}</text>')
    o.append("</svg>")
    return "\n".join(o)


def export(model, path, detail="ops", scale=2) -> str:
    path = os.fspath(path)
    ext = os.path.splitext(path)[1].lower()
    if ext not in (".png", ".svg"):
        raise WorkflowError(f"cannot export a graph to {ext or path!r}; use .png or .svg")
    scene = build(model, detail)
    if ext == ".svg":
        with open(path, "w", encoding="utf-8") as f:
            f.write(render_svg(scene))
    else:
        render_png(scene, scale).save(path)
    return path
