"""``model.benchmark()``: architecture profiling, and evaluation on a dataset."""
from __future__ import annotations

import csv
import json
import os
import time
from dataclasses import dataclass
from typing import Dict, List, Optional

import torch

from .. import _ui
from ..errors import WorkflowError
from ..training import data
from ..training.trainer import _sync, run_eval


def _resolve_device(model, device):
    if device is not None:
        model.device(device)
    elif not model._device_set:
        model.device("auto")
    return model.device()


def _save_table(path, d: Dict):
    path = os.fspath(path)
    ext = os.path.splitext(path)[1].lower()
    if ext == ".json":
        with open(path, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1, default=lambda o: o.tolist() if hasattr(o, "tolist") else str(o))
    elif ext == ".csv":
        with open(path, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["metric", "value"])
            for k, v in d.items():
                if isinstance(v, (int, float, str)):
                    w.writerow([k, v])
            for name, pc in (d.get("per_class") or {}).items():
                w.writerow([f"ap50[{name}]", pc["ap50"]])
                w.writerow([f"ap50_95[{name}]", pc["ap50_95"]])
    else:
        raise WorkflowError(f"cannot save results as {ext or path!r}; use .json or .csv")
    return path


@dataclass
class ArchitectureBenchmark:
    """Architecture-level performance: it says nothing about accuracy."""
    parameters: int
    trainable: int
    macs: int
    flops: int
    weights_mb: float
    activations_mb: float
    peak_mb: float
    device: str
    imgsz: tuple
    latency_ms: float            # batch 1, forward pass only
    fps: float                   # 1000 / latency_ms
    batch_size: int
    throughput: float            # images / s at ``batch_size``
    params_per_op: Dict[str, int]

    def to_dict(self) -> Dict:
        return dict(self.__dict__)

    def save(self, path) -> str:
        return _save_table(path, self.to_dict())

    def show(self) -> None:
        c = _ui.console()
        c.print(_ui._line(("Architecture benchmark", f"bold {_ui.BONE}"),
                          (f"  {self.device} · {self.imgsz[1]}x{self.imgsz[0]} · forward pass only (no NMS)", _ui.ASH)))
        c.print()
        rows = [("parameters", f"{self.parameters:,}"), ("FLOPs", f"{self.flops / 1e9:,.2f} G"),
                ("MACs", f"{self.macs / 1e9:,.2f} G"), ("weights", f"{self.weights_mb:,.1f} MB"),
                ("activations", f"{self.activations_mb:,.1f} MB/img (training)"),
                ("inference peak", f"{self.peak_mb:,.1f} MB/img"),
                ("latency", f"{self.latency_ms:,.2f} ms (batch 1)"), ("FPS", f"{self.fps:,.1f}"),
                (f"throughput", f"{self.throughput:,.1f} img/s (batch {self.batch_size})")]
        _ui.table(["metric", "value"], rows, console_=c)


def architecture(model, imgsz=None, batch_size: int = 8, device: Optional[str] = None,
                 warmup: int = 5, iters: int = 20, quiet: bool = False) -> ArchitectureBenchmark:
    dev = _resolve_device(model, device)
    size = (imgsz, imgsz) if isinstance(imgsz, int) else tuple(imgsz) if imgsz else (model.input[1], model.input[2])
    a = model.analyze((model.input[0], *size))
    was = model.training
    model.eval()

    def timed(bs):
        x = torch.randn(bs, model.input[0], *size, device=dev)
        with torch.inference_mode():
            for _ in range(warmup):
                model(x)
            _sync(dev)
            t = time.perf_counter()
            for _ in range(iters):
                model(x)
            _sync(dev)
        return (time.perf_counter() - t) / iters

    try:
        t1, tb = timed(1), timed(batch_size)
    finally:
        model.train(was)
    mb = lambda b: b / 2**20
    res = ArchitectureBenchmark(
        a.params, a.trainable, a.macs, a.flops, mb(a.param_bytes), mb(a.act_bytes), mb(a.peak_bytes), str(dev), size,
        1000 * t1, 1 / t1, batch_size, batch_size / tb,
        {f"{o.stage}.{o.index} {type(o.op).__name__}": o.trainable + o.non_trainable for o in a.ops})
    if not quiet:
        res.show()
    return res


@dataclass
class EvaluationResults:
    """Accuracy and speed on a dataset split."""
    images: int
    precision: float
    recall: float
    f1: float
    map50: float
    map50_95: float
    conf_threshold: float
    per_class: Dict[str, Dict[str, float]]
    confusion_matrix: torch.Tensor
    class_names: List[str]
    latency_ms: float
    fps: float
    device: str

    def to_dict(self) -> Dict:
        d = dict(self.__dict__)
        d["confusion_matrix"] = self.confusion_matrix.tolist()
        return d

    def save(self, path) -> str:
        return _save_table(path, self.to_dict())

    def show(self) -> None:
        c = _ui.console()
        c.print(_ui._line(("Evaluation", f"bold {_ui.BONE}"),
                          (f"  {self.images:,} images · {self.device} · P/R/F1 at conf {self.conf_threshold:.2f}", _ui.ASH)))
        c.print()
        _ui.table(["metric", "value"], [
            ("mAP50", f"{self.map50:.3f}"), ("mAP50-95", f"{self.map50_95:.3f}"), ("precision", f"{self.precision:.3f}"),
            ("recall", f"{self.recall:.3f}"), ("F1", f"{self.f1:.3f}"),
            ("latency", f"{self.latency_ms:,.2f} ms/img (model + decode + NMS)"), ("FPS", f"{self.fps:,.1f}")], console_=c)
        c.print()
        _ui.table(["class", "AP50", "AP50-95", "instances"],
                  [(n, f"{v['ap50']:.3f}", f"{v['ap50_95']:.3f}", f"{v['instances']:,}") for n, v in self.per_class.items()],
                  right=(1, 2, 3), console_=c)

    def plot_confusion_matrix(self, path=None):
        """Heatmap of the confusion matrix (rows: predicted, columns: true; last row/column: background).
        Returns a PIL image and saves it if ``path`` is given."""
        from PIL import Image, ImageDraw, ImageFont
        m = self.confusion_matrix
        n = m.shape[0]
        names = list(self.class_names) + ["background"]
        cell, left, top = 56, 130, 70
        img = Image.new("RGB", (max(left + n * cell + 20, 560), top + n * cell + 20), "#0b0b0b")
        d = ImageDraw.Draw(img)
        try:
            font = ImageFont.load_default(11)
        except TypeError:
            font = ImageFont.load_default()
        col = m / m.sum(0, keepdim=True).clamp(min=1)          # normalise by true class
        for i in range(n):
            for j in range(n):
                v = col[i, j].item()
                shade = int(20 + 200 * v)
                x, y = left + j * cell, top + i * cell
                fill = (shade, shade // 3, shade // 3) if i != j else (shade // 2, shade, shade // 2)
                d.rectangle([x, y, x + cell - 2, y + cell - 2], fill=fill)
                d.text((x + cell / 2, y + cell / 2), str(int(m[i, j])), fill="#d9d4c7", font=font, anchor="mm")
            d.text((left - 8, top + i * cell + cell / 2), names[i][:16], fill="#8a8a8a", font=font, anchor="rm")
            d.text((left + i * cell + cell / 2, top - 8), names[i][:9], fill="#8a8a8a", font=font, anchor="ms")
        d.text((left, 14), "confusion matrix   rows: predicted   columns: true", fill="#d9d4c7", font=font)
        if path is not None:
            img.save(os.fspath(path))
        return img


def evaluate(model, dataset, imgsz=None, batch_size: int = 16, conf: float = 0.001, iou: float = 0.6,
             device: Optional[str] = None, workers: Optional[int] = None, quiet: bool = False) -> EvaluationResults:
    ds = data.as_dataset(dataset)
    if hasattr(ds, "splits"):          # a whole dataset was given: evaluate its test split (else validation)
        ds = ds.test if len(ds.test) else ds.val if len(ds.val) else ds
    if len(ds) == 0:
        raise WorkflowError("the dataset split to evaluate is empty")
    head = model.head()
    names = ds.classes or model.class_names or [str(i) for i in range(head.classes)]
    if len(names) != head.classes:
        raise WorkflowError(f"the dataset has {len(names)} classes but the model's BBoxHead has {head.classes}")
    dev = _resolve_device(model, device)
    size = (imgsz, imgsz) if isinstance(imgsz, int) else tuple(imgsz) if imgsz else (model.input[1], model.input[2])
    if not model.history and model._train_state is None and not quiet:
        print("note: this model has not been trained; the numbers below measure random weights")
    loader = data.loader(ds, size, batch_size, False, False, workers, dev)
    m, ms = run_eval(model, loader, size, names, conf=conf, iou=iou, device=dev)
    res = EvaluationResults(len(ds), m["precision"], m["recall"], m["f1"], m["map50"], m["map50_95"], m["conf"],
                            m["per_class"], m["confusion_matrix"], list(names), ms, 1000 / max(ms, 1e-9), str(dev))
    if not quiet:
        res.show()
    return res
