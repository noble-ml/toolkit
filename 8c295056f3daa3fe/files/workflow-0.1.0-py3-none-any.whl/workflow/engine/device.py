"""Device selection and speed flags (CUDA → MPS → CPU)."""
from __future__ import annotations

from typing import Dict, List

import torch

from ..errors import DeviceError


def available() -> List[Dict[str, str]]:
    """Every usable device, with a short description."""
    out = [{"name": "cpu", "info": f"{torch.get_num_threads()} threads"}]
    if torch.cuda.is_available():
        for i in range(torch.cuda.device_count()):
            p = torch.cuda.get_device_properties(i)
            out.append({"name": f"cuda:{i}", "info": f"{p.name} · {p.total_memory / 2**30:.1f} GB"})
    if torch.backends.mps.is_available():
        out.append({"name": "mps", "info": "Apple GPU"})
    return out


def resolve(name: str = "auto") -> torch.device:
    """'auto' prefers CUDA, then MPS, then CPU. Unavailable explicit requests raise DeviceError."""
    if isinstance(name, torch.device):
        name = str(name)
    key = str(name).lower().strip()
    if key == "auto":
        if torch.cuda.is_available():
            return torch.device("cuda", torch.cuda.current_device())
        if torch.backends.mps.is_available():
            return torch.device("mps")
        return torch.device("cpu")
    if key == "gpu":
        key = "cuda"
    kind, _, idx = key.partition(":")
    if kind == "cpu":
        return torch.device("cpu")
    if kind == "cuda":
        if not torch.cuda.is_available():
            why = ("this PyTorch build has no CUDA support (install a CUDA build of torch)"
                   if torch.version.cuda is None else "no CUDA device or driver was detected")
            raise DeviceError(f"device {name!r} is not available: {why}. Available: {_names()}")
        n = torch.cuda.device_count()
        i = int(idx) if idx.isdigit() else torch.cuda.current_device()
        if i >= n:
            raise DeviceError(f"device {name!r} does not exist: this machine has {n} CUDA device(s)")
        return torch.device("cuda", i)
    if kind == "mps":
        if not torch.backends.mps.is_available():
            raise DeviceError(f"device {name!r} is not available (needs Apple Silicon and a recent macOS). "
                              f"Available: {_names()}")
        return torch.device("mps")
    raise DeviceError(f"unknown device {name!r}; use 'auto', 'cuda', 'mps' or 'cpu'")


def _names() -> str:
    return ", ".join(d["name"] for d in available())


def configure(dev: torch.device) -> None:
    """Enable the fast paths for a device (idempotent, process-wide)."""
    if dev.type == "cuda":
        torch.backends.cudnn.benchmark = True  # autotune conv algorithms for fixed shapes
        torch.backends.cuda.matmul.allow_tf32 = True
        torch.backends.cudnn.allow_tf32 = True
        torch.set_float32_matmul_precision("high")
