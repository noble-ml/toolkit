from __future__ import annotations

from typing import Tuple

import torch.nn as nn


def count(module: nn.Module) -> Tuple[int, int]:
    """(trainable, non-trainable) values. Buffers (e.g. BatchNorm statistics) count as non-trainable."""
    trainable = sum(p.numel() for p in module.parameters() if p.requires_grad)
    frozen = sum(p.numel() for p in module.parameters() if not p.requires_grad)
    frozen += sum(b.numel() for n, b in module.named_buffers() if not n.endswith("num_batches_tracked"))
    return trainable, frozen
