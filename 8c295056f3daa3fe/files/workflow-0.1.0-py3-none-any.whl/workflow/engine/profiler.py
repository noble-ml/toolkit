"""Architecture analysis: parameters, MACs/FLOPs and memory estimates.

MACs are measured by running the architecture on torch's ``meta`` device (no real compute or
memory), so they follow the real computation for any operation, including custom ones.
Only convolutions are counted (they dominate); BatchNorm folds into the conv at inference and
activations / pooling / upsampling are negligible. FLOPs = 2 × MACs.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import torch

from ..layers.conv import Conv2D
from ..op import Shape
from . import graph, parameters
from ..stage import RESERVED

FP32 = 4  # bytes per value used for the estimates


@dataclass
class OpStat:
    stage: str
    index: int
    op: object
    out_shapes: Tuple[Shape, ...]
    trainable: int
    non_trainable: int
    macs: int
    act_bytes: int          # outputs of this operation, per image, fp32


@dataclass
class Analysis:
    input: Shape
    ops: List[OpStat]
    outputs: Dict[str, Shape]
    trainable: int
    non_trainable: int
    macs: int
    param_bytes: int
    act_bytes: int          # sum of all operation outputs (what training keeps for backprop), per image
    peak_bytes: int         # estimated peak of live tensors during inference, per image

    @property
    def params(self) -> int:
        return self.trainable + self.non_trainable

    @property
    def flops(self) -> int:
        return 2 * self.macs


def _numel(shape) -> int:
    n = 1
    for v in shape:
        n *= v
    return n


def conv_macs(model, input_shape: Shape) -> Dict[Tuple[str, int], int]:
    """MACs per top-level operation, measured on a meta-device copy of the architecture."""
    with torch.device("meta"):
        probe = type(model).from_spec(model.spec())
    probe.eval()
    owner = {}
    for sname, stage in probe.stages.items():
        for i, op in enumerate(stage.ops):
            for m in op.modules():
                if isinstance(m, Conv2D):
                    owner[m] = (sname, i + 1)
    macs: Dict[Tuple[str, int], int] = {}

    def hook(m, _inp, out):
        key = owner[m]
        macs[key] = macs.get(key, 0) + out.numel() * m.in_channels * m.kernel_size[0] * m.kernel_size[1]

    handles = [m.register_forward_hook(hook) for m in owner]
    try:
        with torch.no_grad():
            probe(torch.empty(1, *input_shape, device="meta"))
    finally:
        for h in handles:
            h.remove()
    return macs


def analyze(model, input_shape: Shape) -> Analysis:
    shapes, records = graph.infer(model._plan, tuple(input_shape))
    macs = conv_macs(model, tuple(input_shape))
    ops: List[OpStat] = []
    for r in records:
        tr, fr = parameters.count(r.op)
        ops.append(OpStat(r.stage, r.index, r.op, r.out_shapes, tr, fr, macs.get((r.stage, r.index), 0),
                          sum(_numel(s) for s in r.out_shapes) * FP32))
    trainable, frozen = parameters.count(model)
    return Analysis(
        input=shapes[RESERVED], ops=ops, outputs={n: shapes[n] for n in model._plan.outputs},
        trainable=trainable, non_trainable=frozen, macs=sum(o.macs for o in ops),
        param_bytes=(trainable + frozen) * FP32, act_bytes=sum(o.act_bytes for o in ops),
        peak_bytes=_peak(model, shapes, records))


def _peak(model, shapes, records) -> int:
    """Peak bytes of simultaneously live tensors, following the plan's free schedule."""
    size = {n: _numel(s) * FP32 for n, s in shapes.items()}
    by_stage: Dict[str, List] = {}
    for r in records:
        by_stage.setdefault(r.stage, []).append(r)
    alive, peak = {RESERVED}, 0
    for st in model._plan.steps:
        base = sum(size[n] for n in alive)
        step_peak, prev = 0, 0
        for r in by_stage[st.stage.name]:
            out = sum(_numel(s) for s in r.out_shapes) * FP32
            step_peak = max(step_peak, out + prev)
            prev = out
        peak = max(peak, base + step_peak)
        alive.update(st.publishes)
        alive.difference_update(st.free)
    return peak
