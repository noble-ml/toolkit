from __future__ import annotations

import re
from typing import Any, Dict, Optional, Tuple

import torch.nn as nn

from .errors import RoutingError, WorkflowError
from .op import Op, link

RESERVED = "input"  # name of the model input tensor
_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


class Stage(nn.Module):
    """A named, sequential group of operations.

    Receives the previous stage's output (or the tensor named by ``input=``),
    runs its operations in order and publishes the final result under its name.
    An operation with ``inputs=`` reads named tensors instead of the previous
    operation's output. If the last operation declares ``outputs=``, the stage
    publishes those names instead of its own.
    """

    def __init__(self, name: str, *ops: Op, input: Optional[str] = None):
        super().__init__()
        if not isinstance(name, str) or not _NAME.match(name):
            raise WorkflowError(f"stage name must be an identifier (letters, digits, _), got {name!r}")
        if name == RESERVED:
            raise WorkflowError(f"'{RESERVED}' is reserved for the model input; choose another stage name")
        if not ops:
            raise WorkflowError(f"Stage '{name}' needs at least one operation")
        for i, op in enumerate(ops):
            if not isinstance(op, Op):
                raise WorkflowError(f"Stage '{name}': item {i + 1} is {op!r}, expected a Workflow operation")
            if op.outputs and i < len(ops) - 1:
                raise RoutingError(
                    f"Stage '{name}': {type(op).__name__} (op {i + 1}) produces several named outputs "
                    f"{tuple(op.outputs)} so it must be the last operation of its stage")
        if input is not None and not isinstance(input, str):
            raise WorkflowError(f"Stage '{name}': input= must be a stage/output name, got {input!r}")
        self.name, self.input = name, input
        self.ops = nn.ModuleList(ops)
        link(list(ops))

    def publishes(self) -> Tuple[str, ...]:
        last = self.ops[-1]
        return tuple(last.outputs) if last.outputs else (self.name,)

    def refs(self):
        """(name, description) of every tensor name this stage reads."""
        out = []
        if self.input is not None:
            out.append((self.input, f"Stage '{self.name}' (input=)"))
        for i, op in enumerate(self.ops):
            for n in op.inputs or ():
                out.append((n, f"Stage '{self.name}', op {i + 1} {type(op).__name__}"))
        return out

    def run(self, env: Dict[str, Any], src: Optional[str]):
        x = env[src] if src is not None else None
        for op in self.ops:
            x = op(*[env[n] for n in op.inputs]) if op.inputs else op(x)
        return x

    def spec(self) -> Dict[str, Any]:
        return {"name": self.name, "input": self.input, "ops": [op.spec() for op in self.ops]}

    @staticmethod
    def from_spec(spec: Dict[str, Any]) -> "Stage":
        return Stage(spec["name"], *[Op.from_spec(o) for o in spec["ops"]], input=spec.get("input"))

    def extra_repr(self) -> str:
        return f"name={self.name!r}" + (f", input={self.input!r}" if self.input else "")
