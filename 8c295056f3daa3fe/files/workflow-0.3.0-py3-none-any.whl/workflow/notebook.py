"""``workflow init``: a starter Jupyter notebook with a small model, benchmarks before and after training, and saving."""
from __future__ import annotations

import json
import os

from .errors import WorkflowError

CELLS = [
    ("md", """# __TITLE__

A starter detector made with `workflow init`. Run the cells from top to bottom:

1. load a dataset (or make a small practice one with Felix)
2. build a small, readable model
3. **benchmark it before training**
4. train it
5. **benchmark it again after training**, and compare
6. save it, reload it, and try a prediction

Change anything you like: the model is just a list of layers."""),
    ("code", """import os

import felix as fx
import workflow as wf

DATASET = __DATASET__      # a Felix dataset (folder or .felix); made below if it doesn't exist yet
IMG_SIZE = __IMG_SIZE__    # pictures are resized to IMG_SIZE x IMG_SIZE for the model
EPOCHS = __EPOCHS__
DEVICE = __DEVICE__        # "auto", "cpu", "cuda", "gpu" or "mps"
OUT = "runs/notebook"      # checkpoints and saved models go here"""),
    ("md", """## 1 · Data

If `DATASET` doesn't exist, this makes a small practice dataset: circles, squares and triangles in random
places, sizes and angles. Felix splits every dataset into `train` (to learn from), `val` (to check progress while
learning) and `test` (the final exam)."""),
    ("code", """if not os.path.exists(DATASET):
    fx.reset()
    with fx.class_set("shapes"):
        circle = fx.toolkit.circle(radius=20, color="#d62728")
        square = fx.toolkit.rectangle(width=38, height=38, color="#1f77b4")
        triangle = fx.toolkit.polygon(vertices=[(0, 40), (22, 0), (44, 40)], color="#2ca02c")
    with fx.step(size=(IMG_SIZE, IMG_SIZE)):
        fx.canvas.background("#e8e8e8")
        for chance in (1.0, 0.6):                                  # one or two objects per picture
            obj = fx.paint(fx.random.class_(threshold=chance), position=fx.random.position(margin=40))
            fx.toolkit.transformation(obj, scale=fx.random.uniform(0.7, 1.4), rotation=fx.random.uniform(0, 360))
        fx.gen()
    fx.make(pairs=400, output=DATASET, seed=1)

data = fx.load(DATASET)
print(data.splits, "classes:", data.classes)
data.image(data.train.stems[0]).to_pil()                           # a peek at one training picture"""),
    ("md", """## 2 · The model

Read it from top to bottom, like the picture flows through it:

- each **Conv2D → BatchNorm2D → SiLU** step halves the picture (`stride=2, padding="same"`) and looks for more
  complex patterns; the first number in `Conv2D` is how many channels come out;
- **CSP** adds depth cheaply; **SPPF** lets the deepest layer see the whole picture;
- `wf.feature(...)` names a map so the neck can use it: `"small"` (fine, for small objects) and `"large"` (coarse,
  for big ones);
- **FPN** mixes the two maps, and the **head** turns them into boxes, confidences and classes.

It is deliberately small (well under a million parameters) so it trains quickly on a laptop CPU."""),
    ("code", """model = wf.stack(
    # IMG_SIZE → 1/2
    wf.Conv2D(16, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),

    # 1/2 → 1/4
    wf.Conv2D(32, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.CSP(n=1),

    # 1/4 → 1/8: fine map, good for small objects
    wf.Conv2D(64, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.CSP(n=1),
    wf.feature("small"),

    # 1/8 → 1/16: coarse map, good for big objects
    wf.Conv2D(128, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.SPPF(kernel_size=5),
    wf.feature("large"),

    # neck and head
    wf.FPN("small", "large", channels=64),
    wf.head(classes=len(data.classes)),

    input=(3, IMG_SIZE, IMG_SIZE),
)
model.summary()"""),
    ("code", """model.plot(show=False)                                            # the computation graph"""),
    ("md", """## 3 · Benchmark before training

Size, FLOPs, speed and memory don't depend on training. Accuracy does: before training the model is guessing, so
expect mAP close to 0. That's the baseline the training has to beat."""),
    ("code", """before = wf.eval(model, dataset=data.test, device=DEVICE)"""),
    ("md", """## 4 · Train

Shows a live progress bar. Each epoch is checked on `data.val`; the best model is kept in `OUT/best.nbm`.
You can stop it any time (Interrupt the kernel): it saves first. Running this cell again with a bigger `EPOCHS`
continues from where it stopped."""),
    ("code", """history = model.train(data.train, validation=data.val, epochs=EPOCHS, device=DEVICE, output=OUT)"""),
    ("md", """## 5 · Benchmark after training

The same test pictures as before, so the numbers can be compared directly."""),
    ("code", """after = wf.eval(model, dataset=data.test, device=DEVICE)"""),
    ("code", """rows = [("mAP50", before.map50, after.map50), ("mAP50-95", before.map50_95, after.map50_95),
        ("precision", before.precision_score, after.precision_score), ("recall", before.recall, after.recall)]
print(f"{'':<11}{'before':>8}{'after':>8}")
for name, b, a in rows:
    print(f"{name:<11}{b:>8.3f}{a:>8.3f}")
print(f"{'FPS':<11}{before.fps:>8.1f}{after.fps:>8.1f}   (training doesn't change speed: any gap is timing noise)")"""),
    ("md", """## 6 · Save, reload, use

`model.save` writes one `.nbm` file with the layers, weights, class names and training progress. The int8 copy is
about 4x smaller for deployment, and the ONNX file runs in other programs."""),
    ("code", """os.makedirs(OUT, exist_ok=True)
model.save(f"{OUT}/model.nbm")
model.export(format="nbm", output=f"{OUT}/model-int8.nbm", precision="int8", calibration=data.val)
model.export(format="onnx", output=f"{OUT}/model.onnx")

loaded = wf.load(f"{OUT}/model.nbm")                               # check the file loads back
for f in ("model.nbm", "model-int8.nbm", "model.onnx"):
    print(f"{f:<16}{os.path.getsize(f'{OUT}/{f}') / 2**20:6.2f} MB")"""),
    ("code", """picture = data.image(data.test.stems[0])
result = loaded.predict(picture, output=f"{OUT}/results")          # also saves the drawn picture + predictions.json
print(result, result.classes, [round(c, 2) for c in result.confidences])
result.plot()"""),
    ("md", """## Next

- Make the model bigger (more output channels, `CSP(n=2)`, a third `wf.feature` + `wf.PAN`) and compare the benchmarks.
- Train longer: set `EPOCHS` higher and run the training cell again; it continues.
- Shrink it: `model.train(..., epochs=EPOCHS + 3, quantization=wf.QAT(precision="int8"))`.
- From a terminal: `workflow script runs/notebook/model.nbm --preset webcam`."""),
]


def _cell(kind: str, text: str, i: int) -> dict:
    lines = text.split("\n")
    src = [l + "\n" for l in lines[:-1]] + [lines[-1]]
    if kind == "md":
        return {"cell_type": "markdown", "id": f"md{i}", "metadata": {}, "source": src}
    return {"cell_type": "code", "id": f"code{i}", "execution_count": None, "metadata": {}, "outputs": [], "source": src}


def create(path: str = "workflow.ipynb", dataset: str = "practice_shapes.felix", img_size: int = 256,
           epochs: int = 30, device: str = "auto", overwrite: bool = False) -> str:
    """Write the starter notebook to ``path`` and return the path."""
    path = os.fspath(path)
    if not path.endswith(".ipynb"):
        raise WorkflowError(f"cannot create a notebook called {os.path.basename(path)!r}.",
                            "Jupyter notebooks use the .ipynb extension.", f"use a name like '{os.path.splitext(path)[0]}.ipynb'.")
    if os.path.exists(path) and not overwrite:
        raise WorkflowError(f"{path} already exists.", "Workflow does not overwrite files unless asked.", "pass --overwrite or choose another name.")
    if not isinstance(img_size, int) or img_size < 64 or img_size % 32:
        raise WorkflowError(f"img_size={img_size!r} doesn't suit the starter model.",
                            "the model halves the picture four times and the FPN needs the sizes to line up.",
                            "use a multiple of 32 of at least 64, e.g. 256, 320 or 640.")
    if not isinstance(epochs, int) or epochs < 1:
        raise WorkflowError(f"epochs={epochs!r} is not valid.", "training needs at least one epoch.", "use for example --epochs 30.")
    values = {"__TITLE__": os.path.splitext(os.path.basename(path))[0].replace("_", " ").replace("-", " ").title(),
              "__DATASET__": repr(dataset), "__IMG_SIZE__": str(img_size), "__EPOCHS__": str(epochs), "__DEVICE__": repr(device)}
    cells = []
    for i, (kind, text) in enumerate(CELLS):
        for k, v in values.items():
            text = text.replace(k, v)
        if kind == "code":
            compile(text, f"cell {i}", "exec")                          # never write a notebook that doesn't parse
        cells.append(_cell(kind, text, i))
    nb = {"cells": cells, "nbformat": 4, "nbformat_minor": 5,
          "metadata": {"kernelspec": {"name": "python3", "display_name": "Python 3", "language": "python"},
                       "language_info": {"name": "python"}}}
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(nb, f, indent=1)
        f.write("\n")
    return path
