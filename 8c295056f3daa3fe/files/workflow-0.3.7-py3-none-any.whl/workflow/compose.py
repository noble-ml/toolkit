"""Model composition: stack, Residual, parallel, feature, concat, add, FPN, PAN, head."""
from __future__ import annotations

import difflib
import math
from typing import List, Optional, Sequence, Tuple

from .core import Tensor, device as _device, ops
from .errors import RoutingError, ShapeError, WorkflowError
from .layer import _LEGACY, Ctx, Layer, as_layers, fmt, is_pyramid, positive, single
from .layers import BatchNorm2D, Conv2D, SiLU
from .model import ModelAPI


def link(layers: Sequence[Layer]) -> None:
    """A convolution directly followed by BatchNorm2D needs no bias; any other gets one."""
    for a, b in zip(layers, list(layers[1:]) + [None]):
        absorbed = b is not None and getattr(b, "absorbs_bias", False)
        if hasattr(a, "_set_bias"):
            a._set_bias(not absorbed)
        elif getattr(a, "use_bias", 0) is None:
            a.use_bias = not absorbed


def cba(filters: int, k: int = 1, stride: int = 1, act: bool = True) -> List[Layer]:
    """Conv → BatchNorm → SiLU with padding="same" (keeps the size at stride 1, halves it at stride 2)."""
    out = [Conv2D(filters, kernel_size=k, stride=stride, padding="same"), BatchNorm2D()]
    return out + [SiLU()] if act else out


class Input(Layer):
    """``wf.input(channels=3, height=640, width=640)``: the first line of a model, saying what pictures go in.

    It builds the model for that shape (input channels of every layer, weights, shape checks, summary and FLOPs) and
    is the default image size for training, evaluation and prediction. The trained model also runs at other sizes."""

    def __init__(self, channels: int = 3, height: int = 640, width: int = 640):
        self.shape = (positive(channels, "channels"), positive(height, "height"), positive(width, "width"))

    def label(self):
        return "input"

    def infer(self, shape, ctx):
        return tuple(shape)

    def run(self, x, ctx):
        return x


class Stack(Layer, ModelAPI):
    """``wf.stack(wf.input(...), *layers)``: layers applied in order, one per line. The outermost stack is the model;
    its first line is ``wf.input(channels, height, width)`` (default 3 x 640 x 640 if it is left out)."""

    def __init__(self, *layers: Layer, input: Optional[Tuple[int, int, int]] = None):
        self.layers = as_layers(layers, "wf.stack")
        for i, layer in enumerate(self.layers[1:], start=2):
            if isinstance(layer, Input):
                raise WorkflowError("wf.input(...) must be the first line of the model.",
                                    f"it is item {i} of wf.stack; the input describes the picture before any layer touches it.",
                                    "move wf.input(channels=..., height=..., width=...) to the top of the outermost wf.stack.")
        if input is not None and not _LEGACY[0]:
            c, h, w = (tuple(input) + (None,) * 3)[:3] if isinstance(input, (tuple, list)) else ("C", "H", "W")
            raise WorkflowError("wf.stack(..., input=...) has been replaced by wf.input(...).",
                                "the picture shape now goes on the first line of the model, where the picture comes in.",
                                f"remove input=... and start the stack with wf.input(channels={c}, height={h}, width={w}),")
        if isinstance(self.layers[0], Input):
            self.input = self.layers[0].shape
        elif input is not None:                         # a model saved before wf.input existed
            self.input = tuple(input)
        else:
            self.input = None
        link(self.layers)
        self._init_model()

    def children(self):
        return [(str(i), l) for i, l in enumerate(self.layers)]

    def infer(self, shape, ctx: Ctx):
        records = []
        for i, layer in enumerate(self.layers):
            if isinstance(layer, Input) and getattr(ctx, "top", self) is not self:
                raise WorkflowError("wf.input(...) belongs only at the top of the model.",
                                    "it was found inside a block (Residual, parallel, ...), whose input is simply the previous layer's output.",
                                    "delete it from the block and keep one wf.input(...) as the first line of the outermost wf.stack.")
            before = ctx.macs
            try:
                out = layer.infer(shape, ctx)
            except WorkflowError as e:
                raise e.at(f"layer {i + 1} ({type(layer).__name__})") from None
            records.append((i, layer, shape, out, ctx.macs - before))
            shape = out
        self._records = records
        return shape

    def run(self, x, ctx: Ctx):
        from .layers import BatchNorm2D, _Act
        layers, i = self.layers, 0
        fuse = hasattr(x.dev.be, "bn_act_fwd")
        while i < len(layers):
            layer = layers[i]
            if fuse and type(layer) is BatchNorm2D and i + 1 < len(layers) and isinstance(layers[i + 1], _Act):
                a = layers[i + 1]
                x = ops.batchnorm_act(x, layer.P["gamma"], layer.P["beta"], layer.Bf["mean"], layer.Bf["var"],
                                      ctx.train, a.kind, a.slope)
                i += 2
                continue
            x = layer.run(x, ctx)
            i += 1
        return x


class Residual(Layer):
    """``output = layers(x) + shortcut(x)``. The shortcut is the block's own input unless ``shortcut=`` gives
    projection layers; both paths must produce the same shape."""

    def __init__(self, *layers: Layer, shortcut=None):
        self.body = Stack(*layers)
        self.shortcut = None
        if shortcut is not None:
            self.shortcut = Stack(*([shortcut] if isinstance(shortcut, Layer) else shortcut))

    def children(self):
        return [("body", self.body)] + ([("shortcut", self.shortcut)] if self.shortcut else [])

    def infer(self, shape, ctx):
        shape = single(shape, "Residual")
        out = self.body.infer(shape, ctx)
        carried = self.shortcut.infer(shape, ctx) if self.shortcut else shape
        if is_pyramid(out) or tuple(out) != tuple(carried):
            c_fix = (f"wf.Conv2D({out[0]}, kernel_size=1, stride={max(1, round(shape[1] / out[1]))})"
                     if not is_pyramid(out) else "a matching projection")
            raise ShapeError("Residual cannot add its two paths.",
                             f"the layers output {fmt(out)} but the shortcut carries {fmt(carried)}; addition needs identical shapes.",
                             f"keep the shape inside the block (same channels, stride 1, padding='same'), or project the input with shortcut={c_fix}.")
        return out

    def run(self, x, ctx):
        return ops.add(self.body.run(x, ctx), self.shortcut.run(x, ctx) if self.shortcut else x)


class Parallel(Layer):
    """``wf.parallel(a, b, ..., merge="concat")``: every branch gets the same input; results are concatenated
    along channels (``"concat"``) or summed (``"add"``)."""

    def __init__(self, *branches: Layer, merge: str = "concat"):
        self.branches = as_layers(branches, "wf.parallel")
        if len(self.branches) < 2:
            raise WorkflowError("wf.parallel needs at least two branches.", "one branch is just a stack.",
                                "pass two or more layers/stacks, or use wf.stack.")
        if merge not in ("concat", "add"):
            raise WorkflowError(f"unknown merge={merge!r}.", "branches can be merged by 'concat' or 'add'.", "use merge='concat' or merge='add'.")
        self.merge = merge

    def children(self):
        return [(str(i), b) for i, b in enumerate(self.branches)]

    def infer(self, shape, ctx):
        shape = single(shape, "wf.parallel")
        outs = []
        for i, b in enumerate(self.branches):
            try:
                outs.append(single(b.infer(shape, ctx), "wf.parallel branch"))
            except WorkflowError as e:
                raise e.at(f"branch {i + 1} ({type(b).__name__})") from None
        return _merged_shape(outs, self.merge, [f"branch {i + 1}" for i in range(len(outs))], "wf.parallel")

    def run(self, x, ctx):
        outs = [b.run(x, ctx) for b in self.branches]
        return _merge(outs, self.merge)


def _merged_shape(shapes, how, names, who):
    first = shapes[0]
    for n, s in zip(names[1:], shapes[1:]):
        if how == "add" and tuple(s) != tuple(first):
            raise ShapeError(f"{who} cannot add {names[0]} and {n}.",
                             f"{names[0]} is {fmt(first)} but {n} is {fmt(s)}; addition needs identical shapes.",
                             "give both the same channels and resolution (e.g. a wf.PointwiseConv2D to match channels, "
                             "wf.Upsample / stride to match size), or merge with concat instead.")
        if how == "concat" and tuple(s[1:]) != tuple(first[1:]):
            raise ShapeError(f"{who} cannot concatenate {names[0]} and {n}.",
                             f"{names[0]} is {first[1]}x{first[2]} but {n} is {s[1]}x{s[2]}; concatenation needs the same height and width.",
                             "resize one of them first (wf.Upsample, wf.MaxPool2D or a strided convolution).")
    return tuple(first) if how == "add" else (sum(s[0] for s in shapes), first[1], first[2])


def _merge(tensors, how):
    if how == "concat":
        return ops.concat(tensors)
    out = tensors[0]
    for t in tensors[1:]:
        out = ops.add(out, t)
    return out


def _lookup(ctx: Ctx, name: str, who: str):
    if name not in ctx.features:
        close = difflib.get_close_matches(name, list(ctx.features), n=1, cutoff=0.4)
        have = ", ".join(ctx.features) or "none yet"
        raise RoutingError(f"{who} refers to the feature '{name}', which does not exist here.",
                           f"features must be registered with wf.feature(...) earlier in the model; registered so far: {have}.",
                           (f"did you mean '{close[0]}'? Otherwise " if close else "") + f"add wf.feature(\"{name}\") after the layer whose output you want.")
    return ctx.features[name]


def _names(names, who, minimum):
    if len(names) < minimum or not all(isinstance(n, str) and n for n in names):
        raise WorkflowError(f"{who} needs at least {minimum} feature name(s), got {names!r}.",
                            f"{who} combines features registered with wf.feature(\"name\").",
                            f"write for example {who}(\"p3\", \"p4\").")
    if len(set(names)) != len(names):
        raise WorkflowError(f"{who} lists a feature twice: {names!r}.", "each feature can be used once per operation.", "remove the duplicate.")
    return tuple(names)


class Feature(Layer):
    """``wf.feature("p3")`` registers the current tensor under a name for later layers (FPN, concat, add).
    After a pyramid (e.g. FPN) pass one name per map: ``wf.feature(("n3", "n4", "n5"))``."""

    def __init__(self, name):
        self.names = (name,) if isinstance(name, str) else tuple(name)
        if not self.names or not all(isinstance(n, str) and n for n in self.names):
            raise WorkflowError(f"invalid feature name {name!r}.", "a feature name is a non-empty string (or a tuple of them for a pyramid).",
                                "use for example wf.feature(\"p3\").")
        self.is_multi = not isinstance(name, str)

    def label(self):
        return "feature " + ", ".join(self.names)

    def _register(self, value, ctx):
        if self.is_multi:
            if not is_pyramid(value) or len(value) != len(self.names):
                got = f"a pyramid of {len(value)} maps" if is_pyramid(value) else "a single tensor"
                raise RoutingError(f"wf.feature({self.names}) names {len(self.names)} maps but received {got}.",
                                   "a tuple of names labels the maps of a pyramid one by one.",
                                   "pass exactly one name per map, or a single string for a single tensor.")
            pairs = list(zip(self.names, value))
        else:
            if is_pyramid(value):
                raise RoutingError(f"wf.feature(\"{self.names[0]}\") received a pyramid of {len(value)} maps.",
                                   "one name cannot label several maps.",
                                   f"pass one name per map, e.g. wf.feature({tuple(f'{self.names[0]}{i}' for i in range(len(value)))}).")
            pairs = [(self.names[0], value)]
        for n, v in pairs:
            if n in ctx.features:
                raise RoutingError(f"the feature name '{n}' is registered twice.", "feature names must be unique within a model.",
                                   "rename one of the wf.feature(...) calls.")
            ctx.features[n] = v

    def infer(self, shape, ctx):
        self._register(shape, ctx)
        return shape

    def run(self, x, ctx):
        self._register(x, ctx)
        return x


class Concat(Layer):
    """``wf.concat("a", "b", ...)`` concatenates the named features along channels (same height and width)."""
    how = "concat"

    def __init__(self, *names: str):
        self.names = _names(names, f"wf.{self.how}", 2)

    def label(self):
        return f"{self.how} " + ", ".join(self.names)

    def infer(self, shape, ctx):
        shapes = [single(_lookup(ctx, n, f"wf.{self.how}"), f"wf.{self.how}") for n in self.names]
        return _merged_shape(shapes, self.how, [f"'{n}'" for n in self.names], f"wf.{self.how}")

    def run(self, x, ctx):
        return _merge([ctx.features[n] for n in self.names], self.how)


class Add(Concat):
    """``wf.add("a", "b", ...)`` sums the named features (identical shapes)."""
    how = "add"

    def __init__(self, *names: str):
        self.names = _names(names, "wf.add", 2)


class _Neck(Layer):
    """Shared plumbing for FPN / PAN: read named features (or the current pyramid), largest map first."""

    def _setup(self, names, channels):
        self.names = _names(names, f"wf.{type(self).__name__}", 2) if names else ()
        self.channels = positive(channels, "channels", optional=True)

    def _inputs(self, value, ctx):
        who = f"wf.{type(self).__name__}"
        if self.names:
            vals = [_lookup(ctx, n, who) for n in self.names]
            labels = list(self.names)
        else:
            if not is_pyramid(value) or len(value) < 2:
                raise RoutingError(f"{who} has no feature maps to work on.",
                                   "it was given no feature names and the incoming value is a single tensor.",
                                   f"name the maps to fuse, e.g. {who}(\"p3\", \"p4\", \"p5\", channels=128), after registering them with wf.feature(...).")
            vals, labels = list(value), [f"map {i + 1}" for i in range(len(value))]
        for v, l in zip(vals, labels):
            if is_pyramid(v):
                raise RoutingError(f"{who} input '{l}' is itself a pyramid.", "each input must be a single feature map.",
                                   "register individual maps with wf.feature(...).")
        return vals, labels

    @staticmethod
    def _order(vals, labels, key):
        idx = sorted(range(len(vals)), key=lambda i: -key(vals[i]))
        return [vals[i] for i in idx], [labels[i] for i in idx]


class FPN(_Neck):
    """``wf.FPN("p3", "p4", "p5", channels=128)``: top-down feature pyramid over registered features.

    Each input is projected to ``channels`` with a 1x1 Conv-BN-SiLU, the coarser map is resized (nearest) and added
    to the next finer one, and every level is refined by a 3x3 Conv-BN-SiLU. Inputs may have any channel counts and
    sizes; they are ordered from the largest map to the smallest. The result is a pyramid (largest first).
    ``channels`` defaults to the smallest input channel count."""

    def __init__(self, *names: str, channels: Optional[int] = None):
        self._setup(names, channels)
        self.lateral: List[Stack] = []
        self.smooth: List[Stack] = []

    def children(self):
        return [(f"lateral.{i}", l) for i, l in enumerate(self.lateral)] + [(f"smooth.{i}", l) for i, l in enumerate(self.smooth)]

    def infer(self, shape, ctx):
        vals, labels = self._inputs(shape, ctx)
        vals, labels = self._order(vals, labels, lambda s: s[1] * s[2])
        ch = self.channels or min(v[0] for v in vals)
        if not self.lateral:
            self.lateral = [Stack(*cba(ch, 1)) for _ in vals]
            self.smooth = [Stack(*cba(ch, 3)) for _ in vals]
        if len(self.lateral) != len(vals):
            raise ShapeError("wf.FPN received a different number of maps than it was built for.",
                             f"built for {len(self.lateral)}, received {len(vals)}.", "create a new wf.FPN for a different set of features.")
        outs = []
        for v, lat, sm in zip(vals, self.lateral, self.smooth):
            outs.append(tuple(sm.infer(lat.infer(v, ctx), ctx)))
        return tuple(outs)

    def run(self, x, ctx):
        vals, _ = self._inputs(x, ctx)
        vals, _ = self._order(vals, [""] * len(vals), lambda t: t.shape[2] * t.shape[3])
        lat = [l.run(v, ctx) for l, v in zip(self.lateral, vals)]
        for i in range(len(lat) - 2, -1, -1):
            lat[i] = ops.add(lat[i], ops.upsample(lat[i + 1], lat[i].shape[2], lat[i].shape[3]))
        return tuple(s.run(l, ctx) for s, l in zip(self.smooth, lat))


class PAN(_Neck):
    """``wf.PAN(channels=128)``: bottom-up path aggregation over the incoming pyramid (or named features).

    From the largest map down, each map is reduced by a stride-2 3x3 Conv-BN-SiLU, resized if needed and added to
    the next map, which is then refined by a 3x3 Conv-BN-SiLU. Returns a pyramid (largest first)."""

    def __init__(self, *names: str, channels: Optional[int] = None):
        self._setup(names, channels)
        self.lateral: List[Stack] = []
        self.down: List[Stack] = []
        self.smooth: List[Stack] = []

    def children(self):
        return ([(f"lateral.{i}", l) for i, l in enumerate(self.lateral)] + [(f"down.{i}", l) for i, l in enumerate(self.down)]
                + [(f"smooth.{i}", l) for i, l in enumerate(self.smooth)])

    def infer(self, shape, ctx):
        vals, labels = self._inputs(shape, ctx)
        vals, labels = self._order(vals, labels, lambda s: s[1] * s[2])
        ch = self.channels or min(v[0] for v in vals)
        if not self.lateral:
            self.lateral = [Stack(*cba(ch, 1)) for _ in vals]
            self.down = [Stack(*cba(ch, 3, stride=2)) for _ in vals[1:]]
            self.smooth = [Stack(*cba(ch, 3)) for _ in vals]
        if len(self.lateral) != len(vals):
            raise ShapeError("wf.PAN received a different number of maps than it was built for.",
                             f"built for {len(self.lateral)}, received {len(vals)}.", "create a new wf.PAN for a different set of features.")
        lat = [l.infer(v, ctx) for l, v in zip(self.lateral, vals)]
        outs = [tuple(self.smooth[0].infer(lat[0], ctx))]
        for i in range(1, len(lat)):
            self.down[i - 1].infer(outs[-1], ctx)
            outs.append(tuple(self.smooth[i].infer(lat[i], ctx)))
        return tuple(outs)

    def run(self, x, ctx):
        vals, _ = self._inputs(x, ctx)
        vals, _ = self._order(vals, [""] * len(vals), lambda t: t.shape[2] * t.shape[3])
        lat = [l.run(v, ctx) for l, v in zip(self.lateral, vals)]
        outs = [self.smooth[0].run(lat[0], ctx)]
        for i in range(1, len(lat)):
            d = self.down[i - 1].run(outs[-1], ctx)
            if d.shape[2:] != lat[i].shape[2:]:
                d = ops.upsample(d, lat[i].shape[2], lat[i].shape[3])
            outs.append(self.smooth[i].run(ops.add(lat[i], d), ctx))
        return tuple(outs)


class Head(Layer):
    """``wf.head(classes=80)``: anchor-free bounding-box detection head.

    Works on the incoming pyramid (after FPN / PAN) or on a single tensor. Per map: two 3x3 Conv-BN-SiLU layers and a
    1x1 convolution producing ``4 + 1 + classes`` channels: box distances (left, top, right, bottom, in strides),
    a confidence logit and one logit per class. It must be the last layer of the model."""

    def __init__(self, classes: int = 80, channels: Optional[int] = None):
        self.classes = positive(classes, "classes")
        self.channels = positive(channels, "channels", optional=True)
        self.stems: List[Stack] = []
        self.preds: List[Conv2D] = []

    def label(self):
        return f"head {self.classes} classes"

    def children(self):
        return [(f"stem.{i}", s) for i, s in enumerate(self.stems)] + [(f"pred.{i}", p) for i, p in enumerate(self.preds)]

    def infer(self, shape, ctx):
        maps = list(shape) if is_pyramid(shape) else [tuple(shape)]
        if not self.stems:
            for m in maps:
                w = self.channels or m[0]
                self.stems.append(Stack(*cba(w, 3), *cba(w, 3)))
                p = Conv2D(5 + self.classes, kernel_size=1)
                p.use_bias = True
                self.preds.append(p)
        if len(self.stems) != len(maps):
            raise ShapeError("wf.head received a different number of maps than it was built for.",
                             f"built for {len(self.stems)}, received {len(maps)}.", "create a new wf.head for a different pyramid.")
        outs = []
        for m, s, p in zip(maps, self.stems, self.preds):
            fresh = "bias" not in p.P
            outs.append(tuple(p.infer(s.infer(m, ctx), ctx)))
            if fresh:                                   # start boxes at ~1.3 strides and confidences at ~1%
                prior = -math.log((1 - 0.01) / 0.01)
                t = Tensor.from_list([1.0] * 4 + [prior] * (1 + self.classes), (5 + self.classes,), _device.get("cpu"))
                t.rg = True
                p.P["bias"] = t
        return tuple(outs)

    def run(self, x, ctx):
        maps = list(x) if is_pyramid(x) else [x]
        return tuple(p.run(s.run(m, ctx), ctx) for m, s, p in zip(maps, self.stems, self.preds))
