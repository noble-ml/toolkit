from __future__ import annotations

import os

from .errors import FelixError
from .project import current_step
from .rand import Node


def background(color=None, image=None):
    """Set the canvas background: a color, or an image / folder of images."""
    if image is not None and not isinstance(image, Node) and not os.path.exists(str(image)):
        raise FelixError(f"background image {image!r} does not exist")
    current_step("fx.canvas.background()").ops.append(("bg", color, image))
