from __future__ import annotations

import io
import random
import time
from datetime import datetime, timezone

from . import _yaml
from ._version import __version__
from ._ui import Panel, fmt_dur, fmt_n
from .errors import FelixError
from .project import P
from .store import open_writer


def class_table():
    return [{"id": c.id, "name": c.name, "set": c.set} for c in P.classes]


def make(pairs, output, seed=None, overwrite=False, quiet=False):
    """Generate ``pairs`` image/annotation pairs into ``output``.

    ``output`` is a folder, or a single compiled dataset if it ends in ``.felix``.
    Pairs are split evenly across the defined steps. Returns a dict of stats.
    """
    if not P.steps:
        raise FelixError("no step defined - use `with fx.step(...):` before fx.make()")
    pairs = int(pairs)
    if pairs < 1:
        raise FelixError("pairs must be >= 1")
    if seed is None:
        seed = random.SystemRandom().randrange(2**32)
    steps, n = P.steps, len(P.steps)
    counts = [len(range(k, pairs, n)) for k in range(n)]
    nsets = len([s for s in P.sets.values() if s.classes])

    writer = open_writer(output, overwrite)
    panel = Panel("", quiet=quiet)
    panel.title = panel.join("Felix make", str(output), f"{fmt_n(pairs)} pairs", f"seed {seed}")
    panel.sub = panel.join("Renderer running", f"{n} step{'s' * (n > 1)}",
                           f"{len(P.classes)} classes in {nsets} set{'s' * (nsets != 1)}")
    rows = [panel.row(s.name, counts[k]) for k, s in enumerate(steps)]
    for k, r in enumerate(rows):
        r.label = f"sample 0/{fmt_n(counts[k])}"
    stat = [[0, 0, 0, 0, time.time()] for _ in steps]  # images, boxes, empty, skipped, t0
    try:
        with panel:
            for i in range(pairs):
                k = i % n
                rng = random.Random(f"{seed}:{i}")
                img, anns, skipped = steps[k].run(P, rng)
                stem = f"IMG{i + 1}"
                buf = io.BytesIO()
                img.save(buf, "PNG", compress_level=3)
                writer.write(f"images/{stem}.png", buf.getvalue())
                writer.write(f"annotations/{stem}.yml", _yaml.dumps({
                    "image": f"{stem}.png", "width": img.width, "height": img.height,
                    "step": steps[k].name, "objects": anns}).encode("utf-8"))
                st, r = stat[k], rows[k]
                st[0] += 1
                st[1] += len(anns)
                st[2] += not anns
                st[3] += skipped
                r.label = f"sample {fmt_n(st[0])}/{fmt_n(counts[k])}"
                dt = max(1e-9, time.time() - st[4])
                r.stats = panel.join(f"{st[0] / dt:,.0f} img/s", f"{fmt_n(st[1])} boxes",
                                     f"{st[1] / st[0]:.1f} boxes/img")
                eta = (counts[k] - st[0]) / (st[0] / dt)
                r.foot = panel.join(f"elapsed {fmt_dur(dt)}", f"eta {fmt_dur(eta)}")
                r.advance()
            writer.write("metadata.yml", _yaml.dumps({
                "felix_version": __version__,
                "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "pairs": pairs, "seed": seed, "image_format": "png", "bbox_format": "xywh",
                "steps": [{"name": s.name, "size": list(s.size)} for s in steps],
                "classes": class_table()}).encode("utf-8"))
            writer.close()
            for k, r in enumerate(rows):
                r.done()
                r.foot = panel.join(f"took {fmt_dur(time.time() - stat[k][4])}", f"written to {output}")
            empty, skipped = sum(s[2] for s in stat), sum(s[3] for s in stat)
            if empty:
                panel.note(f"{fmt_n(empty)} image(s) have no annotations (thresholds / no fx.gen()).")
            if skipped:
                panel.note(f"{fmt_n(skipped)} object(s) were fully off-canvas or transparent and not annotated.")
    except BaseException:
        writer.abort()
        raise
    return {"pairs": pairs, "seed": seed, "boxes": sum(s[1] for s in stat), "output": str(output)}
