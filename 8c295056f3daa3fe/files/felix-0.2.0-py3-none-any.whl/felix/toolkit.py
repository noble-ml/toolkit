"""Shape constructors and the transformation call."""
from __future__ import annotations

import os
import sys

from .errors import FelixError
from .project import P, Obj, current_step
from .shapes import Shape


def _new(kind, params, color, position, name):
    sh = Shape(kind, params, color, position, name)
    if P.stack:
        P.stack[-1][1].append(sh)
    return sh


def circle(radius, position=None, color=None, name=None):
    if radius <= 0:
        raise FelixError("circle radius must be > 0")
    return _new("circle", {"radius": radius}, color, position, name)


def rectangle(width, height, position=None, color=None, name=None):
    if width <= 0 or height <= 0:
        raise FelixError("rectangle width/height must be > 0")
    return _new("rectangle", {"width": width, "height": height}, color, position, name)


def polygon(vertices, position=None, color=None, name=None):
    vertices = [(float(x), float(y)) for x, y in vertices]
    if len(vertices) < 3:
        raise FelixError("polygon needs at least 3 vertices")
    return _new("polygon", {"vertices": vertices}, color, position, name)


def image(source, width=None, height=None, position=None, name=None):
    """An image with transparency, e.g. a PNG. Relative paths are looked up in the
    working directory first, then next to the calling script."""
    cands = [os.path.abspath(source)]
    caller = sys._getframe(1).f_globals.get("__file__")
    if caller:
        cands.append(os.path.join(os.path.dirname(os.path.abspath(caller)), source))
    path = next((c for c in cands if os.path.isfile(c)), None)
    if path is None:
        raise FelixError(f"image not found: {source!r}")
    return _new("image", {"source": path, "width": width, "height": height}, None, position, name)


def transformation(obj, hue=None, brightness=None, rotation=None, scale=None, opacity=None):
    """Modify a painted object. Calls accumulate. ``hue``/``rotation`` are in
    degrees (rotation counter-clockwise), ``brightness``/``scale``/``opacity``
    are multipliers. Objects already annotated by fx.gen() are not changed."""
    if not isinstance(obj, Obj):
        raise FelixError("transformation() expects the object returned by fx.paint()")
    kw = {k: v for k, v in dict(hue=hue, brightness=brightness, rotation=rotation,
                                scale=scale, opacity=opacity).items() if v is not None}
    current_step("fx.toolkit.transformation()").ops.append(("xform", obj.idx, kw))
