from __future__ import annotations

import argparse
import os
import runpy
import sys

from . import _ui
from ._ui import Panel, fmt_n
from ._version import __version__
from .errors import FelixError
from .store import Dataset, open_reader, open_writer


def _transfer(src, dst, verb, overwrite):
    r = open_reader(src)
    names = r.names()
    w = open_writer(dst, overwrite)
    panel = Panel("")
    panel.title = panel.join(f"Felix {verb}", f"{src} → {dst}" if panel.uni else f"{src} -> {dst}")
    panel.sub = panel.join("Worker running", f"{fmt_n(len(names))} files")
    row = panel.row("files", len(names))
    try:
        with panel:
            for i, n in enumerate(names):
                w.write(n, r.read(n))
                row.label = f"file {fmt_n(i + 1)}/{fmt_n(len(names))}"
                row.advance()
            w.close()
            row.done()
            row.foot = f"written to {dst}"
    except BaseException:
        w.abort()
        raise
    finally:
        r.close()


def _info(path):
    ds = Dataset(path)
    panel = Panel("")
    panel.title = panel.join("Felix info", path)
    m = ds.metadata
    panel.sub = panel.join(f"{fmt_n(len(ds))} pairs", f"felix {m.get('felix_version', '?')}",
                           f"created {m.get('created', '?')}")
    row = panel.row("annotations", len(ds))
    counts, sizes = {}, {}
    with panel:
        for i, (_, a) in enumerate(ds):
            sizes[(a.get("width"), a.get("height"))] = sizes.get((a.get("width"), a.get("height")), 0) + 1
            for o in a.get("objects") or []:
                counts[o["class"]] = counts.get(o["class"], 0) + 1
            row.label = f"file {fmt_n(i + 1)}/{fmt_n(len(ds))}"
            row.advance()
        row.done()
        row.stats = panel.join(f"{fmt_n(sum(counts.values()))} boxes",
                               *(f"{w}x{h} ×{n}" if panel.uni else f"{w}x{h} x{n}" for (w, h), n in sizes.items()))
    classes = m.get("classes") or [{"id": i, "name": n, "set": "?"} for i, n in enumerate(sorted(counts))]
    panel.table(["id", "class", "set", "boxes"],
                [(c["id"], c["name"], c.get("set", ""), fmt_n(counts.get(c["name"], 0))) for c in classes])
    ds.close()


def _run(script, rest):
    if not os.path.isfile(script):
        raise FelixError(f"{script} not found")
    sys.argv = [script] + rest
    sys.path.insert(0, os.path.dirname(os.path.abspath(script)))
    runpy.run_path(script, run_name="__main__")


def build_parser():
    p = argparse.ArgumentParser(prog="felix", description="Felix dataset pipeline generator.")
    p.add_argument("--version", action="version", version=f"felix {__version__}")
    sub = p.add_subparsers(dest="cmd", metavar="command")
    s = sub.add_parser("run", help="run a pipeline script")
    s.add_argument("script")
    s.add_argument("args", nargs=argparse.REMAINDER)
    s = sub.add_parser("pack", help="compress a dataset folder into one .felix file")
    s.add_argument("folder")
    s.add_argument("-o", "--output")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("unpack", help="expand a .felix file into a folder")
    s.add_argument("file")
    s.add_argument("-o", "--output")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("info", help="summarise a dataset (folder or .felix)")
    s.add_argument("path")
    s = sub.add_parser("convert", help="convert other dataset formats into Felix")
    cs = s.add_subparsers(dest="fmt", metavar="format", required=True)
    c = cs.add_parser("coco", help="Roboflow / COCO export (folder or .zip)")
    c.add_argument("source")
    c.add_argument("-o", "--output", required=True, help="output folder, or a .felix file")
    c.add_argument("--png", action="store_true", help="re-encode images to PNG (much larger files)")
    c.add_argument("--overwrite", action="store_true")
    return p


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except Exception:
            pass
    p = build_parser()
    a = p.parse_args(argv)
    try:
        if a.cmd == "run":
            _run(a.script, a.args)
        elif a.cmd == "pack":
            src = a.folder.rstrip("/\\")
            _transfer(a.folder, a.output or src + ".felix", "pack", a.overwrite)
        elif a.cmd == "unpack":
            out = a.output or (a.file[:-6] if a.file.lower().endswith(".felix") else a.file + "_unpacked")
            _transfer(a.file, out, "unpack", a.overwrite)
        elif a.cmd == "info":
            _info(a.path)
        elif a.cmd == "convert":
            from .coco import convert_coco
            convert_coco(a.source, a.output, not a.png, a.overwrite)
        else:
            _ui.banner(__version__, [("run", "run a pipeline script"), ("pack", "folder → single .felix"),
                                     ("unpack", ".felix → folder"), ("info", "summarise a dataset"),
                                     ("convert", "import coco / roboflow datasets")])
    except FelixError as e:
        _ui.error(str(e))
        return 1
    except KeyboardInterrupt:
        _ui.error("interrupted")
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
