"""Tiny YAML subset writer/reader (block maps, block lists, flow lists of numbers).

Only what Felix itself writes is supported, which keeps Felix dependency-free.
Output is valid YAML, so any real YAML parser can read it too.
"""
from __future__ import annotations

import json
import re

_SAFE = re.compile(r"^[A-Za-z_][A-Za-z0-9_./-]*(?: [A-Za-z0-9_./-]+)*$")
_RESERVED = {"null", "true", "false", "yes", "no", "on", "off", "y", "n", "~"}
_INT = re.compile(r"^[-+]?\d+$")
_DEC = json.JSONDecoder()


def _scalar(v):
    if v is None:
        return "null"
    if v is True:
        return "true"
    if v is False:
        return "false"
    if isinstance(v, (int, float)):
        return repr(v)
    s = str(v)
    if _SAFE.match(s) and s.lower() not in _RESERVED:
        return s
    return json.dumps(s, ensure_ascii=False)


def _inline(v):
    if isinstance(v, dict):
        return None if v else "{}"
    if isinstance(v, (list, tuple)):
        if not v:
            return "[]"
        if all(x is None or isinstance(x, (bool, int, float)) for x in v):
            return "[" + ", ".join(_scalar(x) for x in v) + "]"
        return None
    return _scalar(v)


def _emit(o, ind, out):
    pad = " " * ind
    if isinstance(o, dict):
        for k, v in o.items():
            s = _inline(v)
            if s is not None:
                out.append(f"{pad}{_scalar(k)}: {s}")
            else:
                out.append(f"{pad}{_scalar(k)}:")
                _emit(v, ind + 2, out)
    else:
        for it in o:
            s = _inline(it)
            if s is not None:
                out.append(f"{pad}- {s}")
            else:
                sub = []
                _emit(it, ind + 2, sub)
                sub[0] = pad + "- " + sub[0][ind + 2:]
                out.extend(sub)


def dumps(obj) -> str:
    s = _inline(obj)
    if s is not None:
        return s + "\n"
    out: list = []
    _emit(obj, 0, out)
    return "\n".join(out) + "\n"


# ---------------------------------------------------------------- reader
def _plain(s):
    if s in ("null", "~", ""):
        return None
    if s == "true":
        return True
    if s == "false":
        return False
    if _INT.match(s):
        return int(s)
    try:
        return float(s)
    except ValueError:
        return s


def _value(s):
    if s.startswith('"'):
        return json.loads(s)
    if s == "[]":
        return []
    if s == "{}":
        return {}
    if s.startswith("[") and s.endswith("]"):
        return [_plain(x.strip()) for x in s[1:-1].split(",")]
    return _plain(s)


def _split_kv(s):
    if s.startswith('"'):
        try:
            key, end = _DEC.raw_decode(s)
        except ValueError:
            return None
        rest = s[end:]
        return (key, rest[1:].strip()) if rest.startswith(":") else None
    m = re.match(r"^([^:\[{][^:]*?):(?:\s+(.*))?$", s)
    return (m.group(1), (m.group(2) or "").strip()) if m else None


def _is_item(s):
    return s == "-" or s.startswith("- ")


def _block(t, i, ind):
    return _seq(t, i, ind) if _is_item(t[i][1]) else _map(t, i, ind)


def _seq(t, i, ind):
    out = []
    while i < len(t) and t[i][0] == ind and _is_item(t[i][1]):
        body = t[i][1][2:].strip()
        if not body:
            i += 1
            v, i = _block(t, i, t[i][0])
        else:
            t[i] = (ind + 2, body)
            if _is_item(body) or _split_kv(body):
                v, i = _block(t, i, ind + 2)
            else:
                v, i = _value(body), i + 1
        out.append(v)
    return out, i


def _map(t, i, ind):
    out = {}
    while i < len(t) and t[i][0] == ind and not _is_item(t[i][1]):
        kv = _split_kv(t[i][1])
        if kv is None:
            raise ValueError(f"bad yaml line: {t[i][1]!r}")
        k, rest = kv
        i += 1
        if rest:
            out[k] = _value(rest)
        elif i < len(t) and t[i][0] > ind:
            out[k], i = _block(t, i, t[i][0])
        elif i < len(t) and t[i][0] == ind and _is_item(t[i][1]):
            out[k], i = _seq(t, i, ind)
        else:
            out[k] = None
    return out, i


def loads(text: str):
    t = []
    for raw in text.splitlines():
        s = raw.strip()
        if s and not s.startswith("#"):
            t.append((len(raw) - len(raw.lstrip(" ")), s))
    if not t:
        return None
    if len(t) == 1 and not _is_item(t[0][1]) and not _split_kv(t[0][1]):
        return _value(t[0][1])
    v, _ = _block(t, 0, t[0][0])
    return v
