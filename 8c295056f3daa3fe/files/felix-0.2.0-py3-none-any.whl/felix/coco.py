"""Roboflow / COCO -> Felix converter."""
from __future__ import annotations

import io
import json
import tempfile
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import _yaml
from ._ui import Panel, fmt_dur, fmt_n
from ._version import __version__
from .errors import FelixError
from .store import open_writer

ANN = "_annotations.coco.json"


def _num(v):
    v = round(float(v), 2)
    return int(v) if v.is_integer() else v


def convert_coco(src, out, keep_format=True, overwrite=False, quiet=False):
    src = Path(src)
    if not src.exists():
        raise FelixError(f"{src} does not exist")
    with tempfile.TemporaryDirectory() as tmp:
        root = src
        if src.is_file():
            if not zipfile.is_zipfile(src):
                raise FelixError("input must be a folder or a .zip of a COCO export")
            with zipfile.ZipFile(src) as z:
                z.extractall(tmp)
            root = Path(tmp)
        return _convert(root, out, keep_format, overwrite, quiet)


def _convert(root, out, keep_format, overwrite, quiet):
    found = sorted(root.rglob(ANN))
    if not found:
        raise FelixError(f"no {ANN} found under {root} (expected a Roboflow COCO export)")
    splits = []
    for f in found:
        name = None if f.parent == root else f.parent.name
        try:
            splits.append((name, f.parent, json.loads(f.read_text("utf-8"))))
        except ValueError as e:
            raise FelixError(f"{f}: invalid JSON ({e})") from None

    # ---- classes: drop unused parent categories (Roboflow adds a "supercategory" entry)
    used, cats, parents = set(), {}, set()
    for _, _, d in splits:
        by_id = {c["id"]: c for c in d.get("categories", [])}
        for a in d.get("annotations", []):
            if a.get("category_id") in by_id:
                used.add(by_id[a["category_id"]]["name"])
        for c in d.get("categories", []):
            cats.setdefault(c["name"], c)
            sup = c.get("supercategory")
            if sup and sup != "none":
                parents.add(sup)
    keep = [n for n in cats if n in used or n not in parents]
    classes = []
    for i, n in enumerate(keep):
        sup = cats[n].get("supercategory")
        classes.append({"id": i, "name": n, "set": sup if sup and sup != "none" else "default"})
    cmap = {c["name"]: c for c in classes}

    total = sum(len(d.get("images", [])) for _, _, d in splits)
    writer = open_writer(out, overwrite)
    panel = Panel("", quiet=quiet)
    panel.title = panel.join("Felix convert coco", str(out), f"{fmt_n(total)} images")
    panel.sub = panel.join("Converter running", f"{len(classes)} classes")
    rows = [panel.row(n or "all", len(d.get("images", []))) for n, _, d in splits]
    counter, missing, split_counts, boxes = 0, 0, {}, 0
    t0 = time.time()
    try:
        with panel:
            for (sname, folder, d), row in zip(splits, rows):
                id2name = {c["id"]: c["name"] for c in d.get("categories", [])}
                per_img = {}
                for a in d.get("annotations", []):
                    per_img.setdefault(a.get("image_id"), []).append(a)
                for img in d.get("images", []):
                    path = (folder / img["file_name"]).resolve()
                    if folder.resolve() not in path.parents or not path.is_file():
                        missing += 1
                        row.advance()
                        continue
                    counter += 1
                    raw = path.read_bytes()
                    w, h = img.get("width"), img.get("height")
                    if keep_format and w and h:
                        ext, data = path.suffix.lower() or ".png", raw
                    else:
                        from PIL import Image
                        im = Image.open(io.BytesIO(raw))
                        w, h = im.size
                        if keep_format:
                            ext, data = path.suffix.lower() or ".png", raw
                        else:
                            buf = io.BytesIO()
                            im.convert("RGB" if im.mode not in ("RGBA", "LA", "P") else "RGBA").save(
                                buf, "PNG", compress_level=3)
                            ext, data = ".png", buf.getvalue()
                    stem = f"IMG{counter}"
                    objs = []
                    for a in per_img.get(img["id"], []):
                        c = cmap.get(id2name.get(a.get("category_id")))
                        bx = a.get("bbox")
                        if c is None or not bx or bx[2] <= 0 or bx[3] <= 0:
                            continue
                        objs.append({"class": c["name"], "class_id": c["id"], "class_set": c["set"],
                                     "bbox": [_num(v) for v in bx]})
                    writer.write(f"images/{stem}{ext}", data)
                    ann = {"image": f"{stem}{ext}", "width": int(w), "height": int(h)}
                    if sname:
                        ann["split"] = sname
                    ann["objects"] = objs
                    writer.write(f"annotations/{stem}.yml", _yaml.dumps(ann).encode("utf-8"))
                    boxes += len(objs)
                    split_counts[sname or "all"] = split_counts.get(sname or "all", 0) + 1
                    row.label = f"image {fmt_n(row.n + 1)}/{fmt_n(row.total)}"
                    row.stats = panel.join(f"{fmt_n(boxes)} boxes so far")
                    row.advance()
            writer.write("metadata.yml", _yaml.dumps({
                "felix_version": __version__,
                "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                "source": "coco", "pairs": counter, "image_format": "original" if keep_format else "png",
                "bbox_format": "xywh", "splits": split_counts, "classes": classes}).encode("utf-8"))
            writer.close()
            for row in rows:
                row.done()
                row.foot = panel.join(f"took {fmt_dur(time.time() - t0)}", f"written to {out}")
            if missing:
                panel.note(f"{fmt_n(missing)} image(s) listed in the COCO file were missing and skipped.")
    except BaseException:
        writer.abort()
        raise
    return {"pairs": counter, "boxes": boxes, "classes": len(classes)}
