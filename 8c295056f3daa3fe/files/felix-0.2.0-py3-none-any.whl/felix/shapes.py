"""Shapes (class templates) and per-sample instances with transformations."""
from __future__ import annotations

import math
import os

from PIL import Image, ImageColor, ImageDraw

from .errors import FelixError

_R = getattr(Image, "Resampling", Image)
LANCZOS, BICUBIC = _R.LANCZOS, _R.BICUBIC
_AA = 3  # supersampling factor for smooth edges
_ALPHA_LUT = [255 if v > 16 else 0 for v in range(256)]

PALETTE = (
    "#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#46c8c8",
    "#f032e6", "#9acd32", "#008080", "#9a6324", "#800000", "#808000",
)


def rgba(c):
    if isinstance(c, (tuple, list)):
        t = tuple(int(v) for v in c)
        if len(t) == 3:
            return t + (255,)
        if len(t) == 4:
            return t
        raise FelixError(f"bad color {c!r}")
    try:
        return ImageColor.getcolor(str(c), "RGBA")
    except ValueError:
        raise FelixError(f"unknown color {c!r}") from None


class Shape:
    """A drawable template. Becomes a class when defined inside fx.class_set()."""

    def __init__(self, kind, params, color=None, position=None, name=None):
        if position is not None:
            if len(position) != 2:
                raise FelixError("position must be an (x, y) pair")
            position = (float(position[0]), float(position[1]))
        self.kind, self.params, self.color, self.position = kind, params, color, position
        self.name, self.set, self.id = name, None, None
        self._sprite = None

    def __repr__(self):
        return f"<Shape {self.kind} {self.name or ''}>"

    def sprite(self):
        if self._sprite is None:
            self._sprite = self._build()
        return self._sprite

    def _build(self):
        k, p = self.kind, self.params
        if k == "image":
            im = Image.open(p["source"]).convert("RGBA")
            w, h = p.get("width"), p.get("height")
            if w or h:
                w = w or max(1, round(im.width * h / im.height))
                h = h or max(1, round(im.height * w / im.width))
                im = im.resize((int(w), int(h)), LANCZOS)
            return im
        col = rgba(self.color if self.color is not None else "#808080")
        pts = None
        if k == "circle":
            w = h = max(1, round(2 * p["radius"]))
        elif k == "rectangle":
            w, h = max(1, round(p["width"])), max(1, round(p["height"]))
        else:
            xs, ys = [v[0] for v in p["vertices"]], [v[1] for v in p["vertices"]]
            ox, oy = min(xs), min(ys)
            w, h = max(1, math.ceil(max(xs) - ox)), max(1, math.ceil(max(ys) - oy))
            pts = [((x - ox) * _AA, (y - oy) * _AA) for x, y in p["vertices"]]
        big = Image.new("RGBA", (w * _AA, h * _AA), col[:3] + (0,))
        d = ImageDraw.Draw(big)
        if k == "circle":
            d.ellipse([0, 0, w * _AA - 1, h * _AA - 1], fill=col)
        elif k == "rectangle":
            d.rectangle([0, 0, w * _AA - 1, h * _AA - 1], fill=col)
        else:
            d.polygon(pts, fill=col)
        return big.resize((w, h), LANCZOS)


def _color_shift(im, hue, bright):
    alpha = im.getchannel("A")
    rgb = im.convert("RGB")
    if hue % 360:
        h, s, v = rgb.convert("HSV").split()
        sh = round(hue / 360 * 256)
        h = h.point([(i + sh) & 255 for i in range(256)])
        rgb = Image.merge("HSV", (h, s, v)).convert("RGB")
    if bright != 1:
        rgb = rgb.point([min(255, int(i * bright)) for i in range(256)] * 3)
    rgb.putalpha(alpha)
    return rgb


class Inst:
    """One painted object in one sample."""

    __slots__ = ("shape", "pos", "hue", "brightness", "rotation", "scale", "opacity", "frozen", "_sp")

    def __init__(self, shape, pos):
        self.shape, self.pos = shape, pos
        self.hue, self.brightness, self.rotation, self.scale, self.opacity = 0.0, 1.0, 0.0, 1.0, 1.0
        self.frozen, self._sp = False, None

    def apply(self, hue=None, brightness=None, rotation=None, scale=None, opacity=None):
        if self.frozen:  # already annotated by fx.gen(): changes are ignored
            return
        if hue is not None:
            self.hue += hue
        if brightness is not None:
            self.brightness *= max(0.0, brightness)
        if rotation is not None:
            self.rotation += rotation
        if scale is not None:
            if scale <= 0:
                raise FelixError("scale must be > 0")
            self.scale *= scale
        if opacity is not None:
            self.opacity *= min(1.0, max(0.0, opacity))
        self._sp = None

    def sprite(self):
        if self._sp is None:
            im = self.shape.sprite()
            if self.scale != 1:
                im = im.resize((max(1, round(im.width * self.scale)),
                                max(1, round(im.height * self.scale))), BICUBIC)
            if self.hue % 360 or self.brightness != 1:
                im = _color_shift(im, self.hue, self.brightness)
            if self.rotation % 360:
                im = im.rotate(self.rotation, resample=BICUBIC, expand=True)
            if self.opacity < 1:
                a = im.getchannel("A").point([int(v * self.opacity) for v in range(256)])
                im = im.copy()
                im.putalpha(a)
            self._sp = im
        return self._sp

    def origin(self):
        sp = self.sprite()
        return round(self.pos[0] - sp.width / 2), round(self.pos[1] - sp.height / 2)

    def bbox(self, size):
        """Tight xywh box of visible (non-transparent) pixels, clipped to the canvas."""
        sp = self.sprite()
        bb = sp.getchannel("A").point(_ALPHA_LUT).getbbox()
        if bb is None:
            return None
        ox, oy = self.origin()
        x0, y0 = max(0, ox + bb[0]), max(0, oy + bb[1])
        x1, y1 = min(size[0], ox + bb[2]), min(size[1], oy + bb[3])
        if x1 <= x0 or y1 <= y0:
            return None
        return [x0, y0, x1 - x0, y1 - y0]
