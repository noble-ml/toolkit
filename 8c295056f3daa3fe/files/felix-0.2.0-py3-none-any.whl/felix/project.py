"""Global pipeline state, steps and the per-sample executor."""
from __future__ import annotations

import os
import sys

from PIL import Image

from .errors import FelixError
from .rand import Node, resolve
from .shapes import PALETTE, Inst, Shape, rgba

_IMG_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".webp")
_BG_CACHE: dict = {}


class ClassSet:
    def __init__(self, name):
        self.name, self.classes = name, []


class Project:
    def __init__(self):
        self.reset()

    def reset(self):
        self.sets, self.by_name, self.classes = {}, {}, []
        self.steps, self.stack, self.cur = [], [], None

    def add_class(self, cs, shape, name):
        if name in self.by_name:
            raise FelixError(f"duplicate class name {name!r}")
        shape.name, shape.set, shape.id = name, cs.name, len(self.classes)
        if shape.kind != "image" and shape.color is None:
            shape.color = PALETTE[shape.id % len(PALETTE)]
        cs.classes.append(shape)
        self.classes.append(shape)
        self.by_name[name] = shape

    def lookup(self, t):
        if t is None or isinstance(t, Shape):
            return t
        if isinstance(t, str):
            if t not in self.by_name:
                raise FelixError(f"unknown class {t!r}")
            return self.by_name[t]
        raise FelixError(f"cannot paint {t!r}")


P = Project()


def reset():
    """Forget every class set and step (useful in tests / notebooks)."""
    P.reset()


class _ClassSetCtx:
    def __init__(self, name):
        if not name or not isinstance(name, str):
            raise FelixError("class_set needs a name")
        self.name = name

    def __enter__(self):
        cs = P.sets.setdefault(self.name, ClassSet(self.name))
        P.stack.append((cs, []))
        return cs

    def __exit__(self, et, ev, tb):
        cs, pending = P.stack.pop()
        if et:
            return False
        # Class names come from the variable names used inside the with-block.
        names = {id(v): k for k, v in sys._getframe(1).f_locals.items() if isinstance(v, Shape)}
        for sh in pending:
            P.add_class(cs, sh, sh.name or names.get(id(sh)) or f"{cs.name}_{len(cs.classes)}")
        return False


def class_set(name):
    """``with fx.class_set("animals"): cat = fx.toolkit.circle(...)``"""
    return _ClassSetCtx(name)


class Obj:
    """Handle returned by fx.paint(), used to transform the painted object."""
    __slots__ = ("idx",)

    def __init__(self, idx):
        self.idx = idx


class Ctx:
    def __init__(self, project, rng, size):
        self.project, self.rng, self.size, self.cache = project, rng, size, {}


class Step:
    def __init__(self, size, name):
        try:
            w, h = size
            w, h = int(w), int(h)
        except (TypeError, ValueError):
            raise FelixError("step size must be (width, height)") from None
        if w < 1 or h < 1:
            raise FelixError("step size must be positive")
        self.size, self.name, self.ops, self.n = (w, h), name, [], 0

    def run(self, project, rng):
        """Produce one sample. Returns (image, annotations, skipped_objects)."""
        W, H = self.size
        ctx = Ctx(project, rng, self.size)
        insts, order, pending, anns, skipped, bg = {}, [], [], [], 0, (None, None)
        for op in self.ops:
            kind = op[0]
            if kind == "bg":
                bg = (resolve(op[1], ctx), resolve(op[2], ctx))
            elif kind == "paint":
                shape = project.lookup(resolve(op[2], ctx))
                if shape is None:
                    insts[op[1]] = None
                    continue
                pos = resolve(op[3], ctx)
                if pos is None:
                    pos = shape.position or (W / 2, H / 2)
                inst = Inst(shape, pos)
                insts[op[1]] = inst
                order.append(inst)
                pending.append(inst)
            elif kind == "xform":
                inst = insts.get(op[1])
                if inst is not None:
                    inst.apply(**{k: resolve(v, ctx) for k, v in op[2].items()})
            else:  # gen: annotate everything painted so far, then freeze it
                for inst in pending:
                    inst.frozen = True
                    if inst.shape.name is None:
                        continue  # plain decoration, not a class
                    bb = inst.bbox(self.size)
                    if bb is None:
                        skipped += 1
                        continue
                    s = inst.shape
                    anns.append({"class": s.name, "class_id": s.id, "class_set": s.set, "bbox": bb})
                pending = []
        img = _background(bg, self.size, rng)
        for inst in order:
            sp = inst.sprite()
            img.paste(sp, inst.origin(), sp)
        return img, anns, skipped


def _background(bg, size, rng):
    color, image = bg
    if image is None:
        return Image.new("RGB", size, rgba(color if color is not None else "#ffffff")[:3])
    path = str(image)
    if os.path.isdir(path):
        if path not in _BG_CACHE:
            _BG_CACHE[path] = sorted(
                os.path.join(path, f) for f in os.listdir(path) if f.lower().endswith(_IMG_EXT))
        files = _BG_CACHE[path]
        if not files:
            raise FelixError(f"no images in background folder {path!r}")
        path = rng.choice(files)
    try:
        im = Image.open(path).convert("RGB")
    except OSError as e:
        raise FelixError(f"cannot read background {path!r}: {e}") from None
    s = max(size[0] / im.width, size[1] / im.height)  # cover-fit, then center-crop
    im = im.resize((max(size[0], round(im.width * s)), max(size[1], round(im.height * s))))
    l, t = (im.width - size[0]) // 2, (im.height - size[1]) // 2
    return im.crop((l, t, l + size[0], t + size[1]))


class _StepCtx:
    def __init__(self, size, name):
        self.step_ = Step(size, name)

    def __enter__(self):
        if P.cur is not None:
            raise FelixError("fx.step() blocks cannot be nested")
        P.cur = self.step_
        return self.step_

    def __exit__(self, et, ev, tb):
        P.cur = None
        if not et:
            if self.step_.name is None:
                self.step_.name = f"step-{len(P.steps) + 1}"
            P.steps.append(self.step_)
        return False


def step(size=(640, 640), name=None):
    """``with fx.step(size=(640, 640)):`` - describe how one image is generated.

    The body runs once to record the recipe; random values are re-sampled for
    every image.
    """
    return _StepCtx(size, name)


def current_step(what):
    if P.cur is None:
        raise FelixError(f"{what} must be called inside `with fx.step(...)`")
    return P.cur


def paint(target, position=None):
    """Place a class (or a plain shape) on the canvas. Returns a handle."""
    s = current_step("fx.paint()")
    o = Obj(s.n)
    s.n += 1
    s.ops.append(("paint", o.idx, target, position))
    return o


def gen():
    """Annotate everything painted so far. Later paints are drawn but not annotated."""
    current_step("fx.gen()").ops.append(("gen",))
