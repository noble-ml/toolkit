"""Lazy random values. Nodes are re-sampled for every generated image.

Every constructor accepts ``threshold`` (0..1): the probability that a value is
produced at all. When the roll fails the value is ``None`` - painting ``None``
does nothing and a ``None`` transformation parameter is left unchanged.
"""
from __future__ import annotations

from .errors import FelixError


class Node:
    def value(self, ctx):  # pragma: no cover
        raise NotImplementedError


def resolve(x, ctx):
    """Turn a (possibly nested) lazy value into a concrete one, once per sample."""
    if isinstance(x, Node):
        c = ctx.cache
        if id(x) not in c:
            c[id(x)] = x.value(ctx)
        return c[id(x)]
    if isinstance(x, tuple):
        return tuple(resolve(i, ctx) for i in x)
    if isinstance(x, list):
        return [resolve(i, ctx) for i in x]
    return x


class _Rand(Node):
    def __init__(self, threshold=1.0):
        if not 0.0 <= threshold <= 1.0:
            raise FelixError("threshold must be between 0 and 1")
        self.threshold = threshold

    def value(self, ctx):
        if self.threshold < 1.0 and ctx.rng.random() >= self.threshold:
            return None
        return self.draw(ctx)


class _Uniform(_Rand):
    def __init__(self, lo, hi, threshold=1.0, integer=False):
        super().__init__(threshold)
        self.lo, self.hi, self.integer = lo, hi, integer

    def draw(self, ctx):
        f = ctx.rng.randint if self.integer else ctx.rng.uniform
        if isinstance(self.lo, (tuple, list)):
            return tuple(f(a, b) for a, b in zip(self.lo, self.hi))
        return f(self.lo, self.hi)


class _Choice(_Rand):
    def __init__(self, options, threshold=1.0):
        super().__init__(threshold)
        if not options:
            raise FelixError("choice() needs at least one option")
        self.options = list(options)

    def draw(self, ctx):
        return resolve(ctx.rng.choice(self.options), ctx)


class _Position(_Rand):
    def __init__(self, margin=0, threshold=1.0):
        super().__init__(threshold)
        self.margin = margin

    def draw(self, ctx):
        w, h = ctx.size
        m = self.margin
        return (ctx.rng.uniform(m, max(m, w - m)), ctx.rng.uniform(m, max(m, h - m)))


class _Color(_Rand):
    def draw(self, ctx):
        return "#%02x%02x%02x" % tuple(ctx.rng.randrange(256) for _ in range(3))


class _ClassSet(_Rand):
    def __init__(self, names, threshold=1.0):
        super().__init__(threshold)
        self.names = names

    def draw(self, ctx):
        sets = [s for n, s in ctx.project.sets.items() if (not self.names or n in self.names) and s.classes]
        if not sets:
            raise FelixError("random.class_set(): no class sets with classes defined")
        return ctx.rng.choice(sets)


class _Class(_Rand):
    def __init__(self, source, threshold=1.0):
        super().__init__(threshold)
        self.source = source

    def draw(self, ctx):
        src = resolve(self.source, ctx) if self.source is not None else None
        if src is None and self.source is not None:
            return None  # the class set roll failed
        if src is None:
            pool = ctx.project.classes
        else:
            if isinstance(src, str):
                if src not in ctx.project.sets:
                    raise FelixError(f"unknown class set {src!r}")
                src = ctx.project.sets[src]
            pool = src.classes
        if not pool:
            raise FelixError("random.class_(): no classes to pick from")
        return ctx.rng.choice(pool)


# ------------------------------------------------------------ public API
def uniform(lo, hi, threshold=1.0):
    """Random float in [lo, hi]. ``lo``/``hi`` may be tuples (per-component)."""
    return _Uniform(lo, hi, threshold)


value = uniform


def integer(lo, hi, threshold=1.0):
    """Random int in [lo, hi] (inclusive)."""
    return _Uniform(lo, hi, threshold, integer=True)


def choice(*options, threshold=1.0):
    return _Choice(options, threshold)


def position(margin=0, threshold=1.0):
    """Random (x, y) on the canvas, ``margin`` pixels away from the edges."""
    return _Position(margin, threshold)


def color(threshold=1.0):
    return _Color(threshold)


def class_set(*names, threshold=1.0):
    """Pick a class set (optionally only among ``names``)."""
    return _ClassSet(set(names), threshold)


def class_(from_=None, threshold=1.0):
    """Pick a class from a set (random node, name or None for any class).

    ``class`` is a Python keyword, so the function is called ``class_``.
    """
    return _Class(from_, threshold)


cls = class_
