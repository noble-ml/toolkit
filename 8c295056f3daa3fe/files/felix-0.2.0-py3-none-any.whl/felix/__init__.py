"""Felix - a lightweight dataset pipeline generator."""
from ._version import __version__
from .errors import FelixError
from .project import class_set, step, paint, gen, reset
from . import toolkit, canvas
from . import rand as random
from .make import make
from .store import Dataset, load

__all__ = [
    "__version__", "FelixError", "class_set", "step", "paint", "gen", "reset",
    "toolkit", "canvas", "random", "make", "Dataset", "load",
]
