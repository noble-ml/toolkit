class FelixError(Exception):
    """Raised for any user-facing Felix error."""
