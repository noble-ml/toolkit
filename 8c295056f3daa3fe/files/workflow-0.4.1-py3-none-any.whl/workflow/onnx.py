"""A minimal ONNX writer: just enough protobuf to serialise a model graph, with no dependencies."""
from __future__ import annotations

import struct
from typing import List, Sequence, Tuple

FLOAT, INT8, INT64, FLOAT16 = 1, 3, 7, 10


def _varint(n: int) -> bytes:
    if n < 0:
        n += 1 << 64
    out = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        out.append(b | (0x80 if n else 0))
        if not n:
            return bytes(out)


def _f(field: int, wire: int, payload: bytes) -> bytes:
    return _varint((field << 3) | wire) + payload


def _int(field: int, v: int) -> bytes:
    return _f(field, 0, _varint(int(v)))


def _bytes(field: int, v) -> bytes:
    v = v.encode() if isinstance(v, str) else bytes(v)
    return _f(field, 2, _varint(len(v)) + v)


def tensor(name: str, dims: Sequence[int], dtype: int, raw: bytes) -> bytes:
    return b"".join(_int(1, d) for d in dims) + _int(2, dtype) + _bytes(8, name) + _bytes(9, raw)


def attr(name: str, value) -> bytes:
    out = _bytes(1, name)
    if isinstance(value, float):
        return out + _f(2, 5, struct.pack("<f", value)) + _int(20, 1)
    if isinstance(value, int):
        return out + _int(3, value) + _int(20, 2)
    if isinstance(value, str):
        return out + _bytes(4, value) + _int(20, 3)
    if value and isinstance(value[0], float):
        return out + b"".join(_f(7, 5, struct.pack("<f", v)) for v in value) + _int(20, 6)
    return out + b"".join(_int(8, v) for v in value) + _int(20, 7)


def node(op: str, inputs: Sequence[str], outputs: Sequence[str], name: str = "", **attrs) -> bytes:
    return (b"".join(_bytes(1, i) for i in inputs) + b"".join(_bytes(2, o) for o in outputs) + _bytes(3, name or outputs[0])
            + _bytes(4, op) + b"".join(_bytes(5, attr(k, v)) for k, v in attrs.items()))


def value_info(name: str, dtype: int, dims: Sequence) -> bytes:
    shape = b"".join(_bytes(1, _bytes(2, d) if isinstance(d, str) else _int(1, d)) for d in dims)
    return _bytes(1, name) + _bytes(2, _bytes(1, _int(1, dtype) + _bytes(2, shape)))


def model(nodes: List[bytes], initializers: List[bytes], inputs: List[bytes], outputs: List[bytes],
          producer_version: str, opset: int = 13, name: str = "workflow") -> bytes:
    graph = (b"".join(_bytes(1, n) for n in nodes) + _bytes(2, name) + b"".join(_bytes(5, t) for t in initializers)
             + b"".join(_bytes(11, i) for i in inputs) + b"".join(_bytes(12, o) for o in outputs))
    return (_int(1, 8) + _bytes(2, "workflow") + _bytes(3, producer_version) + _bytes(7, graph)
            + _bytes(8, _bytes(1, "") + _int(2, opset)))
