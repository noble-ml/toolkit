"""The ``.nbm`` (Noble Model) format, version 2.

A zip archive:
* ``meta.json``   - format, architecture spec, input, classes, detection and training metadata, precision,
                    and an index of every tensor (name, shape, dtype, offset)
* ``weights.bin`` - the tensors, little-endian: float32, float16 or int8 (with a scale per tensor)
* ``train.bin``   - optional: optimizer moments and raw (non-EMA) weights, to continue training exactly
"""
from __future__ import annotations

import ctypes as C
import io
import json
import os
import struct
import zipfile
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from ._version import __version__
from .core import Tensor, device as _device
from .core.cpu import lib
from .errors import SerializationError

FORMAT = 2
EXT = ".nbm"


def _pack(tensors: Dict[str, Tensor], precision: str = "fp32", quantizable=()):
    """Serialise tensors → (bytes, index). ``quantizable`` names are stored as int8 when precision is int8."""
    blob, index = io.BytesIO(), []
    cpu = _device.get("cpu")
    for name, t in tensors.items():
        h = t.dev.be.host(t)
        entry = {"name": name, "shape": list(t.shape), "offset": blob.tell(), "dtype": "f32"}
        raw = h.tobytes()
        if precision == "int8" and name in quantizable:
            lo, hi = cpu.be.minmax(h)
            scale = max(abs(lo), abs(hi), 1e-12) / 127.0
            q = (C.c_int8 * h.size)()
            lib().wf_quantize_i8(h.h, q, h.size, scale)
            raw, entry["dtype"], entry["scale"] = bytes(q), "i8", scale
        elif precision == "fp16" and name in quantizable:
            raw, entry["dtype"] = struct.pack(f"<{h.size}e", *struct.unpack(f"<{h.size}f", raw)), "f16"
        blob.write(raw)
        index.append(entry)
    return blob.getvalue(), index


def _unpack(data: bytes, index) -> Dict[str, Tensor]:
    cpu = _device.get("cpu")
    out = {}
    for i, e in enumerate(index):
        n = 1
        for v in e["shape"]:
            n *= v
        off = e["offset"]
        if e["dtype"] == "f32":
            t = Tensor.from_bytes(e["shape"], data[off:off + 4 * n], cpu)
        elif e["dtype"] == "f16":
            t = Tensor.from_bytes(e["shape"], struct.pack(f"<{n}f", *struct.unpack(f"<{n}e", data[off:off + 2 * n])), cpu)
        elif e["dtype"] == "i8":
            t = cpu.be.empty(e["shape"])
            lib().wf_dequantize_i8(data[off:off + n], t.h, n, e["scale"])
        else:
            raise SerializationError(f"the model file uses an unknown tensor type {e['dtype']!r}.",
                                     "it was written by a newer Workflow.", "upgrade Workflow.")
        out[e["name"]] = t
    return out


def save(model, path, weights: Optional[Dict[str, Tensor]] = None, train: Optional[Dict[str, Tensor]] = None,
         precision: str = "fp32", **meta: Any) -> str:
    path = os.fspath(path)
    if not path.lower().endswith(EXT):
        raise SerializationError(f"cannot save a model as {os.path.basename(path)!r}.", f"Workflow models use the {EXT} extension.",
                                 f"use a file name ending in {EXT}; for other formats call model.export(format='onnx', ...).")
    model._ensure()
    state = weights if weights is not None else model.state()
    quantizable = {k for k, t in state.items() if k.endswith("weight") and len(t.shape) == 4}
    blob, index = _pack(state, precision, quantizable)
    doc = {"format": "nbm", "version": FORMAT, "workflow_version": __version__,
           "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "arch": json.loads(json.dumps(model.spec())), "input": list(model.input), "precision": precision,
           "tensors": index, "classes": None, "detection": None, "training": None, "quantization": None}
    doc.update({k: v for k, v in meta.items() if v is not None})
    tmp = path + ".part"
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
            if train is not None:
                tblob, tindex = _pack(train)
                doc["train_tensors"] = tindex
                z.writestr("train.bin", tblob)
            z.writestr("meta.json", json.dumps(doc, indent=1))
            z.writestr("weights.bin", blob)
        with open(tmp, "rb+") as f:                  # on disk before it replaces the old file: a power cut leaves
            os.fsync(f.fileno())                     # either the old checkpoint or the new one, never half of one
        os.replace(tmp, path)
        try:
            d = os.open(os.path.dirname(os.path.abspath(path)), os.O_RDONLY)
            try:
                os.fsync(d)
            finally:
                os.close(d)
        except OSError:
            pass
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)
    return path


def read_meta(path) -> Dict[str, Any]:
    path = os.fspath(path)
    if not os.path.isfile(path):
        raise SerializationError(f"model file not found: {path!r}.", "the path does not point to a file.", "check the path.")
    if not zipfile.is_zipfile(path):
        raise SerializationError(f"{path!r} is not a {EXT} model.", "the file is not a Noble Model archive.",
                                 "pass a file written by model.save(...) or model.export(format='nbm', ...).")
    with zipfile.ZipFile(path) as z:
        try:
            doc = json.loads(z.read("meta.json"))
        except KeyError:
            raise SerializationError(f"{path!r} is not a {EXT} model.", "it has no meta.json.", "pass a file written by Workflow.") from None
    if doc.get("version", 0) < 2:
        raise SerializationError(f"{path!r} was written by an older, PyTorch-based Workflow.",
                                 "the model format changed when Workflow moved to its own compute core.",
                                 "retrain the model with this version (old files cannot be read).")
    if doc.get("version", 0) > FORMAT:
        raise SerializationError(f"{path!r} needs a newer Workflow.", f"it uses format {doc['version']}; this version reads up to {FORMAT}.",
                                 "upgrade Workflow.")
    return doc


def load(path, device=None):
    """Rebuild the model stored in ``path``: architecture, weights, class names, quantisation and training state."""
    from .layer import Layer
    meta = read_meta(path)
    model = Layer.from_spec(meta["arch"])
    restore(model, path, meta)
    return model.device(device) if device else model


def restore(model, path, meta=None) -> None:
    meta = meta or read_meta(path)
    model.build(tuple(meta["input"]))
    with zipfile.ZipFile(os.fspath(path)) as z:
        tensors = _unpack(z.read("weights.bin"), meta["tensors"])
        extra = _unpack(z.read("train.bin"), meta["train_tensors"]) if "train_tensors" in meta else {}
    model.load_state(tensors, source=os.fspath(path))
    model.class_names = meta.get("classes")
    model.precision = meta.get("precision", "fp32")
    q = meta.get("quantization")
    model.quant = None
    if q:
        from .quant import Scheme
        model.quant = Scheme.from_meta(q, model)
    tr = meta.get("training")
    model.history = list(tr.get("history", [])) if tr else []
    model._train_state = None
    if tr:
        model._train_state = {
            "epoch": tr["epoch"], "epochs": tr.get("epochs"), "best_fitness": tr.get("best_fitness"),
            "best_epoch": tr.get("best_epoch"), "config": tr.get("config"), "step": tr.get("step", 0),
            "ema_updates": tr.get("ema_updates", 0), "resume": tr.get("resume"),
            "m": {k[6:]: v for k, v in extra.items() if k.startswith("opt.m.")},
            "v": {k[6:]: v for k, v in extra.items() if k.startswith("opt.v.")},
            "raw": {k[4:]: v for k, v in extra.items() if k.startswith("raw.")} or None}
