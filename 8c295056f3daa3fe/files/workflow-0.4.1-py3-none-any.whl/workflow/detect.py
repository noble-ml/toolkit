"""Detection maths that runs on the host in the C core: loss with gradients, decoding and NMS."""
from __future__ import annotations

import ctypes as C
from typing import List, Sequence, Tuple

from .core import Tensor, device as _device
from .core.cpu import lib


def _levels(outs: Sequence[Tensor]):
    cpu = _device.get("cpu")
    host = [o.dev.be.host(o) for o in outs]
    L = len(host)
    ptrs = (C.c_void_p * L)(*[h.h for h in host])
    hs = (C.c_int * L)(*[h.shape[2] for h in host])
    ws = (C.c_int * L)(*[h.shape[3] for h in host])
    return cpu, host, L, ptrs, hs, ws


def loss(outs: Sequence[Tensor], targets: Sequence[float], img_hw: Tuple[int, int], weights=(5.0, 1.0, 1.0)):
    """Detection loss for the head's raw maps. ``targets`` is a flat list of rows
    [image index, class, x1, y1, x2, y2] in pixels of the network input.

    Sets ``.grad`` on every map (ready for ``backward()``) and returns (total, {"box", "obj", "cls"}).
    Objects are matched to the pyramid level that suits their size; loss = 5·(1−GIoU) + BCE confidence + BCE class,
    normalised by the number of positive cells."""
    cpu, host, L, ptrs, hs, ws = _levels(outs)
    N, CH = host[0].shape[0], host[0].shape[1]
    grads = [cpu.be.empty(h.shape) for h in host]
    gptrs = (C.c_void_p * L)(*[g.h for g in grads])
    T = len(targets) // 6
    tg = (C.c_float * max(1, len(targets)))(*targets)
    parts = (C.c_double * 4)()
    total = lib().wf_det_loss(L, ptrs, gptrs, hs, ws, N, CH - 5, img_hw[0], img_hw[1], tg, T,
                              weights[0], weights[1], weights[2], parts)
    for o, g in zip(outs, grads):
        o.grad = g.to(o.dev)
    return total, {"box": parts[0], "obj": parts[1], "cls": parts[2]}


def decode(outs: Sequence[Tensor], img_hw: Tuple[int, int], conf: float = 0.25, iou: float = 0.45,
           max_det: int = 300, max_nms: int = 1000) -> List[List[List[float]]]:
    """Raw maps → per image a list of [x1, y1, x2, y2, score, class] after class-aware NMS."""
    cpu, host, L, ptrs, hs, ws = _levels(outs)
    N, CH = host[0].shape[0], host[0].shape[1]
    out = (C.c_float * (N * max_det * 6))()
    counts = (C.c_int * N)()
    lib().wf_decode(L, ptrs, hs, ws, N, CH - 5, img_hw[0], img_hw[1], conf, iou, max_det, max_nms, out, counts)
    res = []
    for b in range(N):
        base = b * max_det * 6
        res.append([list(out[base + k * 6: base + k * 6 + 6]) for k in range(counts[b])])
    return res
