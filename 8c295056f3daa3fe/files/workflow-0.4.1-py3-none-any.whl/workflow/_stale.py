"""Catch a Python session (a notebook kernel, usually) that kept an older Workflow in memory after an upgrade.

Parts of Workflow are imported only when first used, so after ``pip install --upgrade`` such a session would run new
code against old code and fail with confusing errors (a missing method, a wrong argument). This compares the version
already loaded with the one on disk and says plainly what to do instead."""
import os
import re
import sys


def check():
    pkg = sys.modules.get(__package__)
    loaded = getattr(pkg, "__version__", None)
    try:
        with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "_version.py"), encoding="utf-8") as f:
            m = re.search(r"""__version__\s*=\s*["']([^"']+)["']""", f.read())
    except OSError:
        return
    on_disk = m.group(1) if m else None
    if loaded and on_disk and loaded != on_disk:
        raise ImportError(
            f"Workflow was upgraded from {loaded} to {on_disk} while this Python session was running, so old and new "
            f"code are mixed. Restart the session (in a notebook: Kernel → Restart) and run it again. Saved .nbm files "
            f"are fine; wf.load them after restarting.")
