"""``wf.inference(source, model, output)``: run a model on anything and keep the evidence.

The source is detected automatically: an image, a video, a folder (of images and/or videos), a Felix dataset (its
``test`` split unless another is chosen), or a loaded Felix dataset / split. The output folder receives
``original/`` (the inputs, untouched), ``annotated/`` (boxes drawn) and ``predictions.json``.
"""
from __future__ import annotations

import json
import os
import random
import shutil
import sys
from datetime import datetime, timezone
from typing import Dict, List, Optional

from . import _ui
from .data import IMAGE_EXT
from .errors import DataError, WorkflowError
from .results import Predictions, Results

VIDEO_EXT = (".mp4", ".avi", ".mov", ".mkv", ".webm", ".m4v", ".mpg", ".mpeg", ".wmv")
SPLITS = ("train", "val", "test")


class Inference:
    """What ``wf.inference`` produced: ``images`` (a list of Results), ``videos`` ({name: per-frame detections}),
    ``output`` (the folder) and ``json`` (the contents of predictions.json)."""

    def __init__(self, output, images, videos, doc):
        self.output, self.images, self.videos, self.json = output, images, videos, doc
        self.json_path = os.path.join(output, "predictions.json")

    def __len__(self):
        return len(self.images) + len(self.videos)

    def __repr__(self):
        n_img = sum(len(r) for r in self.images)
        n_vid = sum(len(d) for frames in self.videos.values() for d in frames)
        parts = []
        if self.images:
            parts.append(f"{len(self.images)} image(s), {n_img} detections")
        if self.videos:
            parts.append(f"{len(self.videos)} video(s), {n_vid} detections")
        return f"Inference({'; '.join(parts) or 'nothing'} → {self.output})"


# ------------------------------------------------------------------ source detection
class _Item:
    """One thing to run: an image (from a file, a dataset or memory) or a video file."""

    def __init__(self, kind, name, src, original=None, dataset=None, stem=None):
        self.kind, self.name, self.src, self.original, self.dataset, self.stem = kind, name, src, original, dataset, stem


def _is_felix_dir(path):
    return os.path.isdir(path) and os.path.isfile(os.path.join(path, "metadata.yml")) and os.path.isdir(os.path.join(path, "annotations"))


def _pick_split(ds, split, label):
    """A Felix dataset → the requested split, else test (then val, then everything)."""
    if not hasattr(ds, "splits"):                       # already a split / subset
        return ds, getattr(ds, "name", "split")
    if split is not None:
        if split not in SPLITS:
            raise WorkflowError(f"unknown split {split!r}.", f"Felix datasets have {', '.join(SPLITS)}.", "use split='test', 'val' or 'train'.")
        chosen = getattr(ds, split)
        if not len(chosen):
            raise DataError(f"the {split} split of {label} is empty.", f"its splits are {ds.splits}.", "pick a split that has images.")
        return chosen, split
    for name in ("test", "val"):
        if len(getattr(ds, name)):
            return getattr(ds, name), name
    return ds, "all"


def _dataset_items(ds, label) -> List[_Item]:
    items = []
    for stem in ds.stems:
        ann = ds.annotation(stem)
        items.append(_Item("image", ann.get("image", f"{stem}.png"), None, dataset=ds, stem=stem))
    return items


def collect(source, split=None):
    """(items, description of what was found)."""
    if hasattr(source, "stems") and hasattr(source, "annotation"):           # a loaded Felix dataset or split
        ds, used = _pick_split(source, split, "the dataset")
        return _dataset_items(ds, "dataset"), f"Felix dataset · {used} split · {len(ds)} images"
    if isinstance(source, (list, tuple)):
        items, kinds = [], []
        for s in source:
            it, what = collect(s, split)
            items += it
            kinds.append(what)
        return items, f"{len(source)} sources"
    if not isinstance(source, (str, os.PathLike)):
        from .data import load_image
        load_image(source)                                                   # raises a clear DataError if unusable
        return [_Item("image", "image.png", source)], "1 image (in memory)"
    path = os.fspath(source)
    low = path.lower().rstrip("/\\")
    if not os.path.exists(path):
        raise DataError(f"nothing found at {path!r}.", "the path does not exist.", "check the spelling and that the file or folder exists.")
    if low.endswith(".felix") or _is_felix_dir(path):
        try:
            import felix
        except ImportError:
            raise DataError("this is a Felix dataset, but Felix is not installed.", "datasets are read through Felix.", "install felix.") from None
        ds = felix.load(path)
        sub, used = _pick_split(ds, split, os.path.basename(low))
        note = "" if split else (" (picked automatically)" if used != "all" else " (no splits, using every image)")
        return _dataset_items(sub, path), f"Felix dataset {os.path.basename(low)} · {used} split{note} · {len(sub)} images"
    if os.path.isdir(path):
        files = sorted(os.listdir(path))
        imgs = [f for f in files if f.lower().endswith(IMAGE_EXT)]
        vids = [f for f in files if f.lower().endswith(VIDEO_EXT)]
        if not imgs and not vids:
            raise DataError(f"no images or videos in {path!r}.",
                            f"inference looks for {', '.join(IMAGE_EXT)} images and {', '.join(VIDEO_EXT)} videos (not in subfolders).",
                            "point it at the folder that holds the files, or at a single file.")
        items = [_Item("image", f, os.path.join(path, f), original=os.path.join(path, f)) for f in imgs]
        items += [_Item("video", f, os.path.join(path, f), original=os.path.join(path, f)) for f in vids]
        return items, f"folder {os.path.basename(low)} · {len(imgs)} images, {len(vids)} videos"
    if low.endswith(IMAGE_EXT):
        return [_Item("image", os.path.basename(path), path, original=path)], "1 image"
    if low.endswith(VIDEO_EXT):
        return [_Item("video", os.path.basename(path), path, original=path)], "1 video"
    raise DataError(f"cannot tell what {os.path.basename(path)!r} is.",
                    f"inference reads images ({', '.join(IMAGE_EXT)}), videos ({', '.join(VIDEO_EXT)}), folders and Felix datasets.",
                    "convert the file to one of those formats.")


def _is_collection(source) -> bool:
    """A dataset or a folder (one item is picked unless all=True). Single files and lists you pass run as given."""
    if hasattr(source, "stems"):
        return True
    if isinstance(source, (str, os.PathLike)):
        path = os.fspath(source)
        return os.path.isdir(path) or path.lower().rstrip("/\\").endswith(".felix")
    return False


# ------------------------------------------------------------------ running
def _unique(name, used):
    stem, ext = os.path.splitext(name)
    out, n = name, 1
    while out.lower() in used:
        n += 1
        out = f"{stem}_{n}{ext}"
    used.add(out.lower())
    return out


def _video(model, item, out_dir, used, panel, settings):
    try:
        import cv2
        import numpy as np
    except ImportError:
        raise DataError(f"{item.name} is a video, which needs OpenCV.", "Workflow reads and writes video frames through OpenCV.",
                        "run `pip install opencv-python`.") from None
    cap = cv2.VideoCapture(item.src)
    if not cap.isOpened():
        raise DataError(f"could not open the video {item.name!r}.", "OpenCV could not decode it (damaged file or unsupported codec).",
                        "re-encode it as H.264 MP4, e.g. with ffmpeg.")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    row = panel.row(item.name, max(total, 1))
    name = _unique(os.path.splitext(item.name)[0] + ".mp4", used["annotated"])
    annotated = os.path.join(out_dir, "annotated", name)
    writer, frames, index = None, [], 0
    try:
        while True:
            batch = []
            for _ in range(settings["batch_size"]):
                ok, frame = cap.read()
                if not ok:
                    break
                batch.append(frame)
            if not batch:
                break
            rgb = [cv2.cvtColor(f, cv2.COLOR_BGR2RGB) for f in batch]
            res = model.predict(rgb, output=None, **settings["predict"])
            for r in res:
                drawn = np.asarray(r.plot())[:, :, ::-1]
                if writer is None:
                    h, w = drawn.shape[:2]
                    writer = cv2.VideoWriter(annotated, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
                writer.write(np.ascontiguousarray(drawn))
                frames.append([dict(d) for d in r])
                index += 1
            row.label = f"frame {index:,}" + (f"/{total:,}" if total else "")
            row.n = min(index, row.total)
            row.status = "running"
            panel.refresh()
    finally:
        cap.release()
        if writer is not None:
            writer.release()
    original = os.path.join(out_dir, "original", _unique(item.name, used["original"]))
    shutil.copy2(item.src, original)
    row.done()
    row.stats = panel.join(f"{index:,} frames", f"{sum(len(f) for f in frames):,} detections")
    return frames, {"video": item.name, "original": os.path.relpath(original, out_dir), "annotated": os.path.relpath(annotated, out_dir),
                    "fps": fps, "frames": index, "detections": frames}


def _webcam_index(source):
    """``"webcam"`` → 0, ``"webcam:1"`` → 1; anything else → None."""
    if not isinstance(source, str):
        return None
    low = source.strip().lower()
    if low == "webcam":
        return 0
    if low.startswith("webcam:") and low[7:].isdigit():
        return int(low[7:])
    return None


_BOX_COLORS = [(75, 25, 230), (75, 180, 60), (200, 99, 67), (49, 130, 245), (180, 30, 145), (200, 200, 70)]


# arrow-key codes from cv2.waitKeyEx: macOS, Windows, Linux (GTK / Qt)
_NEXT_KEYS = {63235, 63232, 2555904, 2490368, 65363, 65362}         # → ↑
_PREV_KEYS = {63234, 63233, 2424832, 2621440, 65361, 65364}         # ← ↓
_CONTROLS = "← → (or ↑ ↓) or 0–9: switch camera · q / Esc: quit"


def _label(cv2, img, text, x, y, color, scale, thick):
    """``text`` in white (or black on a light colour) on a solid ``color`` block whose top-left is (x, y)."""
    font = cv2.FONT_HERSHEY_SIMPLEX
    (tw, th), base = cv2.getTextSize(text, font, scale, thick)
    pad = max(3, int(th * 0.35))
    h, w = img.shape[:2]
    x = max(0, min(int(x), w - tw - 2 * pad))
    y = max(0, min(int(y), h - th - base - 2 * pad))
    cv2.rectangle(img, (x, y), (x + tw + 2 * pad, y + th + base + 2 * pad), color, -1)
    ink = (0, 0, 0) if sum(color) > 450 else (255, 255, 255)
    cv2.putText(img, text, (x + pad, y + pad + th), font, scale, ink, thick, cv2.LINE_AA)
    return th + base + 2 * pad


def _draw(cv2, frame, r, fps):
    """Boxes and labels for the live window: lines and text scale with the picture so they stay easy to read."""
    img = frame.copy()
    side = min(img.shape[:2])
    lw = max(3, round(side / 160))                                   # 720p → 4 px, 1080p → 7 px
    scale = max(0.6, side / 650)
    thick = max(2, round(scale * 2))
    for (x1, y1, x2, y2), conf, k, name in zip(r.xyxy, r.confidences, r.class_ids, r.classes):
        col = _BOX_COLORS[k % len(_BOX_COLORS)]
        x1, y1, x2, y2 = int(x1), int(y1), int(x2), int(y2)
        cv2.rectangle(img, (x1, y1), (x2, y2), col, lw, cv2.LINE_AA)
        text = f"{name} {conf:.2f}"
        (_, th), base = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, scale, thick)
        tag = th + base + 2 * max(3, int(th * 0.35))
        top = y1 - tag if y1 - tag >= 0 else y1                        # above the box, or inside it at the top edge
        _label(cv2, img, text, x1 - lw // 2, top, col, scale, thick)
    _label(cv2, img, f"{fps:.0f} FPS", 8, img.shape[0], (30, 30, 30), scale, thick)   # bottom-left, clear of labels
    return img


def _open_camera(cv2, index):
    """An open camera that delivers a picture, with its first frame; (None, None) if there is none at ``index``."""
    cap = cv2.VideoCapture(index)
    ok, frame = cap.read() if cap.isOpened() else (False, None)
    if not ok:
        cap.release()
        return None, None
    return cap, frame


def _webcam(model, model_name, cam, out_dir, record, mirror, panel, settings):
    """Live detection in an OpenCV window until q / Esc / Ctrl+C. Arrow keys or 0–9 switch camera.
    With ``record``, the session is saved."""
    import time
    try:
        import cv2
    except ImportError:
        raise DataError("the webcam needs OpenCV.", "Workflow reads the camera and shows the window through OpenCV.",
                        "run `pip install opencv-python`.") from None
    cap, frame = _open_camera(cv2, cam)
    if cap is None:
        why = (f"camera {cam} gave no picture. On macOS the app running Python (Terminal, VS Code, Jupyter) needs camera access"
               if sys.platform == "darwin" else f"camera {cam} gave no picture")
        raise DataError(f"could not open the webcam (camera {cam}).", why + "; another app may also be holding the camera.",
                        "allow camera access (System Settings → Privacy & Security → Camera on a Mac) and restart the app, "
                        "close other apps using the camera, or try source='webcam:1' for another camera.")
    title = "Workflow"
    row = panel.row("webcam", 1)
    row.status = "running"
    note = ""

    def show_label():
        row.label = panel.join(f"camera {cam}", _CONTROLS) + (f"  ·  {note}" if note else "")

    show_label()
    panel.refresh(force=True)
    raw_path = ann_path = raw_w = ann_w = None
    size = None
    if record:
        for sub in ("original", "annotated"):
            os.makedirs(os.path.join(out_dir, sub), exist_ok=True)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        raw_path = os.path.join(out_dir, "original", f"webcam-{stamp}.mp4")
        ann_path = os.path.join(out_dir, "annotated", f"webcam-{stamp}.mp4")
    frames, switches, known = [], [{"camera": cam, "from_frame": 0}], {cam}
    fps, n, start, shown = 0.0, 0, time.time(), 0.0

    def switch(to):
        """Move to camera ``to``; keep the current one (with a note) if it has no picture."""
        nonlocal cap, frame, cam, fps, note
        if to == cam:
            return
        new, first = _open_camera(cv2, to)
        if new is None:
            note = f"camera {to} not found"
            return
        cap.release()
        cap, frame, cam, fps, note = new, first, to, 0.0, ""
        known.add(to)
        switches.append({"camera": cam, "from_frame": n})

    try:
        while frame is not None:
            if mirror:
                frame = cv2.flip(frame, 1)
            t = time.time()
            r = model.predict(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB), output=None, **settings["predict"])
            dt = max(1e-6, time.time() - t)
            fps = 0.9 * fps + 0.1 / dt if fps else 1.0 / dt
            frames.append([dict(d) for d in r])
            n += 1
            drawn = _draw(cv2, frame, r, fps)
            if record:
                if raw_w is None:
                    size = (frame.shape[1], frame.shape[0])
                    fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                    raw_w = cv2.VideoWriter(raw_path, fourcc, 15.0, size)
                    ann_w = cv2.VideoWriter(ann_path, fourcc, 15.0, size)
                same = (frame.shape[1], frame.shape[0]) == size              # another camera may have another size
                raw_w.write(frame if same else cv2.resize(frame, size))
                ann_w.write(drawn if same else cv2.resize(drawn, size))
            try:
                cv2.imshow(title, drawn)
                key = cv2.waitKeyEx(1)
            except cv2.error:
                raise DataError("OpenCV could not open a window.", "this OpenCV build or session has no display "
                                "(opencv-python-headless, or a remote / headless machine).",
                                "install opencv-python (not -headless) and run where a screen is available.") from None
            if key in (ord("q"), ord("Q"), 27):
                break
            before = cam
            if ord("0") <= key <= ord("9"):
                switch(key - ord("0"))
            elif key in _NEXT_KEYS:
                switch(cam + 1)
                if cam == before and cam != 0:                                # past the last camera: back to 0
                    note = ""
                    switch(0)
            elif key in _PREV_KEYS:
                if cam > 0:
                    switch(cam - 1)
                elif max(known) > 0:                                          # before 0: the highest one seen
                    switch(max(known))
                else:
                    note = "no other camera found yet (try →)"
            if cam != before:
                show_label()
                panel.refresh(force=True)
                continue                                                      # `frame` is the new camera's first
            try:
                if n > 1 and cv2.getWindowProperty(title, cv2.WND_PROP_VISIBLE) < 1:
                    break                                                     # the window was closed with its button
            except cv2.error:
                break
            if key != -1 or time.time() - shown > 0.5:
                shown = time.time()
                show_label()
                row.stats = panel.join(f"{fps:.0f} FPS", f"{len(r)} objects now", f"{n:,} frames")
                panel.refresh()
            ok, frame = cap.read()
            if not ok:
                frame = None
    except KeyboardInterrupt:
        pass
    finally:
        cap.release()
        for w in (raw_w, ann_w):
            if w is not None:
                w.release()
        try:
            cv2.destroyAllWindows()
            cv2.waitKey(1)                                                    # lets macOS actually close the window
        except cv2.error:
            pass
    secs = time.time() - start
    row.done()
    used = sorted({s["camera"] for s in switches})
    row.label = f"camera{'s' if len(used) > 1 else ''} {', '.join(map(str, used))}"
    row.stats = panel.join(f"{n:,} frames in {secs:.0f} s", f"{sum(len(f) for f in frames):,} detections",
                           f"saved to {out_dir}" if record else "not recorded (record=True saves it)")
    doc = {"video": "webcam", "cameras": switches, "frames": n, "fps": n / secs if secs else 0.0, "detections": frames}
    if record:
        doc.update({"original": os.path.relpath(raw_path, out_dir), "annotated": os.path.relpath(ann_path, out_dir)})
    return frames, doc


def inference(source, model, output: str = "results/", all: bool = False, split: Optional[str] = None,
              confidence: float = 0.25, iou: float = 0.45, img_size=None, device: Optional[str] = None,
              batch_size: int = 16, quiet: bool = False, record: bool = False, mirror: bool = False) -> Inference:
    """Run ``model`` (a Workflow model or the path of a ``.nbm``) on ``source`` and save everything to ``output``.

    ``source`` is detected automatically: an image, a video, a folder of images/videos, a Felix dataset (its test split
    is picked unless you pass ``split="val"`` / ``"train"`` or a split such as ``data.val``), or a list of these.
    For a dataset or a folder, **one randomly chosen item** is run unless ``all=True``; single files and lists run as given.
    ``output`` receives ``original/`` (the inputs, untouched), ``annotated/`` (boxes drawn) and ``predictions.json``.

    ``source="webcam"`` (or ``"webcam:1"`` for another camera) opens a window with live detection until you press q
    or Esc. In the window, ← → (or ↑ ↓) and the number keys 0–9 switch camera; the controls are shown in the console,
    the window shows the boxes and FPS. Nothing is written unless ``record=True`` (then both videos and predictions.json are saved). ``mirror=True``
    flips the picture like a selfie view."""
    if isinstance(model, (str, os.PathLike)):
        from .nbm import load
        model_name, model = os.path.basename(os.fspath(model)), load(model)
    elif hasattr(model, "predict") and hasattr(model, "head"):
        model_name = "model"
    else:
        raise WorkflowError(f"the model argument is {type(model).__name__}, not a model.",
                            "wf.inference(source, model, output) needs a Workflow model or a .nbm path as its second argument.",
                            "pass model = wf.load('detector.nbm'), or the path itself.")
    model.head()
    cam = _webcam_index(source)
    if cam is not None:
        return _run_webcam(model, model_name, cam, os.fspath(output), record, mirror, quiet,
                           dict(device=device, confidence=confidence, iou=iou, img_size=img_size))
    items, found = collect(source, split)
    if _is_collection(source) and not all and len(items) > 1:
        pick = random.choice(items)
        found = f"{found} · 1 picked at random ({pick.name}); all=True runs every item"
        items = [pick]
    out_dir = os.fspath(output)
    for sub in ("original", "annotated"):
        os.makedirs(os.path.join(out_dir, sub), exist_ok=True)
    settings = {"batch_size": batch_size, "predict": dict(device=device, confidence=confidence, iou=iou, img_size=img_size)}
    images = [i for i in items if i.kind == "image"]
    videos = [i for i in items if i.kind == "video"]
    used = {"original": set(), "annotated": set()}
    panel = _ui.Panel("", quiet=quiet)
    panel.title = panel.join("Workflow inference", found, f"→ {out_dir}")
    panel.sub = panel.join(model_name, f"confidence {confidence}", f"iou {iou}")
    image_docs, image_results = [], Predictions()
    video_docs, video_frames = [], {}
    with panel:
        if images:
            row = panel.row("images", len(images))
            for start in range(0, len(images), batch_size):
                chunk = images[start:start + batch_size]
                srcs = [it.dataset.image(it.stem) if it.dataset is not None else it.src for it in chunk]
                res = model.predict(srcs, output=None, **settings["predict"])
                for it, r in zip(chunk, res):
                    base = os.path.splitext(it.name)[0]
                    if it.dataset is not None:                     # the dataset's own bytes, untouched
                        oname = _unique(it.name, used["original"])
                        with open(os.path.join(out_dir, "original", oname), "wb") as f:
                            f.write(it.dataset.image_bytes(it.stem))
                    elif it.original is not None:
                        oname = _unique(it.name, used["original"])
                        shutil.copy2(it.original, os.path.join(out_dir, "original", oname))
                    else:
                        from PIL import Image
                        oname = _unique(base + ".png", used["original"])
                        Image.frombytes("RGB", (r.width, r.height), r._rgb).save(os.path.join(out_dir, "original", oname))
                    aname = _unique(base + ".png", used["annotated"])
                    r.saved_to = r.save(os.path.join(out_dir, "annotated", aname))
                    r.path = r.path or it.name
                    image_results.append(r)
                    image_docs.append({"image": it.name, "original": f"original/{oname}", "annotated": f"annotated/{aname}",
                                       "width": r.width, "height": r.height, "detections": list(r)})
                row.n, row.status = min(start + len(chunk), row.total), "running"
                row.label = f"image {row.n:,}/{row.total:,}"
                panel.refresh()
            row.done()
            row.stats = panel.join(f"{sum(len(r) for r in image_results):,} detections", f"saved to {out_dir}")
        for it in videos:
            frames, doc = _video(model, it, out_dir, used, panel, settings)
            video_frames[it.name] = frames
            video_docs.append(doc)
    doc = {"model": model_name, "classes": model.class_names, "source": found,
           "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "settings": {"confidence": confidence, "iou": iou, "img_size": img_size}, "images": image_docs, "videos": video_docs}
    with open(os.path.join(out_dir, "predictions.json"), "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1)
    return Inference(out_dir, image_results, video_frames, doc)


def _run_webcam(model, model_name, cam, out_dir, record, mirror, quiet, predict):
    panel = _ui.Panel("", quiet=quiet)
    panel.title = panel.join("Workflow inference", "webcam · live", f"→ {out_dir}" if record else "not recorded")
    panel.sub = panel.join(model_name, f"confidence {predict['confidence']}", f"iou {predict['iou']}")
    with panel:
        frames, vdoc = _webcam(model, model_name, cam, out_dir, record, mirror, panel, {"predict": predict})
    doc = {"model": model_name, "classes": model.class_names, "source": "webcam",
           "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "settings": {"confidence": predict["confidence"], "iou": predict["iou"], "img_size": predict["img_size"]},
           "images": [], "videos": [vdoc]}
    if record:
        with open(os.path.join(out_dir, "predictions.json"), "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=1)
    return Inference(out_dir, [], {vdoc["video"]: frames}, doc)
