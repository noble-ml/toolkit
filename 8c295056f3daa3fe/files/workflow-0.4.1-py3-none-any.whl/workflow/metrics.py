"""Detection metrics in plain Python: mAP50, mAP50-95, precision, recall, F1, per-class AP, confusion matrix."""
from __future__ import annotations

from typing import Dict, List, Optional, Sequence

IOU_THRS = [0.5 + 0.05 * i for i in range(10)]


def iou(a, b) -> float:
    iw = min(a[2], b[2]) - max(a[0], b[0])
    ih = min(a[3], b[3]) - max(a[1], b[1])
    if iw <= 0 or ih <= 0:
        return 0.0
    inter = iw * ih
    return inter / ((a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter + 1e-9)


def _match(pairs, thr):
    """Greedy one-to-one matching of (iou, gt, pred) triples above ``thr``, best first."""
    used_g, used_p, out = set(), set(), []
    for v, g, p in sorted((t for t in pairs if t[0] >= thr), reverse=True):
        if g not in used_g and p not in used_p:
            used_g.add(g); used_p.add(p); out.append((g, p))
    return out


def _ap(recall: List[float], precision: List[float]) -> float:
    """COCO-style 101-point interpolated AP."""
    mrec = [0.0] + recall + [1.0]
    mpre = [1.0] + precision + [0.0]
    for i in range(len(mpre) - 2, -1, -1):
        mpre[i] = max(mpre[i], mpre[i + 1])
    total, j = 0.0, 0
    for k in range(101):
        x = k / 100
        while j < len(mrec) - 1 and mrec[j] < x:
            j += 1
        total += mpre[j]
    return total / 101


class DetectionMetrics:
    """``update(pred, gt)`` per image, then ``compute()``. ``pred`` rows are [x1, y1, x2, y2, score, class];
    ``gt`` rows are [class, x1, y1, x2, y2]."""

    def __init__(self, num_classes: int, names: Optional[Sequence[str]] = None):
        self.nc = num_classes
        self.names = list(names) if names else [str(i) for i in range(num_classes)]
        self.rows: List[tuple] = []          # (score, class, [tp at each IoU threshold])
        self.n_gt = [0] * num_classes
        self.confusion = [[0] * (num_classes + 1) for _ in range(num_classes + 1)]

    def update(self, pred, gt) -> None:
        for g in gt:
            self.n_gt[int(g[0])] += 1
        tps = [[False] * len(IOU_THRS) for _ in pred]
        same = [(iou(g[1:5], p[:4]), gi, pi) for gi, g in enumerate(gt) for pi, p in enumerate(pred) if int(g[0]) == int(p[5])]
        for t, thr in enumerate(IOU_THRS):
            for _, pi in _match(same, thr):
                tps[pi][t] = True
        for p, tp in zip(pred, tps):
            self.rows.append((p[4], int(p[5]), tp))
        det = [p for p in pred if p[4] > 0.25]                       # confusion matrix at conf 0.25, IoU 0.45
        anyc = [(iou(g[1:5], p[:4]), gi, pi) for gi, g in enumerate(gt) for pi, p in enumerate(det)]
        m = _match(anyc, 0.45)
        mg, mp = {g for g, _ in m}, {p for _, p in m}
        for g, p in m:
            self.confusion[int(det[p][5])][int(gt[g][0])] += 1
        for pi, p in enumerate(det):
            if pi not in mp:
                self.confusion[int(p[5])][self.nc] += 1              # false positive on background
        for gi, g in enumerate(gt):
            if gi not in mg:
                self.confusion[self.nc][int(g[0])] += 1              # missed object

    def compute(self) -> Dict:
        rows = sorted(self.rows, key=lambda r: -r[0])
        T = len(IOU_THRS)
        ap = [[0.0] * T for _ in range(self.nc)]
        curves = {}
        for c in range(self.nc):
            mine = [r for r in rows if r[1] == c]
            if not mine or self.n_gt[c] == 0:
                continue
            for t in range(T):
                tp = fp = 0
                rec, pre = [], []
                for r in mine:
                    tp += r[2][t]; fp += not r[2][t]
                    rec.append(tp / self.n_gt[c]); pre.append(tp / (tp + fp))
                ap[c][t] = _ap(rec, pre)
                if t == 0:
                    curves[c] = ([r[0] for r in mine], rec, pre)
        present = [c for c in range(self.nc) if self.n_gt[c] > 0]
        best = (0.0, 0.0, 0.0, 0.0)                                   # (f1, precision, recall, conf)
        for k in range(1000):
            x = k / 1000
            ps, rs = [], []
            for c in present:
                if c not in curves:
                    ps.append(0.0); rs.append(0.0); continue
                conf, rec, pre = curves[c]
                lo, hi = 0, len(conf)                                 # number of predictions with score >= x
                while lo < hi:
                    mid = (lo + hi) // 2
                    if conf[mid] >= x:
                        lo = mid + 1
                    else:
                        hi = mid
                ps.append(pre[lo - 1] if lo else 0.0); rs.append(rec[lo - 1] if lo else 0.0)
            if not present:
                break
            p, r = sum(ps) / len(present), sum(rs) / len(present)
            f1 = sum(2 * a * b / (a + b + 1e-16) for a, b in zip(ps, rs)) / len(present)
            if f1 > best[0]:
                best = (f1, p, r, x)
        mean = lambda v: sum(v) / len(v) if v else 0.0
        return {"precision": best[1], "recall": best[2], "f1": best[0], "conf": best[3],
                "map50": mean([ap[c][0] for c in present]), "map50_95": mean([mean(ap[c]) for c in present]),
                "per_class": {n: {"ap50": ap[i][0], "ap50_95": mean(ap[i]), "instances": self.n_gt[i]} for i, n in enumerate(self.names)},
                "confusion_matrix": [row[:] for row in self.confusion]}
