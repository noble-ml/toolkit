"""Layer base class: lazy building (input channels are inferred), parameters, serialization."""
from __future__ import annotations

import functools
import inspect
from typing import Any, Dict, Iterator, List, Optional, Sequence, Tuple

from .core import Tensor, device as _device
from .errors import SerializationError, ShapeError, WorkflowError

Shape = Tuple[int, int, int]          # (channels, height, width); a tuple of Shapes is a feature pyramid
_REGISTRY: Dict[str, type] = {}
_seed = [0]


def is_pyramid(v) -> bool:
    return isinstance(v, (tuple, list)) and len(v) > 0 and isinstance(v[0], (tuple, list, Tensor))


def fmt(shape) -> str:
    if is_pyramid(shape):
        return "[" + ", ".join(fmt(s) for s in shape) + "]"
    return "(" + ", ".join(str(int(v)) for v in shape) + ")"


def pair(value, name: str, minimum: int = 1) -> Tuple[int, int]:
    if isinstance(value, int) and not isinstance(value, bool):
        value = (value, value)
    if (isinstance(value, (tuple, list)) and len(value) == 2
            and all(isinstance(v, int) and not isinstance(v, bool) for v in value) and min(value) >= minimum):
        return (value[0], value[1])
    raise WorkflowError(f"invalid {name}: {value!r}.", f"{name} must be an integer or a pair of integers, each at least {minimum}.",
                        f"use for example {name}={max(minimum, 1)} or {name}=({max(minimum, 1)}, {max(minimum, 2)}).")


_LEGACY = [0]          # > 0 while rebuilding a model saved by Workflow 0.2 (numeric padding)


def _numeric_padding(value):
    ok = lambda v: isinstance(v, int) and not isinstance(v, bool) and v >= 0
    if ok(value):
        return (value,) * 4
    if isinstance(value, (tuple, list)) and all(ok(v) for v in value) and len(value) in (2, 4):
        return (value[0], value[0], value[1], value[1]) if len(value) == 2 else tuple(value)
    return None


def padding_mode(value):
    """'same' or 'valid' (numbers are only accepted when loading models saved by Workflow 0.2)."""
    if isinstance(value, str) and value.lower() in ("same", "valid"):
        return value.lower()
    if _LEGACY[0] and _numeric_padding(value) is not None:
        return _numeric_padding(value)
    suggestion = "padding='valid'" if value == 0 else "padding='same'"
    raise WorkflowError(f"padding={value!r} is not supported.",
                        "padding is chosen by name: 'same' keeps the size (the output is the input divided by stride, "
                        "rounded up) and 'valid' adds no padding (the kernel only visits real pixels).",
                        f"use {suggestion}" + (" (what padding=0 meant)" if value == 0 else
                                               " (the size-keeping padding, what padding=kernel_size//2 meant)") + ".")


def resolve_padding(mode, size: Tuple[int, int], k: Tuple[int, int], s: Tuple[int, int], d=(1, 1)) -> Tuple[int, int, int, int]:
    """Pixels to add (top, bottom, left, right) for an input of ``size`` = (height, width).

    'valid' adds none. 'same' gives an output of ceil(input / stride): with an odd effective kernel it pads
    (kernel - 1) / 2 on both sides; with an even one the extra pixel goes to the bottom / right."""
    if isinstance(mode, tuple):
        return mode
    if mode == "valid":
        return (0, 0, 0, 0)
    out = []
    for n, kk, ss, dd in zip(size, k, s, d):
        eff = dd * (kk - 1) + 1
        if eff % 2:
            out += [(eff - 1) // 2] * 2
        else:
            total = max((-(-n // ss) - 1) * ss + eff - n, 0)
            out += [total // 2, total - total // 2]
    return tuple(out)


def pad_label(mode) -> str:
    if isinstance(mode, str):
        return f" {mode}" if mode == "same" else ""
    return f" p{mode}" if any(mode) else ""


def positive(value, name: str, optional: bool = False):
    if optional and value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 1:
        raise WorkflowError(f"invalid {name}: {value!r}.", f"{name} must be a positive integer.", f"use for example {name}=32.")
    return value


def single(shape, who: str) -> Shape:
    """The layer needs one tensor, not a pyramid."""
    if is_pyramid(shape):
        raise ShapeError(f"{who} received a feature pyramid of {len(shape)} maps {fmt(shape)}.",
                         f"{who} works on a single tensor.",
                         "place wf.head(...) or wf.PAN(...) after wf.FPN(...), or name the maps with wf.feature((...)) "
                         "and pick one with wf.concat/wf.add.")
    return tuple(shape)


class Ctx:
    """State shared while building or running a model: named features, mode flags, analysis counters."""

    def __init__(self, train: bool = False, quant=None):
        self.features: Dict[str, Any] = {}
        self.train, self.quant = train, quant
        self.macs = 0
        self.checkpoint = None       # the model stack, when training with low_memory (see Stack.run)
        self.frozen = False          # recomputing: BatchNorm must not update its running statistics again


def _capture(init):
    sig = inspect.signature(init)

    @functools.wraps(init)
    def wrapper(self, *a, **k):
        if "_args" not in self.__dict__:
            try:
                bound = sig.bind(self, *a, **k)
            except TypeError:
                pass
            else:
                self.__dict__["_args"] = dict(list(bound.arguments.items())[1:])
        init(self, *a, **k)

    return wrapper


def _enc(v):
    if isinstance(v, Layer):
        return v.spec()
    if isinstance(v, (list, tuple)):
        return [_enc(i) for i in v]
    if isinstance(v, dict):
        return {k: _enc(i) for k, i in v.items()}
    return v


def _dec(v):
    if isinstance(v, dict) and "layer" in v and "args" in v:
        return Layer.from_spec(v)
    if isinstance(v, list):
        return [_dec(i) for i in v]
    if isinstance(v, dict):
        return {k: _dec(i) for k, i in v.items()}
    return v


class Layer:
    """Base class of everything that can go into ``wf.stack``.

    Subclasses implement ``infer(shape, ctx)`` (validate the input, create parameters on first use, return the
    output shape) and ``run(x, ctx)`` (compute). Input channels are never passed by the user: they are inferred.
    """

    def __init_subclass__(cls, **kw):
        super().__init_subclass__(**kw)
        if "__init__" in cls.__dict__:
            cls.__init__ = _capture(cls.__dict__["__init__"])
        if not cls.__name__.startswith("_"):
            _REGISTRY[cls.__name__] = cls

    # -- state
    @property
    def P(self) -> Dict[str, Tensor]:          # trainable parameters
        return self.__dict__.setdefault("_p", {})

    @property
    def Bf(self) -> Dict[str, Tensor]:         # buffers (running statistics, quantisation ranges)
        return self.__dict__.setdefault("_b", {})

    def children(self) -> List[Tuple[str, "Layer"]]:
        return []

    def param(self, name: str, shape, lo: float, hi: float) -> Tensor:
        """Create a parameter once (uniform in [lo, hi]); later builds reuse it."""
        if name not in self.P:
            _seed[0] += 1
            t = _device.get("cpu").be.uniform(shape, lo, hi, _seed[0])
            t.rg = True
            self.P[name] = t
        return self.P[name]

    def buffer(self, name: str, shape, value: float) -> Tensor:
        if name not in self.Bf:
            self.Bf[name] = Tensor.full(shape, value, _device.get("cpu"))
        return self.Bf[name]

    def walk(self, prefix: str = "") -> Iterator[Tuple[str, "Layer"]]:
        yield prefix, self
        for key, child in self.children():
            yield from child.walk(f"{prefix}{key}.")

    def state(self) -> Dict[str, Tensor]:
        """Every parameter and buffer by dotted name."""
        out = {}
        for prefix, layer in self.walk():
            for k, t in layer.P.items():
                out[prefix + k] = t
            for k, t in layer.Bf.items():
                out[prefix + k] = t
        return out

    def parameters(self) -> List[Tensor]:
        return [t for _, layer in self.walk() for t in layer.P.values()]

    def to_device(self, dev) -> None:
        for _, layer in self.walk():
            for store in (layer.P, layer.Bf):
                for k, t in list(store.items()):
                    if t.dev is not dev:
                        n = t.to(dev)
                        n.rg = t.rg
                        store[k] = n

    # -- to implement
    def infer(self, shape, ctx: Ctx):
        raise NotImplementedError(type(self).__name__)

    def run(self, x, ctx: Ctx):
        raise NotImplementedError(type(self).__name__)

    def label(self) -> str:
        return type(self).__name__

    # -- serialization
    def spec(self) -> Dict[str, Any]:
        return {"layer": type(self).__name__, "args": _enc(self.__dict__.get("_args", {}))}

    @staticmethod
    def from_spec(spec: Dict[str, Any]) -> "Layer":
        cls = _REGISTRY.get(spec.get("layer"))
        if cls is None:
            raise SerializationError(f"unknown layer {spec.get('layer')!r} in the model file.",
                                     "the file was written by a newer Workflow, or uses a custom layer that is not imported.",
                                     "upgrade Workflow, or import the module that defines the custom layer before loading.")
        args = _dec(spec.get("args", {}))
        params = list(inspect.signature(cls.__init__).parameters.values())[1:]
        names = {p.name for p in params}
        if "filters" in args and "filters" not in names and "out_channels" in names:   # files from Workflow 0.2
            args["out_channels"] = args.pop("filters")
        has_var = any(p.kind is p.VAR_POSITIONAL for p in params)
        pos, kw = [], {}
        for p in params:
            if p.name not in args:
                continue
            v = args[p.name]
            if p.kind is p.VAR_POSITIONAL:
                pos.extend(v)
            elif p.kind is p.VAR_KEYWORD:
                kw.update(v)
            elif p.kind is p.KEYWORD_ONLY or not has_var:
                kw[p.name] = v
            else:
                pos.append(v)
        _LEGACY[0] += 1
        try:
            return cls(*pos, **kw)
        finally:
            _LEGACY[0] -= 1


def as_layers(items: Sequence[Any], owner: str) -> List[Layer]:
    out = []
    for i, it in enumerate(items):
        if not isinstance(it, Layer):
            raise WorkflowError(f"{owner} item {i + 1} is {it!r}, not a Workflow layer.",
                                f"{owner} is built from layers such as wf.Conv2D(...) or wf.Bottleneck(...).",
                                "pass layer objects, one per line, e.g.\n"
                                "  wf.stack(\n"
                                "      wf.Conv2D(32, kernel_size=3, stride=1, padding=\"same\"),\n"
                                "      wf.BatchNorm2D(),\n"
                                "      wf.SiLU(),\n"
                                "  )")
        out.append(it)
    if not out:
        raise WorkflowError(f"{owner} is empty.", f"{owner} needs at least one layer.", "add a layer, e.g. wf.Conv2D(32, kernel_size=3).")
    return out
