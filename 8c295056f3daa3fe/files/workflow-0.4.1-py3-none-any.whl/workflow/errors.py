"""Workflow errors. Every error says what happened, why, and how to fix it."""
from __future__ import annotations

import warnings as _warnings


class WorkflowError(Exception):
    """Base class. ``what`` happened, ``why`` it happened, and how to ``fix`` it."""

    def __init__(self, what: str, why: str = "", fix: str = "", where: str = ""):
        self.what, self.why, self.fix, self.where = what, why, fix, where
        super().__init__(self._text())

    def _text(self) -> str:
        head = (self.where + ": " if self.where else "") + self.what
        return head + (f"\n  why: {self.why}" if self.why else "") + (f"\n  fix: {self.fix}" if self.fix else "")

    def at(self, label: str) -> "WorkflowError":
        """The same error with ``label`` prepended to its location."""
        return type(self)(self.what, self.why, self.fix, label + (" → " + self.where if self.where else ""))


class ShapeError(WorkflowError):
    """A tensor's shape or channel count does not fit an operation."""


class RoutingError(WorkflowError):
    """A named feature is missing, duplicated or used ambiguously."""


class DeviceError(WorkflowError):
    """A requested device or accelerator is not available."""


class BackendError(WorkflowError):
    """The compute backend could not be loaded or does not support an operation."""


class SerializationError(WorkflowError):
    """A model file is invalid, or the model cannot be exported as requested."""


class DataError(WorkflowError):
    """A dataset or image is missing, unreadable or does not match the model."""


class WorkflowWarning(UserWarning):
    """Non-fatal issues (experimental backends, fallbacks, ...)."""


def warn(what: str, why: str = "", fix: str = "") -> None:
    msg = what + (f"\n  why: {why}" if why else "") + (f"\n  fix: {fix}" if fix else "")
    _warnings.warn(msg, WorkflowWarning, stacklevel=3)
