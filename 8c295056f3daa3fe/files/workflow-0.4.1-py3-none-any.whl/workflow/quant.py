"""Quantisation: QAT (simulated during training) and post-training quantisation (PTQ).

INT8 scheme: weights of every convolution are symmetric int8 per tensor (scale = max|w| / 127); the input of
every convolution is affine int8 (scale and zero point from its observed range). FP16 stores weights as half
precision. FP32 is no quantisation.
"""
from __future__ import annotations

from typing import Dict, List, Optional

from .core import ops
from .errors import BackendError, WorkflowError, warn

PRECISIONS = ("fp32", "fp16", "int8")


def check_precision(precision: str) -> str:
    p = str(precision).lower()
    if p not in PRECISIONS:
        raise WorkflowError(f"unknown precision {precision!r}.", "Workflow supports 'fp32', 'fp16' and 'int8'.", "use one of those.")
    return p


def conv_layers(model):
    """[(dotted path, layer)] of every quantisable convolution, and the names of layers that stay float."""
    from .layers import TransposeConv2D, _Conv
    convs, floats = [], []
    for path, layer in model.walk():
        if isinstance(layer, _Conv):
            convs.append((path, layer))
        elif isinstance(layer, TransposeConv2D):
            floats.append(f"{path}TransposeConv2D")
    return convs, floats


class Scheme:
    """The active INT8 simulation on a model: per-convolution input ranges, observed or fixed."""

    def __init__(self, precision: str = "int8", observe: bool = True):
        self.precision, self.observe, self.momentum = precision, observe, 0.99
        self.ranges: Dict[int, List[float]] = {}             # id(layer) -> [lo, hi]

    def conv_inputs(self, layer, x, w, ctx):
        be = x.dev.be
        if hasattr(be, "quant_weight"):                      # exporting: emit real quantised nodes
            r = self.ranges.get(id(layer))
            if r is not None:
                x = ops.fake_quant(x, *self._affine(r))
            return x, be.quant_weight(w)
        key = id(layer)
        if self.observe and (ctx.train or getattr(self, "calibrating", False)):
            lo, hi = be.minmax(x)
            r = self.ranges.get(key)
            if r is None:
                self.ranges[key] = [min(lo, 0.0), max(hi, 0.0)]
            else:
                m = self.momentum if ctx.train else 0.9
                r[0], r[1] = m * r[0] + (1 - m) * min(lo, 0.0), m * r[1] + (1 - m) * max(hi, 0.0)
        r = self.ranges.get(key)
        if r is not None:
            x = ops.fake_quant(x, *self._affine(r))
        wlo, whi = w.dev.be.minmax(w)
        s = max(abs(wlo), abs(whi), 1e-12) / 127.0
        return x, ops.fake_quant(w, s, 0.0, -127.0, 127.0)

    @staticmethod
    def _affine(r):
        lo, hi = min(r[0], 0.0), max(r[1], 0.0)
        scale = max(hi - lo, 1e-8) / 255.0
        zp = float(round(-128 - lo / scale))
        return scale, max(-128.0, min(127.0, zp)), -128.0, 127.0

    def meta(self, model=None) -> dict:
        out = {"precision": self.precision, "scheme": "conv inputs affine int8, weights symmetric int8 per tensor", "ranges": {}}
        if model is not None:
            for path, layer in conv_layers(model)[0]:
                if id(layer) in self.ranges:
                    out["ranges"][path] = [float(v) for v in self.ranges[id(layer)]]
        return out

    @staticmethod
    def from_meta(q: dict, model) -> Optional["Scheme"]:
        if q.get("precision") != "int8":
            return None
        s = Scheme("int8", observe=False)
        by_path = dict(conv_layers(model)[0])
        for path, r in (q.get("ranges") or {}).items():
            if path in by_path:
                s.ranges[id(by_path[path])] = list(r)
        return s


class QAT:
    """``wf.QAT(precision="int8")``: quantisation-aware training. Pass it to ``model.train(quantization=...)``.

    INT8: every forward pass in training rounds convolution weights and inputs to the int8 grid (gradients pass
    straight through), so the model learns weights that survive quantisation; input ranges are tracked as moving
    averages. FP16: weights are saved in half precision (no simulation is needed). FP32: no effect."""

    def __init__(self, precision: str = "int8"):
        self.precision = check_precision(precision)

    def describe(self) -> str:
        return f"QAT {self.precision}"

    def attach(self, model) -> None:
        model.precision = self.precision
        if self.precision != "int8":
            model.quant = None
            return
        convs, floats = conv_layers(model)
        if not convs:
            raise BackendError("this model cannot be quantised to int8.", "it has no convolution layers, the only layers the int8 scheme covers.",
                               "use precision='fp16' or 'fp32'.")
        if floats:
            warn(f"{len(floats)} layer(s) are not quantised and stay in float: {', '.join(floats[:4])}.",
                 "the int8 scheme covers Conv2D, DepthwiseConv2D, PointwiseConv2D, SeparableConv2D and DilatedConv2D.",
                 "replace transposed convolutions with wf.Upsample + wf.Conv2D if every layer must be int8.")
        if model.quant is None or model.quant.precision != "int8":
            model.quant = Scheme("int8", observe=True)
        model.quant.observe = True


def calibrate(model, dataset=None, images: int = 64) -> Scheme:
    """Post-training quantisation: observe convolution input ranges on ``dataset`` (a Felix split). Without a dataset
    only the weights are quantised (activations stay float). The model's weights are not changed."""
    from . import data
    from .core import no_grad
    model._ensure()
    convs, floats = conv_layers(model)
    if not convs:
        raise BackendError("this model cannot be quantised to int8.", "it has no convolution layers.", "use precision='fp16' or 'fp32'.")
    scheme = Scheme("int8", observe=True)
    if dataset is None:
        scheme.observe = False
        return scheme
    ds = data.as_dataset(dataset)
    if hasattr(ds, "splits"):
        ds = ds.val if len(ds.val) else ds.train
    size = (model.input[1], model.input[2])
    old, model.quant = model.quant, scheme
    scheme.calibrating = True
    try:
        seen = 0
        with no_grad():
            for x, _ in data.Batches(ds, size, 8, model.device()):
                model(x, train=False)
                seen += x.shape[0]
                if seen >= images:
                    break
    finally:
        model.quant = old
        scheme.calibrating, scheme.observe = False, False
    return scheme
