"""Apple GPU backend ('mps'), experimental: runs on Metal through MLX, Apple's open-source array library.

Speed notes:
- 4-D tensors are *stored* channels-last (N, H, W, C), MLX's native layout; weights (O, I, kh, kw) are stored as
  (O, kh, kw, I), exactly what MLX convolutions take. ``Tensor.shape`` stays (N, C, H, W): only this file sees the
  difference, and data is converted when it enters or leaves the GPU.
- Nothing is evaluated eagerly: a training step builds one lazy MLX graph (forward, backward, optimizer, EMA) that
  runs when the loss needs the head outputs and when ``flush`` is called at the end of the step.
- Element-wise chains (BatchNorm, activations, AdamW) are compiled into fused Metal kernels with ``mx.compile``.
Gradients of convolutions, pooling and resizing use MLX's vector-Jacobian products.
"""
from __future__ import annotations

from typing import Tuple

from ..errors import BackendError
from .tensor import Buf, Tensor

_mx = None

# logical NCHW axis -> stored NHWC axis
_PHYS = (0, 3, 1, 2)


def _load():
    global _mx
    if _mx is None:
        import mlx.core as mx
        _mx = mx
    return _mx


def probe() -> Tuple[bool, str]:
    try:
        mx = _load()
    except ImportError:
        return False, "MLX is not installed (it provides Apple GPU support)"
    try:
        if not mx.metal.is_available():
            return False, "this machine has no Metal GPU"
    except Exception as e:  # pragma: no cover
        return False, str(e)
    return True, "Apple GPU through MLX"


def _logical(shape):
    shape = tuple(int(s) for s in shape)
    return (shape[0], shape[3], shape[1], shape[2]) if len(shape) == 4 else shape


def _physical(shape):
    shape = tuple(int(s) for s in shape)
    return (shape[0], shape[2], shape[3], shape[1]) if len(shape) == 4 else shape


class MetalBackend:
    name = "mps"

    def __init__(self):
        ok, why = probe()
        if not ok:
            raise BackendError("the Apple GPU backend is not available.", why, "run `pip install mlx` on an Apple-silicon Mac, or use device='cpu'.")
        self.mx = mx = _load()
        from . import device as _device
        self.cpu = _device.get("cpu")
        c = mx.compile

        # ---- fused element-wise kernels (compiled once per shape)
        def silu_back(v, g):
            s = mx.sigmoid(v)
            return g * s * (1 + v * (1 - s))

        def adamw(p, g, m, v, lr, b1, b2, eps, wd, c1, c2):
            nm = b1 * m + (1 - b1) * g
            nv = b2 * v + (1 - b2) * g * g
            return p - lr * ((nm / c1) / (mx.sqrt(nv / c2) + eps) + wd * p), nm, nv

        self._bn_affine = c(lambda x, sc, sh: x * sc + sh)
        self._bn_dx = c(lambda dy, x, a, c1, c0: dy * a + x * c1 + c0)
        self._kernels()

        def act(z, kind, slope):
            return mx.maximum(z, 0) if kind == 0 else mx.where(z > 0, z, slope * z) if kind == 1 else \
                z * mx.sigmoid(z) if kind == 2 else mx.sigmoid(z)

        def dact(z, kind, slope):
            if kind == 0:
                return (z > 0).astype(z.dtype)
            if kind == 1:
                return mx.where(z > 0, 1.0, slope)
            s = mx.sigmoid(z)
            return s * (1 + z * (1 - s)) if kind == 2 else s * (1 - s)

        self._bnact = {}
        for kind in range(4):
            self._bnact[kind] = (
                c(lambda x, sc, sh, slope, kind=kind: act(x * sc + sh, kind, slope)),
                c(lambda dy, x, sc, sh, slope, a, c1, c0, kind=kind: dy * dact(x * sc + sh, kind, slope) * a + x * c1 + c0))
        self._silu = c(lambda v: v * mx.sigmoid(v))
        self._silu_back = c(silu_back)
        self._adamw = c(adamw)
        self._ema = c(lambda s, p, d: d * s + (1 - d) * p)

    def _kernels(self):
        """Custom Metal kernels for what MLX does in several passes: per-channel statistics, max pooling."""
        mx = self.mx
        # per channel c of channels-last data: s1 = sum(d), s2 = sum(d * e) where
        #   SQUARE: d = e = a - shift[c]            (BatchNorm forward: mean and variance, shifted for accuracy)
        #   else:   d = a, e = b - shift[c]         (BatchNorm backward: sum(dy) and sum(dy * (x - mean)))
        # thread t owns channel t % C and rows t / C, t / C + R, ... (neighbouring threads read neighbouring floats)
        src = """
            uint t = thread_position_in_grid.x;
            uint C = dims[0], rows = dims[1], R = dims[2];
            uint c = t % C;
            float k = shift[c], s1 = 0.0f, s2 = 0.0f;
            for (uint r = t / C; r < rows; r += R) {
                float d = SQUARE ? a[r * C + c] - k : a[r * C + c];
                float e = SQUARE ? d : b[r * C + c] - k;
                s1 += d;
                s2 += d * e;
            }
            out1[t] = s1;
            out2[t] = s2;
        """
        k = mx.fast.metal_kernel
        self._k_sq = k(name="wf_chan_stats_sq", input_names=["a", "b", "shift", "dims"], output_names=["out1", "out2"],
                       source=src.replace("SQUARE", "true"))
        self._k_ab = k(name="wf_chan_stats_ab", input_names=["a", "b", "shift", "dims"], output_names=["out1", "out2"],
                       source=src.replace("SQUARE", "false"))
        # max pooling (N,H,W,C): value and the flat input position (h*W + w) of the first maximum, -1 if all padding
        self._k_maxpool = k(name="wf_maxpool_fwd", input_names=["x", "p"], output_names=["y", "idx"], source="""
            uint t = thread_position_in_grid.x;
            int H = p[0], W = p[1], C = p[2], OH = p[3], OW = p[4], kh = p[5], kw = p[6], sh = p[7], sw = p[8], pt = p[9], pl = p[10];
            int c = t % C, ow = (t / C) % OW, oh = (t / (C * OW)) % OH, n = t / (C * OW * OH);
            float best = -INFINITY;
            int at = -1;
            for (int i = 0; i < kh; i++) {
                int ih = oh * sh - pt + i;
                if (ih < 0 || ih >= H) continue;
                for (int j = 0; j < kw; j++) {
                    int iw = ow * sw - pl + j;
                    if (iw < 0 || iw >= W) continue;
                    float v = x[((n * H + ih) * W + iw) * C + c];
                    if (at < 0 || v > best) { best = v; at = ih * W + iw; }
                }
            }
            y[t] = best;
            idx[t] = at;
        """)
        # its gradient, gathered per input element from the (at most kh*kw) windows that contain it
        self._k_maxpool_bwd = k(name="wf_maxpool_bwd", input_names=["dy", "idx", "p"], output_names=["dx"], source="""
            uint t = thread_position_in_grid.x;
            int H = p[0], W = p[1], C = p[2], OH = p[3], OW = p[4], kh = p[5], kw = p[6], sh = p[7], sw = p[8], pt = p[9], pl = p[10];
            int c = t % C, iw = (t / C) % W, ih = (t / (C * W)) % H, n = t / (C * W * H);
            int me = ih * W + iw;
            int oh0 = max(0, (ih + pt - kh + sh) / sh), oh1 = min(OH - 1, (ih + pt) / sh);
            int ow0 = max(0, (iw + pl - kw + sw) / sw), ow1 = min(OW - 1, (iw + pl) / sw);
            float g = 0.0f;
            for (int oh = oh0; oh <= oh1; oh++)
                for (int ow = ow0; ow <= ow1; ow++) {
                    int o = ((n * OH + oh) * OW + ow) * C + c;
                    if (idx[o] == me) g += dy[o];
                }
            dx[t] = g;
        """)

        # BatchNorm + activation backward: dz = dy * act'(x*sc + sh) is formed inside the reduction (never stored)
        acts = {0: "z > 0.0f ? 1.0f : 0.0f", 1: "z > 0.0f ? 1.0f : slope", 2: "s * (1.0f + z * (1.0f - s))", 3: "s * (1.0f - s)"}
        self._k_bnact = {kind: k(name=f"wf_bnact_stats_{kind}", input_names=["dy", "x", "sc", "sh", "shift", "dims", "slope_"],
                                 output_names=["out1", "out2"], source=f"""
            uint t = thread_position_in_grid.x;
            uint C = dims[0], rows = dims[1], R = dims[2];
            uint c = t % C;
            float k = shift[c], a = sc[c], b = sh[c], slope = slope_[0], s1 = 0.0f, s2 = 0.0f;
            for (uint r = t / C; r < rows; r += R) {{
                float xv = x[r * C + c];
                float z = xv * a + b;
                float s = 1.0f / (1.0f + metal::exp(-z));
                float d = dy[r * C + c] * ({acts[kind]});
                s1 += d;
                s2 += d * (xv - k);
            }}
            out1[t] = s1;
            out2[t] = s2;
        """) for kind in acts}

    def _stats(self, a, b, shift):
        mx = self.mx
        C = a.shape[-1]
        rows = a.size // C
        R = max(1, min(rows, (1 << 16) // C))
        T = R * C
        kern = self._k_sq if b is None else self._k_ab
        o1, o2 = kern(inputs=[a, a if b is None else b, shift, mx.array([C, rows, R], dtype=mx.uint32)],
                      grid=(T, 1, 1), threadgroup=(min(256, T), 1, 1), output_shapes=[(T,), (T,)],
                      output_dtypes=[mx.float32, mx.float32])
        return o1.reshape(R, C).sum(axis=0), o2.reshape(R, C).sum(axis=0)

    # ---- plumbing
    def release(self, h, n):
        pass

    def T(self, a, shape=None) -> Tensor:
        """Wrap a stored (channels-last) MLX array; the logical shape is derived unless given."""
        return Tensor(tuple(shape) if shape is not None else _logical(a.shape), self.dev, Buf(self, a, 0))

    def flush(self, tensors):
        """Run everything pending for these tensors now (one GPU submission) and cut their history."""
        self.mx.eval([t.h for t in tensors if t is not None])

    def empty(self, shape) -> Tensor:
        return self.zeros(shape)

    def zeros(self, shape) -> Tensor:
        return self.T(self.mx.zeros(_physical(shape), dtype=self.mx.float32), shape)

    def from_bytes(self, shape, data) -> Tensor:
        mx = self.mx
        a = mx.array(memoryview(bytes(data)).cast("f")).reshape(tuple(shape))
        if len(shape) == 4:
            a = mx.contiguous(a.transpose(0, 2, 3, 1))
        return self.T(a, shape)

    def from_host(self, t: Tensor) -> Tensor:
        return self.from_bytes(t.shape, t.tobytes())

    def _logical_array(self, t):
        a = t.h
        if a.ndim == 4:
            a = self.mx.contiguous(a.transpose(0, 3, 1, 2))
        a = a.astype(self.mx.float32)
        self.mx.eval(a)
        return a

    def host(self, t) -> Tensor:
        return self.cpu.be.from_bytes(t.shape, bytes(memoryview(self._logical_array(t))))

    def tobytes(self, t) -> bytes:
        return bytes(memoryview(self._logical_array(t)))

    def clone(self, t) -> Tensor:
        return self.T(t.h + 0, t.shape)

    def fill(self, t, v):
        t.buf.h = self.mx.full(_physical(t.shape), float(v), dtype=self.mx.float32)

    def sync(self):
        self.mx.synchronize()

    # ---- arithmetic (lazy: the step's flush evaluates them together)
    def axpy(self, y, x, a):
        y.buf.h = y.h + x.h if a == 1.0 else y.h + float(a) * x.h

    def scale(self, x, a):
        x.buf.h = x.h * a

    def add(self, a, b) -> Tensor:
        return self.T(a.h + b.h, a.shape)

    def neg(self, x) -> Tensor:
        return self.T(-x.h, x.shape)

    def sumsq(self, x) -> float:
        return float((x.h * x.h).sum().item())

    def clip_norm(self, grads, max_norm):
        """Scale all gradients so their joint norm is at most ``max_norm``, without waiting for the GPU."""
        mx = self.mx
        total = mx.sqrt(sum((g.h * g.h).sum() for g in grads))
        f = mx.minimum(1.0, max_norm / (total + 1e-12))
        for g in grads:
            g.buf.h = g.h * f
        return total

    def minmax(self, x):
        return float(x.h.min().item()), float(x.h.max().item())

    def adamw(self, p, g, m, v, lr, b1, b2, eps, wd, step):
        k = (lr, b1, b2, eps, wd, step)
        if getattr(self, "_adam_k", None) != k:    # scalars as arrays, so the compiled kernel is reused every step
            f = self.mx.float32
            self._adam_k, self._adam_s = k, [self.mx.array(v, dtype=f) for v in (lr, b1, b2, eps, wd, 1 - b1 ** step, 1 - b2 ** step)]
        p.buf.h, m.buf.h, v.buf.h = self._adamw(p.h, g.h, m.h, v.h, *self._adam_s)

    def sgd(self, p, g, m, lr, mom, wd):
        nm = mom * m.h + g.h + wd * p.h
        m.buf.h, p.buf.h = nm, p.h - lr * nm

    def ema(self, shadow, p, d):
        if getattr(self, "_ema_k", None) != d:
            self._ema_k, self._ema_d = d, self.mx.array(d, dtype=self.mx.float32)
        shadow.buf.h = self._ema(shadow.h, p.h, self._ema_d)

    # ---- convolution: stored layouts are exactly MLX's (x: N,H,W,C; w: O,kh,kw,I/groups)
    def _conv(self, x, w, cfg):
        mx = self.mx
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        if pt != pb or pl != pr:
            return mx.conv_general(x, w, stride=(sh, sw), padding=([pt, pl], [pb, pr]), kernel_dilation=(dh, dw), groups=G)
        return mx.conv2d(x, w, stride=(sh, sw), padding=(pt, pl), dilation=(dh, dw), groups=G)

    def conv_fwd(self, x, w, b, cfg, oshape) -> Tensor:
        y = self._conv(x.h, w.h, cfg)
        if b is not None:
            y = y + b.h
        return self.T(y, oshape)

    def conv_bwd_data(self, dy, w, cfg, xshape) -> Tensor:
        mx = self.mx
        _, g = mx.vjp(lambda x: self._conv(x, w.h, cfg), [mx.zeros(_physical(xshape))], [dy.h])
        return self.T(g[0], xshape)

    def conv_bwd_weight(self, x, dy, cfg, wshape, bias: bool):
        mx = self.mx
        _, g = mx.vjp(lambda w: self._conv(x.h, w, cfg), [mx.zeros(_physical(wshape))], [dy.h])
        return self.T(g[0], wshape), (self.sum_ch(dy) if bias else None)

    def sum_ch(self, x) -> Tensor:
        return self.T(x.h.sum(axis=(0, 1, 2)), (x.shape[1],))

    def add_ch(self, y, b):
        y.buf.h = y.h + b.h

    # ---- normalisation / activations
    def bn_fwd(self, x, g, b, rm, rv, mom, eps, train):
        mx = self.mx
        if train:
            xa = mx.contiguous(x.h)
            C = xa.shape[-1]
            m = xa.size // C
            k = mx.stop_gradient(xa.reshape(-1, C)[0])          # shift by one sample per channel (accuracy)
            s1, s2 = self._stats(xa, None, k)
            md = s1 / m
            var = mx.maximum(s2 / m - md * md, 0.0)
            mean = md + k
            istd = mx.rsqrt(var + eps)
            sc = istd * g.h
            y = self._bn_affine(xa, sc, b.h - mean * sc)
            rm.buf.h = (1 - mom) * rm.h + mom * mean
            rv.buf.h = (1 - mom) * rv.h + mom * var * (m / (m - 1) if m > 1 else 1.0)
            return self.T(y, x.shape), self.T(mean), self.T(istd)
        istd = mx.rsqrt(rv.h + eps)
        sc = istd * g.h
        return self.T(self._bn_affine(x.h, sc, b.h - rm.h * sc), x.shape), None, None

    def bn_bwd(self, x, dy, g, mean, istd, rm, rv, eps, train):
        mx = self.mx
        if train:
            mu, is_ = mean.h, istd.h
        else:
            mu, is_ = rm.h, mx.rsqrt(rv.h + eps)
        xa, da = mx.contiguous(x.h), mx.contiguous(dy.h)
        db, s2 = self._stats(da, xa, mu)                       # sum(dy), sum(dy * (x - mean))
        dg = s2 * is_
        a = g.h * is_
        if not train:
            return self.T(da * a, x.shape), self.T(dg), self.T(db)
        m = xa.size // xa.shape[-1]
        c1 = -a * is_ * dg / m
        c0 = -a * db / m - c1 * mu
        return self.T(self._bn_dx(da, xa, a, c1, c0), x.shape), self.T(dg), self.T(db)

    # ---- BatchNorm followed by an activation, fused
    def bn_act_fwd(self, x, g, b, rm, rv, mom, eps, train, kind, slope):
        mx = self.mx
        sl = mx.array(float(slope), dtype=mx.float32)
        xa = mx.contiguous(x.h)
        if train:
            C = xa.shape[-1]
            m = xa.size // C
            k = mx.stop_gradient(xa.reshape(-1, C)[0])
            s1, s2 = self._stats(xa, None, k)
            md = s1 / m
            var = mx.maximum(s2 / m - md * md, 0.0)
            mean = md + k
            istd = mx.rsqrt(var + eps)
            rm.buf.h = (1 - mom) * rm.h + mom * mean
            rv.buf.h = (1 - mom) * rv.h + mom * var * (m / (m - 1) if m > 1 else 1.0)
        else:
            mean, istd = rm.h, mx.rsqrt(rv.h + eps)
        sc = istd * g.h
        sh = b.h - mean * sc
        return self.T(self._bnact[kind][0](xa, sc, sh, sl), x.shape), (mean, istd)

    def bn_act_bwd(self, x, dy, g, b, saved, rm, rv, eps, train, kind, slope):
        mx = self.mx
        mean, istd = saved
        sl = mx.array([float(slope)], dtype=mx.float32)
        xa, da = mx.contiguous(x.h), mx.contiguous(dy.h)
        sc = istd * g.h
        sh = b.h - mean * sc
        C = xa.shape[-1]
        rows = xa.size // C
        R = max(1, min(rows, (1 << 16) // C))
        T = R * C
        o1, o2 = self._k_bnact[kind](inputs=[da, xa, sc, sh, mean, mx.array([C, rows, R], dtype=mx.uint32), sl],
                                     grid=(T, 1, 1), threadgroup=(min(256, T), 1, 1), output_shapes=[(T,), (T,)],
                                     output_dtypes=[mx.float32, mx.float32])
        db, s2 = o1.reshape(R, C).sum(axis=0), o2.reshape(R, C).sum(axis=0)
        dg = s2 * istd
        a = sc
        if train:
            c1 = -a * istd * dg / rows
            c0 = -a * db / rows - c1 * mean
        else:
            c1 = mx.zeros_like(a)
            c0 = mx.zeros_like(a)
        dx = self._bnact[kind][1](da, xa, sc, sh, sl.reshape(()), a, c1, c0)
        return self.T(dx, x.shape), self.T(dg), self.T(db)

    def act_fwd(self, kind, x, slope=0.0) -> Tensor:
        mx, v = self.mx, x.h
        y = mx.maximum(v, 0) if kind == 0 else mx.where(v > 0, v, slope * v) if kind == 1 else self._silu(v) if kind == 2 else mx.sigmoid(v)
        return self.T(y, x.shape)

    def act_bwd(self, kind, x, y, dy, slope=0.0) -> Tensor:
        mx, v, g = self.mx, x.h, dy.h
        if kind == 0:
            d = mx.where(v > 0, g, 0.0)
        elif kind == 1:
            d = mx.where(v > 0, g, slope * g)
        elif kind == 2:
            d = self._silu_back(v, g)
        else:
            d = g * y.h * (1 - y.h)
        return self.T(d, x.shape)

    # ---- pooling / resize (stored N,H,W,C). The "idx" returned by max-style ops is the input itself (for the vjp).
    def _pool(self, a, win, kind, OH, OW):
        """Pooling over windows; padding below / right is derived from the requested output size."""
        kh, kw, sh, sw, pt, pl = win
        mx = self.mx
        H, W = a.shape[1], a.shape[2]
        pb, pr = max(0, (OH - 1) * sh + kh - H - pt), max(0, (OW - 1) * sw + kw - W - pl)
        if pt or pl or pb or pr:
            a = mx.pad(a, [(0, 0), (pt, pb), (pl, pr), (0, 0)], constant_values=float("-inf") if kind == "max" else 0.0)
        if kh == a.shape[1] and kw == a.shape[2] and OH == 1 and OW == 1:      # global pooling
            return a.max(axis=(1, 2), keepdims=True) if kind == "max" else a.mean(axis=(1, 2), keepdims=True)
        # separable: a kh x kw window is a kh-tall window followed by a kw-wide one (same result, kh + kw steps)
        comb = mx.maximum if kind == "max" else mx.add
        rows = None
        for i in range(kh):
            t = a[:, i:i + (OH - 1) * sh + 1:sh]
            rows = t if rows is None else comb(rows, t)
        y = None
        for j in range(kw):
            t = rows[:, :, j:j + (OW - 1) * sw + 1:sw]
            y = t if y is None else comb(y, t)
        return y if kind == "max" else y / (kh * kw)

    def _pool_params(self, xshape, oshape, win):
        kh, kw, sh, sw, pt, pl = win
        return self.mx.array([xshape[2], xshape[3], xshape[1], oshape[2], oshape[3], kh, kw, sh, sw, pt, pl], dtype=self.mx.int32)

    def maxpool_fwd(self, x, win, oshape):
        mx = self.mx
        p = self._pool_params(x.shape, oshape, win)
        n = oshape[0] * oshape[1] * oshape[2] * oshape[3]
        y, idx = self._k_maxpool(inputs=[mx.contiguous(x.h), p], grid=(n, 1, 1), threadgroup=(min(256, n), 1, 1),
                                 output_shapes=[_physical(oshape)] * 2, output_dtypes=[mx.float32, mx.int32])
        return self.T(y, oshape), (idx, p)

    def maxpool_bwd(self, dy, idx, xshape) -> Tensor:
        mx = self.mx
        ix, p = idx
        n = xshape[0] * xshape[1] * xshape[2] * xshape[3]
        dx, = self._k_maxpool_bwd(inputs=[mx.contiguous(dy.h), ix, p], grid=(n, 1, 1), threadgroup=(min(256, n), 1, 1),
                                  output_shapes=[_physical(xshape)], output_dtypes=[mx.float32])
        return self.T(dx, xshape)

    def avgpool_fwd(self, x, win, oshape) -> Tensor:
        return self.T(self._pool(x.h, win, "avg", oshape[2], oshape[3]), oshape)

    def avgpool_bwd(self, dy, win, xshape) -> Tensor:
        OH, OW = dy.shape[2], dy.shape[3]
        _, g = self.mx.vjp(lambda a: self._pool(a, win, "avg", OH, OW), [self.mx.zeros(_physical(xshape))], [dy.h])
        return self.T(g[0], xshape)

    def _up(self, a, OH, OW):
        mx = self.mx
        H, W = a.shape[1], a.shape[2]
        if OH % H == 0 and OW % W == 0:            # integer factor: repeat (fast, and its gradient is a reshape-sum)
            fh, fw = OH // H, OW // W
            N, C = a.shape[0], a.shape[3]
            a = mx.broadcast_to(a[:, :, None, :, None, :], (N, H, fh, W, fw, C))
            return a.reshape(N, OH, OW, C)
        rows = mx.array([i * H // OH for i in range(OH)])
        cols = mx.array([j * W // OW for j in range(OW)])
        return mx.take(mx.take(a, rows, axis=1), cols, axis=2)

    def upsample_fwd(self, x, OH, OW) -> Tensor:
        return self.T(self._up(x.h, OH, OW), (x.shape[0], x.shape[1], OH, OW))

    def upsample_bwd(self, dy, xshape) -> Tensor:
        N, C, H, W = xshape
        OH, OW = dy.shape[2], dy.shape[3]
        if OH % H == 0 and OW % W == 0:
            g = dy.h.reshape(N, H, OH // H, W, OW // W, C).sum(axis=(2, 4))
            return self.T(g, xshape)
        _, g = self.mx.vjp(lambda a: self._up(a, OH, OW), [self.mx.zeros(_physical(xshape))], [dy.h])
        return self.T(g[0], xshape)

    # ---- channel ops and broadcasting (channels are the last stored axis)
    def concat(self, xs) -> Tensor:
        return self.T(self.mx.concatenate([x.h for x in xs], axis=3))

    def slice_ch(self, x, off, c) -> Tensor:
        return self.T(x.h[..., off:off + c])

    def pad_ch(self, dy, off, total) -> Tensor:
        return self.T(self.mx.pad(dy.h, [(0, 0), (0, 0), (0, 0), (off, total - off - dy.shape[1])]))

    def mul_bc(self, x, s) -> Tensor:
        return self.T(x.h * s.h, x.shape)

    def mul_reduce(self, a, b, sshape) -> Tensor:
        axes = tuple(_PHYS[i] for i in range(4) if sshape[i] == 1 and a.shape[i] != 1)
        p = a.h * b.h
        return self.T(p.sum(axis=axes, keepdims=True) if axes else p, sshape)

    def chan_mean(self, x) -> Tensor:
        return self.T(x.h.mean(axis=3, keepdims=True))

    def chan_mean_bwd(self, dy, Cc) -> Tensor:
        N, _, H, W = dy.shape
        return self.T(self.mx.broadcast_to(dy.h / Cc, (N, H, W, Cc)) + 0)

    def chan_max(self, x):
        return self.T(x.h.max(axis=3, keepdims=True)), x

    def chan_max_bwd(self, dy, idx, Cc) -> Tensor:
        _, g = self.mx.vjp(lambda a: a.max(axis=3, keepdims=True), [idx.h], [dy.h])
        return self.T(g[0], idx.shape)

    def _s2d(self, a):
        return self.mx.concatenate([a[:, ::2, ::2], a[:, 1::2, ::2], a[:, ::2, 1::2], a[:, 1::2, 1::2]], axis=3)

    def s2d(self, x) -> Tensor:
        return self.T(self._s2d(x.h))

    def s2d_bwd(self, dy) -> Tensor:
        N, C4, OH, OW = dy.shape
        shape = (N, C4 // 4, OH * 2, OW * 2)
        _, g = self.mx.vjp(self._s2d, [self.mx.zeros(_physical(shape))], [dy.h])
        return self.T(g[0], shape)

    # ---- quantisation
    def fake_quant(self, x, scale, zp, qmin, qmax) -> Tensor:
        mx = self.mx
        return self.T((mx.clip(mx.round(x.h / scale + zp), qmin, qmax) - zp) * scale, x.shape)

    def fake_quant_bwd(self, x, dy, scale, zp, qmin, qmax) -> Tensor:
        q = x.h / scale + zp
        return self.T(self.mx.where((q >= qmin - 0.5) & (q <= qmax + 0.5), dy.h, 0.0), x.shape)
