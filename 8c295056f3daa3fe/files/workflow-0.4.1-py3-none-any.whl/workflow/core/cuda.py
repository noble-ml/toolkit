"""CUDA backend: Workflow's own kernels (src/wf_cuda.cu) run through the NVIDIA driver API via ctypes.

Only the NVIDIA driver is needed at run time; the kernels ship precompiled as PTX. If the PTX is missing and
``nvcc`` is installed, it is compiled on first use.
"""
from __future__ import annotations

import ctypes as C
import math
import os
import shutil
import struct
import subprocess
import sys
from typing import Tuple

from ..errors import BackendError
from .tensor import Buf, Tensor, numel

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "src", "wf_cuda.cu")
PTX = os.path.join(HERE, "lib", "cuda", "wf_cuda.ptx")
BLOCK = 256
CHUNK = 4096
_drv = None


def _driver():
    global _drv
    if _drv is None:
        for name in ("libcuda.so.1", "libcuda.so", "nvcuda.dll"):
            try:
                _drv = C.CDLL(name)
                break
            except OSError:
                continue
        if _drv is None:
            raise OSError("the NVIDIA driver library (libcuda) was not found")
    return _drv


def _ok(code: int, what: str):
    if code != 0:
        hint = {2: "the GPU is out of memory", 100: "no CUDA-capable device was detected", 200: "the kernel image is invalid",
                700: "a kernel accessed invalid memory"}.get(code, f"CUDA error {code}")
        raise BackendError(f"CUDA {what} failed.", f"{hint}.",
                           "lower batch_size / img_size if memory ran out; otherwise check `nvidia-smi` and the driver, or use device='cpu'.")


_probe = None


def probe() -> Tuple[bool, str]:
    """(usable, description or reason)."""
    global _probe
    if _probe is None:
        try:
            d = _driver()
            if d.cuInit(0) != 0:
                _probe = (False, "the NVIDIA driver is installed but could not start (cuInit failed)")
            else:
                n = C.c_int()
                d.cuDeviceGetCount(C.byref(n))
                if n.value < 1:
                    _probe = (False, "the NVIDIA driver found no GPU")
                else:
                    dev, name, mem = C.c_int(), C.create_string_buffer(128), C.c_size_t()
                    d.cuDeviceGet(C.byref(dev), 0)
                    d.cuDeviceGetName(name, 128, dev)
                    d.cuDeviceTotalMem_v2(C.byref(mem), dev)
                    _probe = (True, f"{name.value.decode()} · {mem.value / 2**30:.1f} GB · own CUDA kernels")
        except OSError as e:
            _probe = (False, f"no NVIDIA driver on this machine ({e})")
    return _probe


def build_ptx(out: str = PTX) -> str:
    nvcc = shutil.which("nvcc")
    if not nvcc:
        raise BackendError("Workflow's CUDA kernels are not available.",
                           "the precompiled kernel file (wf_cuda.ptx) is missing and nvcc (the CUDA compiler) is not installed to build it.",
                           "reinstall workflow (the wheel ships the kernels), or install the CUDA toolkit so `nvcc` is on PATH.")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    r = subprocess.run([nvcc, "--ptx", "-O3", "-arch=sm_50", "-Wno-deprecated-gpu-targets", "-o", out, SRC], capture_output=True, text=True)
    if r.returncode != 0:
        raise BackendError("compiling Workflow's CUDA kernels failed.", r.stderr.strip()[-600:], "check `nvcc --version`; use device='cpu' meanwhile.")
    return out


class CudaBackend:
    name = "cuda"

    def __init__(self, index: int = 0):
        ok, why = probe()
        if not ok:
            raise BackendError("CUDA is not available.", why, "use device='cpu'.")
        d = self.d = _driver()
        dev, self.ctx, self.mod = C.c_int(), C.c_void_p(), C.c_void_p()
        _ok(d.cuDeviceGet(C.byref(dev), index), "device selection")
        _ok(d.cuCtxCreate_v2(C.byref(self.ctx), 0, dev), "context creation")
        ptx = PTX if os.path.exists(PTX) else build_ptx(os.path.join(os.path.expanduser("~"), ".cache", "workflow", "wf_cuda.ptx")
                                                         if not os.access(os.path.dirname(HERE), os.W_OK) else PTX)
        with open(ptx, "rb") as f:
            _ok(d.cuModuleLoadData(C.byref(self.mod), f.read() + b"\0"), "kernel loading")
        self.fn, self.pool, self.pooled = {}, {}, 0
        from . import device as _device
        self.cpu = _device.get("cpu")

    # ---- plumbing
    def _f(self, name):
        if name not in self.fn:
            h = C.c_void_p()
            _ok(self.d.cuModuleGetFunction(C.byref(h), self.mod, name.encode()), f"kernel lookup ({name})")
            self.fn[name] = h
        return self.fn[name]

    def run(self, name: str, n: int, *args):
        """Launch kernel ``name`` over ``n`` work items. Args: Tensor/None → pointer, int → int, float → float,
        ("l", v) → long."""
        if n <= 0:
            return
        vals = []
        for a in args:
            if isinstance(a, Tensor):
                vals.append(C.c_uint64(a.h))
            elif a is None:
                vals.append(C.c_uint64(0))
            elif isinstance(a, tuple):
                vals.append(C.c_int64(a[1]))
            elif isinstance(a, float):
                vals.append(C.c_float(a))
            else:
                vals.append(C.c_int(int(a)))
        ptrs = (C.c_void_p * len(vals))(*[C.cast(C.pointer(v), C.c_void_p) for v in vals])
        _ok(self.d.cuLaunchKernel(self._f(name), (n + BLOCK - 1) // BLOCK, 1, 1, BLOCK, 1, 1, 0, None, ptrs, None), f"kernel {name}")

    def _alloc(self, n: int):
        free = self.pool.get(n)
        if free:
            self.pooled -= n
            return free.pop()
        p = C.c_uint64()
        code = self.d.cuMemAlloc_v2(C.byref(p), C.c_size_t(max(1, n) * 4))
        if code == 2 and self.pooled:                      # out of memory: drop the reuse pool and retry
            for size, items in self.pool.items():
                for h in items:
                    self.d.cuMemFree_v2(C.c_uint64(h))
            self.pool, self.pooled = {}, 0
            code = self.d.cuMemAlloc_v2(C.byref(p), C.c_size_t(max(1, n) * 4))
        _ok(code, f"memory allocation ({n * 4 / 2**20:.0f} MB)")
        return p.value

    def release(self, h, n):
        if self.pooled + n <= 192 * 2**20:                 # keep up to 768 MB of buffers for reuse
            self.pool.setdefault(n, []).append(h)
            self.pooled += n
        else:
            self.d.cuMemFree_v2(C.c_uint64(h))

    def empty(self, shape) -> Tensor:
        n = numel(shape)
        return Tensor(shape, self.dev, Buf(self, self._alloc(n), n))

    def zeros(self, shape) -> Tensor:
        t = self.empty(shape)
        _ok(self.d.cuMemsetD32_v2(C.c_uint64(t.h), 0, C.c_size_t(t.size)), "memset")
        return t

    def from_bytes(self, shape, data) -> Tensor:
        t = self.empty(shape)
        data = bytes(data) if not isinstance(data, (bytes, bytearray)) else data
        _ok(self.d.cuMemcpyHtoD_v2(C.c_uint64(t.h), data, C.c_size_t(t.size * 4)), "upload")
        return t

    def from_host(self, t: Tensor) -> Tensor:
        o = self.empty(t.shape)
        _ok(self.d.cuMemcpyHtoD_v2(C.c_uint64(o.h), C.c_void_p(t.h), C.c_size_t(t.size * 4)), "upload")
        return o

    def host(self, t) -> Tensor:
        h = self.cpu.be.empty(t.shape)
        _ok(self.d.cuMemcpyDtoH_v2(C.c_void_p(h.h), C.c_uint64(t.h), C.c_size_t(t.size * 4)), "download")
        return h

    def tobytes(self, t) -> bytes:
        return self.host(t).tobytes()

    def clone(self, t) -> Tensor:
        o = self.empty(t.shape)
        _ok(self.d.cuMemcpyDtoD_v2(C.c_uint64(o.h), C.c_uint64(t.h), C.c_size_t(t.size * 4)), "copy")
        return o

    def fill(self, t, v):
        self.run("fill", t.size, t, ("l", t.size), float(v))

    def sync(self):
        self.d.cuCtxSynchronize()

    def _floats(self, t, n) -> tuple:
        buf = (C.c_float * n)()
        _ok(self.d.cuMemcpyDtoH_v2(buf, C.c_uint64(t.h), C.c_size_t(n * 4)), "download")
        return tuple(buf)

    # ---- arithmetic
    def axpy(self, y, x, a):
        self.run("axpy", y.size, y, x, ("l", y.size), float(a))

    def scale(self, x, a):
        self.run("scale", x.size, x, ("l", x.size), float(a))

    def add(self, a, b) -> Tensor:
        y = self.empty(a.shape)
        self.run("add", a.size, y, a, b, ("l", a.size))
        return y

    def sumsq(self, x) -> float:
        k = (x.size + CHUNK - 1) // CHUNK
        part = self.empty((k,))
        self.run("part_sumsq", k, x, ("l", x.size), part, ("l", CHUNK))
        return float(sum(self._floats(part, k)))

    def minmax(self, x):
        k = (x.size + CHUNK - 1) // CHUNK
        part = self.empty((2 * k,))
        self.run("part_minmax", k, x, ("l", x.size), part, ("l", CHUNK))
        v = self._floats(part, 2 * k)
        return min(v[0::2]), max(v[1::2])

    def adamw(self, p, g, m, v, lr, b1, b2, eps, wd, step):
        self.run("adamw", p.size, p, g, m, v, ("l", p.size), float(lr), float(b1), float(b2), float(eps), float(wd),
                 float(1 - b1 ** step), float(1 - b2 ** step))

    def sgd(self, p, g, m, lr, mom, wd):
        self.run("sgd", p.size, p, g, m, ("l", p.size), float(lr), float(mom), float(wd))

    def ema(self, shadow, p, d):
        self.run("ema", p.size, shadow, p, ("l", p.size), float(d))

    # ---- convolution
    @staticmethod
    def _cv(xs, ws, cfg, oshape):
        N, Cc, H, W = xs
        OC, _, KH, KW = ws
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        return (N, Cc, H, W, OC, KH, KW, sh, sw, pt, pl, dh, dw, G, oshape[2], oshape[3])

    def gemm(self, A, B, Cm, M, N, Kd, ars, acs, brs, bcs, segments=1):
        """Cm[M x N] = A[M x Kd] * B[Kd x N] with strides (see the kernel). With ``segments`` > 1, Cm must hold
        ``segments`` partial results (segments x M x N) that the caller sums."""
        kseg = (Kd + segments - 1) // segments
        vals = [C.c_uint64(A.h), C.c_uint64(B.h), C.c_uint64(Cm.h), C.c_int(M), C.c_int(N), C.c_int(Kd),
                C.c_int64(ars), C.c_int64(acs), C.c_int64(brs), C.c_int64(bcs), C.c_int(0), C.c_int(kseg)]
        ptrs = (C.c_void_p * len(vals))(*[C.cast(C.pointer(v), C.c_void_p) for v in vals])
        _ok(self.d.cuLaunchKernel(self._f("gemm"), (N + 63) // 64, (M + 63) // 64, segments, 16, 16, 1, 0, None, ptrs, None), "kernel gemm")

    @staticmethod
    def _direct(xshape, wshape, cfg):
        """1x1, stride 1, no padding: the column matrix is the input itself."""
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        return wshape[2] == 1 and wshape[3] == 1 and sh == 1 and sw == 1 and not (pt or pb or pl or pr)

    def _cols(self, x, wshape, cfg, OH, OW):
        """(K, N*OH*OW) column matrix of ``x``."""
        N, Cc, H, W = x.shape
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        if self._direct(x.shape, wshape, cfg):
            col = self.empty((Cc, N * H * W))
            self.run("nchw_to_cn", x.size, x, col, N, Cc, ("l", H * W))
            return col
        Kd = Cc * wshape[2] * wshape[3]
        col = self.empty((Kd, N * OH * OW))
        self.run("im2col", col.size, x, col, N, Cc, H, W, wshape[2], wshape[3], sh, sw, pt, pl, dh, dw, OH, OW)
        return col

    def conv_fwd(self, x, w, b, cfg, oshape) -> Tensor:
        y = self.empty(oshape)
        if cfg[8] != 1:                                      # grouped / depthwise: direct kernel
            self.run("conv_fwd", y.size, x, w, b, y, *self._cv(x.shape, w.shape, cfg, oshape), 0 if b is None else 1)
            return y
        N, OC, OH, OW = oshape
        Kd, NON = numel(w.shape[1:]), N * OH * OW
        col = self._cols(x, w.shape, cfg, OH, OW)
        ycn = self.empty((OC, NON))
        self.gemm(w, col, ycn, OC, NON, Kd, Kd, 1, NON, 1)
        self.run("cn_to_nchw", y.size, ycn, y, b, N, OC, ("l", OH * OW), 0 if b is None else 1)
        return y

    def conv_bwd_data(self, dy, w, cfg, xshape) -> Tensor:
        dx = self.empty(xshape)
        if cfg[8] != 1:
            self.run("conv_bwd_data", dx.size, dy, w, dx, *self._cv(xshape, w.shape, cfg, dy.shape))
            return dx
        N, OC, OH, OW = dy.shape
        _, Cc, H, W = xshape
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        Kd, NON = numel(w.shape[1:]), N * OH * OW
        dycn = self.empty((OC, NON))
        self.run("nchw_to_cn", dy.size, dy, dycn, N, OC, ("l", OH * OW))
        dcol = self.empty((Kd, NON))
        self.gemm(w, dycn, dcol, Kd, NON, OC, 1, Kd, NON, 1)   # dcol = W^T · dy
        if self._direct(xshape, w.shape, cfg):
            self.run("cn_to_nchw", dx.size, dcol, dx, None, N, Cc, ("l", H * W), 0)
        else:
            self.run("col2im", dx.size, dcol, dx, N, Cc, H, W, w.shape[2], w.shape[3], sh, sw, pt, pl, dh, dw, OH, OW)
        return dx

    def conv_bwd_weight(self, x, dy, cfg, wshape, bias: bool):
        if cfg[8] != 1:
            N, M = x.shape[0], numel(wshape)
            part = self.empty((N, M))
            self.run("conv_bwd_weight", N * M, x, dy, part, *self._cv(x.shape, wshape, cfg, dy.shape))
            dw = self.zeros(wshape)
            self.run("reduce_n", M, part, dw, N, ("l", M))
            return dw, (self.sum_ch(dy) if bias else None)
        N, OC, OH, OW = dy.shape
        Kd, NON = numel(wshape[1:]), N * OH * OW
        col = self._cols(x, wshape, cfg, OH, OW)
        dycn = self.empty((OC, NON))
        self.run("nchw_to_cn", dy.size, dy, dycn, N, OC, ("l", OH * OW))
        blocks = ((OC + 63) // 64) * ((Kd + 63) // 64)          # dW = dy · col^T: few outputs, a very long sum
        seg = max(1, min(NON // 256, 1024 // blocks))
        if seg == 1:
            dw = self.empty(wshape)
            self.gemm(dycn, col, dw, OC, Kd, NON, NON, 1, 1, NON)
        else:
            part = self.empty((seg, OC * Kd))
            self.gemm(dycn, col, part, OC, Kd, NON, NON, 1, 1, NON, segments=seg)
            dw = self.zeros(wshape)
            self.run("reduce_n", OC * Kd, part, dw, seg, ("l", OC * Kd))
        return dw, (self.sum_ch(dy) if bias else None)

    def sum_ch(self, x) -> Tensor:
        N, Cc, H, W = x.shape
        part = self.empty((N, Cc))
        self.run("plane_sum", N * Cc, x, part, ("l", N * Cc), ("l", H * W))
        o = self.zeros((Cc,))
        self.run("reduce_n", Cc, part, o, N, ("l", Cc))
        return o

    def add_ch(self, y, b):
        N, Cc, H, W = y.shape
        self.run("add_ch", y.size, y, b, N, Cc, ("l", H * W))

    # ---- normalisation / activations
    def bn_fwd(self, x, g, b, rm, rv, mom, eps, train):
        N, Cc, H, W = x.shape
        y = self.empty(x.shape)
        mean, istd = self.empty((Cc,)), self.empty((Cc,))
        if train:
            s1, s2 = self.empty((N, Cc)), self.empty((N, Cc))
            self.run("plane_moments", N * Cc, x, s1, s2, ("l", N * Cc), ("l", H * W))
            self.run("bn_stats", Cc, s1, s2, N, Cc, ("l", H * W), mean, istd, rm, rv, float(mom), float(eps))
            self.run("bn_apply", x.size, x, y, mean, istd, g, b, N, Cc, ("l", H * W))
            return y, mean, istd
        self.run("istd_of", Cc, rv, istd, Cc, float(eps))
        self.run("bn_apply", x.size, x, y, rm, istd, g, b, N, Cc, ("l", H * W))
        return y, None, None

    def bn_bwd(self, x, dy, g, mean, istd, rm, rv, eps, train):
        N, Cc, H, W = x.shape
        if not train:
            mean, istd = rm, self.empty((Cc,))
            self.run("istd_of", Cc, rv, istd, Cc, float(eps))
        s1, s2 = self.empty((N, Cc)), self.empty((N, Cc))
        self.run("bn_bwd_sums", N * Cc, x, dy, mean, istd, s1, s2, ("l", N * Cc), Cc, ("l", H * W))
        dg, db = self.zeros((Cc,)), self.zeros((Cc,))
        self.run("reduce_n", Cc, s1, db, N, ("l", Cc))
        self.run("reduce_n", Cc, s2, dg, N, ("l", Cc))
        dx = self.empty(x.shape)
        self.run("bn_bwd_apply", x.size, x, dy, g, mean, istd, dg, db, dx, N, Cc, ("l", H * W), int(train))
        return dx, dg, db

    def act_fwd(self, kind, x, slope=0.0) -> Tensor:
        y = self.empty(x.shape)
        self.run("act_fwd", x.size, kind, x, y, ("l", x.size), float(slope))
        return y

    def act_bwd(self, kind, x, y, dy, slope=0.0) -> Tensor:
        dx = self.empty(x.shape)
        self.run("act_bwd", x.size, kind, x, y, dy, dx, ("l", x.size), float(slope))
        return dx

    # ---- pooling / resize
    def maxpool_fwd(self, x, win, oshape):
        N, Cc, H, W = x.shape
        y, idx = self.empty(oshape), self.empty(oshape)
        self.run("maxpool_fwd", y.size, x, y, idx, ("l", N * Cc), H, W, oshape[2], oshape[3], *win)
        return y, idx

    def maxpool_bwd(self, dy, idx, xshape) -> Tensor:
        N, Cc, H, W = xshape
        dx = self.zeros(xshape)
        self.run("maxpool_bwd", dy.size, dy, idx, dx, ("l", N * Cc), H, W, dy.shape[2], dy.shape[3])
        return dx

    def avgpool_fwd(self, x, win, oshape) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty(oshape)
        self.run("avgpool_fwd", y.size, x, y, ("l", N * Cc), H, W, oshape[2], oshape[3], *win)
        return y

    def avgpool_bwd(self, dy, win, xshape) -> Tensor:
        N, Cc, H, W = xshape
        dx = self.zeros(xshape)
        self.run("avgpool_bwd", dy.size, dy, dx, ("l", N * Cc), H, W, dy.shape[2], dy.shape[3], *win)
        return dx

    def upsample_fwd(self, x, OH, OW) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty((N, Cc, OH, OW))
        self.run("upsample_fwd", y.size, x, y, ("l", N * Cc), H, W, OH, OW)
        return y

    def upsample_bwd(self, dy, xshape) -> Tensor:
        N, Cc, H, W = xshape
        dx = self.zeros(xshape)
        self.run("upsample_bwd", dy.size, dy, dx, ("l", N * Cc), H, W, dy.shape[2], dy.shape[3])
        return dx

    # ---- channel ops and broadcasting
    def concat(self, xs) -> Tensor:
        N, _, H, W = xs[0].shape
        total = sum(x.shape[1] for x in xs)
        y = self.empty((N, total, H, W))
        off = 0
        for x in xs:
            self.run("copy_ch", x.size, y, total, off, x, x.shape[1], N, ("l", H * W))
            off += x.shape[1]
        return y

    def slice_ch(self, x, off, c) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty((N, c, H, W))
        self.run("slice_ch", y.size, x, Cc, off, y, c, N, ("l", H * W))
        return y

    def pad_ch(self, dy, off, total) -> Tensor:
        N, c, H, W = dy.shape
        dx = self.zeros((N, total, H, W))
        self.run("copy_ch", dy.size, dx, total, off, dy, c, N, ("l", H * W))
        return dx

    def mul_bc(self, x, s) -> Tensor:
        y = self.empty(x.shape)
        self.run("mul_bc", x.size, x, s, y, *x.shape, *s.shape)
        return y

    def mul_reduce(self, a, b, sshape) -> Tensor:
        o = self.zeros(sshape)
        self.run("mul_reduce", numel(sshape), a, b, o, *a.shape, *sshape)
        return o

    def chan_mean(self, x) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty((N, 1, H, W))
        self.run("chan_mean", N * H * W, x, y, N, Cc, ("l", H * W))
        return y

    def chan_mean_bwd(self, dy, Cc) -> Tensor:
        N, _, H, W = dy.shape
        dx = self.empty((N, Cc, H, W))
        self.run("chan_mean_bwd", dx.size, dy, dx, N, Cc, ("l", H * W))
        return dx

    def chan_max(self, x):
        N, Cc, H, W = x.shape
        y, idx = self.empty((N, 1, H, W)), self.empty((N, 1, H, W))
        self.run("chan_max", N * H * W, x, y, idx, N, Cc, ("l", H * W))
        return y, idx

    def chan_max_bwd(self, dy, idx, Cc) -> Tensor:
        N, _, H, W = dy.shape
        dx = self.zeros((N, Cc, H, W))
        self.run("chan_max_bwd", N * H * W, dy, idx, dx, N, Cc, ("l", H * W))
        return dx

    def s2d(self, x) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty((N, 4 * Cc, H // 2, W // 2))
        self.run("s2d", y.size, x, y, N, Cc, H, W, 0)
        return y

    def s2d_bwd(self, dy) -> Tensor:
        N, C4, OH, OW = dy.shape
        dx = self.empty((N, C4 // 4, OH * 2, OW * 2))
        self.run("s2d", dy.size, dx, dy, N, C4 // 4, OH * 2, OW * 2, 1)
        return dx

    # ---- quantisation
    def fake_quant(self, x, scale, zp, qmin, qmax) -> Tensor:
        y = self.empty(x.shape)
        self.run("fake_quant", x.size, x, y, ("l", x.size), float(scale), float(zp), float(qmin), float(qmax))
        return y

    def fake_quant_bwd(self, x, dy, scale, zp, qmin, qmax) -> Tensor:
        dx = self.empty(x.shape)
        self.run("fake_quant_bwd", x.size, x, dy, dx, ("l", x.size), float(scale), float(zp), float(qmin), float(qmax))
        return dx
