/* wfcore: Workflow's native CPU kernels. Plain C99 + pthreads, no external math libraries.
 * All tensors are contiguous float32 in NCHW order. Every exported function is prefixed wf_. */
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define API __attribute__((visibility("default")))
typedef float f32;

/* ------------------------------------------------------------------ thread pool */
typedef void (*wf_fn)(void *ctx, long lo, long hi, int tid);
#define MAXT 64
static int g_nt = 0;
static pthread_t g_th[MAXT];
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_cv = PTHREAD_COND_INITIALIZER, g_done = PTHREAD_COND_INITIALIZER;
static struct { wf_fn fn; void *ctx; long n; int nt; long gen; int pending; } g_job;
static __thread int t_inpar = 0;

static void *worker(void *arg) {
    int tid = (int)(intptr_t)arg;
    long seen = 0;
    t_inpar = 1;
    for (;;) {
        pthread_mutex_lock(&g_mu);
        while (g_job.gen == seen) pthread_cond_wait(&g_cv, &g_mu);
        seen = g_job.gen;
        wf_fn fn = g_job.fn; void *ctx = g_job.ctx; long n = g_job.n; int nt = g_job.nt;
        pthread_mutex_unlock(&g_mu);
        if (tid < nt) { long lo = n * tid / nt, hi = n * (tid + 1) / nt; if (hi > lo) fn(ctx, lo, hi, tid); }
        pthread_mutex_lock(&g_mu);
        if (--g_job.pending == 0) pthread_cond_signal(&g_done);
        pthread_mutex_unlock(&g_mu);
    }
    return 0;
}

API void wf_set_threads(int n) {
    if (g_nt) return;                       /* fixed once started */
    if (n <= 0) { n = (int)sysconf(_SC_NPROCESSORS_ONLN); if (n > 16) n = 16; }
    if (n < 1) n = 1;
    if (n > MAXT) n = MAXT;
    g_nt = n;
    for (int i = 1; i < n; i++) pthread_create(&g_th[i], 0, worker, (void *)(intptr_t)i);
}
API int wf_threads(void) { if (!g_nt) wf_set_threads(0); return g_nt; }

static void pfor(long n, wf_fn fn, void *ctx) {
    if (!g_nt) wf_set_threads(0);
    if (g_nt <= 1 || n < 2 || t_inpar) { fn(ctx, 0, n, 0); return; }
    int nt = n < g_nt ? (int)n : g_nt;
    pthread_mutex_lock(&g_mu);
    g_job.fn = fn; g_job.ctx = ctx; g_job.n = n; g_job.nt = nt; g_job.pending = g_nt - 1; g_job.gen++;
    pthread_cond_broadcast(&g_cv);
    pthread_mutex_unlock(&g_mu);
    t_inpar = 1;
    fn(ctx, 0, n / nt, 0);
    t_inpar = 0;
    pthread_mutex_lock(&g_mu);
    while (g_job.pending) pthread_cond_wait(&g_done, &g_mu);
    pthread_mutex_unlock(&g_mu);
}

/* ------------------------------------------------------------------ memory + basics */
API void *wf_alloc(long n) { void *p = 0; if (posix_memalign(&p, 64, (size_t)(n > 0 ? n : 1) * sizeof(f32))) return 0; return p; }
API void wf_free(void *p) { free(p); }
API void wf_fill(f32 *x, long n, f32 v) { for (long i = 0; i < n; i++) x[i] = v; }
API void wf_copy(f32 *d, const f32 *s, long n) { memcpy(d, s, (size_t)n * sizeof(f32)); }

typedef struct { f32 *a; const f32 *b, *c; long n; f32 s, t; int kind; } EW;
static void ew_run(void *v, long lo, long hi, int tid) {
    EW *e = (EW *)v; f32 *a = e->a; const f32 *b = e->b, *c = e->c; f32 s = e->s; (void)tid;
    switch (e->kind) {
    case 0: for (long i = lo; i < hi; i++) a[i] += s * b[i]; break;                 /* axpy */
    case 1: for (long i = lo; i < hi; i++) a[i] *= s; break;                        /* scale */
    case 2: for (long i = lo; i < hi; i++) a[i] = b[i] + c[i]; break;               /* add */
    case 3: for (long i = lo; i < hi; i++) a[i] = e->t * a[i] + s * b[i]; break;    /* lerp: a = t*a + s*b */
    }
}
static void ew(int kind, f32 *a, const f32 *b, const f32 *c, long n, f32 s, f32 t) {
    EW e = {a, b, c, n, s, t, kind};
    if (n < 32768) ew_run(&e, 0, n, 0); else pfor(n, ew_run, &e);
}
API void wf_axpy(f32 *y, const f32 *x, long n, f32 a) { ew(0, y, x, 0, n, a, 0); }
API void wf_scale(f32 *x, long n, f32 a) { ew(1, x, 0, 0, n, a, 0); }
API void wf_add(f32 *y, const f32 *a, const f32 *b, long n) { ew(2, y, a, b, n, 0, 0); }
API void wf_ema(f32 *shadow, const f32 *p, long n, f32 d) { ew(3, shadow, p, 0, n, 1 - d, d); }
API double wf_sumsq(const f32 *x, long n) { double s = 0; for (long i = 0; i < n; i++) s += (double)x[i] * x[i]; return s; }
API void wf_minmax(const f32 *x, long n, f32 *out) {
    f32 lo = x[0], hi = x[0];
    for (long i = 1; i < n; i++) { if (x[i] < lo) lo = x[i]; if (x[i] > hi) hi = x[i]; }
    out[0] = lo; out[1] = hi;
}
API void wf_adamw(f32 *p, const f32 *g, f32 *m, f32 *v, long n, f32 lr, f32 b1, f32 b2, f32 eps, f32 wd, int step) {
    f32 c1 = 1.f - powf(b1, (f32)step), c2 = 1.f - powf(b2, (f32)step);
    for (long i = 0; i < n; i++) {
        f32 gi = g[i];
        m[i] = b1 * m[i] + (1 - b1) * gi;
        v[i] = b2 * v[i] + (1 - b2) * gi * gi;
        p[i] -= lr * ((m[i] / c1) / (sqrtf(v[i] / c2) + eps) + wd * p[i]);
    }
}
API void wf_sgd(f32 *p, const f32 *g, f32 *m, long n, f32 lr, f32 mom, f32 wd) {
    for (long i = 0; i < n; i++) { f32 gi = g[i] + wd * p[i]; m[i] = mom * m[i] + gi; p[i] -= lr * m[i]; }
}

/* ------------------------------------------------------------------ fast exp / sigmoid (vectorisable) */
static inline f32 fexp(f32 x) {
    x = x > 88.f ? 88.f : (x < -87.f ? -87.f : x);
    f32 t = x * 1.44269504088896341f;
    int n = (int)(t + (t >= 0 ? 0.5f : -0.5f));
    f32 fn = (f32)n;
    x -= fn * 0.693359375f;
    x -= fn * -2.12194440e-4f;
    f32 z = x * x;
    f32 y = ((((1.9875691500E-4f * x + 1.3981999507E-3f) * x + 8.3334519073E-3f) * x + 4.1665795894E-2f) * x
             + 1.6666665459E-1f) * x + 5.0000001201E-1f;
    y = y * z + x + 1.f;
    union { uint32_t u; f32 f; } p; p.u = (uint32_t)(n + 127) << 23;
    return y * p.f;
}
static inline f32 fsig(f32 x) { return 1.f / (1.f + fexp(-x)); }


/* ------------------------------------------------------------------ vector math (8 lanes; AVX / NEON via vector extensions) */
typedef float v8 __attribute__((vector_size(32)));
typedef float v8u __attribute__((vector_size(32), aligned(4)));
typedef int32_t v8i __attribute__((vector_size(32)));
static inline v8 ld8(const f32 *p) { return *(const v8u *)p; }
static inline void st8(f32 *p, v8 v) { *(v8u *)p = v; }
static inline v8 bc8(f32 a) { return (v8){a, a, a, a, a, a, a, a}; }
static inline v8 vsel(v8i m, v8 a, v8 b) { return (v8)((m & (v8i)a) | (~m & (v8i)b)); }
static inline v8 vexp8(v8 x) {                   /* same polynomial as fexp: about 1 ulp */
    x = vsel(x > bc8(88.f), bc8(88.f), x); x = vsel(x < bc8(-87.f), bc8(-87.f), x);
    v8 t = x * bc8(1.44269504088896341f);
    v8 fn = (t + bc8(12582912.f)) - bc8(12582912.f);          /* round to nearest */
    v8i n = __builtin_convertvector(fn, v8i);
    x -= fn * bc8(0.693359375f);
    x -= fn * bc8(-2.12194440e-4f);
    v8 z = x * x;
    v8 y = ((((bc8(1.9875691500E-4f) * x + bc8(1.3981999507E-3f)) * x + bc8(8.3334519073E-3f)) * x + bc8(4.1665795894E-2f)) * x
            + bc8(1.6666665459E-1f)) * x + bc8(5.0000001201E-1f);
    y = y * z + x + bc8(1.f);
    return y * (v8)((n + 127) << 23);
}
static inline v8 vsig8(v8 x) { return bc8(1.f) / (bc8(1.f) + vexp8(-x)); }
/* activation and its derivative (kind: 0 relu, 1 leaky, 2 silu, 3 sigmoid), z = the activation's input */
static inline v8 vact(int kind, v8 z, f32 s) {
    switch (kind) {
    case 0: return vsel(z > bc8(0.f), z, bc8(0.f));
    case 1: return vsel(z > bc8(0.f), z, z * s);
    case 2: return z * vsig8(z);
    default: return vsig8(z);
    }
}
static inline v8 vdact(int kind, v8 z, v8 dy, f32 s) {
    switch (kind) {
    case 0: return vsel(z > bc8(0.f), dy, bc8(0.f));
    case 1: return vsel(z > bc8(0.f), dy, dy * s);
    case 2: { v8 g = vsig8(z); return dy * g * (bc8(1.f) + z * (bc8(1.f) - g)); }
    default: { v8 g = vsig8(z); return dy * g * (bc8(1.f) - g); }
    }
}
/* load / store up to 8 floats (zero-filled), for loop tails */
static inline v8 ldn(const f32 *p, long n) { f32 t[8] = {0}; for (long i = 0; i < n; i++) t[i] = p[i]; return ld8(t); }
static inline void stn(f32 *p, v8 v, long n) { f32 t[8]; st8(t, v); for (long i = 0; i < n; i++) p[i] = t[i]; }
static inline double hsum(v8 v) { double s = 0; for (int i = 0; i < 8; i++) s += v[i]; return s; }

/* ------------------------------------------------------------------ activations: 0 relu, 1 leaky, 2 silu, 3 sigmoid */
typedef struct { const f32 *x, *y, *dy; f32 *o; f32 s; int kind, bwd; } ACT;
static void act_run(void *v, long lo, long hi, int tid) {
    ACT *a = (ACT *)v; const f32 *x = a->x, *dy = a->dy; f32 *o = a->o; f32 s = a->s; (void)tid;
    long i = lo;
    if (!a->bwd) {
        for (; i + 8 <= hi; i += 8) st8(o + i, vact(a->kind, ld8(x + i), s));
        if (i < hi) stn(o + i, vact(a->kind, ldn(x + i, hi - i), s), hi - i);
    } else {
        for (; i + 8 <= hi; i += 8) st8(o + i, vdact(a->kind, ld8(x + i), ld8(dy + i), s));
        if (i < hi) stn(o + i, vdact(a->kind, ldn(x + i, hi - i), ldn(dy + i, hi - i), s), hi - i);
    }
}
API void wf_act_fwd(int kind, const f32 *x, f32 *y, long n, f32 slope) { ACT a = {x, 0, 0, y, slope, kind, 0}; if (n < 16384) act_run(&a, 0, n, 0); else pfor(n, act_run, &a); }
API void wf_act_bwd(int kind, const f32 *x, const f32 *y, const f32 *dy, f32 *dx, long n, f32 slope) { ACT a = {x, y, dy, dx, slope, kind, 1}; if (n < 16384) act_run(&a, 0, n, 0); else pfor(n, act_run, &a); }

/* ------------------------------------------------------------------ convolution */
typedef struct { int N, C, H, W, OC, KH, KW, sh, sw, pt, pl, dh, dw, G, OH, OW; } CV;

static void im2col(const f32 *x, const CV *c, int Cg, f32 *col) {
    long ON = (long)c->OH * c->OW;
    for (int ch = 0; ch < Cg; ch++) for (int ki = 0; ki < c->KH; ki++) for (int kj = 0; kj < c->KW; kj++) {
        f32 *r = col + ((long)(ch * c->KH + ki) * c->KW + kj) * ON;
        const f32 *xp = x + (long)ch * c->H * c->W;
        for (int oh = 0; oh < c->OH; oh++) {
            int ih = oh * c->sh - c->pt + ki * c->dh;
            f32 *rr = r + (long)oh * c->OW;
            if (ih < 0 || ih >= c->H) { memset(rr, 0, sizeof(f32) * c->OW); continue; }
            const f32 *xr = xp + (long)ih * c->W;
            for (int ow = 0; ow < c->OW; ow++) { int iw = ow * c->sw - c->pl + kj * c->dw; rr[ow] = (iw >= 0 && iw < c->W) ? xr[iw] : 0.f; }
        }
    }
}
static void col2im(const f32 *col, const CV *c, int Cg, f32 *x) {
    long ON = (long)c->OH * c->OW;
    for (int ch = 0; ch < Cg; ch++) for (int ki = 0; ki < c->KH; ki++) for (int kj = 0; kj < c->KW; kj++) {
        const f32 *r = col + ((long)(ch * c->KH + ki) * c->KW + kj) * ON;
        f32 *xp = x + (long)ch * c->H * c->W;
        for (int oh = 0; oh < c->OH; oh++) {
            int ih = oh * c->sh - c->pt + ki * c->dh;
            if (ih < 0 || ih >= c->H) continue;
            const f32 *rr = r + (long)oh * c->OW; f32 *xr = xp + (long)ih * c->W;
            for (int ow = 0; ow < c->OW; ow++) { int iw = ow * c->sw - c->pl + kj * c->dw; if (iw >= 0 && iw < c->W) xr[iw] += rr[ow]; }
        }
    }
}
/* C[i,:] += sum_k A[i*ai + k*ak] * B[k,:]   (B is K x N, C is M x N), cache-blocked over N */
static void gemm_rows(const f32 *A, long ai, long ak, const f32 *B, f32 *C, int K, long N, int i0, int i1) {
    const long NB = 384;
    for (long j0 = 0; j0 < N; j0 += NB) {
        long nb = N - j0 < NB ? N - j0 : NB;
        for (int i = i0; i < i1; i++) {
            f32 *c = C + (long)i * N + j0; const f32 *a = A + i * ai;
            int k = 0;
            for (; k + 3 < K; k += 4) {
                f32 a0 = a[k * ak], a1 = a[(k + 1) * ak], a2 = a[(k + 2) * ak], a3 = a[(k + 3) * ak];
                const f32 *b0 = B + (long)k * N + j0, *b1 = b0 + N, *b2 = b1 + N, *b3 = b2 + N;
                for (long j = 0; j < nb; j++) c[j] += a0 * b0[j] + a1 * b1[j] + a2 * b2[j] + a3 * b3[j];
            }
            for (; k < K; k++) { f32 a0 = a[k * ak]; const f32 *b0 = B + (long)k * N + j0; for (long j = 0; j < nb; j++) c[j] += a0 * b0[j]; }
        }
    }
}
/* W[i,k] += dot(Y[i,:], B[k,:]) */
static void gemm_dots(const f32 *Y, const f32 *B, f32 *W, int K, long N, int i0, int i1) {
    for (int i = i0; i < i1; i++) {
        const f32 *y = Y + (long)i * N;
        for (int k = 0; k < K; k++) {
            const f32 *b = B + (long)k * N; f32 s = 0;
#pragma omp simd reduction(+ : s)
            for (long j = 0; j < N; j++) s += y[j] * b[j];
            W[(long)i * K + k] += s;
        }
    }
}

/* ------------------------------------------------------------------ packed GEMM
 * C[M x N] += A[M x K] * B[K x N] with any element strides (so transposes are free).
 * BLIS-style: B is packed into GKC x GNR panels, A into GMR x GKC panels, and a 6 x 16 register-blocked micro-kernel
 * does the arithmetic (12 vector accumulators). Written with GCC/Clang vector extensions, so the same code becomes
 * AVX (x86), AVX2+FMA (with -mfma) or NEON (arm64). Plain fp32 throughout. */
#define GMR 6
#define GNR 16
#define GKC 256
#define GMC 96
#define GNC 1024

static __thread f32 *t_work = 0;
static f32 *gemm_work(void) {
    if (!t_work && posix_memalign((void **)&t_work, 64, sizeof(f32) * ((size_t)GMC * GKC + (size_t)GKC * GNC))) t_work = 0;
    return t_work;
}

static void pack_a(int mc, int kc, const f32 *A, long rs, long cs, f32 *Ap) {
    for (int i0 = 0; i0 < mc; i0 += GMR) {
        int m = mc - i0 < GMR ? mc - i0 : GMR;
        if (cs == 1) {
            for (int k = 0; k < kc; k++) { for (int i = 0; i < m; i++) Ap[i] = A[(long)(i0 + i) * rs + k]; for (int i = m; i < GMR; i++) Ap[i] = 0; Ap += GMR; }
        } else {
            for (int k = 0; k < kc; k++) { const f32 *a = A + (long)k * cs + (long)i0 * rs;
                for (int i = 0; i < m; i++) Ap[i] = a[(long)i * rs]; for (int i = m; i < GMR; i++) Ap[i] = 0; Ap += GMR; }
        }
    }
}
static void pack_b(int kc, int nc, const f32 *B, long rs, long cs, f32 *Bp) {
    for (int j0 = 0; j0 < nc; j0 += GNR) {
        int n = nc - j0 < GNR ? nc - j0 : GNR;
        if (cs == 1 && n == GNR) {
            for (int k = 0; k < kc; k++) { const f32 *b = B + (long)k * rs + j0; st8(Bp, ld8(b)); st8(Bp + 8, ld8(b + 8)); Bp += GNR; }
        } else if (cs == 1) {
            for (int k = 0; k < kc; k++) { const f32 *b = B + (long)k * rs + j0; for (int j = 0; j < n; j++) Bp[j] = b[j]; for (int j = n; j < GNR; j++) Bp[j] = 0; Bp += GNR; }
        } else {                                  /* transposed B: walk each of the GNR source rows sequentially */
            for (int j = 0; j < n; j++) { const f32 *b = B + (long)(j0 + j) * cs; for (int k = 0; k < kc; k++) Bp[(long)k * GNR + j] = b[(long)k * rs]; }
            for (int j = n; j < GNR; j++) for (int k = 0; k < kc; k++) Bp[(long)k * GNR + j] = 0;
            Bp += (long)kc * GNR;
        }
    }
}
static void ukr(int kc, const f32 *A, const f32 *B, f32 *C, long ldc, int m, int n) {
    v8 c00 = {0}, c01 = {0}, c10 = {0}, c11 = {0}, c20 = {0}, c21 = {0}, c30 = {0}, c31 = {0}, c40 = {0}, c41 = {0}, c50 = {0}, c51 = {0};
    for (int k = 0; k < kc; k++) {
        v8 b0 = *(const v8 *)B, b1 = *(const v8 *)(B + 8), a;
        a = bc8(A[0]); c00 += a * b0; c01 += a * b1;
        a = bc8(A[1]); c10 += a * b0; c11 += a * b1;
        a = bc8(A[2]); c20 += a * b0; c21 += a * b1;
        a = bc8(A[3]); c30 += a * b0; c31 += a * b1;
        a = bc8(A[4]); c40 += a * b0; c41 += a * b1;
        a = bc8(A[5]); c50 += a * b0; c51 += a * b1;
        A += GMR; B += GNR;
    }
    if (m == GMR && n == GNR) {
#define ROW(i, x0, x1) { f32 *c = C + (long)(i) * ldc; st8(c, ld8(c) + x0); st8(c + 8, ld8(c + 8) + x1); }
        ROW(0, c00, c01) ROW(1, c10, c11) ROW(2, c20, c21) ROW(3, c30, c31) ROW(4, c40, c41) ROW(5, c50, c51)
#undef ROW
        return;
    }
    f32 t[GMR * GNR] __attribute__((aligned(32)));
    st8(t, c00); st8(t + 8, c01); st8(t + 16, c10); st8(t + 24, c11); st8(t + 32, c20); st8(t + 40, c21);
    st8(t + 48, c30); st8(t + 56, c31); st8(t + 64, c40); st8(t + 72, c41); st8(t + 80, c50); st8(t + 88, c51);
    for (int i = 0; i < m; i++) for (int j = 0; j < n; j++) C[(long)i * ldc + j] += t[i * GNR + j];
}
/* B can come from a strided matrix or be packed on the fly (implicit im2col for convolutions). */
typedef void (*packb_fn)(const void *ctx, int kc, int nc, long k0, long n0, f32 *Bp);
typedef struct { const f32 *B; long rs, cs; } SB;
static void packb_strided(const void *v, int kc, int nc, long k0, long n0, f32 *Bp) {
    const SB *b = (const SB *)v; pack_b(kc, nc, b->B + k0 * b->rs + n0 * b->cs, b->rs, b->cs, Bp);
}
/* C (row stride ldc) += A * B; single-threaded (callers parallelise around it). */
static void sgemm_p(int M, long N, int K, const f32 *A, long rsa, long csa, packb_fn pb, const void *bctx, f32 *C, long ldc) {
    if (M <= 0 || N <= 0 || K <= 0) return;
    f32 *Ap = gemm_work(), *Bp = Ap + (size_t)GMC * GKC;
    for (long jc = 0; jc < N; jc += GNC) {
        int nc = (int)(N - jc < GNC ? N - jc : GNC);
        for (int pc = 0; pc < K; pc += GKC) {
            int kc = K - pc < GKC ? K - pc : GKC;
            pb(bctx, kc, nc, pc, jc, Bp);
            for (int ic = 0; ic < M; ic += GMC) {
                int mc = M - ic < GMC ? M - ic : GMC;
                pack_a(mc, kc, A + (long)ic * rsa + (long)pc * csa, rsa, csa, Ap);
                for (int jr = 0; jr < nc; jr += GNR)
                    for (int ir = 0; ir < mc; ir += GMR)
                        ukr(kc, Ap + (long)ir * kc, Bp + (long)jr * kc, C + (long)(ic + ir) * ldc + jc + jr, ldc,
                            mc - ir < GMR ? mc - ir : GMR, nc - jr < GNR ? nc - jr : GNR);
            }
        }
    }
}
static void sgemm(int M, long N, int K, const f32 *A, long rsa, long csa, const f32 *B, long rsb, long csb, f32 *C, long ldc) {
    SB b = {B, rsb, csb}; sgemm_p(M, N, K, A, rsa, csa, packb_strided, &b, C, ldc);
}
static int is_1x1(const CV *c) { return c->KH == 1 && c->KW == 1 && c->sh == 1 && c->sw == 1 && c->pt == 0 && c->pl == 0 && c->OH == c->H && c->OW == c->W; }
static int is_dw(const CV *c) { return c->G == c->C && c->OC == c->C && c->G > 1; }

/* Implicit im2col: the GEMM's B panels are packed straight from the image, so the K x OH*OW column matrix is
 * never built. Row k of B is (channel, ki, kj); column n is the output pixel (oh, ow). Same values as im2col. */
typedef struct { const f32 *x; const CV *c; } XB;
static void packb_im2col(const void *v, int kc, int nc, long k0, long n0, f32 *Bp) {
    const XB *q = (const XB *)v; const CV *c = q->c; const f32 *x = q->x;
    int KK = c->KH * c->KW;
    for (int j0 = 0; j0 < nc; j0 += GNR) {
        int n = nc - j0 < GNR ? nc - j0 : GNR;
        int ih0[GNR], iw0[GNR];
        long p0 = n0 + j0; int oh = (int)(p0 / c->OW), ow = (int)(p0 % c->OW);
        for (int j = 0; j < n; j++) { ih0[j] = oh * c->sh - c->pt; iw0[j] = ow * c->sw - c->pl; if (++ow == c->OW) { ow = 0; oh++; } }
        int row = n == GNR && ih0[0] == ih0[GNR - 1] && c->sw == 1;       /* the 16 pixels lie on one output row */
        long k = k0; int ch = (int)(k / KK), r = (int)(k % KK), ki = r / c->KW, kj = r % c->KW;
        for (int t = 0; t < kc; t++, Bp += GNR) {
            const f32 *xp = x + (long)ch * c->H * c->W;
            int dh = ki * c->dh, dw = kj * c->dw;
            if (row) {
                int ih = ih0[0] + dh, iw = iw0[0] + dw;
                if (ih < 0 || ih >= c->H) { st8(Bp, bc8(0.f)); st8(Bp + 8, bc8(0.f)); }
                else if (iw >= 0 && iw + GNR <= c->W) { const f32 *src = xp + (long)ih * c->W + iw; st8(Bp, ld8(src)); st8(Bp + 8, ld8(src + 8)); }
                else { const f32 *xr = xp + (long)ih * c->W; for (int j = 0; j < GNR; j++) { int w = iw + j; Bp[j] = (w >= 0 && w < c->W) ? xr[w] : 0.f; } }
            } else {
                for (int j = 0; j < n; j++) { int ih = ih0[j] + dh, iw = iw0[j] + dw;
                    Bp[j] = (ih >= 0 && ih < c->H && iw >= 0 && iw < c->W) ? xp[(long)ih * c->W + iw] : 0.f; }
                for (int j = n; j < GNR; j++) Bp[j] = 0.f;
            }
            if (++kj == c->KW) { kj = 0; if (++ki == c->KH) { ki = 0; ch++; } }
        }
    }
}
/* The transpose, for weight gradients: row k of B is the output pixel, column n is (channel, ki, kj). */
static void packb_im2col_t(const void *v, int kc, int nc, long k0, long n0, f32 *Bp) {
    const XB *q = (const XB *)v; const CV *c = q->c; const f32 *x = q->x;
    int KK = c->KH * c->KW;
    for (int j0 = 0; j0 < nc; j0 += GNR) {
        int n = nc - j0 < GNR ? nc - j0 : GNR;
        for (int j = 0; j < n; j++) {
            long kk = n0 + j0 + j; int ch = (int)(kk / KK), r = (int)(kk % KK), ki = r / c->KW, kj = r % c->KW;
            const f32 *xp = x + (long)ch * c->H * c->W;
            int oh = (int)(k0 / c->OW), ow = (int)(k0 % c->OW);
            f32 *dst = Bp + j;
            for (int t = 0; t < kc; ) {
                int ih = oh * c->sh - c->pt + ki * c->dh, run = c->OW - ow;      /* the rest of this output row */
                if (run > kc - t) run = kc - t;
                if (ih < 0 || ih >= c->H) { for (int u = 0; u < run; u++) dst[(long)(t + u) * GNR] = 0.f; }
                else {
                    const f32 *xr = xp + (long)ih * c->W; int iw = ow * c->sw - c->pl + kj * c->dw;
                    for (int u = 0; u < run; u++, iw += c->sw) dst[(long)(t + u) * GNR] = (iw >= 0 && iw < c->W) ? xr[iw] : 0.f;
                }
                t += run; ow += run; if (ow == c->OW) { ow = 0; oh++; }
            }
        }
        for (int j = n; j < GNR; j++) for (int t = 0; t < kc; t++) Bp[(long)t * GNR + j] = 0.f;
        Bp += (long)kc * GNR;
    }
}

typedef struct { const XB *q; long off; } XO;
static void packb_im2col_off(const void *v, int kc, int nc, long k0, long n0, f32 *Bp) {
    const XO *o = (const XO *)v; packb_im2col(o->q, kc, nc, k0, n0 + o->off, Bp);
}

typedef struct { CV c; const f32 *x, *w, *b, *dy, *wt; f32 *y, *dx, *dw; int mode; pthread_mutex_t *mu; int one; } CJ;

static void dw_fwd(const CV *c, const f32 *x, const f32 *w, const f32 *b, f32 *y, long lo, long hi) {
    for (long t = lo; t < hi; t++) {             /* t = n*C + ch */
        int ch = (int)(t % c->C);
        const f32 *xp = x + t * c->H * c->W, *wp = w + (long)ch * c->KH * c->KW; f32 *yp = y + t * c->OH * c->OW; f32 bias = b ? b[ch] : 0;
        for (int oh = 0; oh < c->OH; oh++) for (int ow = 0; ow < c->OW; ow++) {
            f32 s = bias;
            for (int ki = 0; ki < c->KH; ki++) { int ih = oh * c->sh - c->pt + ki * c->dh; if (ih < 0 || ih >= c->H) continue;
                for (int kj = 0; kj < c->KW; kj++) { int iw = ow * c->sw - c->pl + kj * c->dw; if (iw >= 0 && iw < c->W) s += xp[(long)ih * c->W + iw] * wp[ki * c->KW + kj]; } }
            yp[(long)oh * c->OW + ow] = s;
        }
    }
}
static void dw_bwd(const CV *c, const f32 *x, const f32 *w, const f32 *dy, f32 *dx, f32 *dwl, long lo, long hi) {
    for (long t = lo; t < hi; t++) {             /* dx and (thread-local) dw for depthwise */
        int ch = (int)(t % c->C);
        const f32 *wp = w ? w + (long)ch * c->KH * c->KW : 0, *dyp = dy + t * c->OH * c->OW;
        const f32 *xp = x ? x + t * c->H * c->W : 0; f32 *dxp = dx ? dx + t * c->H * c->W : 0, *dwp = dwl ? dwl + (long)ch * c->KH * c->KW : 0;
        for (int oh = 0; oh < c->OH; oh++) for (int ow = 0; ow < c->OW; ow++) {
            f32 g = dyp[(long)oh * c->OW + ow];
            for (int ki = 0; ki < c->KH; ki++) { int ih = oh * c->sh - c->pt + ki * c->dh; if (ih < 0 || ih >= c->H) continue;
                for (int kj = 0; kj < c->KW; kj++) { int iw = ow * c->sw - c->pl + kj * c->dw; if (iw < 0 || iw >= c->W) continue;
                    if (dxp) dxp[(long)ih * c->W + iw] += g * wp[ki * c->KW + kj];
                    if (dwp) dwp[ki * c->KW + kj] += g * xp[(long)ih * c->W + iw]; } }
        }
    }
}

static void conv_run(void *v, long lo, long hi, int tid) {
    CJ *j = (CJ *)v; const CV *c = &j->c; (void)tid;
    int Cg = c->C / c->G, OCg = c->OC / c->G, K = Cg * c->KH * c->KW;
    long ON = (long)c->OH * c->OW, IN = (long)c->H * c->W, WN = (long)c->OC * K;
    if (is_dw(c)) {
        if (j->mode == 0) { dw_fwd(c, j->x, j->w, j->b, j->y, lo, hi); return; }
        if (j->mode == 1) { dw_bwd(c, 0, j->w, j->dy, j->dx, 0, lo, hi); return; }
        f32 *loc = (f32 *)calloc((size_t)WN, sizeof(f32));
        dw_bwd(c, j->x, 0, j->dy, 0, loc, lo, hi);
        pthread_mutex_lock(j->mu); for (long i = 0; i < WN; i++) j->dw[i] += loc[i]; pthread_mutex_unlock(j->mu);
        free(loc); return;
    }
    int direct = is_1x1(c);
    if (j->one) {                                /* one image, fwd: this thread owns output columns [lo, hi) */
        for (int i = 0; i < c->OC; i++) { f32 bv = j->b ? j->b[i] : 0; f32 *yr = j->y + (long)i * ON; for (long q = lo; q < hi; q++) yr[q] = bv; }
        if (direct) sgemm(c->OC, hi - lo, K, j->w, K, 1, j->x + lo, ON, 1, j->y + lo, ON);
        else { XB q = {j->x, c}; sgemm_p(c->OC, hi - lo, K, j->w, K, 1, packb_im2col_off, &(XO){&q, lo}, j->y + lo, ON); }
        return;
    }
    f32 *col = (direct || j->mode != 1 || j->wt) ? 0 : (f32 *)malloc(sizeof(f32) * (size_t)K * ON);
    f32 *loc = (j->mode == 2) ? (f32 *)calloc((size_t)WN, sizeof(f32)) : 0;
    for (long n = lo; n < hi; n++) for (int g = 0; g < c->G; g++) {
        const f32 *wg = j->w ? j->w + (long)g * OCg * K : 0;
        if (j->mode == 0) {                      /* y[oc, :] = b[oc] + W[oc, :] . col */
            const f32 *xg = j->x + (n * c->C + (long)g * Cg) * IN; f32 *yg = j->y + (n * c->OC + (long)g * OCg) * ON;
            for (int i = 0; i < OCg; i++) { f32 bv = j->b ? j->b[g * OCg + i] : 0; f32 *yr = yg + (long)i * ON; for (long q = 0; q < ON; q++) yr[q] = bv; }
            if (direct) sgemm(OCg, ON, K, wg, K, 1, xg, ON, 1, yg, ON);
            else { XB q = {xg, c}; sgemm_p(OCg, ON, K, wg, K, 1, packb_im2col, &q, yg, ON); }
        } else if (j->mode == 1 && j->wt) {      /* stride 1: dx = dy convolved with the flipped weights (implicit GEMM) */
            const f32 *dyg = j->dy + (n * c->OC + (long)g * OCg) * ON; f32 *dxg = j->dx + (n * c->C + (long)g * Cg) * IN;
            CV v = *c; v.H = c->OH; v.W = c->OW; v.OH = c->H; v.OW = c->W; v.C = OCg;
            v.pt = (c->KH - 1) * c->dh - c->pt; v.pl = (c->KW - 1) * c->dw - c->pl;
            XB q = {dyg, &v}; int K2 = OCg * c->KH * c->KW;
            sgemm_p(Cg, IN, K2, j->wt + (long)g * Cg * K2, K2, 1, packb_im2col, &q, dxg, IN);
        } else if (j->mode == 1) {               /* dcol = W^T . dy, then scatter back */
            const f32 *dyg = j->dy + (n * c->OC + (long)g * OCg) * ON; f32 *dxg = j->dx + (n * c->C + (long)g * Cg) * IN;
            f32 *dst = direct ? dxg : col;
            if (!direct) memset(col, 0, sizeof(f32) * (size_t)K * ON);
            sgemm(K, ON, OCg, wg, 1, K, dyg, ON, 1, dst, ON);
            if (!direct) col2im(col, c, Cg, dxg);
        } else {                                 /* dW += dy . col^T */
            const f32 *xg = j->x + (n * c->C + (long)g * Cg) * IN, *dyg = j->dy + (n * c->OC + (long)g * OCg) * ON;
            if (direct) sgemm(OCg, K, (int)ON, dyg, ON, 1, xg, 1, ON, loc + (long)g * OCg * K, K);
            else { XB q = {xg, c}; sgemm_p(OCg, K, (int)ON, dyg, ON, 1, packb_im2col_t, &q, loc + (long)g * OCg * K, K); }
        }
    }
    if (loc) { pthread_mutex_lock(j->mu); for (long i = 0; i < WN; i++) j->dw[i] += loc[i]; pthread_mutex_unlock(j->mu); free(loc); }
    free(col);
}
static CV mkcv(int N, int C, int H, int W, int OC, int KH, int KW, int sh, int sw, int pt, int pb, int pl, int pr, int dh, int dw, int G) {
    CV c = {N, C, H, W, OC, KH, KW, sh, sw, pt, pl, dh, dw, G, 0, 0};
    c.OH = (H + pt + pb - dh * (KH - 1) - 1) / sh + 1; c.OW = (W + pl + pr - dw * (KW - 1) - 1) / sw + 1;
    return c;
}
#define CVARGS int N, int C, int H, int W, int OC, int KH, int KW, int sh, int sw, int pt, int pb, int pl, int pr, int dh, int dw, int G
#define CVPASS N, C, H, W, OC, KH, KW, sh, sw, pt, pb, pl, pr, dh, dw, G

API void wf_conv2d_fwd(const f32 *x, const f32 *w, const f32 *b, f32 *y, CVARGS) {
    CJ j; memset(&j, 0, sizeof j); j.c = mkcv(CVPASS); j.x = x; j.w = w; j.b = b; j.y = y; j.mode = 0;
    if (is_dw(&j.c)) { pfor((long)N * C, conv_run, &j); return; }
    if (N == 1 && G == 1) {                                   /* single image: parallelise over output channels */
        j.one = 1; pfor((long)j.c.OH * j.c.OW, conv_run, &j); return;
    }
    pfor(N, conv_run, &j);
}
API void wf_conv2d_bwd_data(const f32 *dy, const f32 *w, f32 *dx, CVARGS) {      /* dx must be zeroed by the caller */
    CJ j; memset(&j, 0, sizeof j); j.c = mkcv(CVPASS); j.dy = dy; j.w = w; j.dx = dx; j.mode = 1;
    f32 *wt = 0;
    if (!is_dw(&j.c) && !is_1x1(&j.c) && sh == 1 && sw == 1) {   /* flipped, transposed weights: wt[g][c][oc][KH-1-ki][KW-1-kj] */
        int Cg = C / G, OCg = OC / G, KK = KH * KW;
        wt = (f32 *)malloc(sizeof(f32) * (size_t)OC * Cg * KK);
        for (int g = 0; g < G; g++) for (int ci = 0; ci < Cg; ci++) for (int oc = 0; oc < OCg; oc++) for (int r = 0; r < KK; r++)
            wt[(((long)g * Cg + ci) * OCg + oc) * KK + (KK - 1 - r)] = w[(((long)g * OCg + oc) * Cg + ci) * KK + r];
        j.wt = wt;
    }
    pfor(is_dw(&j.c) ? (long)N * C : N, conv_run, &j);
    free(wt);
}
API void wf_conv2d_bwd_weight(const f32 *x, const f32 *dy, f32 *dw_, f32 *db, CVARGS) {   /* dw, db zeroed by the caller */
    pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;
    CJ j; memset(&j, 0, sizeof j); j.c = mkcv(CVPASS); j.x = x; j.dy = dy; j.dw = dw_; j.mode = 2; j.mu = &mu;
    pfor(is_dw(&j.c) ? (long)N * C : N, conv_run, &j);
    if (db) { long ON = (long)j.c.OH * j.c.OW;
        for (int n = 0; n < N; n++) for (int oc = 0; oc < OC; oc++) { const f32 *p = dy + ((long)n * OC + oc) * ON; f32 s = 0; for (long q = 0; q < ON; q++) s += p[q]; db[oc] += s; } }
}

/* ------------------------------------------------------------------ batch norm */
typedef struct { const f32 *x, *g, *b, *dy; f32 *rm, *rv, *y, *mean, *istd, *dx, *dg, *db; int N, C; long HW; f32 mom, eps; int mode; } BN;
static void bn_run(void *v, long lo, long hi, int tid) {
    BN *p = (BN *)v; long HW = p->HW; int N = p->N, C = p->C; double m = (double)N * HW; (void)tid;
    for (long c = lo; c < hi; c++) {
        if (p->mode == 0) {                                   /* train forward */
            double s = 0, ss = 0;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) s += x[i]; }
            f32 mu = (f32)(s / m);
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) { f32 d = x[i] - mu; ss += d * d; } }
            f32 var = (f32)(ss / m), is = 1.f / sqrtf(var + p->eps), g = p->g[c], b = p->b[c];
            p->mean[c] = mu; p->istd[c] = is;
            p->rm[c] = (1 - p->mom) * p->rm[c] + p->mom * mu;
            p->rv[c] = (1 - p->mom) * p->rv[c] + p->mom * (f32)(m > 1 ? ss / (m - 1) : ss / m);
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; f32 *y = p->y + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) y[i] = (x[i] - mu) * is * g + b; }
        } else if (p->mode == 1) {                            /* eval forward */
            f32 is = 1.f / sqrtf(p->rv[c] + p->eps), g = p->g[c] * is, b = p->b[c] - p->rm[c] * g;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; f32 *y = p->y + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) y[i] = x[i] * g + b; }
        } else if (p->mode == 2) {                            /* train backward */
            f32 mu = p->mean[c], is = p->istd[c], g = p->g[c]; double sdy = 0, sdx = 0;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW, *dy = p->dy + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) { sdy += dy[i]; sdx += dy[i] * (x[i] - mu) * is; } }
            p->db[c] += (f32)sdy; p->dg[c] += (f32)sdx;
            f32 k = g * is / (f32)m, a = (f32)sdy, bb = (f32)sdx;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW, *dy = p->dy + ((long)n * C + c) * HW; f32 *dx = p->dx + ((long)n * C + c) * HW;
                for (long i = 0; i < HW; i++) dx[i] = k * ((f32)m * dy[i] - a - (x[i] - mu) * is * bb); }
        } else {                                              /* eval backward (frozen statistics) */
            f32 is = 1.f / sqrtf(p->rv[c] + p->eps), g = p->g[c] * is, rm = p->rm[c]; double sdy = 0, sdx = 0;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW, *dy = p->dy + ((long)n * C + c) * HW; f32 *dx = p->dx + ((long)n * C + c) * HW;
                for (long i = 0; i < HW; i++) { sdy += dy[i]; sdx += dy[i] * (x[i] - rm) * is; dx[i] = dy[i] * g; } }
            p->db[c] += (f32)sdy; p->dg[c] += (f32)sdx;
        }
    }
}
API void wf_bn_fwd(const f32 *x, const f32 *g, const f32 *b, f32 *rm, f32 *rv, f32 *y, f32 *mean, f32 *istd, int N, int C, long HW, f32 mom, f32 eps, int train) {
    BN p; memset(&p, 0, sizeof p); p.x = x; p.g = g; p.b = b; p.rm = rm; p.rv = rv; p.y = y; p.mean = mean; p.istd = istd; p.N = N; p.C = C; p.HW = HW; p.mom = mom; p.eps = eps; p.mode = train ? 0 : 1;
    pfor(C, bn_run, &p);
}
API void wf_bn_bwd(const f32 *x, const f32 *dy, const f32 *g, const f32 *mean, const f32 *istd, f32 *rm, f32 *rv, f32 *dx, f32 *dg, f32 *db, int N, int C, long HW, f32 eps, int train) {
    BN p; memset(&p, 0, sizeof p); p.x = x; p.dy = dy; p.g = g; p.mean = (f32 *)mean; p.istd = (f32 *)istd; p.rm = rm; p.rv = rv; p.dx = dx; p.dg = dg; p.db = db; p.N = N; p.C = C; p.HW = HW; p.eps = eps; p.mode = train ? 2 : 3;
    pfor(C, bn_run, &p);
}

/* ------------------------------------------------------------------ fused batch norm + activation
 * y = act(bn(x)). Same arithmetic as wf_bn_* followed by wf_act_*, but the BN output is never stored: the backward
 * pass recomputes it from x (exactly), which saves one activation-sized tensor per layer and two memory passes. */
typedef struct { const f32 *x, *g, *b, *dy; f32 *rm, *rv, *y, *mean, *istd, *dx, *dg, *db; int N, C, kind; long HW; f32 mom, eps, slope; int mode; } BA;
static void ba_run(void *v, long lo, long hi, int tid) {
    BA *p = (BA *)v; long HW = p->HW; int N = p->N, C = p->C, kind = p->kind; f32 sl = p->slope; double m = (double)N * HW; (void)tid;
    for (long c = lo; c < hi; c++) {
        f32 mu, is, g = p->g[c], b = p->b[c];
        if (p->mode == 0 || p->mode == 2) {
            if (p->mode == 0) {                               /* batch statistics: float partials over 256 values, summed in double */
                double s = 0, ss = 0;
                for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; long i = 0;
                    while (i + 8 <= HW) { v8 a = {0}; long e = i + 256 < HW ? i + 256 : HW; for (; i + 8 <= e; i += 8) a += ld8(x + i); s += hsum(a); }
                    for (; i < HW; i++) s += x[i]; }
                mu = (f32)(s / m);
                for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; long i = 0;
                    while (i + 8 <= HW) { v8 a = {0}; long e = i + 256 < HW ? i + 256 : HW; for (; i + 8 <= e; i += 8) { v8 d = ld8(x + i) - mu; a += d * d; } ss += hsum(a); }
                    for (; i < HW; i++) { f32 d = x[i] - mu; ss += d * d; } }
                f32 var = (f32)(ss / m); is = 1.f / sqrtf(var + p->eps);
                p->mean[c] = mu; p->istd[c] = is;
                p->rm[c] = (1 - p->mom) * p->rm[c] + p->mom * mu;
                p->rv[c] = (1 - p->mom) * p->rv[c] + p->mom * (f32)(m > 1 ? ss / (m - 1) : ss / m);
            } else { mu = p->mean[c]; is = p->istd[c]; }
        } else { is = 1.f / sqrtf(p->rv[c] + p->eps); mu = p->rm[c]; }
        if (p->mode == 0 || p->mode == 1) {                   /* forward */
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; f32 *y = p->y + ((long)n * C + c) * HW; long i = 0;
                if (p->mode == 0) {
                    for (; i + 8 <= HW; i += 8) st8(y + i, vact(kind, (ld8(x + i) - mu) * is * g + b, sl));
                    if (i < HW) stn(y + i, vact(kind, (ldn(x + i, HW - i) - mu) * is * g + b, sl), HW - i);
                } else {
                    f32 gg = g * is, bb = b - mu * gg;
                    for (; i + 8 <= HW; i += 8) st8(y + i, vact(kind, ld8(x + i) * gg + bb, sl));
                    if (i < HW) stn(y + i, vact(kind, ldn(x + i, HW - i) * gg + bb, sl), HW - i);
                } }
            continue;
        }
        /* backward: dz = dy * act'(z) is written into dx, then dx is finished in place */
        double sdy = 0, sdx = 0; int train = p->mode == 2;
        f32 gg = g * is, bb = b - mu * gg;
        for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW, *dy = p->dy + ((long)n * C + c) * HW; f32 *dx = p->dx + ((long)n * C + c) * HW; long i = 0;
            while (i < HW) {
                v8 a1 = {0}, a2 = {0}; long e = i + 256 < HW ? i + 256 : HW;
                for (; i < e; i += 8) {
                    long r = e - i < 8 ? e - i : 8;
                    v8 xv = r == 8 ? ld8(x + i) : ldn(x + i, r), dyv = r == 8 ? ld8(dy + i) : ldn(dy + i, r);
                    v8 z = train ? (xv - mu) * is * g + b : xv * gg + bb;
                    v8 dz = vdact(kind, z, dyv, sl);
                    if (r < 8) { v8i keep = {0, 1, 2, 3, 4, 5, 6, 7}; dz = vsel(keep < (int)r, dz, bc8(0.f)); }
                    a1 += dz; a2 += dz * (xv - mu) * is;
                    if (r == 8) st8(dx + i, dz); else stn(dx + i, dz, r);
                }
                sdy += hsum(a1); sdx += hsum(a2);
            } }
        p->db[c] += (f32)sdy; p->dg[c] += (f32)sdx;
        if (train) {
            f32 k = g * is / (f32)m, a = (f32)sdy, bs = (f32)sdx, fm = (f32)m;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; f32 *dx = p->dx + ((long)n * C + c) * HW; long i = 0;
                for (; i + 8 <= HW; i += 8) st8(dx + i, k * (fm * ld8(dx + i) - a - (ld8(x + i) - mu) * is * bs));
                for (; i < HW; i++) dx[i] = k * (fm * dx[i] - a - (x[i] - mu) * is * bs); }
        } else {
            for (int n = 0; n < N; n++) { f32 *dx = p->dx + ((long)n * C + c) * HW; long i = 0;
                for (; i + 8 <= HW; i += 8) st8(dx + i, ld8(dx + i) * gg);
                for (; i < HW; i++) dx[i] *= gg; }
        }
    }
}
API void wf_bn_act_fwd(const f32 *x, const f32 *g, const f32 *b, f32 *rm, f32 *rv, f32 *y, f32 *mean, f32 *istd, int N, int C, long HW, f32 mom, f32 eps, int train, int kind, f32 slope) {
    BA p; memset(&p, 0, sizeof p); p.x = x; p.g = g; p.b = b; p.rm = rm; p.rv = rv; p.y = y; p.mean = mean; p.istd = istd;
    p.N = N; p.C = C; p.HW = HW; p.mom = mom; p.eps = eps; p.kind = kind; p.slope = slope; p.mode = train ? 0 : 1;
    pfor(C, ba_run, &p);
}
API void wf_bn_act_bwd(const f32 *x, const f32 *dy, const f32 *g, const f32 *b, const f32 *mean, const f32 *istd, f32 *rm, f32 *rv, f32 *dx, f32 *dg, f32 *db, int N, int C, long HW, f32 eps, int train, int kind, f32 slope) {
    BA p; memset(&p, 0, sizeof p); p.x = x; p.dy = dy; p.g = g; p.b = b; p.mean = (f32 *)mean; p.istd = (f32 *)istd; p.rm = rm; p.rv = rv;
    p.dx = dx; p.dg = dg; p.db = db; p.N = N; p.C = C; p.HW = HW; p.eps = eps; p.kind = kind; p.slope = slope; p.mode = train ? 2 : 3;
    pfor(C, ba_run, &p);
}

/* ------------------------------------------------------------------ pooling / resize */
typedef struct { const f32 *x; f32 *y; int32_t *idx; int H, W, OH, OW, kh, kw, sh, sw, pt, pl, mode; } PL;
static void pool_run(void *v, long lo, long hi, int tid) {
    PL *p = (PL *)v; (void)tid;
    for (long t = lo; t < hi; t++) {                          /* t = plane index (n*C + c) */
        const f32 *x = p->x + t * p->H * p->W; f32 *y = p->y + t * p->OH * p->OW; int32_t *ix = p->idx ? p->idx + t * p->OH * p->OW : 0;
        for (int oh = 0; oh < p->OH; oh++) {
            int ow = 0;
            int ih0 = oh * p->sh - p->pt;
            if (p->mode == 0 && p->sw == 1 && ih0 >= 0 && ih0 + p->kh <= p->H) {
                /* max pooling, stride 1, window rows inside: 8 neighbouring outputs at once, same scan order and
                 * strict '>' as the scalar loop, so the same maximum and index win */
                for (; ow < p->OW && ow - p->pl < 0; ow++) {
                    f32 best = -INFINITY; int bi = -1;
                    for (int ki = 0; ki < p->kh; ki++) { int ih = ih0 + ki;
                        for (int kj = 0; kj < p->kw; kj++) { int iw = ow - p->pl + kj; if (iw < 0 || iw >= p->W) continue;
                            f32 val = x[(long)ih * p->W + iw]; if (val > best) { best = val; bi = ih * p->W + iw; } } }
                    y[(long)oh * p->OW + ow] = best; ix[(long)oh * p->OW + ow] = bi;
                }
                for (; ow + 8 <= p->OW && ow + 7 - p->pl + p->kw <= p->W; ow += 8) {
                    v8 best = bc8(-INFINITY); v8i bi = {-1, -1, -1, -1, -1, -1, -1, -1};
                    v8i lane = {0, 1, 2, 3, 4, 5, 6, 7};
                    for (int ki = 0; ki < p->kh; ki++) { int ih = ih0 + ki;
                        for (int kj = 0; kj < p->kw; kj++) { int iw = ow - p->pl + kj;
                            v8 val = ld8(x + (long)ih * p->W + iw); v8i m = val > best;
                            best = vsel(m, val, best); v8i at = lane + (ih * p->W + iw); bi = (m & at) | (~m & bi); } }
                    st8(y + (long)oh * p->OW + ow, best);
                    for (int l = 0; l < 8; l++) ix[(long)oh * p->OW + ow + l] = bi[l];
                }
            }
            for (; ow < p->OW; ow++) {
                f32 best = -INFINITY, s = 0; int bi = -1;
                for (int ki = 0; ki < p->kh; ki++) { int ih = ih0 + ki; if (ih < 0 || ih >= p->H) continue;
                    for (int kj = 0; kj < p->kw; kj++) { int iw = ow * p->sw - p->pl + kj; if (iw < 0 || iw >= p->W) continue;
                        f32 val = x[(long)ih * p->W + iw]; s += val; if (val > best) { best = val; bi = ih * p->W + iw; } } }
                long o = (long)oh * p->OW + ow;
                if (p->mode == 0) { y[o] = best; ix[o] = bi; } else y[o] = s / (f32)(p->kh * p->kw);
            }
        }
    }
}
API void wf_maxpool_fwd(const f32 *x, f32 *y, int32_t *idx, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    PL p = {x, y, idx, H, W, OH, OW, kh, kw, sh, sw, pt, pl, 0}; pfor(planes, pool_run, &p);
}
API void wf_avgpool_fwd(const f32 *x, f32 *y, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    PL p = {x, y, 0, H, W, OH, OW, kh, kw, sh, sw, pt, pl, 1}; pfor(planes, pool_run, &p);
}
typedef struct { const f32 *a; const int32_t *ix; f32 *b; int H, W, OH, OW, up; } PB;
static void plane_run(void *v, long lo, long hi, int tid) {
    PB *q = (PB *)v; int H = q->H, W = q->W, OH = q->OH, OW = q->OW; (void)tid;
    for (long t = lo; t < hi; t++) {
        if (q->ix) {                                            /* maxpool backward: route each gradient to its winner */
            const f32 *g = q->a + t * OH * OW; const int32_t *ix = q->ix + t * OH * OW; f32 *d = q->b + t * H * W;
            for (long o = 0; o < (long)OH * OW; o++) if (ix[o] >= 0) d[ix[o]] += g[o];
        } else if (q->up == 0) {                                /* nearest upsample forward */
            const f32 *xp = q->a + t * H * W; f32 *yp = q->b + t * OH * OW;
            for (int oh = 0; oh < OH; oh++) { const f32 *xr = xp + (long)((long)oh * H / OH) * W; f32 *yr = yp + (long)oh * OW;
                for (int ow = 0; ow < OW; ow++) yr[ow] = xr[(long)ow * W / OW]; }
        } else {                                                /* nearest upsample backward */
            f32 *xp = q->b + t * H * W; const f32 *yp = q->a + t * OH * OW;
            for (int oh = 0; oh < OH; oh++) { f32 *xr = xp + (long)((long)oh * H / OH) * W; const f32 *yr = yp + (long)oh * OW;
                for (int ow = 0; ow < OW; ow++) xr[(long)ow * W / OW] += yr[ow]; }
        }
    }
}
API void wf_maxpool_bwd(const f32 *dy, const int32_t *idx, f32 *dx, long planes, int H, int W, int OH, int OW) {   /* dx zeroed */
    PB q = {dy, idx, dx, H, W, OH, OW, 0}; pfor(planes, plane_run, &q);
}
API void wf_avgpool_bwd(const f32 *dy, f32 *dx, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {   /* dx zeroed */
    f32 inv = 1.f / (f32)(kh * kw);
    for (long t = 0; t < planes; t++) { const f32 *g = dy + t * OH * OW; f32 *d = dx + t * H * W;
        for (int oh = 0; oh < OH; oh++) for (int ow = 0; ow < OW; ow++) { f32 gv = g[(long)oh * OW + ow] * inv;
            for (int ki = 0; ki < kh; ki++) { int ih = oh * sh - pt + ki; if (ih < 0 || ih >= H) continue;
                for (int kj = 0; kj < kw; kj++) { int iw = ow * sw - pl + kj; if (iw >= 0 && iw < W) d[(long)ih * W + iw] += gv; } } } }
}
API void wf_upsample_fwd(const f32 *x, f32 *y, long planes, int H, int W, int OH, int OW) {      /* nearest */
    PB q = {x, 0, y, H, W, OH, OW, 0}; pfor(planes, plane_run, &q);
}
API void wf_upsample_bwd(const f32 *dy, f32 *dx, long planes, int H, int W, int OH, int OW) {    /* dx zeroed */
    PB q = {dy, 0, dx, H, W, OH, OW, 1}; pfor(planes, plane_run, &q);
}

/* ------------------------------------------------------------------ channel ops, broadcasting, reshuffles */
API void wf_copy_ch(f32 *dst, int dC, int off, const f32 *src, int sC, int N, long HW) {         /* dst[n, off+c] = src[n, c] */
    for (int n = 0; n < N; n++) memcpy(dst + ((long)n * dC + off) * HW, src + (long)n * sC * HW, sizeof(f32) * (size_t)sC * HW);
}
API void wf_slice_ch(const f32 *src, int sC, int off, f32 *dst, int dC, int N, long HW) {        /* dst[n, c] = src[n, off+c] */
    for (int n = 0; n < N; n++) memcpy(dst + (long)n * dC * HW, src + ((long)n * sC + off) * HW, sizeof(f32) * (size_t)dC * HW);
}
/* y = x * s, s broadcast: each of sN,sC,sH,sW equals the x dim or 1 */
API void wf_mul_bc(const f32 *x, const f32 *s, f32 *y, int N, int C, int H, int W, int sN, int sC, int sH, int sW) {
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) for (int h = 0; h < H; h++) {
        const f32 *xr = x + (((long)n * C + c) * H + h) * W; f32 *yr = y + (((long)n * C + c) * H + h) * W;
        const f32 *sr = s + (((long)(sN > 1 ? n : 0) * sC + (sC > 1 ? c : 0)) * sH + (sH > 1 ? h : 0)) * sW;
        if (sW > 1) for (int w = 0; w < W; w++) yr[w] = xr[w] * sr[w]; else { f32 sv = sr[0]; for (int w = 0; w < W; w++) yr[w] = xr[w] * sv; }
    }
}
/* out (broadcast shape) += sum over broadcast dims of a*b; out zeroed by the caller */
API void wf_mul_reduce(const f32 *a, const f32 *b, f32 *out, int N, int C, int H, int W, int sN, int sC, int sH, int sW) {
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) for (int h = 0; h < H; h++) {
        const f32 *ar = a + (((long)n * C + c) * H + h) * W, *br = b + (((long)n * C + c) * H + h) * W;
        f32 *o = out + (((long)(sN > 1 ? n : 0) * sC + (sC > 1 ? c : 0)) * sH + (sH > 1 ? h : 0)) * sW;
        if (sW > 1) for (int w = 0; w < W; w++) o[w] += ar[w] * br[w]; else { f32 t = 0; for (int w = 0; w < W; w++) t += ar[w] * br[w]; o[0] += t; }
    }
}
API void wf_chan_mean(const f32 *x, f32 *y, int N, int C, long HW) {
    for (int n = 0; n < N; n++) { f32 *yp = y + (long)n * HW; memset(yp, 0, sizeof(f32) * HW);
        for (int c = 0; c < C; c++) { const f32 *xp = x + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) yp[i] += xp[i]; }
        f32 inv = 1.f / C; for (long i = 0; i < HW; i++) yp[i] *= inv; }
}
API void wf_chan_mean_bwd(const f32 *dy, f32 *dx, int N, int C, long HW) {
    f32 inv = 1.f / C;
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) { const f32 *g = dy + (long)n * HW; f32 *d = dx + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) d[i] = g[i] * inv; }
}
API void wf_chan_max(const f32 *x, f32 *y, int32_t *idx, int N, int C, long HW) {
    for (int n = 0; n < N; n++) { f32 *yp = y + (long)n * HW; int32_t *ip = idx + (long)n * HW;
        for (long i = 0; i < HW; i++) { yp[i] = -INFINITY; ip[i] = 0; }
        for (int c = 0; c < C; c++) { const f32 *xp = x + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) if (xp[i] > yp[i]) { yp[i] = xp[i]; ip[i] = c; } } }
}
API void wf_chan_max_bwd(const f32 *dy, const int32_t *idx, f32 *dx, int N, int C, long HW) {   /* dx zeroed */
    for (int n = 0; n < N; n++) { const f32 *g = dy + (long)n * HW; const int32_t *ip = idx + (long)n * HW; for (long i = 0; i < HW; i++) dx[((long)n * C + ip[i]) * HW + i] += g[i]; }
}
/* Focus: (N,C,H,W) -> (N,4C,H/2,W/2) in the order [even rows/even cols, odd rows/even cols, even/odd, odd/odd] */
API void wf_space_to_depth(const f32 *x, f32 *y, int N, int C, int H, int W, int inverse) {
    int OH = H / 2, OW = W / 2;
    for (int n = 0; n < N; n++) for (int q = 0; q < 4; q++) for (int c = 0; c < C; c++) {
        int dr = q & 1, dc = q >> 1;
        f32 *yp = (f32 *)y + (((long)n * 4 * C) + (long)q * C + c) * OH * OW; f32 *xp = (f32 *)x + ((long)n * C + c) * H * W;
        for (int oh = 0; oh < OH; oh++) for (int ow = 0; ow < OW; ow++) {
            if (!inverse) yp[(long)oh * OW + ow] = xp[(long)(2 * oh + dr) * W + 2 * ow + dc];
            else xp[(long)(2 * oh + dr) * W + 2 * ow + dc] = yp[(long)oh * OW + ow];
        }
    }
}

/* ------------------------------------------------------------------ quantisation (uniform, per tensor) */
API void wf_fake_quant(const f32 *x, f32 *y, long n, f32 scale, f32 zp, f32 qmin, f32 qmax) {
    for (long i = 0; i < n; i++) { f32 q = nearbyintf(x[i] / scale + zp); q = q < qmin ? qmin : (q > qmax ? qmax : q); y[i] = (q - zp) * scale; }
}
API void wf_fake_quant_bwd(const f32 *x, const f32 *dy, f32 *dx, long n, f32 scale, f32 zp, f32 qmin, f32 qmax) {   /* straight-through */
    for (long i = 0; i < n; i++) { f32 q = x[i] / scale + zp; dx[i] = (q >= qmin - 0.5f && q <= qmax + 0.5f) ? dy[i] : 0.f; }
}
API void wf_quantize_i8(const f32 *x, int8_t *q, long n, f32 scale) {
    for (long i = 0; i < n; i++) { f32 v = nearbyintf(x[i] / scale); q[i] = (int8_t)(v < -127 ? -127 : (v > 127 ? 127 : v)); }
}
API void wf_dequantize_i8(const int8_t *q, f32 *x, long n, f32 scale) { for (long i = 0; i < n; i++) x[i] = q[i] * scale; }

/* ------------------------------------------------------------------ detection: loss (with gradients), decode + NMS
 * Head maps are (N, 5+NC, h, w): channels 0-3 = distances left/top/right/bottom in strides (softplus),
 * 4 = objectness logit, 5.. = class logits. Targets are rows [image, class, x1, y1, x2, y2] in pixels. */
static inline f32 softplus(f32 r) { return r > 20.f ? r : log1pf(expf(r)); }
static inline f32 sigm(f32 z) { return 1.f / (1.f + expf(-z)); }
static inline f32 bce(f32 z, f32 t) { return (z > 0 ? z : 0) - z * t + log1pf(expf(-fabsf(z))); }

API double wf_det_loss(int L, const f32 **pred, f32 **grad, const int *hs, const int *ws, int N, int NC, int img_h, int img_w,
                       const f32 *tg, int T, f32 wbox, f32 wobj, f32 wcls, double *parts) {
    const f32 RADIUS = 1.5f, RANGE = 8.f;
    int CH = 5 + NC; double lbox = 0, lobj = 0, lcls = 0; long npos = 0;
    int *tlvl = (int *)malloc(sizeof(int) * (size_t)(T > 0 ? T : 1));
    for (int l = 0; l < L; l++) memset(grad[l], 0, sizeof(f32) * (size_t)N * CH * hs[l] * ws[l]);
    for (int t = 0; t < T; t++) {                             /* the level whose stride suits the object's size */
        f32 gm = fmaxf(tg[t * 6 + 4] - tg[t * 6 + 2], tg[t * 6 + 5] - tg[t * 6 + 3]); int lv = L - 1;
        for (int l = 0; l < L - 1; l++) if (gm <= RANGE * (f32)img_w / ws[l]) { lv = l; break; }
        tlvl[t] = lv;
    }
    for (int l = 0; l < L; l++) {
        int h = hs[l], w = ws[l]; long hw = (long)h * w; f32 sx = (f32)img_w / w, sy = (f32)img_h / h, s = 0.5f * (sx + sy);
        for (int b = 0; b < N; b++) {
            const f32 *p = pred[l] + (long)b * CH * hw; f32 *g = grad[l] + (long)b * CH * hw;
            for (int i = 0; i < h; i++) for (int j = 0; j < w; j++) {
                long o = (long)i * w + j; f32 cx = (j + 0.5f) * sx, cy = (i + 0.5f) * sy; int best = -1; f32 barea = INFINITY;
                for (int t = 0; t < T; t++) {
                    const f32 *q = tg + t * 6;
                    if ((int)q[0] != b || tlvl[t] != l) continue;
                    f32 gcx = 0.5f * (q[2] + q[4]), gcy = 0.5f * (q[3] + q[5]);
                    int ix = (int)(gcx / sx), iy = (int)(gcy / sy);
                    ix = ix < 0 ? 0 : (ix > w - 1 ? w - 1 : ix); iy = iy < 0 ? 0 : (iy > h - 1 ? h - 1 : iy);
                    int ok = (ix == j && iy == i) ||
                             (cx > q[2] && cx < q[4] && cy > q[3] && cy < q[5] && fabsf(cx - gcx) < RADIUS * s && fabsf(cy - gcy) < RADIUS * s);
                    f32 area = (q[4] - q[2]) * (q[5] - q[3]);
                    if (ok && area < barea) { barea = area; best = t; }
                }
                f32 z = p[4 * hw + o], tt = best >= 0 ? 1.f : 0.f;
                lobj += bce(z, tt); g[4 * hw + o] = wobj * (sigm(z) - tt);
                if (best < 0) continue;
                npos++;
                const f32 *q = tg + best * 6; int kc = (int)q[1];
                for (int k = 0; k < NC; k++) { f32 zc = p[(5 + k) * hw + o], tc = k == kc ? 1.f : 0.f; lcls += bce(zc, tc); g[(5 + k) * hw + o] = wcls * (sigm(zc) - tc); }
                f32 r0 = p[o], r1 = p[hw + o], r2 = p[2 * hw + o], r3 = p[3 * hw + o];
                f32 x1 = cx - softplus(r0) * sx, y1 = cy - softplus(r1) * sy, x2 = cx + softplus(r2) * sx, y2 = cy + softplus(r3) * sy;
                f32 gx1 = q[2], gy1 = q[3], gx2 = q[4], gy2 = q[5];
                f32 iw = fminf(x2, gx2) - fmaxf(x1, gx1), ih = fminf(y2, gy2) - fmaxf(y1, gy1);
                int has = iw > 0 && ih > 0; if (iw < 0) iw = 0; if (ih < 0) ih = 0;
                f32 I = iw * ih, pw = x2 - x1, ph = y2 - y1, U = pw * ph + (gx2 - gx1) * (gy2 - gy1) - I + 1e-9f;
                f32 cw = fmaxf(x2, gx2) - fminf(x1, gx1), chh = fmaxf(y2, gy2) - fminf(y1, gy1), Cc = cw * chh + 1e-9f;
                lbox += 2.f - I / U - U / Cc;                 /* 1 - GIoU */
                f32 dI[4] = {(has && x1 > gx1) ? -ih : 0, (has && y1 > gy1) ? -iw : 0, (has && x2 < gx2) ? ih : 0, (has && y2 < gy2) ? iw : 0};
                f32 dA[4] = {-ph, -pw, ph, pw};
                f32 dC[4] = {x1 < gx1 ? -chh : 0, y1 < gy1 ? -cw : 0, x2 > gx2 ? chh : 0, y2 > gy2 ? cw : 0};
                f32 rr[4] = {r0, r1, r2, r3}, sg[4] = {-sx, -sy, sx, sy};
                for (int e = 0; e < 4; e++) {
                    f32 dU = dA[e] - dI[e];
                    f32 d = -(dI[e] * U - I * dU) / (U * U) - (dU * Cc - U * dC[e]) / (Cc * Cc);
                    g[e * hw + o] = wbox * d * sg[e] * sigm(rr[e]);
                }
            }
        }
    }
    f32 inv = 1.f / (f32)(npos > 0 ? npos : 1);
    for (int l = 0; l < L; l++) { long n = (long)N * CH * hs[l] * ws[l]; f32 *g = grad[l]; for (long i = 0; i < n; i++) g[i] *= inv; }
    free(tlvl);
    parts[0] = lbox * inv; parts[1] = lobj * inv; parts[2] = lcls * inv; parts[3] = (double)npos;
    return wbox * parts[0] + wobj * parts[1] + wcls * parts[2];
}

typedef struct { f32 b[4], score; int cls; } Det;
static int det_cmp(const void *a, const void *b) { f32 d = ((const Det *)b)->score - ((const Det *)a)->score; return d > 0 ? 1 : (d < 0 ? -1 : 0); }
static f32 iou_of(const f32 *a, const f32 *b) {
    f32 iw = fminf(a[2], b[2]) - fmaxf(a[0], b[0]), ih = fminf(a[3], b[3]) - fmaxf(a[1], b[1]);
    if (iw <= 0 || ih <= 0) return 0;
    f32 I = iw * ih; return I / ((a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - I + 1e-9f);
}
/* out: N * max_det rows of [x1, y1, x2, y2, score, class]; counts[n] = rows used for image n */
API void wf_decode(int L, const f32 **pred, const int *hs, const int *ws, int N, int NC, int img_h, int img_w,
                   f32 conf, f32 iou, int max_det, int max_nms, f32 *out, int *counts) {
    int CH = 5 + NC; long A = 0;
    for (int l = 0; l < L; l++) A += (long)hs[l] * ws[l];
    Det *d = (Det *)malloc(sizeof(Det) * (size_t)A); char *dead = (char *)malloc((size_t)(max_nms > 0 ? max_nms : 1));
    for (int b = 0; b < N; b++) {
        long m = 0;
        for (int l = 0; l < L; l++) {
            int h = hs[l], w = ws[l]; long hw = (long)h * w; f32 sx = (f32)img_w / w, sy = (f32)img_h / h; const f32 *p = pred[l] + (long)b * CH * hw;
            for (long o = 0; o < hw; o++) {
                f32 ob = sigm(p[4 * hw + o]);
                if (ob <= conf) continue;
                int kc = 0; f32 zb = p[5 * hw + o];
                for (int k = 1; k < NC; k++) if (p[(5 + k) * hw + o] > zb) { zb = p[(5 + k) * hw + o]; kc = k; }
                f32 sc = ob * sigm(zb);
                if (sc <= conf) continue;
                f32 cx = ((f32)(o % w) + 0.5f) * sx, cy = ((f32)(o / w) + 0.5f) * sy;
                Det *q = &d[m++]; q->score = sc; q->cls = kc;
                q->b[0] = cx - softplus(p[o]) * sx; q->b[1] = cy - softplus(p[hw + o]) * sy;
                q->b[2] = cx + softplus(p[2 * hw + o]) * sx; q->b[3] = cy + softplus(p[3 * hw + o]) * sy;
            }
        }
        qsort(d, (size_t)m, sizeof(Det), det_cmp);
        if (m > max_nms) m = max_nms;
        memset(dead, 0, (size_t)m);
        int k = 0; f32 *o = out + (long)b * max_det * 6;
        for (long i = 0; i < m && k < max_det; i++) {
            if (dead[i]) continue;
            memcpy(o + k * 6, d[i].b, 4 * sizeof(f32)); o[k * 6 + 4] = d[i].score; o[k * 6 + 5] = (f32)d[i].cls; k++;
            for (long j = i + 1; j < m; j++) if (!dead[j] && d[j].cls == d[i].cls && iou_of(d[i].b, d[j].b) > iou) dead[j] = 1;
        }
        counts[b] = k;
    }
    free(d); free(dead);
}

/* ------------------------------------------------------------------ image preprocessing
 * RGB uint8 (h, w, 3) -> float CHW (3, th, tw) in [0,1]: bilinear resize to (nh, nw), pasted at (px, py) on a grey
 * canvas, with optional horizontal flip and brightness gain/bias (augmentation). */
API void wf_letterbox(const uint8_t *rgb, int h, int w, f32 *out, int th, int tw, int nh, int nw, int px, int py,
                      f32 fill, int flip, f32 gain, f32 bias) {
    long plane = (long)th * tw; f32 fv = fill / 255.f;
    for (long i = 0; i < 3 * plane; i++) out[i] = fv;
    for (int oy = 0; oy < nh; oy++) {
        f32 fy = ((f32)oy + 0.5f) * h / nh - 0.5f; if (fy < 0) fy = 0; if (fy > h - 1) fy = (f32)(h - 1);
        int y0 = (int)fy, y1 = y0 + 1 < h ? y0 + 1 : y0; f32 wy = fy - y0;
        for (int ox = 0; ox < nw; ox++) {
            f32 fx = ((f32)ox + 0.5f) * w / nw - 0.5f; if (fx < 0) fx = 0; if (fx > w - 1) fx = (f32)(w - 1);
            int x0 = (int)fx, x1 = x0 + 1 < w ? x0 + 1 : x0; f32 wx = fx - x0;
            const uint8_t *a = rgb + ((long)y0 * w + x0) * 3, *b = rgb + ((long)y0 * w + x1) * 3, *c = rgb + ((long)y1 * w + x0) * 3, *d = rgb + ((long)y1 * w + x1) * 3;
            int dx = flip ? tw - 1 - (px + ox) : px + ox;
            long o = (long)(py + oy) * tw + dx;
            for (int ch = 0; ch < 3; ch++) {
                f32 v = (a[ch] * (1 - wx) + b[ch] * wx) * (1 - wy) + (c[ch] * (1 - wx) + d[ch] * wx) * wy;
                v = v * gain + bias; v = v < 0 ? 0 : (v > 255 ? 255 : v);
                out[ch * plane + o] = v / 255.f;
            }
        }
    }
}
API int wf_abi(void) { return 2; }
API void wf_sum_ch(const f32 *x, f32 *out, int N, int C, long HW) {      /* out[c] += sum over n, h, w */
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) { const f32 *p = x + ((long)n * C + c) * HW; f32 s = 0; for (long i = 0; i < HW; i++) s += p[i]; out[c] += s; }
}
API void wf_add_ch(f32 *y, const f32 *b, int N, int C, long HW) {        /* y[n, c] += b[c] */
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) { f32 *p = y + ((long)n * C + c) * HW; f32 v = b[c]; for (long i = 0; i < HW; i++) p[i] += v; }
}
API void wf_uniform(f32 *x, long n, f32 lo, f32 hi, uint64_t seed) {     /* xorshift64*, reproducible initialisation */
    uint64_t s = seed * 0x9E3779B97F4A7C15ULL + 0x632BE59BD9B4E019ULL;
    for (long i = 0; i < n; i++) { s ^= s >> 12; s ^= s << 25; s ^= s >> 27; x[i] = lo + (hi - lo) * (f32)(((s * 0x2545F4914F6CDD1DULL) >> 40) * (1.0 / 16777216.0)); }
}
