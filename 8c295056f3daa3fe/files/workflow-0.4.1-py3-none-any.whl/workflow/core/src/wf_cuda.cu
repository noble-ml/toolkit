// wf_cuda: Workflow's own CUDA kernels. Compiled once to PTX (nvcc --ptx) and loaded through the driver API.
// Every kernel uses a 1-D grid over its work items. Tensors are contiguous float32 NCHW.
#define K extern "C" __global__ void
#define IDX long i = (long)blockIdx.x * blockDim.x + threadIdx.x
typedef float f32;

__device__ inline f32 sig(f32 x) { return 1.f / (1.f + expf(-x)); }

K fill(f32 *x, long n, f32 v) { IDX; if (i < n) x[i] = v; }
K axpy(f32 *y, const f32 *x, long n, f32 a) { IDX; if (i < n) y[i] += a * x[i]; }
K scale(f32 *x, long n, f32 a) { IDX; if (i < n) x[i] *= a; }
K add(f32 *y, const f32 *a, const f32 *b, long n) { IDX; if (i < n) y[i] = a[i] + b[i]; }
K ema(f32 *s, const f32 *p, long n, f32 d) { IDX; if (i < n) s[i] = d * s[i] + (1.f - d) * p[i]; }
K adamw(f32 *p, const f32 *g, f32 *m, f32 *v, long n, f32 lr, f32 b1, f32 b2, f32 eps, f32 wd, f32 c1, f32 c2) {
    IDX; if (i >= n) return;
    f32 gi = g[i];
    m[i] = b1 * m[i] + (1.f - b1) * gi;
    v[i] = b2 * v[i] + (1.f - b2) * gi * gi;
    p[i] -= lr * ((m[i] / c1) / (sqrtf(v[i] / c2) + eps) + wd * p[i]);
}
K sgd(f32 *p, const f32 *g, f32 *m, long n, f32 lr, f32 mom, f32 wd) {
    IDX; if (i >= n) return;
    f32 gi = g[i] + wd * p[i]; m[i] = mom * m[i] + gi; p[i] -= lr * m[i];
}
// chunked reductions: out[i] covers elements [i*chunk, (i+1)*chunk)
K part_sumsq(const f32 *x, long n, f32 *out, long chunk) {
    IDX; long lo = i * chunk; if (lo >= n) return; long hi = lo + chunk < n ? lo + chunk : n;
    double s = 0; for (long j = lo; j < hi; j++) s += (double)x[j] * x[j]; out[i] = (f32)s;
}
K part_minmax(const f32 *x, long n, f32 *out, long chunk) {
    IDX; long lo = i * chunk; if (lo >= n) return; long hi = lo + chunk < n ? lo + chunk : n;
    f32 a = x[lo], b = x[lo]; for (long j = lo + 1; j < hi; j++) { a = fminf(a, x[j]); b = fmaxf(b, x[j]); }
    out[2 * i] = a; out[2 * i + 1] = b;
}
K plane_sum(const f32 *x, f32 *out, long planes, long HW) {      // out[plane] = sum of the plane
    IDX; if (i >= planes) return; const f32 *p = x + i * HW; double s = 0; for (long j = 0; j < HW; j++) s += p[j]; out[i] = (f32)s;
}
K reduce_n(const f32 *part, f32 *out, int N, long M) {           // out[m] += sum_n part[n*M + m]
    IDX; if (i >= M) return; double s = 0; for (int n = 0; n < N; n++) s += part[(long)n * M + i]; out[i] += (f32)s;
}

// ---------------------------------------------------------------- activations: 0 relu, 1 leaky, 2 silu, 3 sigmoid
K act_fwd(int kind, const f32 *x, f32 *y, long n, f32 s) {
    IDX; if (i >= n) return; f32 v = x[i];
    y[i] = kind == 0 ? (v > 0 ? v : 0) : kind == 1 ? (v > 0 ? v : s * v) : kind == 2 ? v * sig(v) : sig(v);
}
K act_bwd(int kind, const f32 *x, const f32 *y, const f32 *dy, f32 *dx, long n, f32 s) {
    IDX; if (i >= n) return; f32 v = x[i], g = dy[i];
    if (kind == 0) dx[i] = v > 0 ? g : 0;
    else if (kind == 1) dx[i] = v > 0 ? g : s * g;
    else if (kind == 2) { f32 q = sig(v); dx[i] = g * q * (1.f + v * (1.f - q)); }
    else dx[i] = g * y[i] * (1.f - y[i]);
}

// ---------------------------------------------------------------- convolution (direct, one thread per result element)
#define CV int N, int C, int H, int W, int OC, int KH, int KW, int sh, int sw, int pt, int pl, int dh, int dw, int G, int OH, int OW
K conv_fwd(const f32 *x, const f32 *w, const f32 *b, f32 *y, CV, int has_b) {
    IDX; if (i >= (long)N * OC * OH * OW) return;
    int ow = i % OW; long t = i / OW; int oh = t % OH; t /= OH; int oc = t % OC; int n = (int)(t / OC);
    int Cg = C / G, g = oc / (OC / G);
    f32 s = has_b ? b[oc] : 0.f;
    const f32 *wp = w + (long)oc * Cg * KH * KW;
    for (int c = 0; c < Cg; c++) {
        const f32 *xp = x + ((long)n * C + g * Cg + c) * H * W;
        for (int ki = 0; ki < KH; ki++) { int ih = oh * sh - pt + ki * dh; if (ih < 0 || ih >= H) continue;
            for (int kj = 0; kj < KW; kj++) { int iw = ow * sw - pl + kj * dw; if (iw < 0 || iw >= W) continue;
                s += xp[ih * W + iw] * wp[(c * KH + ki) * KW + kj]; } }
    }
    y[i] = s;
}
K conv_bwd_data(const f32 *dy, const f32 *w, f32 *dx, CV) {
    IDX; if (i >= (long)N * C * H * W) return;
    int iw = i % W; long t = i / W; int ih = t % H; t /= H; int c = t % C; int n = (int)(t / C);
    int Cg = C / G, OCg = OC / G, g = c / Cg, cl = c % Cg;
    f32 s = 0;
    for (int o = 0; o < OCg; o++) {
        const f32 *wp = w + ((long)(g * OCg + o) * Cg + cl) * KH * KW;
        const f32 *dp = dy + ((long)n * OC + g * OCg + o) * OH * OW;
        for (int ki = 0; ki < KH; ki++) { int a = ih + pt - ki * dh; if (a < 0 || a % sh) continue; int oh = a / sh; if (oh >= OH) continue;
            for (int kj = 0; kj < KW; kj++) { int b = iw + pl - kj * dw; if (b < 0 || b % sw) continue; int ow = b / sw; if (ow >= OW) continue;
                s += dp[oh * OW + ow] * wp[ki * KW + kj]; } }
    }
    dx[i] = s;
}
K conv_bwd_weight(const f32 *x, const f32 *dy, f32 *part, CV) {   // part[n, oc, c, ki, kj]; reduce over n afterwards
    int Cg = C / G; long M = (long)OC * Cg * KH * KW;
    IDX; if (i >= (long)N * M) return;
    int kj = i % KW; long t = i / KW; int ki = t % KH; t /= KH; int c = t % Cg; t /= Cg; int oc = t % OC; int n = (int)(t / OC);
    int g = oc / (OC / G);
    const f32 *xp = x + ((long)n * C + g * Cg + c) * H * W, *dp = dy + ((long)n * OC + oc) * OH * OW;
    f32 s = 0;
    for (int oh = 0; oh < OH; oh++) { int ih = oh * sh - pt + ki * dh; if (ih < 0 || ih >= H) continue;
        for (int ow = 0; ow < OW; ow++) { int iw = ow * sw - pl + kj * dw; if (iw < 0 || iw >= W) continue; s += dp[oh * OW + ow] * xp[ih * W + iw]; } }
    part[i] = s;
}
K add_ch(f32 *y, const f32 *b, int N, int C, long HW) { IDX; if (i < (long)N * C * HW) y[i] += b[(i / HW) % C]; }

// ---------------------------------------------------------------- batch norm
K plane_moments(const f32 *x, f32 *s1, f32 *s2, long planes, long HW) {
    IDX; if (i >= planes) return; const f32 *p = x + i * HW; double a = 0, b = 0;
    for (long j = 0; j < HW; j++) { a += p[j]; b += (double)p[j] * p[j]; }
    s1[i] = (f32)a; s2[i] = (f32)b;
}
K bn_stats(const f32 *s1, const f32 *s2, int N, int C, long HW, f32 *mean, f32 *istd, f32 *rm, f32 *rv, f32 mom, f32 eps) {
    IDX; if (i >= C) return; double a = 0, b = 0, m = (double)N * HW;
    for (int n = 0; n < N; n++) { a += s1[(long)n * C + i]; b += s2[(long)n * C + i]; }
    double mu = a / m, var = b / m - mu * mu; if (var < 0) var = 0;
    mean[i] = (f32)mu; istd[i] = (f32)(1.0 / sqrt(var + eps));
    rm[i] = (1.f - mom) * rm[i] + mom * (f32)mu;
    rv[i] = (1.f - mom) * rv[i] + mom * (f32)(m > 1 ? var * m / (m - 1) : var);
}
K istd_of(const f32 *rv, f32 *istd, int C, f32 eps) { IDX; if (i < C) istd[i] = 1.f / sqrtf(rv[i] + eps); }
K bn_apply(const f32 *x, f32 *y, const f32 *mean, const f32 *istd, const f32 *g, const f32 *b, int N, int C, long HW) {
    IDX; if (i >= (long)N * C * HW) return; int c = (i / HW) % C; y[i] = (x[i] - mean[c]) * istd[c] * g[c] + b[c];
}
K bn_bwd_sums(const f32 *x, const f32 *dy, const f32 *mean, const f32 *istd, f32 *s1, f32 *s2, long planes, int C, long HW) {
    IDX; if (i >= planes) return; int c = i % C; const f32 *xp = x + i * HW, *dp = dy + i * HW; double a = 0, b = 0; f32 mu = mean[c], is = istd[c];
    for (long j = 0; j < HW; j++) { a += dp[j]; b += (double)dp[j] * (xp[j] - mu) * is; }
    s1[i] = (f32)a; s2[i] = (f32)b;
}
K bn_bwd_apply(const f32 *x, const f32 *dy, const f32 *g, const f32 *mean, const f32 *istd, const f32 *dg, const f32 *db,
               f32 *dx, int N, int C, long HW, int train) {
    IDX; if (i >= (long)N * C * HW) return; int c = (i / HW) % C;
    if (!train) { dx[i] = dy[i] * g[c] * istd[c]; return; }
    f32 m = (f32)N * (f32)HW;
    dx[i] = g[c] * istd[c] / m * (m * dy[i] - db[c] - (x[i] - mean[c]) * istd[c] * dg[c]);
}

// ---------------------------------------------------------------- pooling / resize
K maxpool_fwd(const f32 *x, f32 *y, int *idx, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    const f32 *xp = x + p * H * W; f32 best = -INFINITY; int bi = -1;
    for (int ki = 0; ki < kh; ki++) { int ih = oh * sh - pt + ki; if (ih < 0 || ih >= H) continue;
        for (int kj = 0; kj < kw; kj++) { int iw = ow * sw - pl + kj; if (iw < 0 || iw >= W) continue; f32 v = xp[ih * W + iw]; if (v > best) { best = v; bi = ih * W + iw; } } }
    y[i] = best; idx[i] = bi;
}
K maxpool_bwd(const f32 *dy, const int *idx, f32 *dx, long planes, int H, int W, int OH, int OW) {
    IDX; if (i >= planes * OH * OW) return; long p = i / ((long)OH * OW); if (idx[i] >= 0) atomicAdd(dx + p * H * W + idx[i], dy[i]);
}
K avgpool_fwd(const f32 *x, f32 *y, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    const f32 *xp = x + p * H * W; f32 s = 0;
    for (int ki = 0; ki < kh; ki++) { int ih = oh * sh - pt + ki; if (ih < 0 || ih >= H) continue;
        for (int kj = 0; kj < kw; kj++) { int iw = ow * sw - pl + kj; if (iw >= 0 && iw < W) s += xp[ih * W + iw]; } }
    y[i] = s / (f32)(kh * kw);
}
K avgpool_bwd(const f32 *dy, f32 *dx, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    f32 g = dy[i] / (f32)(kh * kw); f32 *xp = dx + p * H * W;
    for (int ki = 0; ki < kh; ki++) { int ih = oh * sh - pt + ki; if (ih < 0 || ih >= H) continue;
        for (int kj = 0; kj < kw; kj++) { int iw = ow * sw - pl + kj; if (iw >= 0 && iw < W) atomicAdd(xp + ih * W + iw, g); } }
}
K upsample_fwd(const f32 *x, f32 *y, long planes, int H, int W, int OH, int OW) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    y[i] = x[p * H * W + ((long)oh * H / OH) * W + (long)ow * W / OW];
}
K upsample_bwd(const f32 *dy, f32 *dx, long planes, int H, int W, int OH, int OW) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    atomicAdd(dx + p * H * W + ((long)oh * H / OH) * W + (long)ow * W / OW, dy[i]);
}

// ---------------------------------------------------------------- channel ops, broadcasting, reshuffles
K copy_ch(f32 *dst, int dC, int off, const f32 *src, int sC, int N, long HW) {     // dst[n, off+c] = src[n, c]
    IDX; if (i >= (long)N * sC * HW) return; long hw = i % HW; long t = i / HW; int c = t % sC; long n = t / sC;
    dst[(n * dC + off + c) * HW + hw] = src[i];
}
K slice_ch(const f32 *src, int sC, int off, f32 *dst, int dC, int N, long HW) {    // dst[n, c] = src[n, off+c]
    IDX; if (i >= (long)N * dC * HW) return; long hw = i % HW; long t = i / HW; int c = t % dC; long n = t / dC;
    dst[i] = src[(n * sC + off + c) * HW + hw];
}
K mul_bc(const f32 *x, const f32 *s, f32 *y, int N, int C, int H, int W, int sN, int sC, int sH, int sW) {
    IDX; if (i >= (long)N * C * H * W) return; int w = i % W; long t = i / W; int h = t % H; t /= H; int c = t % C; int n = (int)(t / C);
    y[i] = x[i] * s[(((long)(sN > 1 ? n : 0) * sC + (sC > 1 ? c : 0)) * sH + (sH > 1 ? h : 0)) * sW + (sW > 1 ? w : 0)];
}
K mul_reduce(const f32 *a, const f32 *b, f32 *out, int N, int C, int H, int W, int sN, int sC, int sH, int sW) {   // one thread per out element
    IDX; if (i >= (long)sN * sC * sH * sW) return; int w0 = i % sW; long t = i / sW; int h0 = t % sH; t /= sH; int c0 = t % sC; int n0 = (int)(t / sC);
    double s = 0;
    for (int n = (sN > 1 ? n0 : 0); n < (sN > 1 ? n0 + 1 : N); n++) for (int c = (sC > 1 ? c0 : 0); c < (sC > 1 ? c0 + 1 : C); c++)
        for (int h = (sH > 1 ? h0 : 0); h < (sH > 1 ? h0 + 1 : H); h++) for (int w = (sW > 1 ? w0 : 0); w < (sW > 1 ? w0 + 1 : W); w++) {
            long j = (((long)n * C + c) * H + h) * W + w; s += (double)a[j] * b[j]; }
    out[i] += (f32)s;
}
K chan_mean(const f32 *x, f32 *y, int N, int C, long HW) {
    IDX; if (i >= (long)N * HW) return; long hw = i % HW; long n = i / HW; f32 s = 0; for (int c = 0; c < C; c++) s += x[(n * C + c) * HW + hw]; y[i] = s / C;
}
K chan_mean_bwd(const f32 *dy, f32 *dx, int N, int C, long HW) {
    IDX; if (i >= (long)N * C * HW) return; long hw = i % HW; long n = i / (HW * C); dx[i] = dy[n * HW + hw] / C;
}
K chan_max(const f32 *x, f32 *y, int *idx, int N, int C, long HW) {
    IDX; if (i >= (long)N * HW) return; long hw = i % HW; long n = i / HW; f32 best = -INFINITY; int bi = 0;
    for (int c = 0; c < C; c++) { f32 v = x[(n * C + c) * HW + hw]; if (v > best) { best = v; bi = c; } }
    y[i] = best; idx[i] = bi;
}
K chan_max_bwd(const f32 *dy, const int *idx, f32 *dx, int N, int C, long HW) {    // dx zeroed
    IDX; if (i >= (long)N * HW) return; long hw = i % HW; long n = i / HW; dx[(n * C + idx[i]) * HW + hw] = dy[i];
}
K s2d(f32 *x, f32 *y, int N, int C, int H, int W, int inverse) {                   // one thread per y element
    int OH = H / 2, OW = W / 2;
    IDX; if (i >= (long)N * 4 * C * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; t /= OH; int ch = t % (4 * C); long n = t / (4 * C);
    int q = ch / C, c = ch % C; long j = ((n * C + c) * H + 2 * oh + (q & 1)) * W + 2 * ow + (q >> 1);
    if (inverse) x[j] = y[i]; else y[i] = x[j];
}
K fake_quant(const f32 *x, f32 *y, long n, f32 scale, f32 zp, f32 qmin, f32 qmax) {
    IDX; if (i >= n) return; f32 q = nearbyintf(x[i] / scale + zp); q = fminf(fmaxf(q, qmin), qmax); y[i] = (q - zp) * scale;
}
K fake_quant_bwd(const f32 *x, const f32 *dy, f32 *dx, long n, f32 scale, f32 zp, f32 qmin, f32 qmax) {
    IDX; if (i >= n) return; f32 q = x[i] / scale + zp; dx[i] = (q >= qmin - 0.5f && q <= qmax + 0.5f) ? dy[i] : 0.f;
}

// ---------------------------------------------------------------- GEMM-based convolution (groups == 1)
// C[M x N] (+)= A[M x Kd] * B[Kd x N], with strides so transposed operands need no copy:
//   A(i, k) = A[i*ars + k*acs],  B(k, j) = B[k*brs + j*bcs].
// Each block computes a 64x64 tile of C with 16x16 threads; every thread owns a 4x4 patch (register blocking), and
// the A / B tiles for 16 values of k live in shared memory, so each multiply-add costs ~0.5 shared reads.
#define GB 64
#define GK 16
// The sum over k can be split into segments of ``kseg`` (grid z): segment z writes its partial result to
// Cm + z*M*N, to be summed afterwards. That keeps the GPU busy when C is small but Kd is huge (weight gradients).
K gemm(const f32 *A, const f32 *B, f32 *Cm, int M, int N, int Kd, long ars, long acs, long brs, long bcs, int accumulate, int kseg) {
    __shared__ f32 As[GK][GB];
    __shared__ f32 Bs[GK][GB];
    int tx = threadIdx.x, ty = threadIdx.y, t = ty * 16 + tx;
    int row0 = blockIdx.y * GB, col0 = blockIdx.x * GB;
    f32 acc[4][4];
    for (int a = 0; a < 4; a++) for (int b = 0; b < 4; b++) acc[a][b] = 0.f;
    int kbeg = blockIdx.z * kseg, kend = kbeg + kseg < Kd ? kbeg + kseg : Kd;
    Cm += (long)blockIdx.z * M * N;
    for (int k0 = kbeg; k0 < kend; k0 += GK) {
        for (int e = 0; e < 4; e++) {
            int id = t * 4 + e, kk = id / GB, r = id % GB;
            int k = k0 + kk, row = row0 + r, col = col0 + r;
            As[kk][r] = (k < kend && row < M) ? A[(long)row * ars + (long)k * acs] : 0.f;
            Bs[kk][r] = (k < kend && col < N) ? B[(long)k * brs + (long)col * bcs] : 0.f;
        }
        __syncthreads();
#pragma unroll
        for (int kk = 0; kk < GK; kk++) {
            f32 a0 = As[kk][ty * 4], a1 = As[kk][ty * 4 + 1], a2 = As[kk][ty * 4 + 2], a3 = As[kk][ty * 4 + 3];
            f32 b0 = Bs[kk][tx * 4], b1 = Bs[kk][tx * 4 + 1], b2 = Bs[kk][tx * 4 + 2], b3 = Bs[kk][tx * 4 + 3];
            acc[0][0] += a0 * b0; acc[0][1] += a0 * b1; acc[0][2] += a0 * b2; acc[0][3] += a0 * b3;
            acc[1][0] += a1 * b0; acc[1][1] += a1 * b1; acc[1][2] += a1 * b2; acc[1][3] += a1 * b3;
            acc[2][0] += a2 * b0; acc[2][1] += a2 * b1; acc[2][2] += a2 * b2; acc[2][3] += a2 * b3;
            acc[3][0] += a3 * b0; acc[3][1] += a3 * b1; acc[3][2] += a3 * b2; acc[3][3] += a3 * b3;
        }
        __syncthreads();
    }
    for (int a = 0; a < 4; a++) { int row = row0 + ty * 4 + a; if (row >= M) continue;
        for (int b = 0; b < 4; b++) { int col = col0 + tx * 4 + b; if (col >= N) continue;
            if (accumulate) Cm[(long)row * N + col] += acc[a][b]; else Cm[(long)row * N + col] = acc[a][b]; } }
}
// (N, C, HW) <-> (C, N*HW)
K nchw_to_cn(const f32 *x, f32 *y, int N, int C, long HW) {
    IDX; if (i >= (long)N * C * HW) return; long hw = i % HW; long t = i / HW; int c = t % C; long n = t / C;
    y[((long)c * N + n) * HW + hw] = x[i];
}
K cn_to_nchw(const f32 *y, f32 *x, const f32 *b, int N, int C, long HW, int has_b) {
    IDX; if (i >= (long)N * C * HW) return; long hw = i % HW; long t = i / HW; int c = t % C; long n = t / C;
    x[i] = y[((long)c * N + n) * HW + hw] + (has_b ? b[c] : 0.f);
}
// col[(c, ki, kj), (n, oh, ow)]
K im2col(const f32 *x, f32 *col, int N, int C, int H, int W, int KH, int KW, int sh, int sw, int pt, int pl, int dh, int dw, int OH, int OW) {
    long NON = (long)N * OH * OW;
    IDX; if (i >= (long)C * KH * KW * NON) return;
    long q = i % NON; long k = i / NON; int ow = q % OW; long t = q / OW; int oh = t % OH; long n = t / OH;
    int kj = k % KW; long u = k / KW; int ki = u % KH; int c = (int)(u / KH);
    int ih = oh * sh - pt + ki * dh, iw = ow * sw - pl + kj * dw;
    col[i] = (ih >= 0 && ih < H && iw >= 0 && iw < W) ? x[((n * C + c) * H + ih) * W + iw] : 0.f;
}
K col2im(const f32 *col, f32 *dx, int N, int C, int H, int W, int KH, int KW, int sh, int sw, int pt, int pl, int dh, int dw, int OH, int OW) {
    long NON = (long)N * OH * OW;
    IDX; if (i >= (long)N * C * H * W) return;
    int iw = i % W; long t = i / W; int ih = t % H; t /= H; int c = t % C; long n = t / C;
    f32 s = 0;
    for (int ki = 0; ki < KH; ki++) { int a = ih + pt - ki * dh; if (a < 0 || a % sh) continue; int oh = a / sh; if (oh >= OH) continue;
        for (int kj = 0; kj < KW; kj++) { int b = iw + pl - kj * dw; if (b < 0 || b % sw) continue; int ow = b / sw; if (ow >= OW) continue;
            s += col[((long)(c * KH + ki) * KW + kj) * NON + (n * OH + oh) * OW + ow]; } }
    dx[i] = s;
}
