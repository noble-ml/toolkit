"""Devices: cpu (native C core), cuda (own CUDA kernels), mps (Apple GPU through MLX, experimental)."""
from __future__ import annotations

from typing import Dict, List

from ..errors import DeviceError, warn


class Device:
    def __init__(self, kind: str, index: int = 0):
        self.kind, self.index, self.be = kind, index, None

    def __repr__(self):
        return self.kind if self.kind != "cuda" else f"cuda:{self.index}"

    __str__ = __repr__


_devices: Dict[str, Device] = {}
_mps_warned = False


def _make(kind: str, index: int = 0) -> Device:
    key = f"{kind}:{index}"
    if key in _devices:
        return _devices[key]
    dev = Device(kind, index)
    if kind == "cpu":
        from .cpu import CpuBackend
        dev.be = CpuBackend()
    elif kind == "cuda":
        from .cuda import CudaBackend
        dev.be = CudaBackend(index)
    else:
        from .metal import MetalBackend
        dev.be = MetalBackend()
    dev.be.dev = dev
    _devices[key] = dev
    return dev


def cuda_status():
    """(available, reason)."""
    try:
        from . import cuda
        return cuda.probe()
    except Exception as e:  # pragma: no cover
        return False, str(e)


def mps_status():
    try:
        from . import metal
        return metal.probe()
    except Exception as e:  # pragma: no cover
        return False, str(e)


def available() -> List[dict]:
    from .cpu import lib
    out = [{"name": "cpu", "info": f"native C core · {lib().wf_threads()} threads"}]
    ok, info = cuda_status()
    if ok:
        out.append({"name": "cuda", "info": info})
    ok, info = mps_status()
    if ok:
        out.append({"name": "mps", "info": info + " (experimental)"})
    return out


def get(name="auto") -> Device:
    """Resolve 'auto', 'cpu', 'cuda', 'cuda:N', 'gpu' or 'mps'. Unavailable accelerators raise DeviceError;
    nothing is silently swapped for something else."""
    global _mps_warned
    if isinstance(name, Device):
        return name
    key = str(name).lower().strip()
    kind, _, idx = key.partition(":")
    if kind == "cpu":
        return _make("cpu")
    if kind == "auto":                       # the best *stable* device: experimental MPS is never picked implicitly
        return _make("cuda") if cuda_status()[0] else _make("cpu")
    if kind == "gpu":                        # any GPU: CUDA first, then Apple
        if cuda_status()[0]:
            kind = "cuda"
        elif mps_status()[0]:
            kind = "mps"
        else:
            raise DeviceError("no GPU is available for device='gpu'.",
                              f"CUDA: {cuda_status()[1]}; Apple GPU: {mps_status()[1]}",
                              "use device='cpu', or install what the message above names.")
    if kind == "cuda":
        ok, why = cuda_status()
        if not ok:
            raise DeviceError("device 'cuda' is not available.", why,
                              "use device='cpu', or install the NVIDIA driver and check `nvidia-smi` works.")
        return _make("cuda", int(idx) if idx.isdigit() else 0)
    if kind == "mps":
        ok, why = mps_status()
        if not ok:
            raise DeviceError("device 'mps' is not available.", why,
                              "use device='cpu'; on an Apple-silicon Mac install MLX with `pip install mlx`.")
        if not _mps_warned:
            _mps_warned = True
            warn("the 'mps' device is experimental.",
                 "Apple GPU support runs through the open-source MLX library and is less tested than cpu and cuda.",
                 "if results look wrong or it is slow, switch to device='cpu'.")
        return _make("mps")
    raise DeviceError(f"unknown device {name!r}.", "Workflow knows 'auto', 'cpu', 'cuda', 'cuda:N', 'gpu' and 'mps'.",
                      "pass one of those names.")
