"""Dataset storage: a folder or a single compiled ``.felix`` file (a zip)."""
from __future__ import annotations

import io
import os
import re
import zipfile
from pathlib import Path

from . import _yaml
from .errors import FelixError

EXT = ".felix"
_STORED = (".png", ".jpg", ".jpeg", ".webp")


def _safe(name):
    parts = name.split("/")
    if name.startswith("/") or "\\" in name or ".." in parts or ":" in parts[0] or "" in parts:
        raise FelixError(f"unsafe path in dataset: {name!r}")


class DirWriter:
    def __init__(self, root, overwrite=False):
        self.root = Path(root)
        img = self.root / "images"
        if img.is_dir() and any(img.iterdir()) and not overwrite:
            raise FelixError(f"{root} already holds a dataset (pass overwrite=True / --overwrite)")
        self._made = set()

    def write(self, name, data):
        _safe(name)
        p = self.root.joinpath(*name.split("/"))
        if p.parent not in self._made:
            p.parent.mkdir(parents=True, exist_ok=True)
            self._made.add(p.parent)
        p.write_bytes(data)

    def close(self):
        self.root.mkdir(parents=True, exist_ok=True)

    def abort(self):
        pass


class ZipWriter:
    def __init__(self, path, overwrite=False):
        self.path = Path(path)
        if self.path.exists() and not overwrite:
            raise FelixError(f"{path} already exists (pass overwrite=True / --overwrite)")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.tmp = self.path.with_name(self.path.name + ".part")
        self.z = zipfile.ZipFile(self.tmp, "w")

    def write(self, name, data):
        _safe(name)
        comp = zipfile.ZIP_STORED if name.lower().endswith(_STORED) else zipfile.ZIP_DEFLATED
        self.z.writestr(name, data, compress_type=comp)

    def close(self):
        self.z.close()
        os.replace(self.tmp, self.path)

    def abort(self):
        self.z.close()
        try:
            self.tmp.unlink()
        except OSError:
            pass


def open_writer(output, overwrite=False):
    out = str(output)
    return ZipWriter(out, overwrite) if out.lower().endswith(EXT) else DirWriter(out, overwrite)


class DirReader:
    def __init__(self, root):
        self.root = Path(root)

    def names(self):
        out = []
        for d, _, files in os.walk(self.root):
            rel = Path(d).relative_to(self.root).as_posix()
            out += [f if rel == "." else f"{rel}/{f}" for f in files]
        return sorted(out)

    def read(self, name):
        _safe(name)
        return self.root.joinpath(*name.split("/")).read_bytes()

    def close(self):
        pass


class ZipReader:
    def __init__(self, path):
        self.z = zipfile.ZipFile(path)

    def names(self):
        return [n for n in self.z.namelist() if not n.endswith("/")]

    def read(self, name):
        return self.z.read(name)

    def close(self):
        self.z.close()


def open_reader(path):
    p = Path(path)
    if p.is_dir():
        return DirReader(p)
    if p.is_file() and zipfile.is_zipfile(p):
        return ZipReader(p)
    raise FelixError(f"{path} is not a Felix dataset folder or .felix file")


def _nat(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s)]


class Dataset:
    """Read access to a dataset folder or ``.felix`` file."""

    def __init__(self, path):
        self.path = str(path)
        self._r = open_reader(path)
        try:
            self.metadata = _yaml.loads(self._r.read("metadata.yml").decode("utf-8")) or {}
        except (KeyError, OSError):
            self.metadata = {}
        self.stems = sorted((n[12:-4] for n in self._r.names()
                             if n.startswith("annotations/") and n.endswith(".yml")), key=_nat)

    def __len__(self):
        return len(self.stems)

    def __iter__(self):
        for s in self.stems:
            yield s, self.annotation(s)

    def annotation(self, stem):
        return _yaml.loads(self._r.read(f"annotations/{stem}.yml").decode("utf-8"))

    def image_bytes(self, stem):
        return self._r.read("images/" + self.annotation(stem)["image"])

    def image(self, stem):
        from PIL import Image
        return Image.open(io.BytesIO(self.image_bytes(stem)))

    def close(self):
        self._r.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()


def load(path):
    return Dataset(path)
