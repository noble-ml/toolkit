# Licences and provenance

Publicly visible images are not automatically free to reuse. Felix records what each provider says about an image,
checks it against how you release the dataset, and writes the files that go with it. This is guidance from the
licence names providers report, **not legal advice**: check the terms before publishing or using a dataset
commercially.

## What every image records

Its annotation file holds a `source` block, for example:

```yaml
source:
  type: wikimedia
  title: "File:Sawtooth Oak Leaves.jpg"
  url: https://upload.wikimedia.org/…/1024px-….jpg
  page: https://commons.wikimedia.org/wiki/File:…
  license: CC BY-SA 3.0
  license_url: https://creativecommons.org/licenses/by-sa/3.0
  author: Derek Ramsey
  attribution: "Sawtooth Oak Leaves.jpg by Derek Ramsey, CC BY-SA 3.0, via Wikimedia Commons (https://…)"
  query: plant leaves
  acquired: "2026-11-21T09:15:02Z"
```

Depending on the source: original URL and file name, dataset id, licence and its URL, author and their page,
attribution text, the provider's usage terms, acquisition time, and for video frames the video file, frame number and
time. Transforms and annotation add `history`; face blurring adds `privacy`.

## Open or closed

```python
fx.export("leaves.felix")                          # closed (default)
fx.export("leaves.felix", license="CC-BY-4.0")     # open, under this licence
fx.export("leaves.felix", license="auto")          # open, under the most permissive licence every image allows
fx.export("leaves.felix", license="CC-BY-4.0", strict=True)   # leave out images that do not fit
```

- **Closed**: the compilation and annotations are all rights reserved (LICENSE.txt says so, naming `authors` as the
  owner). Third-party images keep their licences and are still credited. Felix flags images with unknown licences,
  all-rights-reserved images, non-commercial images (in case you use the data commercially) and no-derivatives
  images that were cropped.
- **Open**: everything above, plus conflicts with the chosen licence: non-commercial images under a licence that allows
  commercial use, share-alike images under a licence without share-alike, attribution-required images under CC0, your
  own files (confirm you hold the rights and people's consent), and photos whose licence does not clearly allow
  redistribution in a dataset (Unsplash, Pexels). `"auto"` picks CC0 if every image is free of conditions, CC BY 4.0
  if some need credit, CC BY-SA 4.0 with share-alike images, and the NC variants if any image is non-commercial.

Problems never stop the export (unless `strict=True` leaves those images out). They are listed in ATTRIBUTIONS.md
(marked ⚠) and counted in `metadata.yml` under `license`.

## The files

| File | Contents |
|---|---|
| `LICENSE.txt` | the dataset's licence (or the closed notice), that images keep their own licences, and a count per image licence |
| `ATTRIBUTIONS.md` | every image: file, source, licence (with any ⚠ issue), author / credit, link |
| `CITATION.cff` | how to cite the dataset (title, authors, date, licence), plus the datasets and collections it draws on (Open Images, COCO, Wikimedia Commons, iNaturalist, …) |

They sit next to the data: inside a `.felix` file, at the top of a dataset folder, or beside the shards.

## Faces

`fx.transform.blur_faces()` (or `fx.acquire(..., blur_faces=True)`) blurs faces found by OpenCV's frontal and
profile face detectors, and records how many in each image. It is best effort: small, turned, partly hidden or unusual
faces can be missed. Do not rely on it alone for sensitive data.
