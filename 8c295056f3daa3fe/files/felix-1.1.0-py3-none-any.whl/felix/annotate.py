"""``fx.annotate(model=...)``: boxes (and masks, where the model makes them) for every image that has none yet.

``model`` is a Workflow model (``wf.load("custom.nbm")``), a built-in one (``fx.models.yolo26n``, ``fx.models.yoloe``,
``fx.models.sam``) or your own function ``fn(image) -> [{"class", "bbox": [x, y, w, h] or "xyxy": [...],
"confidence"}]``. Detections are mapped onto classes.yml (others dropped) and below-threshold ones removed. An image the
model fails on is marked ``failed`` and is never exported as an image without objects."""
from __future__ import annotations

import os
from typing import List, Optional

from . import _images
from ._session import Item, session
from .errors import FelixError
from .transform import Step, _register


class _Workflow:
    """Adapter for a Workflow model (anything with ``predict`` and ``class_names``)."""

    def __init__(self, model):
        self.m = model
        self.task = getattr(model, "task", None)

    def describe(self):
        import workflow
        return {"name": getattr(self.m, "name", None) or "workflow model", "framework": f"workflow {workflow.__version__}",
                "classes": list(self.m.class_names or []), "task": self.task}

    def detect(self, images, conf, classes):
        res = self.m.predict(list(images), output=None, confidence=conf)
        res = [res] if not isinstance(res, list) else list(res)
        out = []
        for r in res:
            if getattr(r, "kind", None) == "classification":
                out.append({"label": r.class_name, "confidence": round(float(r.confidence), 4)})
                continue
            out.append([{"class": name, "bbox": [b[0], b[1], b[2] - b[0], b[3] - b[1]], "confidence": round(float(c), 4)}
                        for b, c, name in zip(r.xyxy, r.confidences, r.classes)])
        return out


class _Function:
    def __init__(self, fn):
        self.fn = fn

    def describe(self):
        return {"name": getattr(self.fn, "__name__", "function"), "framework": "python function"}

    def detect(self, images, conf, classes):
        out = []
        for im in images:
            objs = []
            for o in self.fn(im) or []:
                if "xyxy" in o:
                    x1, y1, x2, y2 = o["xyxy"]
                    o = dict(o, bbox=[x1, y1, x2 - x1, y2 - y1])
                objs.append({k: v for k, v in o.items() if k != "xyxy"})
            out.append(objs)
        return out


def _adapter(model):
    from .models import Model
    if isinstance(model, Model):
        return model
    if hasattr(model, "predict") and hasattr(model, "class_names"):
        return _Workflow(model)
    if callable(model):
        return _Function(model)
    raise FelixError("annotate: model must be a Workflow model (wf.load(...)), a built-in model (fx.models.yolo26n, "
                     "fx.models.yoloe, fx.models.sam) or a function image -> boxes")


class AnnotateStep(Step):
    name = "annotate"

    def __init__(self, model, confidence: float, replace: bool, batch_size: int):
        self.adapter, self.confidence, self.replace, self.bs = _adapter(model), confidence, replace, batch_size
        self.segment_only = getattr(self.adapter, "kind", None) == "sam"

    def describe(self):
        return {"step": "annotate", "model": self.adapter.describe(), "confidence": self.confidence, "replace": self.replace}

    def start(self):
        self.done = self.failed = self.boxes = self.dropped = 0
        self.errors = {}

    def _fail(self, it: Item, e: Exception):
        it.status, it.error = "failed", f"{type(e).__name__}: {e}"[:300]
        it.objects = []
        self.failed += 1
        self.errors[type(e).__name__] = self.errors.get(type(e).__name__, 0) + 1
        self.example = getattr(self, "example", None) or it.error

    def process(self, batch):
        S = session()
        info = self.adapter.describe()
        if self.segment_only:                              # SAM: masks for the boxes images already have
            for it in batch:
                if not it.objects:
                    continue
                try:
                    it.objects = self.adapter.segment(_images.open_rgb(it.path), it.objects)
                    it.history.append("segmented by sam")
                    self.done += 1
                except Exception as e:
                    self._fail(it, e)
            return batch
        todo = [it for it in batch if self.replace or it.status in ("none", "failed")]
        for k in range(0, len(todo), self.bs):
            chunk = todo[k:k + self.bs]
            try:
                images = [_images.open_rgb(it.path) for it in chunk]
                results = self.adapter.detect(images, self.confidence, S.classes)
                if len(results) != len(chunk):
                    raise FelixError(f"the model returned {len(results)} results for {len(chunk)} images")
            except Exception:
                results = []
                for it in chunk:                           # find which image fails; the others still get labels
                    try:
                        results.append(self.adapter.detect([_images.open_rgb(it.path)], self.confidence, S.classes)[0])
                    except Exception as e:
                        self._fail(it, e)
                        results.append(None)
            for it, res in zip(chunk, results):
                if res is None:
                    continue
                if isinstance(res, dict) and "label" in res:   # a classification model: one label per image
                    name = S.resolve(res["label"])
                    it.label = {"class": name, "confidence": res["confidence"], "origin": "model"} if name and \
                        res["confidence"] >= S.confidence_for(name, self.confidence) else None
                    it.status, it.model, it.error = "model", info, None
                    self.done += 1
                    continue
                objs = []
                for o in res:
                    name = S.resolve(o["class"])
                    if name is None or o.get("confidence", 1.0) < S.confidence_for(name, self.confidence):
                        self.dropped += 1
                        continue
                    b = _images.clip_box(o["bbox"], it.width, it.height)
                    if b is None:
                        continue
                    n = dict(o, **{"class": name, "bbox": [_images.num(v) for v in b], "origin": "model"})
                    objs.append(n)
                it.objects = objs if self.replace or it.status != "dataset" else it.objects + objs
                it.status, it.model, it.error = "model", info, None
                it.history.append(f"annotated by {info.get('name')}")
                self.done += 1
                self.boxes += len(objs)
        return batch

    def finish(self):
        s = (f"annotate ({self.adapter.describe().get('name')}): masks for the boxes of {self.done} image(s)" if self.segment_only
             else f"annotate: {self.done} image(s), {self.boxes} box(es)")
        if self.failed:
            s += (f"; {self.failed} failed ({', '.join(f'{k} ×{v}' for k, v in self.errors.items())}; e.g. "
                  f"{(getattr(self, 'example', '') or '')[:160]}), left out of the export (not counted as images without objects)")
        return s


def annotate(model, confidence: Optional[float] = None, replace: bool = False, batch_size: int = 8) -> None:
    """Annotate every image that has no labels yet with ``model`` (see the module docs). ``confidence``: minimum
    score (classes.yml can set it per class); by default 0.25, or 0.1 for open-vocabulary models (fx.models.yoloe),
    whose scores run lower. ``replace=True`` also re-annotates images that came with labels."""
    S = session()
    if S.terminal == "consequential":
        raise FelixError("fx.annotate must come before fx.transform.consequential: consequential crops around the "
                         "annotated objects")
    if confidence is None:
        confidence = getattr(model, "default_confidence", 0.25)
        if getattr(model, "kind", None) == "yoloe" and S.classes is None:
            confidence = 0.25                            # prompt-free (no class file): its huge vocabulary is noisy lower down
    if not 0 <= confidence <= 1:
        raise FelixError("annotate: confidence must be between 0 and 1")
    step = AnnotateStep(model, confidence, replace, batch_size)
    _register(step)
