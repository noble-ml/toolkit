"""``fx.load_class("classes.yml")``: which classes the dataset is about, and how models should look for them.

    classes:
      - leaf                                  # just a name
      - name: fruit
        prompt: a ripe tomato on the vine     # what a promptable model (YOLOE) is asked to find; default: the name
        aliases: [tomato, Tomato]             # names that mean this class in imported datasets / model labels
        confidence: 0.4                       # optional, per class
    confidence: 0.25                          # optional default minimum confidence for model annotations

Imported annotations and model detections are mapped onto these names (case-insensitive, through ``aliases``);
anything else is left out. Without a class file every class is kept, and models detect everything they know.
"""
from __future__ import annotations

import os

from . import _yaml
from ._session import session
from .errors import FelixError


def _parse(data, where):
    if isinstance(data, dict):
        default = data.get("confidence")
        entries = data.get("classes")
        if entries is None:
            raise FelixError(f"{where}: no 'classes:' list (write classes: [leaf, fruit] or one '- name: …' per class)")
    elif isinstance(data, list):
        default, entries = None, data
    else:
        raise FelixError(f"{where}: expected a 'classes:' list")
    if not isinstance(entries, list) or not entries:
        raise FelixError(f"{where}: 'classes' must be a non-empty list")
    out, seen = [], set()
    for i, e in enumerate(entries):
        if isinstance(e, (str, int, float)) and not isinstance(e, bool):
            e = {"name": str(e)}
        if not isinstance(e, dict) or not str(e.get("name", "")).strip():
            raise FelixError(f"{where}: class {i + 1} needs a name")
        unknown = set(e) - {"name", "prompt", "aliases", "confidence"}
        if unknown:
            raise FelixError(f"{where}: class {e['name']!r} has unknown key(s) {', '.join(sorted(unknown))} "
                             "(allowed: name, prompt, aliases, confidence)")
        name = str(e["name"]).strip()
        aliases = e.get("aliases") or []
        if isinstance(aliases, str):
            aliases = [aliases]
        conf = e.get("confidence")
        if conf is not None and not (isinstance(conf, (int, float)) and 0 <= conf <= 1):
            raise FelixError(f"{where}: class {name!r}: confidence must be between 0 and 1")
        keys = {k.lower() for k in [name] + [str(a) for a in aliases]}       # an alias may repeat its own name
        clash = keys & seen
        if clash:
            raise FelixError(f"{where}: {sorted(clash)[0]!r} names two classes (names and aliases must be unique across classes)")
        seen |= keys
        out.append({"name": name, "prompt": str(e.get("prompt") or name), "aliases": [str(a) for a in aliases],
                    "confidence": conf})
    if default is not None and not (isinstance(default, (int, float)) and 0 <= default <= 1):
        raise FelixError(f"{where}: confidence must be between 0 and 1")
    return out, default


def load_class(path) -> list:
    """Load the target classes from a YAML file (see the module docs for the format). Returns the class names."""
    path = os.fspath(path)
    if not os.path.isfile(path):
        raise FelixError(f"class file not found: {path}")
    with open(path, encoding="utf-8") as f:
        try:
            data = _yaml.loads(f.read())
        except Exception as e:
            raise FelixError(f"{path}: not valid YAML ({e})") from None
    classes, default = _parse(data, path)
    S = session()
    S.classes, S.class_file, S.default_confidence = classes, os.path.abspath(path), default
    # images already acquired: map their labels onto the new classes
    dropped = 0
    for it in S.items:
        kept = []
        for o in it.objects:
            name = S.resolve(o["class"])
            if name is None:
                dropped += 1
            else:
                kept.append(dict(o, **{"class": name}))
        it.objects = kept
        if it.label and S.resolve(it.label["class"]) is None:
            it.label = None
    S.log("load_class", file=os.path.basename(path), classes=[c["name"] for c in classes])
    if dropped:
        from ._ui import note
        note(f"{dropped} existing box(es) are of classes not in {os.path.basename(path)} and were left out")
    return [c["name"] for c in classes]
