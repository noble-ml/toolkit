"""HTTP for online sources: a descriptive User-Agent, polite per-host pacing, retries that honour Retry-After, size
limits, and credentials from arguments, environment variables or ~/.config/felix/credentials.yml."""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, Optional

from ._version import __version__
from .errors import FelixError

MAX_BYTES = 60 * 2**20                          # one image may not be larger than this
CONFIG = os.path.join(os.path.expanduser("~"), ".config", "felix", "credentials.yml")


def user_agent() -> str:
    """Wikimedia and others require a User-Agent naming the tool and a way to reach its operator. Set FELIX_CONTACT
    (an email or URL) or ``contact:`` in ~/.config/felix/credentials.yml to include yours."""
    contact = os.environ.get("FELIX_CONTACT") or _config().get("contact")
    who = f"; {contact}" if contact else ""
    return f"felix/{__version__} (computer-vision dataset toolkit{who})"


_cfg = None


def _config() -> Dict:
    global _cfg
    if _cfg is None:
        _cfg = {}
        if os.path.isfile(CONFIG):
            from . import _yaml
            try:
                with open(CONFIG, encoding="utf-8") as f:
                    _cfg = _yaml.loads(f.read()) or {}
            except Exception:
                _cfg = {}
    return _cfg


def credential(name: str, given: Optional[str], env: str, how: str) -> str:
    """An API key from the argument, the environment variable ``env``, or the credentials file (key ``name``)."""
    key = given or os.environ.get(env) or _config().get(name)
    if not key:
        raise FelixError(f"{how} needs an API key: pass api_key=..., set the {env} environment variable, or add "
                         f"'{name}: <key>' to {CONFIG}")
    return str(key)


class _Pacer:
    """At most one request per ``interval`` seconds to each host (requests to one host go one after another)."""

    def __init__(self):
        self.last: Dict[str, float] = {}
        self.lock = threading.Lock()

    def wait(self, host: str, interval: float):
        with self.lock:
            now = time.monotonic()
            t = max(now, self.last.get(host, 0.0) + interval)
            self.last[host] = t
        if t > now:
            time.sleep(t - now)


_pacer = _Pacer()


def safe_url(url: str) -> str:
    """Percent-encode what servers put unencoded in URLs (spaces, non-ASCII) without touching what is already encoded."""
    return urllib.parse.quote(url, safe=":/?&=%#~+,;@!$'()*[]")


def request(url: str, *, headers=None, interval: float = 0.5, retries: int = 4, timeout: float = 60,
            max_bytes: int = MAX_BYTES, expect_image: bool = False) -> bytes:
    """GET ``url`` politely. Retries on 429 / 5xx and network errors with backoff (Retry-After first)."""
    url = safe_url(url)
    host = urllib.parse.urlsplit(url).netloc
    h = {"User-Agent": user_agent(), "Accept": "*/*", "Accept-Encoding": "identity"}
    h.update(headers or {})
    delay = 2.0
    for attempt in range(retries + 1):
        _pacer.wait(host, interval)
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=timeout) as r:
                ctype = r.headers.get("Content-Type", "")
                if expect_image and ctype and not ctype.startswith("image/") and "octet-stream" not in ctype:
                    raise FelixError(f"not an image (the server sent {ctype.split(';')[0]})")
                size = r.headers.get("Content-Length")
                if size and int(size) > max_bytes:
                    raise FelixError(f"too large ({int(size) / 2**20:.0f} MB, limit {max_bytes / 2**20:.0f} MB)")
                data = r.read(max_bytes + 1)
                if len(data) > max_bytes:
                    raise FelixError(f"too large (over {max_bytes / 2**20:.0f} MB)")
                return data
        except urllib.error.HTTPError as e:
            if e.code in (429, 500, 502, 503, 504) and attempt < retries:
                wait = e.headers.get("Retry-After") if e.headers else None
                try:
                    pause = float(wait) if wait else delay
                except ValueError:
                    pause = delay
                time.sleep(min(pause, 120))
                delay *= 2
                continue
            raise FelixError(f"HTTP {e.code} {e.reason}") from None
        except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
            if attempt < retries:
                time.sleep(delay)
                delay *= 2
                continue
            raise FelixError(f"network error ({getattr(e, 'reason', e)})") from None
    raise FelixError("gave up after retries")


def get_json(url: str, **kw):
    data = request(url, max_bytes=200 * 2**20, **kw)
    try:
        return json.loads(data.decode("utf-8"))
    except ValueError:
        raise FelixError(f"the server did not return JSON ({data[:120]!r})") from None


def download(url: str, path: str, *, interval: float = 0.5, max_bytes: int = 20 * 2**30, chunk: int = 2**20,
             headers=None) -> str:
    """Stream a large file (archives, metadata CSVs) to ``path`` via a .part file."""
    url = safe_url(url)
    host = urllib.parse.urlsplit(url).netloc
    _pacer.wait(host, interval)
    h = {"User-Agent": user_agent(), "Accept": "*/*"}
    h.update(headers or {})
    tmp = path + ".part"
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=120) as r, open(tmp, "wb") as f:
            done = 0
            while True:
                b = r.read(chunk)
                if not b:
                    break
                done += len(b)
                if done > max_bytes:
                    raise FelixError(f"download larger than {max_bytes / 2**30:.0f} GB")
                f.write(b)
        os.replace(tmp, path)
        return path
    except urllib.error.HTTPError as e:
        raise FelixError(f"HTTP {e.code} {e.reason} while downloading") from None
    except (urllib.error.URLError, OSError) as e:
        raise FelixError(f"download failed ({getattr(e, 'reason', e)})") from None
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def cache_dir(*parts) -> str:
    d = os.path.join(os.environ.get("FELIX_CACHE") or os.path.join(os.path.expanduser("~"), ".cache", "felix"), *parts)
    os.makedirs(d, exist_ok=True)
    return d
