"""What every source shares: turning files or downloaded bytes into images of the working dataset."""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import List, Optional

from .. import _images
from .._session import Item, session
from ..errors import FelixError


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class Stopped(Exception):
    """Raised inside a source when the export has what it needs (or was stopped): the source just ends."""


class Collector:
    """Receives the images one source produces (``sink``: hands each to the export as soon as it exists), with counts
    for the report. ``stop``: a threading.Event; once set, the next ``add`` ends the source."""

    def __init__(self, source_name: str, sink=None, stop=None):
        self.name = source_name
        self.sink, self.stop = sink, stop
        self.count = 0
        self.require_objects = False              # skip dataset images with none of the wanted classes
        self.items: List[Item] = []
        self.skipped: List[str] = []              # "what: why"
        self.dropped_boxes = 0
        self.unmapped = {}                        # dataset class name -> boxes left out (not in classes.yml)

    def skip(self, what: str, why: str):
        self.skipped.append(f"{what}: {why}")

    def add(self, *, path: Optional[str] = None, data: Optional[bytes] = None, ext: Optional[str] = None,
            name: str, source: dict, objects=None, label=None, split=None, keep_orientation: bool = False) -> Optional[Item]:
        """Add one image. ``path``: a file that already exists (referenced, not copied); ``data``: bytes to store in
        the working folder. ``objects`` (dataset boxes, [x, y, w, h] pixels) or ``label`` (image class) make the image
        count as labelled by its dataset."""
        if self.stop is not None and self.stop.is_set():
            raise Stopped()
        S = session()
        try:
            if data is not None:
                w, h, orient = _images.probe(data)
                ext = (ext or ".jpg").lower()
                path = S.new_path(ext if ext in _images.IMAGE_EXT else ".jpg")
                with open(path, "wb") as f:
                    f.write(data)
                owned = True
            else:
                w, h, orient = _images.probe(path)
                ext = os.path.splitext(path)[1].lower()
                owned = False
        except FelixError as e:
            self.skip(name, str(e).replace("not a readable image", "unreadable"))
            return None
        if w < 2 or h < 2:
            self.skip(name, f"too small ({w}x{h})")
            return None
        src = dict(source)
        src.setdefault("acquired", now())
        if orient not in (1, 0) and not keep_orientation and objects is None:
            # stored sideways (camera EXIF): keep the picture as people see it
            im = _images.upright(path)
            new = S.new_path(_images.out_ext(ext))
            _images.save(im, new)
            path, ext, owned = new, _images.out_ext(ext), True
            w, h = im.size
            src["exif_rotation_applied"] = True
        it = Item(S.unique_id(os.path.splitext(os.path.basename(name))[0]), path, w, h, src, ext=ext, owned=owned)
        if objects is not None:
            kept = []
            for o in objects:
                cls = S.resolve(o["class"])
                if cls is None:
                    self.unmapped[o["class"]] = self.unmapped.get(o["class"], 0) + 1
                    continue
                b = _images.clip_box(o["bbox"], w, h)
                if b is None:
                    self.dropped_boxes += 1
                    continue
                kept.append(dict(o, **{"class": cls, "bbox": [_images.num(v) for v in b], "origin": "dataset"}))
            if not kept and objects and self.require_objects:
                self.skip(name, "none of its boxes are of the wanted classes")
                return None
            it.objects, it.status = kept, "dataset"
        if label is not None:
            cls = S.resolve(label)
            if cls is not None:
                it.label, it.status = {"class": cls, "origin": "dataset"}, "dataset"
            else:
                self.unmapped[label] = self.unmapped.get(label, 0) + 1
        if split:
            it.split = split
        self.count += 1
        if self.sink is not None:
            self.sink(it)                                # blocks while the export is busy (bounded queue)
        else:
            self.items.append(it)
        return it


class Source:
    """A place images come from. Subclasses implement ``collect(collector, progress)``."""

    kind = "source"

    def describe(self) -> dict:
        return {"type": self.kind}

    def label(self) -> str:
        return self.kind

    def collect(self, c: Collector, progress) -> None:
        raise NotImplementedError


def fetch(c: Collector, url: str, name: str, source: dict, interval: float = 0.5, headers=None, **add):
    """Download one image and add it; a failed download is reported, not fatal. Returns the Item or None."""
    import os
    from .. import _http
    try:
        data = _http.request(url, interval=interval, expect_image=True, headers=headers)
    except FelixError as e:
        c.skip(name, str(e))
        return None
    ext = os.path.splitext(url.split("?")[0])[1].lower()
    return c.add(data=data, ext=ext if ext in _images.IMAGE_EXT else ".jpg", name=name,
                 source={k: v for k, v in source.items() if v not in (None, "")}, **add)


def need_int(value, what, allow_none=True):
    if value is None and allow_none:
        return None
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise FelixError(f"{what} must be a positive whole number" + (" (or None)" if allow_none else ""))
    return value
