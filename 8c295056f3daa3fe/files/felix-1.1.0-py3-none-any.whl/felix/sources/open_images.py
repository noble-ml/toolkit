"""``fx.sources.open_images(classes=[...])``: images and boxes from Google's Open Images V7 for the given classes.

Annotations come from the official CSVs (cached in ~/.cache/felix/open_images; the validation split needs about 40 MB,
test about 120 MB, train several GB); images from the public open-images-dataset bucket. Every image keeps its own
licence, author and original page from Open Images' metadata."""
from __future__ import annotations

import csv
import difflib
import os
import random
from typing import Optional, Sequence

from .. import _http
from ..errors import FelixError
from ._base import Collector, Source

BASE = "https://storage.googleapis.com/openimages"
CLASSES = f"{BASE}/v7/oidv7-class-descriptions-boxable.csv"
BOXES = {"train": f"{BASE}/v6/oidv6-train-annotations-bbox.csv", "validation": f"{BASE}/v5/validation-annotations-bbox.csv",
         "test": f"{BASE}/v5/test-annotations-bbox.csv"}
IMAGES = {"train": f"{BASE}/2018_04/train/train-images-boxable-with-rotation.csv",
          "validation": f"{BASE}/2018_04/validation/validation-images-with-rotation.csv",
          "test": f"{BASE}/2018_04/test/test-images-with-rotation.csv"}
BUCKET = "https://open-images-dataset.s3.amazonaws.com"
SPLIT = {"train": "train", "validation": "val", "test": "test"}


def _cached(url: str) -> str:
    path = os.path.join(_http.cache_dir("open_images"), url.rsplit("/", 1)[1])
    if not os.path.isfile(path):
        _http.download(url, path)
    return path


class open_images(Source):
    """Images of Open Images V7 that contain any of ``classes`` (display names such as "Car", "Person"; see the
    boxable class list), with every box of those classes. ``split``: "validation" (default, ~42k boxed images),
    "test" or "train" (1.7M images; its box file is several GB). ``limit``: at most this many images, chosen at random
    with ``seed``. Group boxes ("a crowd of people") are kept and marked ``group_of``; ``group_of=False`` drops them."""

    kind = "open_images"

    def __init__(self, classes: Sequence[str], split: str = "validation", limit: Optional[int] = None, seed: int = 0,
                 group_of: bool = True):
        if isinstance(classes, str):
            classes = [classes]
        if not classes:
            raise FelixError("sources.open_images: give at least one class, e.g. classes=['Car']")
        if split not in BOXES:
            raise FelixError("sources.open_images: split must be 'validation', 'test' or 'train'")
        self.classes, self.split, self.limit, self.seed, self.group_of = list(classes), split, limit, seed, group_of

    def label(self):
        return f"open images {', '.join(self.classes)} ({self.split})"

    def describe(self):
        return {"type": "open_images", "classes": self.classes, "split": self.split, "limit": self.limit}

    def collect(self, c: Collector, progress):
        with open(_cached(CLASSES), newline="", encoding="utf-8") as f:
            table = {row[0]: row[1] for row in csv.reader(f) if len(row) >= 2 and row[0] != "LabelName"}
        by_name = {v.lower(): k for k, v in table.items()}
        mids = {}
        for name in self.classes:
            mid = by_name.get(name.lower())
            if mid is None:
                close = difflib.get_close_matches(name, list(table.values()), n=3)
                raise FelixError(f"sources.open_images: {name!r} is not an Open Images box class"
                                 + (f" (did you mean {', '.join(close)}?)" if close else ""))
            mids[mid] = table[mid]
        if self.split == "train":
            from .._ui import note
            note("Open Images train: the box file is several GB; downloading it once into the cache")
        boxes = {}
        with open(_cached(BOXES[self.split]), newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row["LabelName"] in mids and (self.group_of or row.get("IsGroupOf") != "1"):
                    boxes.setdefault(row["ImageID"], []).append(row)
        ids = sorted(boxes)
        if self.limit is not None and len(ids) > self.limit:
            ids = sorted(random.Random(self.seed).sample(ids, self.limit))
        meta = {}
        wanted = set(ids)
        with open(_cached(IMAGES[self.split]), newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row["ImageID"] in wanted:
                    meta[row["ImageID"]] = row
        for i, iid in enumerate(ids):
            m = meta.get(iid, {})
            rot = (m.get("Rotation") or "").strip()
            if rot not in ("", "0", "0.0", "nan"):
                c.skip(iid, f"stored rotated by {rot}° in Open Images (its boxes may not line up); skipped")
                continue
            try:
                data = _http.request(f"{BUCKET}/{self.split}/{iid}.jpg", interval=0.05, expect_image=True)
            except FelixError as e:
                c.skip(iid, str(e))
                continue
            from .._images import probe
            w, h, _ = probe(data)
            objs = []
            for r in boxes[iid]:
                x1, x2, y1, y2 = (float(r[k]) for k in ("XMin", "XMax", "YMin", "YMax"))
                o = {"class": mids[r["LabelName"]], "bbox": [x1 * w, y1 * h, (x2 - x1) * w, (y2 - y1) * h]}
                attrs = {k: r.get(f"Is{k}") == "1" for k in ("Occluded", "Truncated", "GroupOf", "Depiction")}
                attrs = {("group_of" if k == "GroupOf" else k.lower()): True for k, v in attrs.items() if v}
                if attrs:
                    o["attributes"] = attrs
                objs.append(o)
            src = {"type": "open_images", "dataset": f"Open Images V7 ({self.split})", "image_id": iid,
                   "url": f"{BUCKET}/{self.split}/{iid}.jpg", "original_url": m.get("OriginalURL"),
                   "page": m.get("OriginalLandingURL"), "license": m.get("License") or "CC BY 2.0 (as listed by Open Images)",
                   "author": m.get("Author"), "author_page": m.get("AuthorProfileURL"), "title": m.get("Title"),
                   "annotation_license": "CC BY 4.0 (Google LLC)"}
            c.add(data=data, ext=".jpg", name=f"{iid}.jpg", source={k: v for k, v in src.items() if v},
                  objects=objs, split=SPLIT[self.split], keep_orientation=True)
            progress(i + 1, len(ids))
