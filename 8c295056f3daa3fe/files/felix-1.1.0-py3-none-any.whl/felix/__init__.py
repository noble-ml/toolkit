"""Felix: a toolkit for building computer-vision datasets from real images.

    import felix as fx

    fx.load_class("classes.yml")               # what the dataset is about
    fx.acquire([fx.sources.local("raw/"),       # where the images come from
                fx.sources.wikimedia(query="plant leaves", limit=500)])
    fx.transform.center_crop(size=640)          # what happens to them
    fx.annotate(model=fx.models.yolo26n)        # boxes from a model
    fx.export("leaves.felix", pairs=1000)       # build the dataset (with licences and citation)

Namespaces: fx.sources, fx.sampling, fx.transform, fx.models. Reading datasets: fx.load(path).
File utilities: fx.split, fx.partition, fx.shard. Start over: fx.reset().
"""
from ._version import __version__
from .errors import FelixError
from . import sampling, sources, transform, models
from .classes import load_class
from .acquire import acquire
from .annotate import annotate
from .export import export
from ._session import reset
from .store import Dataset, load
from .partition import partition
from .split import split
from .shard import shard

__all__ = ["__version__", "FelixError", "load_class", "acquire", "transform", "annotate", "export", "sources",
           "sampling", "models", "reset", "load", "Dataset", "split", "partition", "shard"]


def __getattr__(name):
    """A typo such as fx.aquire gets a "did you mean" instead of a bare AttributeError."""
    import difflib
    public = [n for n in globals() if not n.startswith("_")]
    match = [n for n in public if n.lower() == name.lower()] or difflib.get_close_matches(name, public, n=1, cutoff=0.6)
    hint = f" Did you mean {__name__}.{match[0]}?" if match else ""
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'.{hint}")
