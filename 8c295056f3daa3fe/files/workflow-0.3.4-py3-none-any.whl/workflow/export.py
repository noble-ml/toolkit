"""``model.export``: ONNX (fp32 / fp16 / int8 as QDQ) and precision-converted ``.nbm`` files."""
from __future__ import annotations

import ctypes as C
import os
import struct
from typing import List, Optional

from . import nbm, onnx, quant
from ._version import __version__
from .core import Tensor, device as _device, no_grad
from .core.cpu import lib
from .core.device import Device
from .core.tensor import Buf
from .errors import BackendError, SerializationError, WorkflowError


class _Trace:
    """A backend that records ONNX nodes instead of computing. Tensor handles are ONNX value names."""
    name = "trace"

    def __init__(self, half: bool):
        self.nodes: List[bytes] = []
        self.inits: List[bytes] = []
        self.n, self.half = 0, half
        self.dev = Device("trace")
        self.dev.be = self
        self.cpu = _device.get("cpu")

    def release(self, h, n):
        pass

    def new(self, shape, prefix="t") -> Tensor:
        self.n += 1
        return Tensor(shape, self.dev, Buf(self, f"{prefix}{self.n}", 0))

    def emit(self, op, inputs, shape, **attrs) -> Tensor:
        out = self.new(shape)
        self.nodes.append(onnx.node(op, [i.h if isinstance(i, Tensor) else i for i in inputs], [out.h], **attrs))
        return out

    def const(self, t: Tensor, shape=None) -> str:
        """A real tensor becomes a float initializer (float16 when exporting fp16)."""
        self.n += 1
        name = f"w{self.n}"
        raw = t.dev.be.host(t).tobytes()
        dims = list(shape or t.shape)
        if self.half:
            raw = struct.pack(f"<{t.size}e", *struct.unpack(f"<{t.size}f", raw))
        self.inits.append(onnx.tensor(name, dims, onnx.FLOAT16 if self.half else onnx.FLOAT, raw))
        return name

    def raw(self, dims, dtype, data, prefix="c") -> str:
        self.n += 1
        name = f"{prefix}{self.n}"
        self.inits.append(onnx.tensor(name, dims, dtype, data))
        return name

    def val(self, t):
        return t.h if t.dev is self.dev else self.const(t)

    # ---- operations the layers use in inference mode
    def conv_fwd(self, x, w, b, cfg, oshape):
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        ins = [x.h, self.val(w)] + ([self.const(b)] if b is not None else [])
        return self.emit("Conv", ins, oshape, kernel_shape=[w.shape[2], w.shape[3]], strides=[sh, sw], pads=[pt, pl, pb, pr],
                         dilations=[dh, dw], group=G)

    def conv_bwd_data(self, x, w, cfg, oshape):                   # forward of TransposeConv2D
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        return self.emit("ConvTranspose", [x.h, self.val(w)], oshape, kernel_shape=[w.shape[2], w.shape[3]], strides=[sh, sw],
                         pads=[pt, pl, pb, pr], dilations=[dh, dw])

    def add_ch(self, y, b):
        out = self.emit("Add", [y.h, self.const(b, (1, b.shape[0], 1, 1))], y.shape)
        y.buf = out.buf

    def bn_fwd(self, x, g, b, rm, rv, mom, eps, train):
        y = self.emit("BatchNormalization", [x.h, self.const(g), self.const(b), self.const(rm), self.const(rv)], x.shape, epsilon=float(eps))
        return y, None, None

    def act_fwd(self, kind, x, slope=0.0):
        if kind == 0:
            return self.emit("Relu", [x], x.shape)
        if kind == 1:
            return self.emit("LeakyRelu", [x], x.shape, alpha=float(slope))
        s = self.emit("Sigmoid", [x], x.shape)
        return s if kind == 3 else self.emit("Mul", [x, s], x.shape)

    @staticmethod
    def _pool_pads(x, win, oshape):
        kh, kw, sh, sw, pt, pl = win
        pb = max(0, (oshape[2] - 1) * sh + kh - x.shape[2] - pt)
        pr = max(0, (oshape[3] - 1) * sw + kw - x.shape[3] - pl)
        return [kh, kw], [sh, sw], [pt, pl, pb, pr]

    def maxpool_fwd(self, x, win, oshape):
        k, s, p = self._pool_pads(x, win, oshape)
        return self.emit("MaxPool", [x], oshape, kernel_shape=k, strides=s, pads=p), None

    def avgpool_fwd(self, x, win, oshape):
        k, s, p = self._pool_pads(x, win, oshape)
        return self.emit("AveragePool", [x], oshape, kernel_shape=k, strides=s, pads=p, count_include_pad=1)

    def neg(self, x):
        return self.emit("Neg", [x], x.shape)

    def upsample_fwd(self, x, OH, OW):
        scales = self.raw([4], onnx.FLOAT, struct.pack("<4f", 1.0, 1.0, OH / x.shape[2], OW / x.shape[3]))
        return self.emit("Resize", [x.h, "", scales], (x.shape[0], x.shape[1], OH, OW), mode="nearest",
                         coordinate_transformation_mode="asymmetric", nearest_mode="floor")

    def add(self, a, b):
        return self.emit("Add", [self.val(a), self.val(b)], a.shape)

    def mul_bc(self, x, s):
        return self.emit("Mul", [self.val(x), self.val(s)], x.shape)

    def concat(self, xs):
        return self.emit("Concat", [self.val(x) for x in xs], (xs[0].shape[0], sum(x.shape[1] for x in xs), xs[0].shape[2], xs[0].shape[3]), axis=1)

    def _slice(self, x, starts, ends, axes, steps, shape):
        i64 = lambda v: self.raw([len(v)], onnx.INT64, struct.pack(f"<{len(v)}q", *v))
        return self.emit("Slice", [x.h, i64(starts), i64(ends), i64(axes), i64(steps)], shape)

    def slice_ch(self, x, off, c):
        return self._slice(x, [off], [off + c], [1], [1], (x.shape[0], c, x.shape[2], x.shape[3]))

    def chan_mean(self, x):
        return self.emit("ReduceMean", [x], (x.shape[0], 1, x.shape[2], x.shape[3]), axes=[1], keepdims=1)

    def chan_max(self, x):
        return self.emit("ReduceMax", [x], (x.shape[0], 1, x.shape[2], x.shape[3]), axes=[1], keepdims=1), None

    def s2d(self, x):
        N, Cc, H, W = x.shape
        big = 1 << 40
        parts = [self._slice(x, [r, c], [big, big], [2, 3], [2, 2], (N, Cc, H // 2, W // 2)) for r, c in ((0, 0), (1, 0), (0, 1), (1, 1))]
        return self.concat(parts)

    def fake_quant(self, x, scale, zp, qmin, qmax):
        if self.half:
            raise BackendError("int8 and fp16 cannot be combined.", "a quantised model stores int8 values.", "export with precision='int8'.")
        s = self.raw([], onnx.FLOAT, struct.pack("<f", scale), "s")
        z = self.raw([], onnx.INT8, struct.pack("<b", int(zp)), "z")
        q = self.emit("QuantizeLinear", [x.h, s, z], x.shape)
        return self.emit("DequantizeLinear", [q.h, s, z], x.shape)

    def quant_weight(self, w):
        """Real int8 weights followed by DequantizeLinear."""
        h = w.dev.be.host(w)
        lo, hi = self.cpu.be.minmax(h)
        scale = max(abs(lo), abs(hi), 1e-12) / 127.0
        q = (C.c_int8 * h.size)()
        lib().wf_quantize_i8(h.h, q, h.size, scale)
        name = self.raw(list(w.shape), onnx.INT8, bytes(q), "q")
        s = self.raw([], onnx.FLOAT, struct.pack("<f", scale), "s")
        z = self.raw([], onnx.INT8, b"\x00", "z")
        return self.emit("DequantizeLinear", [name, s, z], w.shape)


def to_onnx(model, path: str, precision: str, size) -> str:
    from .layer import Ctx
    half = precision == "fp16"
    tr = _Trace(half)
    c = model.input[0]
    x = Tensor((1, c, size[0], size[1]), tr.dev, Buf(tr, "images", 0))
    first = x
    if half:
        first = tr.emit("Cast", [x], x.shape, to=onnx.FLOAT16)
    with no_grad():
        try:
            out = model.run(first, Ctx(train=False, quant=model.quant if precision == "int8" else None))
        except AttributeError as e:
            raise BackendError("this model uses an operation that cannot be exported to ONNX.", f"the exporter has no mapping for it ({e}).",
                               "export to format='nbm' instead, or remove the unsupported layer.") from None
    outs = list(out) if isinstance(out, (tuple, list)) else [out]
    names = []
    for i, o in enumerate(outs):
        name = f"output{i}" if len(outs) > 1 else "output"
        tr.nodes.append(onnx.node("Cast", [o.h], [name], to=onnx.FLOAT) if half else onnx.node("Identity", [o.h], [name]))
        names.append((name, o.shape))
    data = onnx.model(tr.nodes, tr.inits, [onnx.value_info("images", onnx.FLOAT, ["batch", c, size[0], size[1]])],
                      [onnx.value_info(n, onnx.FLOAT, ["batch", *s[1:]]) for n, s in names], __version__)
    with open(path, "wb") as f:
        f.write(data)
    return path


def export(model, format: str, output: Optional[str], precision: str, calibration, img_size) -> str:
    fmt = str(format).lower().lstrip(".")
    precision = quant.check_precision(precision)
    if fmt not in ("onnx", "nbm"):
        raise SerializationError(f"cannot export to format {format!r}.", "Workflow exports 'onnx' and 'nbm'.",
                                 "use format='onnx' or format='nbm' (TorchScript .pt is no longer available: Workflow no longer uses PyTorch).")
    model._ensure()
    output = os.fspath(output) if output else f"model.{fmt}"
    if not output.lower().endswith("." + fmt):
        raise SerializationError(f"the output name {output!r} does not match format={fmt!r}.", f"a {fmt} export should end in .{fmt}.",
                                 f"use output='{os.path.splitext(output)[0]}.{fmt}'.")
    os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
    scheme, old = model.quant, model.quant
    if precision == "int8" and (scheme is None or not scheme.ranges):
        scheme = quant.calibrate(model, calibration)          # PTQ (weights only when no calibration data is given)
    model.quant = scheme if precision == "int8" else None
    try:
        if fmt == "onnx":
            size = (img_size, img_size) if isinstance(img_size, int) else tuple(img_size) if img_size else (model.input[1], model.input[2])
            model.check((model.input[0], *size))
            return to_onnx(model, output, precision, size)
        return nbm.save(model, output, precision=precision, classes=model.class_names, detection=model.detection_config(),
                        quantization=scheme.meta(model) if precision == "int8" else {"precision": precision})
    finally:
        model.quant = old
