/* wfcore: Workflow's native CPU kernels. Plain C99 + pthreads, no external math libraries.
 * All tensors are contiguous float32 in NCHW order. Every exported function is prefixed wf_. */
#include <math.h>
#include <pthread.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define API __attribute__((visibility("default")))
typedef float f32;

/* ------------------------------------------------------------------ thread pool */
typedef void (*wf_fn)(void *ctx, long lo, long hi, int tid);
#define MAXT 64
static int g_nt = 0;
static pthread_t g_th[MAXT];
static pthread_mutex_t g_mu = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t g_cv = PTHREAD_COND_INITIALIZER, g_done = PTHREAD_COND_INITIALIZER;
static struct { wf_fn fn; void *ctx; long n; int nt; long gen; int pending; } g_job;
static __thread int t_inpar = 0;

static void *worker(void *arg) {
    int tid = (int)(intptr_t)arg;
    long seen = 0;
    t_inpar = 1;
    for (;;) {
        pthread_mutex_lock(&g_mu);
        while (g_job.gen == seen) pthread_cond_wait(&g_cv, &g_mu);
        seen = g_job.gen;
        wf_fn fn = g_job.fn; void *ctx = g_job.ctx; long n = g_job.n; int nt = g_job.nt;
        pthread_mutex_unlock(&g_mu);
        if (tid < nt) { long lo = n * tid / nt, hi = n * (tid + 1) / nt; if (hi > lo) fn(ctx, lo, hi, tid); }
        pthread_mutex_lock(&g_mu);
        if (--g_job.pending == 0) pthread_cond_signal(&g_done);
        pthread_mutex_unlock(&g_mu);
    }
    return 0;
}

API void wf_set_threads(int n) {
    if (g_nt) return;                       /* fixed once started */
    if (n <= 0) { n = (int)sysconf(_SC_NPROCESSORS_ONLN); if (n > 16) n = 16; }
    if (n < 1) n = 1;
    if (n > MAXT) n = MAXT;
    g_nt = n;
    for (int i = 1; i < n; i++) pthread_create(&g_th[i], 0, worker, (void *)(intptr_t)i);
}
API int wf_threads(void) { if (!g_nt) wf_set_threads(0); return g_nt; }

static void pfor(long n, wf_fn fn, void *ctx) {
    if (!g_nt) wf_set_threads(0);
    if (g_nt <= 1 || n < 2 || t_inpar) { fn(ctx, 0, n, 0); return; }
    int nt = n < g_nt ? (int)n : g_nt;
    pthread_mutex_lock(&g_mu);
    g_job.fn = fn; g_job.ctx = ctx; g_job.n = n; g_job.nt = nt; g_job.pending = g_nt - 1; g_job.gen++;
    pthread_cond_broadcast(&g_cv);
    pthread_mutex_unlock(&g_mu);
    t_inpar = 1;
    fn(ctx, 0, n / nt, 0);
    t_inpar = 0;
    pthread_mutex_lock(&g_mu);
    while (g_job.pending) pthread_cond_wait(&g_done, &g_mu);
    pthread_mutex_unlock(&g_mu);
}

/* ------------------------------------------------------------------ memory + basics */
API void *wf_alloc(long n) { void *p = 0; if (posix_memalign(&p, 64, (size_t)(n > 0 ? n : 1) * sizeof(f32))) return 0; return p; }
API void wf_free(void *p) { free(p); }
API void wf_fill(f32 *x, long n, f32 v) { for (long i = 0; i < n; i++) x[i] = v; }
API void wf_copy(f32 *d, const f32 *s, long n) { memcpy(d, s, (size_t)n * sizeof(f32)); }

typedef struct { f32 *a; const f32 *b, *c; long n; f32 s, t; int kind; } EW;
static void ew_run(void *v, long lo, long hi, int tid) {
    EW *e = (EW *)v; f32 *a = e->a; const f32 *b = e->b, *c = e->c; f32 s = e->s; (void)tid;
    switch (e->kind) {
    case 0: for (long i = lo; i < hi; i++) a[i] += s * b[i]; break;                 /* axpy */
    case 1: for (long i = lo; i < hi; i++) a[i] *= s; break;                        /* scale */
    case 2: for (long i = lo; i < hi; i++) a[i] = b[i] + c[i]; break;               /* add */
    case 3: for (long i = lo; i < hi; i++) a[i] = e->t * a[i] + s * b[i]; break;    /* lerp: a = t*a + s*b */
    }
}
static void ew(int kind, f32 *a, const f32 *b, const f32 *c, long n, f32 s, f32 t) {
    EW e = {a, b, c, n, s, t, kind};
    if (n < 32768) ew_run(&e, 0, n, 0); else pfor(n, ew_run, &e);
}
API void wf_axpy(f32 *y, const f32 *x, long n, f32 a) { ew(0, y, x, 0, n, a, 0); }
API void wf_scale(f32 *x, long n, f32 a) { ew(1, x, 0, 0, n, a, 0); }
API void wf_add(f32 *y, const f32 *a, const f32 *b, long n) { ew(2, y, a, b, n, 0, 0); }
API void wf_ema(f32 *shadow, const f32 *p, long n, f32 d) { ew(3, shadow, p, 0, n, 1 - d, d); }
API double wf_sumsq(const f32 *x, long n) { double s = 0; for (long i = 0; i < n; i++) s += (double)x[i] * x[i]; return s; }
API void wf_minmax(const f32 *x, long n, f32 *out) {
    f32 lo = x[0], hi = x[0];
    for (long i = 1; i < n; i++) { if (x[i] < lo) lo = x[i]; if (x[i] > hi) hi = x[i]; }
    out[0] = lo; out[1] = hi;
}
API void wf_adamw(f32 *p, const f32 *g, f32 *m, f32 *v, long n, f32 lr, f32 b1, f32 b2, f32 eps, f32 wd, int step) {
    f32 c1 = 1.f - powf(b1, (f32)step), c2 = 1.f - powf(b2, (f32)step);
    for (long i = 0; i < n; i++) {
        f32 gi = g[i];
        m[i] = b1 * m[i] + (1 - b1) * gi;
        v[i] = b2 * v[i] + (1 - b2) * gi * gi;
        p[i] -= lr * ((m[i] / c1) / (sqrtf(v[i] / c2) + eps) + wd * p[i]);
    }
}
API void wf_sgd(f32 *p, const f32 *g, f32 *m, long n, f32 lr, f32 mom, f32 wd) {
    for (long i = 0; i < n; i++) { f32 gi = g[i] + wd * p[i]; m[i] = mom * m[i] + gi; p[i] -= lr * m[i]; }
}

/* ------------------------------------------------------------------ fast exp / sigmoid (vectorisable) */
static inline f32 fexp(f32 x) {
    x = x > 88.f ? 88.f : (x < -87.f ? -87.f : x);
    f32 t = x * 1.44269504088896341f;
    int n = (int)(t + (t >= 0 ? 0.5f : -0.5f));
    f32 fn = (f32)n;
    x -= fn * 0.693359375f;
    x -= fn * -2.12194440e-4f;
    f32 z = x * x;
    f32 y = ((((1.9875691500E-4f * x + 1.3981999507E-3f) * x + 8.3334519073E-3f) * x + 4.1665795894E-2f) * x
             + 1.6666665459E-1f) * x + 5.0000001201E-1f;
    y = y * z + x + 1.f;
    union { uint32_t u; f32 f; } p; p.u = (uint32_t)(n + 127) << 23;
    return y * p.f;
}
static inline f32 fsig(f32 x) { return 1.f / (1.f + fexp(-x)); }

/* ------------------------------------------------------------------ activations: 0 relu, 1 leaky, 2 silu, 3 sigmoid */
typedef struct { const f32 *x, *y, *dy; f32 *o; f32 s; int kind, bwd; } ACT;
static void act_run(void *v, long lo, long hi, int tid) {
    ACT *a = (ACT *)v; const f32 *x = a->x, *y = a->y, *dy = a->dy; f32 *o = a->o; f32 s = a->s; (void)tid;
    if (!a->bwd) switch (a->kind) {
        case 0: for (long i = lo; i < hi; i++) o[i] = x[i] > 0 ? x[i] : 0; break;
        case 1: for (long i = lo; i < hi; i++) o[i] = x[i] > 0 ? x[i] : s * x[i]; break;
        case 2: for (long i = lo; i < hi; i++) o[i] = x[i] * fsig(x[i]); break;
        case 3: for (long i = lo; i < hi; i++) o[i] = fsig(x[i]); break;
    } else switch (a->kind) {
        case 0: for (long i = lo; i < hi; i++) o[i] = x[i] > 0 ? dy[i] : 0; break;
        case 1: for (long i = lo; i < hi; i++) o[i] = x[i] > 0 ? dy[i] : s * dy[i]; break;
        case 2: for (long i = lo; i < hi; i++) { f32 g = fsig(x[i]); o[i] = dy[i] * g * (1.f + x[i] * (1.f - g)); } break;
        case 3: for (long i = lo; i < hi; i++) o[i] = dy[i] * y[i] * (1.f - y[i]); break;
    }
}
API void wf_act_fwd(int kind, const f32 *x, f32 *y, long n, f32 slope) { ACT a = {x, 0, 0, y, slope, kind, 0}; if (n < 16384) act_run(&a, 0, n, 0); else pfor(n, act_run, &a); }
API void wf_act_bwd(int kind, const f32 *x, const f32 *y, const f32 *dy, f32 *dx, long n, f32 slope) { ACT a = {x, y, dy, dx, slope, kind, 1}; if (n < 16384) act_run(&a, 0, n, 0); else pfor(n, act_run, &a); }

/* ------------------------------------------------------------------ convolution */
typedef struct { int N, C, H, W, OC, KH, KW, sh, sw, pt, pl, dh, dw, G, OH, OW; } CV;

static void im2col(const f32 *x, const CV *c, int Cg, f32 *col) {
    long ON = (long)c->OH * c->OW;
    for (int ch = 0; ch < Cg; ch++) for (int ki = 0; ki < c->KH; ki++) for (int kj = 0; kj < c->KW; kj++) {
        f32 *r = col + ((long)(ch * c->KH + ki) * c->KW + kj) * ON;
        const f32 *xp = x + (long)ch * c->H * c->W;
        for (int oh = 0; oh < c->OH; oh++) {
            int ih = oh * c->sh - c->pt + ki * c->dh;
            f32 *rr = r + (long)oh * c->OW;
            if (ih < 0 || ih >= c->H) { memset(rr, 0, sizeof(f32) * c->OW); continue; }
            const f32 *xr = xp + (long)ih * c->W;
            for (int ow = 0; ow < c->OW; ow++) { int iw = ow * c->sw - c->pl + kj * c->dw; rr[ow] = (iw >= 0 && iw < c->W) ? xr[iw] : 0.f; }
        }
    }
}
static void col2im(const f32 *col, const CV *c, int Cg, f32 *x) {
    long ON = (long)c->OH * c->OW;
    for (int ch = 0; ch < Cg; ch++) for (int ki = 0; ki < c->KH; ki++) for (int kj = 0; kj < c->KW; kj++) {
        const f32 *r = col + ((long)(ch * c->KH + ki) * c->KW + kj) * ON;
        f32 *xp = x + (long)ch * c->H * c->W;
        for (int oh = 0; oh < c->OH; oh++) {
            int ih = oh * c->sh - c->pt + ki * c->dh;
            if (ih < 0 || ih >= c->H) continue;
            const f32 *rr = r + (long)oh * c->OW; f32 *xr = xp + (long)ih * c->W;
            for (int ow = 0; ow < c->OW; ow++) { int iw = ow * c->sw - c->pl + kj * c->dw; if (iw >= 0 && iw < c->W) xr[iw] += rr[ow]; }
        }
    }
}
/* C[i,:] += sum_k A[i*ai + k*ak] * B[k,:]   (B is K x N, C is M x N), cache-blocked over N */
static void gemm_rows(const f32 *A, long ai, long ak, const f32 *B, f32 *C, int K, long N, int i0, int i1) {
    const long NB = 384;
    for (long j0 = 0; j0 < N; j0 += NB) {
        long nb = N - j0 < NB ? N - j0 : NB;
        for (int i = i0; i < i1; i++) {
            f32 *c = C + (long)i * N + j0; const f32 *a = A + i * ai;
            int k = 0;
            for (; k + 3 < K; k += 4) {
                f32 a0 = a[k * ak], a1 = a[(k + 1) * ak], a2 = a[(k + 2) * ak], a3 = a[(k + 3) * ak];
                const f32 *b0 = B + (long)k * N + j0, *b1 = b0 + N, *b2 = b1 + N, *b3 = b2 + N;
                for (long j = 0; j < nb; j++) c[j] += a0 * b0[j] + a1 * b1[j] + a2 * b2[j] + a3 * b3[j];
            }
            for (; k < K; k++) { f32 a0 = a[k * ak]; const f32 *b0 = B + (long)k * N + j0; for (long j = 0; j < nb; j++) c[j] += a0 * b0[j]; }
        }
    }
}
/* W[i,k] += dot(Y[i,:], B[k,:]) */
static void gemm_dots(const f32 *Y, const f32 *B, f32 *W, int K, long N, int i0, int i1) {
    for (int i = i0; i < i1; i++) {
        const f32 *y = Y + (long)i * N;
        for (int k = 0; k < K; k++) {
            const f32 *b = B + (long)k * N; f32 s = 0;
#pragma omp simd reduction(+ : s)
            for (long j = 0; j < N; j++) s += y[j] * b[j];
            W[(long)i * K + k] += s;
        }
    }
}
static int is_1x1(const CV *c) { return c->KH == 1 && c->KW == 1 && c->sh == 1 && c->sw == 1 && c->pt == 0 && c->pl == 0 && c->OH == c->H && c->OW == c->W; }
static int is_dw(const CV *c) { return c->G == c->C && c->OC == c->C && c->G > 1; }

typedef struct { CV c; const f32 *x, *w, *b, *dy; f32 *y, *dx, *dw; int mode; pthread_mutex_t *mu; int one; } CJ;

static void dw_fwd(const CV *c, const f32 *x, const f32 *w, const f32 *b, f32 *y, long lo, long hi) {
    for (long t = lo; t < hi; t++) {             /* t = n*C + ch */
        int ch = (int)(t % c->C);
        const f32 *xp = x + t * c->H * c->W, *wp = w + (long)ch * c->KH * c->KW; f32 *yp = y + t * c->OH * c->OW; f32 bias = b ? b[ch] : 0;
        for (int oh = 0; oh < c->OH; oh++) for (int ow = 0; ow < c->OW; ow++) {
            f32 s = bias;
            for (int ki = 0; ki < c->KH; ki++) { int ih = oh * c->sh - c->pt + ki * c->dh; if (ih < 0 || ih >= c->H) continue;
                for (int kj = 0; kj < c->KW; kj++) { int iw = ow * c->sw - c->pl + kj * c->dw; if (iw >= 0 && iw < c->W) s += xp[(long)ih * c->W + iw] * wp[ki * c->KW + kj]; } }
            yp[(long)oh * c->OW + ow] = s;
        }
    }
}
static void dw_bwd(const CV *c, const f32 *x, const f32 *w, const f32 *dy, f32 *dx, f32 *dwl, long lo, long hi) {
    for (long t = lo; t < hi; t++) {             /* dx and (thread-local) dw for depthwise */
        int ch = (int)(t % c->C);
        const f32 *wp = w ? w + (long)ch * c->KH * c->KW : 0, *dyp = dy + t * c->OH * c->OW;
        const f32 *xp = x ? x + t * c->H * c->W : 0; f32 *dxp = dx ? dx + t * c->H * c->W : 0, *dwp = dwl ? dwl + (long)ch * c->KH * c->KW : 0;
        for (int oh = 0; oh < c->OH; oh++) for (int ow = 0; ow < c->OW; ow++) {
            f32 g = dyp[(long)oh * c->OW + ow];
            for (int ki = 0; ki < c->KH; ki++) { int ih = oh * c->sh - c->pt + ki * c->dh; if (ih < 0 || ih >= c->H) continue;
                for (int kj = 0; kj < c->KW; kj++) { int iw = ow * c->sw - c->pl + kj * c->dw; if (iw < 0 || iw >= c->W) continue;
                    if (dxp) dxp[(long)ih * c->W + iw] += g * wp[ki * c->KW + kj];
                    if (dwp) dwp[ki * c->KW + kj] += g * xp[(long)ih * c->W + iw]; } }
        }
    }
}

static void conv_run(void *v, long lo, long hi, int tid) {
    CJ *j = (CJ *)v; const CV *c = &j->c; (void)tid;
    int Cg = c->C / c->G, OCg = c->OC / c->G, K = Cg * c->KH * c->KW;
    long ON = (long)c->OH * c->OW, IN = (long)c->H * c->W, WN = (long)c->OC * K;
    if (is_dw(c)) {
        if (j->mode == 0) { dw_fwd(c, j->x, j->w, j->b, j->y, lo, hi); return; }
        if (j->mode == 1) { dw_bwd(c, 0, j->w, j->dy, j->dx, 0, lo, hi); return; }
        f32 *loc = (f32 *)calloc((size_t)WN, sizeof(f32));
        dw_bwd(c, j->x, 0, j->dy, 0, loc, lo, hi);
        pthread_mutex_lock(j->mu); for (long i = 0; i < WN; i++) j->dw[i] += loc[i]; pthread_mutex_unlock(j->mu);
        free(loc); return;
    }
    int direct = is_1x1(c);
    f32 *col = (direct || j->one) ? 0 : (f32 *)malloc(sizeof(f32) * (size_t)K * ON);
    f32 *loc = (j->mode == 2 && !j->one) ? (f32 *)calloc((size_t)WN, sizeof(f32)) : 0;
    long n0 = j->one ? 0 : lo, n1 = j->one ? c->N : hi;
    int r0 = 0, r1 = OCg;
    for (long n = n0; n < n1; n++) for (int g = 0; g < c->G; g++) {
        const f32 *wg = j->w ? j->w + (long)g * OCg * K : 0;
        if (j->mode == 0) {
            const f32 *xg = j->x + (n * c->C + (long)g * Cg) * IN; f32 *yg = j->y + (n * c->OC + (long)g * OCg) * ON;
            if (j->one) { r0 = (int)lo; r1 = (int)hi; }
            if (!direct && !j->one) im2col(xg, c, Cg, col);
            const f32 *B = direct ? xg : (j->one ? j->dx /* shared col */ : col);
            for (int i = r0; i < r1; i++) { f32 bv = j->b ? j->b[g * OCg + i] : 0; f32 *yr = yg + (long)i * ON; for (long q = 0; q < ON; q++) yr[q] = bv; }
            gemm_rows(wg, K, 1, B, yg, K, ON, r0, r1);
        } else if (j->mode == 1) {
            const f32 *dyg = j->dy + (n * c->OC + (long)g * OCg) * ON; f32 *dxg = j->dx + (n * c->C + (long)g * Cg) * IN;
            f32 *dst = direct ? dxg : col;
            if (!direct) memset(col, 0, sizeof(f32) * (size_t)K * ON);
            gemm_rows(wg, 1, K, dyg, dst, OCg, ON, 0, K);       /* dcol[k,:] += w[oc,k] * dy[oc,:] */
            if (!direct) col2im(col, c, Cg, dxg);
        } else {
            const f32 *xg = j->x + (n * c->C + (long)g * Cg) * IN, *dyg = j->dy + (n * c->OC + (long)g * OCg) * ON;
            if (!direct) im2col(xg, c, Cg, col);
            gemm_dots(dyg, direct ? xg : col, (loc ? loc : j->dw) + (long)g * OCg * K, K, ON, 0, OCg);
        }
    }
    if (loc) { pthread_mutex_lock(j->mu); for (long i = 0; i < WN; i++) j->dw[i] += loc[i]; pthread_mutex_unlock(j->mu); free(loc); }
    free(col);
}
static CV mkcv(int N, int C, int H, int W, int OC, int KH, int KW, int sh, int sw, int pt, int pb, int pl, int pr, int dh, int dw, int G) {
    CV c = {N, C, H, W, OC, KH, KW, sh, sw, pt, pl, dh, dw, G, 0, 0};
    c.OH = (H + pt + pb - dh * (KH - 1) - 1) / sh + 1; c.OW = (W + pl + pr - dw * (KW - 1) - 1) / sw + 1;
    return c;
}
#define CVARGS int N, int C, int H, int W, int OC, int KH, int KW, int sh, int sw, int pt, int pb, int pl, int pr, int dh, int dw, int G
#define CVPASS N, C, H, W, OC, KH, KW, sh, sw, pt, pb, pl, pr, dh, dw, G

API void wf_conv2d_fwd(const f32 *x, const f32 *w, const f32 *b, f32 *y, CVARGS) {
    CJ j; memset(&j, 0, sizeof j); j.c = mkcv(CVPASS); j.x = x; j.w = w; j.b = b; j.y = y; j.mode = 0;
    if (is_dw(&j.c)) { pfor((long)N * C, conv_run, &j); return; }
    if (N == 1 && G == 1) {                                   /* single image: parallelise over output channels */
        int K = C * KH * KW; long ON = (long)j.c.OH * j.c.OW; f32 *col = 0;
        if (!is_1x1(&j.c)) { col = (f32 *)malloc(sizeof(f32) * (size_t)K * ON); im2col(x, &j.c, C, col); }
        j.one = 1; j.dx = col; pfor(OC, conv_run, &j); free(col); return;
    }
    pfor(N, conv_run, &j);
}
API void wf_conv2d_bwd_data(const f32 *dy, const f32 *w, f32 *dx, CVARGS) {      /* dx must be zeroed by the caller */
    CJ j; memset(&j, 0, sizeof j); j.c = mkcv(CVPASS); j.dy = dy; j.w = w; j.dx = dx; j.mode = 1;
    pfor(is_dw(&j.c) ? (long)N * C : N, conv_run, &j);
}
API void wf_conv2d_bwd_weight(const f32 *x, const f32 *dy, f32 *dw_, f32 *db, CVARGS) {   /* dw, db zeroed by the caller */
    pthread_mutex_t mu = PTHREAD_MUTEX_INITIALIZER;
    CJ j; memset(&j, 0, sizeof j); j.c = mkcv(CVPASS); j.x = x; j.dy = dy; j.dw = dw_; j.mode = 2; j.mu = &mu;
    pfor(is_dw(&j.c) ? (long)N * C : N, conv_run, &j);
    if (db) { long ON = (long)j.c.OH * j.c.OW;
        for (int n = 0; n < N; n++) for (int oc = 0; oc < OC; oc++) { const f32 *p = dy + ((long)n * OC + oc) * ON; f32 s = 0; for (long q = 0; q < ON; q++) s += p[q]; db[oc] += s; } }
}

/* ------------------------------------------------------------------ batch norm */
typedef struct { const f32 *x, *g, *b, *dy; f32 *rm, *rv, *y, *mean, *istd, *dx, *dg, *db; int N, C; long HW; f32 mom, eps; int mode; } BN;
static void bn_run(void *v, long lo, long hi, int tid) {
    BN *p = (BN *)v; long HW = p->HW; int N = p->N, C = p->C; double m = (double)N * HW; (void)tid;
    for (long c = lo; c < hi; c++) {
        if (p->mode == 0) {                                   /* train forward */
            double s = 0, ss = 0;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) s += x[i]; }
            f32 mu = (f32)(s / m);
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) { f32 d = x[i] - mu; ss += d * d; } }
            f32 var = (f32)(ss / m), is = 1.f / sqrtf(var + p->eps), g = p->g[c], b = p->b[c];
            p->mean[c] = mu; p->istd[c] = is;
            p->rm[c] = (1 - p->mom) * p->rm[c] + p->mom * mu;
            p->rv[c] = (1 - p->mom) * p->rv[c] + p->mom * (f32)(m > 1 ? ss / (m - 1) : ss / m);
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; f32 *y = p->y + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) y[i] = (x[i] - mu) * is * g + b; }
        } else if (p->mode == 1) {                            /* eval forward */
            f32 is = 1.f / sqrtf(p->rv[c] + p->eps), g = p->g[c] * is, b = p->b[c] - p->rm[c] * g;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW; f32 *y = p->y + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) y[i] = x[i] * g + b; }
        } else if (p->mode == 2) {                            /* train backward */
            f32 mu = p->mean[c], is = p->istd[c], g = p->g[c]; double sdy = 0, sdx = 0;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW, *dy = p->dy + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) { sdy += dy[i]; sdx += dy[i] * (x[i] - mu) * is; } }
            p->db[c] += (f32)sdy; p->dg[c] += (f32)sdx;
            f32 k = g * is / (f32)m, a = (f32)sdy, bb = (f32)sdx;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW, *dy = p->dy + ((long)n * C + c) * HW; f32 *dx = p->dx + ((long)n * C + c) * HW;
                for (long i = 0; i < HW; i++) dx[i] = k * ((f32)m * dy[i] - a - (x[i] - mu) * is * bb); }
        } else {                                              /* eval backward (frozen statistics) */
            f32 is = 1.f / sqrtf(p->rv[c] + p->eps), g = p->g[c] * is, rm = p->rm[c]; double sdy = 0, sdx = 0;
            for (int n = 0; n < N; n++) { const f32 *x = p->x + ((long)n * C + c) * HW, *dy = p->dy + ((long)n * C + c) * HW; f32 *dx = p->dx + ((long)n * C + c) * HW;
                for (long i = 0; i < HW; i++) { sdy += dy[i]; sdx += dy[i] * (x[i] - rm) * is; dx[i] = dy[i] * g; } }
            p->db[c] += (f32)sdy; p->dg[c] += (f32)sdx;
        }
    }
}
API void wf_bn_fwd(const f32 *x, const f32 *g, const f32 *b, f32 *rm, f32 *rv, f32 *y, f32 *mean, f32 *istd, int N, int C, long HW, f32 mom, f32 eps, int train) {
    BN p; memset(&p, 0, sizeof p); p.x = x; p.g = g; p.b = b; p.rm = rm; p.rv = rv; p.y = y; p.mean = mean; p.istd = istd; p.N = N; p.C = C; p.HW = HW; p.mom = mom; p.eps = eps; p.mode = train ? 0 : 1;
    pfor(C, bn_run, &p);
}
API void wf_bn_bwd(const f32 *x, const f32 *dy, const f32 *g, const f32 *mean, const f32 *istd, f32 *rm, f32 *rv, f32 *dx, f32 *dg, f32 *db, int N, int C, long HW, f32 eps, int train) {
    BN p; memset(&p, 0, sizeof p); p.x = x; p.dy = dy; p.g = g; p.mean = (f32 *)mean; p.istd = (f32 *)istd; p.rm = rm; p.rv = rv; p.dx = dx; p.dg = dg; p.db = db; p.N = N; p.C = C; p.HW = HW; p.eps = eps; p.mode = train ? 2 : 3;
    pfor(C, bn_run, &p);
}

/* ------------------------------------------------------------------ pooling / resize */
typedef struct { const f32 *x; f32 *y; int32_t *idx; int H, W, OH, OW, kh, kw, sh, sw, pt, pl, mode; } PL;
static void pool_run(void *v, long lo, long hi, int tid) {
    PL *p = (PL *)v; (void)tid;
    for (long t = lo; t < hi; t++) {                          /* t = plane index (n*C + c) */
        const f32 *x = p->x + t * p->H * p->W; f32 *y = p->y + t * p->OH * p->OW; int32_t *ix = p->idx ? p->idx + t * p->OH * p->OW : 0;
        for (int oh = 0; oh < p->OH; oh++) for (int ow = 0; ow < p->OW; ow++) {
            f32 best = -INFINITY, s = 0; int bi = -1;
            for (int ki = 0; ki < p->kh; ki++) { int ih = oh * p->sh - p->pt + ki; if (ih < 0 || ih >= p->H) continue;
                for (int kj = 0; kj < p->kw; kj++) { int iw = ow * p->sw - p->pl + kj; if (iw < 0 || iw >= p->W) continue;
                    f32 val = x[(long)ih * p->W + iw]; s += val; if (val > best) { best = val; bi = ih * p->W + iw; } } }
            long o = (long)oh * p->OW + ow;
            if (p->mode == 0) { y[o] = best; ix[o] = bi; } else y[o] = s / (f32)(p->kh * p->kw);
        }
    }
}
API void wf_maxpool_fwd(const f32 *x, f32 *y, int32_t *idx, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    PL p = {x, y, idx, H, W, OH, OW, kh, kw, sh, sw, pt, pl, 0}; pfor(planes, pool_run, &p);
}
API void wf_avgpool_fwd(const f32 *x, f32 *y, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    PL p = {x, y, 0, H, W, OH, OW, kh, kw, sh, sw, pt, pl, 1}; pfor(planes, pool_run, &p);
}
API void wf_maxpool_bwd(const f32 *dy, const int32_t *idx, f32 *dx, long planes, int H, int W, int OH, int OW) {   /* dx zeroed */
    for (long t = 0; t < planes; t++) { const f32 *g = dy + t * OH * OW; const int32_t *ix = idx + t * OH * OW; f32 *d = dx + t * H * W;
        for (long o = 0; o < (long)OH * OW; o++) if (ix[o] >= 0) d[ix[o]] += g[o]; }
}
API void wf_avgpool_bwd(const f32 *dy, f32 *dx, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {   /* dx zeroed */
    f32 inv = 1.f / (f32)(kh * kw);
    for (long t = 0; t < planes; t++) { const f32 *g = dy + t * OH * OW; f32 *d = dx + t * H * W;
        for (int oh = 0; oh < OH; oh++) for (int ow = 0; ow < OW; ow++) { f32 gv = g[(long)oh * OW + ow] * inv;
            for (int ki = 0; ki < kh; ki++) { int ih = oh * sh - pt + ki; if (ih < 0 || ih >= H) continue;
                for (int kj = 0; kj < kw; kj++) { int iw = ow * sw - pl + kj; if (iw >= 0 && iw < W) d[(long)ih * W + iw] += gv; } } } }
}
API void wf_upsample_fwd(const f32 *x, f32 *y, long planes, int H, int W, int OH, int OW) {      /* nearest */
    for (long t = 0; t < planes; t++) { const f32 *xp = x + t * H * W; f32 *yp = y + t * OH * OW;
        for (int oh = 0; oh < OH; oh++) { const f32 *xr = xp + (long)((long)oh * H / OH) * W; f32 *yr = yp + (long)oh * OW;
            for (int ow = 0; ow < OW; ow++) yr[ow] = xr[(long)ow * W / OW]; } }
}
API void wf_upsample_bwd(const f32 *dy, f32 *dx, long planes, int H, int W, int OH, int OW) {    /* dx zeroed */
    for (long t = 0; t < planes; t++) { f32 *xp = dx + t * H * W; const f32 *yp = dy + t * OH * OW;
        for (int oh = 0; oh < OH; oh++) { f32 *xr = xp + (long)((long)oh * H / OH) * W; const f32 *yr = yp + (long)oh * OW;
            for (int ow = 0; ow < OW; ow++) xr[(long)ow * W / OW] += yr[ow]; } }
}

/* ------------------------------------------------------------------ channel ops, broadcasting, reshuffles */
API void wf_copy_ch(f32 *dst, int dC, int off, const f32 *src, int sC, int N, long HW) {         /* dst[n, off+c] = src[n, c] */
    for (int n = 0; n < N; n++) memcpy(dst + ((long)n * dC + off) * HW, src + (long)n * sC * HW, sizeof(f32) * (size_t)sC * HW);
}
API void wf_slice_ch(const f32 *src, int sC, int off, f32 *dst, int dC, int N, long HW) {        /* dst[n, c] = src[n, off+c] */
    for (int n = 0; n < N; n++) memcpy(dst + (long)n * dC * HW, src + ((long)n * sC + off) * HW, sizeof(f32) * (size_t)dC * HW);
}
/* y = x * s, s broadcast: each of sN,sC,sH,sW equals the x dim or 1 */
API void wf_mul_bc(const f32 *x, const f32 *s, f32 *y, int N, int C, int H, int W, int sN, int sC, int sH, int sW) {
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) for (int h = 0; h < H; h++) {
        const f32 *xr = x + (((long)n * C + c) * H + h) * W; f32 *yr = y + (((long)n * C + c) * H + h) * W;
        const f32 *sr = s + (((long)(sN > 1 ? n : 0) * sC + (sC > 1 ? c : 0)) * sH + (sH > 1 ? h : 0)) * sW;
        if (sW > 1) for (int w = 0; w < W; w++) yr[w] = xr[w] * sr[w]; else { f32 sv = sr[0]; for (int w = 0; w < W; w++) yr[w] = xr[w] * sv; }
    }
}
/* out (broadcast shape) += sum over broadcast dims of a*b; out zeroed by the caller */
API void wf_mul_reduce(const f32 *a, const f32 *b, f32 *out, int N, int C, int H, int W, int sN, int sC, int sH, int sW) {
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) for (int h = 0; h < H; h++) {
        const f32 *ar = a + (((long)n * C + c) * H + h) * W, *br = b + (((long)n * C + c) * H + h) * W;
        f32 *o = out + (((long)(sN > 1 ? n : 0) * sC + (sC > 1 ? c : 0)) * sH + (sH > 1 ? h : 0)) * sW;
        if (sW > 1) for (int w = 0; w < W; w++) o[w] += ar[w] * br[w]; else { f32 t = 0; for (int w = 0; w < W; w++) t += ar[w] * br[w]; o[0] += t; }
    }
}
API void wf_chan_mean(const f32 *x, f32 *y, int N, int C, long HW) {
    for (int n = 0; n < N; n++) { f32 *yp = y + (long)n * HW; memset(yp, 0, sizeof(f32) * HW);
        for (int c = 0; c < C; c++) { const f32 *xp = x + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) yp[i] += xp[i]; }
        f32 inv = 1.f / C; for (long i = 0; i < HW; i++) yp[i] *= inv; }
}
API void wf_chan_mean_bwd(const f32 *dy, f32 *dx, int N, int C, long HW) {
    f32 inv = 1.f / C;
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) { const f32 *g = dy + (long)n * HW; f32 *d = dx + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) d[i] = g[i] * inv; }
}
API void wf_chan_max(const f32 *x, f32 *y, int32_t *idx, int N, int C, long HW) {
    for (int n = 0; n < N; n++) { f32 *yp = y + (long)n * HW; int32_t *ip = idx + (long)n * HW;
        for (long i = 0; i < HW; i++) { yp[i] = -INFINITY; ip[i] = 0; }
        for (int c = 0; c < C; c++) { const f32 *xp = x + ((long)n * C + c) * HW; for (long i = 0; i < HW; i++) if (xp[i] > yp[i]) { yp[i] = xp[i]; ip[i] = c; } } }
}
API void wf_chan_max_bwd(const f32 *dy, const int32_t *idx, f32 *dx, int N, int C, long HW) {   /* dx zeroed */
    for (int n = 0; n < N; n++) { const f32 *g = dy + (long)n * HW; const int32_t *ip = idx + (long)n * HW; for (long i = 0; i < HW; i++) dx[((long)n * C + ip[i]) * HW + i] += g[i]; }
}
/* Focus: (N,C,H,W) -> (N,4C,H/2,W/2) in the order [even rows/even cols, odd rows/even cols, even/odd, odd/odd] */
API void wf_space_to_depth(const f32 *x, f32 *y, int N, int C, int H, int W, int inverse) {
    int OH = H / 2, OW = W / 2;
    for (int n = 0; n < N; n++) for (int q = 0; q < 4; q++) for (int c = 0; c < C; c++) {
        int dr = q & 1, dc = q >> 1;
        f32 *yp = (f32 *)y + (((long)n * 4 * C) + (long)q * C + c) * OH * OW; f32 *xp = (f32 *)x + ((long)n * C + c) * H * W;
        for (int oh = 0; oh < OH; oh++) for (int ow = 0; ow < OW; ow++) {
            if (!inverse) yp[(long)oh * OW + ow] = xp[(long)(2 * oh + dr) * W + 2 * ow + dc];
            else xp[(long)(2 * oh + dr) * W + 2 * ow + dc] = yp[(long)oh * OW + ow];
        }
    }
}

/* ------------------------------------------------------------------ quantisation (uniform, per tensor) */
API void wf_fake_quant(const f32 *x, f32 *y, long n, f32 scale, f32 zp, f32 qmin, f32 qmax) {
    for (long i = 0; i < n; i++) { f32 q = nearbyintf(x[i] / scale + zp); q = q < qmin ? qmin : (q > qmax ? qmax : q); y[i] = (q - zp) * scale; }
}
API void wf_fake_quant_bwd(const f32 *x, const f32 *dy, f32 *dx, long n, f32 scale, f32 zp, f32 qmin, f32 qmax) {   /* straight-through */
    for (long i = 0; i < n; i++) { f32 q = x[i] / scale + zp; dx[i] = (q >= qmin - 0.5f && q <= qmax + 0.5f) ? dy[i] : 0.f; }
}
API void wf_quantize_i8(const f32 *x, int8_t *q, long n, f32 scale) {
    for (long i = 0; i < n; i++) { f32 v = nearbyintf(x[i] / scale); q[i] = (int8_t)(v < -127 ? -127 : (v > 127 ? 127 : v)); }
}
API void wf_dequantize_i8(const int8_t *q, f32 *x, long n, f32 scale) { for (long i = 0; i < n; i++) x[i] = q[i] * scale; }

/* ------------------------------------------------------------------ detection: loss (with gradients), decode + NMS
 * Head maps are (N, 5+NC, h, w): channels 0-3 = distances left/top/right/bottom in strides (softplus),
 * 4 = objectness logit, 5.. = class logits. Targets are rows [image, class, x1, y1, x2, y2] in pixels. */
static inline f32 softplus(f32 r) { return r > 20.f ? r : log1pf(expf(r)); }
static inline f32 sigm(f32 z) { return 1.f / (1.f + expf(-z)); }
static inline f32 bce(f32 z, f32 t) { return (z > 0 ? z : 0) - z * t + log1pf(expf(-fabsf(z))); }

API double wf_det_loss(int L, const f32 **pred, f32 **grad, const int *hs, const int *ws, int N, int NC, int img_h, int img_w,
                       const f32 *tg, int T, f32 wbox, f32 wobj, f32 wcls, double *parts) {
    const f32 RADIUS = 1.5f, RANGE = 8.f;
    int CH = 5 + NC; double lbox = 0, lobj = 0, lcls = 0; long npos = 0;
    int *tlvl = (int *)malloc(sizeof(int) * (size_t)(T > 0 ? T : 1));
    for (int l = 0; l < L; l++) memset(grad[l], 0, sizeof(f32) * (size_t)N * CH * hs[l] * ws[l]);
    for (int t = 0; t < T; t++) {                             /* the level whose stride suits the object's size */
        f32 gm = fmaxf(tg[t * 6 + 4] - tg[t * 6 + 2], tg[t * 6 + 5] - tg[t * 6 + 3]); int lv = L - 1;
        for (int l = 0; l < L - 1; l++) if (gm <= RANGE * (f32)img_w / ws[l]) { lv = l; break; }
        tlvl[t] = lv;
    }
    for (int l = 0; l < L; l++) {
        int h = hs[l], w = ws[l]; long hw = (long)h * w; f32 sx = (f32)img_w / w, sy = (f32)img_h / h, s = 0.5f * (sx + sy);
        for (int b = 0; b < N; b++) {
            const f32 *p = pred[l] + (long)b * CH * hw; f32 *g = grad[l] + (long)b * CH * hw;
            for (int i = 0; i < h; i++) for (int j = 0; j < w; j++) {
                long o = (long)i * w + j; f32 cx = (j + 0.5f) * sx, cy = (i + 0.5f) * sy; int best = -1; f32 barea = INFINITY;
                for (int t = 0; t < T; t++) {
                    const f32 *q = tg + t * 6;
                    if ((int)q[0] != b || tlvl[t] != l) continue;
                    f32 gcx = 0.5f * (q[2] + q[4]), gcy = 0.5f * (q[3] + q[5]);
                    int ix = (int)(gcx / sx), iy = (int)(gcy / sy);
                    ix = ix < 0 ? 0 : (ix > w - 1 ? w - 1 : ix); iy = iy < 0 ? 0 : (iy > h - 1 ? h - 1 : iy);
                    int ok = (ix == j && iy == i) ||
                             (cx > q[2] && cx < q[4] && cy > q[3] && cy < q[5] && fabsf(cx - gcx) < RADIUS * s && fabsf(cy - gcy) < RADIUS * s);
                    f32 area = (q[4] - q[2]) * (q[5] - q[3]);
                    if (ok && area < barea) { barea = area; best = t; }
                }
                f32 z = p[4 * hw + o], tt = best >= 0 ? 1.f : 0.f;
                lobj += bce(z, tt); g[4 * hw + o] = wobj * (sigm(z) - tt);
                if (best < 0) continue;
                npos++;
                const f32 *q = tg + best * 6; int kc = (int)q[1];
                for (int k = 0; k < NC; k++) { f32 zc = p[(5 + k) * hw + o], tc = k == kc ? 1.f : 0.f; lcls += bce(zc, tc); g[(5 + k) * hw + o] = wcls * (sigm(zc) - tc); }
                f32 r0 = p[o], r1 = p[hw + o], r2 = p[2 * hw + o], r3 = p[3 * hw + o];
                f32 x1 = cx - softplus(r0) * sx, y1 = cy - softplus(r1) * sy, x2 = cx + softplus(r2) * sx, y2 = cy + softplus(r3) * sy;
                f32 gx1 = q[2], gy1 = q[3], gx2 = q[4], gy2 = q[5];
                f32 iw = fminf(x2, gx2) - fmaxf(x1, gx1), ih = fminf(y2, gy2) - fmaxf(y1, gy1);
                int has = iw > 0 && ih > 0; if (iw < 0) iw = 0; if (ih < 0) ih = 0;
                f32 I = iw * ih, pw = x2 - x1, ph = y2 - y1, U = pw * ph + (gx2 - gx1) * (gy2 - gy1) - I + 1e-9f;
                f32 cw = fmaxf(x2, gx2) - fminf(x1, gx1), chh = fmaxf(y2, gy2) - fminf(y1, gy1), Cc = cw * chh + 1e-9f;
                lbox += 2.f - I / U - U / Cc;                 /* 1 - GIoU */
                f32 dI[4] = {(has && x1 > gx1) ? -ih : 0, (has && y1 > gy1) ? -iw : 0, (has && x2 < gx2) ? ih : 0, (has && y2 < gy2) ? iw : 0};
                f32 dA[4] = {-ph, -pw, ph, pw};
                f32 dC[4] = {x1 < gx1 ? -chh : 0, y1 < gy1 ? -cw : 0, x2 > gx2 ? chh : 0, y2 > gy2 ? cw : 0};
                f32 rr[4] = {r0, r1, r2, r3}, sg[4] = {-sx, -sy, sx, sy};
                for (int e = 0; e < 4; e++) {
                    f32 dU = dA[e] - dI[e];
                    f32 d = -(dI[e] * U - I * dU) / (U * U) - (dU * Cc - U * dC[e]) / (Cc * Cc);
                    g[e * hw + o] = wbox * d * sg[e] * sigm(rr[e]);
                }
            }
        }
    }
    f32 inv = 1.f / (f32)(npos > 0 ? npos : 1);
    for (int l = 0; l < L; l++) { long n = (long)N * CH * hs[l] * ws[l]; f32 *g = grad[l]; for (long i = 0; i < n; i++) g[i] *= inv; }
    free(tlvl);
    parts[0] = lbox * inv; parts[1] = lobj * inv; parts[2] = lcls * inv; parts[3] = (double)npos;
    return wbox * parts[0] + wobj * parts[1] + wcls * parts[2];
}

typedef struct { f32 b[4], score; int cls; } Det;
static int det_cmp(const void *a, const void *b) { f32 d = ((const Det *)b)->score - ((const Det *)a)->score; return d > 0 ? 1 : (d < 0 ? -1 : 0); }
static f32 iou_of(const f32 *a, const f32 *b) {
    f32 iw = fminf(a[2], b[2]) - fmaxf(a[0], b[0]), ih = fminf(a[3], b[3]) - fmaxf(a[1], b[1]);
    if (iw <= 0 || ih <= 0) return 0;
    f32 I = iw * ih; return I / ((a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - I + 1e-9f);
}
/* out: N * max_det rows of [x1, y1, x2, y2, score, class]; counts[n] = rows used for image n */
API void wf_decode(int L, const f32 **pred, const int *hs, const int *ws, int N, int NC, int img_h, int img_w,
                   f32 conf, f32 iou, int max_det, int max_nms, f32 *out, int *counts) {
    int CH = 5 + NC; long A = 0;
    for (int l = 0; l < L; l++) A += (long)hs[l] * ws[l];
    Det *d = (Det *)malloc(sizeof(Det) * (size_t)A); char *dead = (char *)malloc((size_t)(max_nms > 0 ? max_nms : 1));
    for (int b = 0; b < N; b++) {
        long m = 0;
        for (int l = 0; l < L; l++) {
            int h = hs[l], w = ws[l]; long hw = (long)h * w; f32 sx = (f32)img_w / w, sy = (f32)img_h / h; const f32 *p = pred[l] + (long)b * CH * hw;
            for (long o = 0; o < hw; o++) {
                f32 ob = sigm(p[4 * hw + o]);
                if (ob <= conf) continue;
                int kc = 0; f32 zb = p[5 * hw + o];
                for (int k = 1; k < NC; k++) if (p[(5 + k) * hw + o] > zb) { zb = p[(5 + k) * hw + o]; kc = k; }
                f32 sc = ob * sigm(zb);
                if (sc <= conf) continue;
                f32 cx = ((f32)(o % w) + 0.5f) * sx, cy = ((f32)(o / w) + 0.5f) * sy;
                Det *q = &d[m++]; q->score = sc; q->cls = kc;
                q->b[0] = cx - softplus(p[o]) * sx; q->b[1] = cy - softplus(p[hw + o]) * sy;
                q->b[2] = cx + softplus(p[2 * hw + o]) * sx; q->b[3] = cy + softplus(p[3 * hw + o]) * sy;
            }
        }
        qsort(d, (size_t)m, sizeof(Det), det_cmp);
        if (m > max_nms) m = max_nms;
        memset(dead, 0, (size_t)m);
        int k = 0; f32 *o = out + (long)b * max_det * 6;
        for (long i = 0; i < m && k < max_det; i++) {
            if (dead[i]) continue;
            memcpy(o + k * 6, d[i].b, 4 * sizeof(f32)); o[k * 6 + 4] = d[i].score; o[k * 6 + 5] = (f32)d[i].cls; k++;
            for (long j = i + 1; j < m; j++) if (!dead[j] && d[j].cls == d[i].cls && iou_of(d[i].b, d[j].b) > iou) dead[j] = 1;
        }
        counts[b] = k;
    }
    free(d); free(dead);
}

/* ------------------------------------------------------------------ image preprocessing
 * RGB uint8 (h, w, 3) -> float CHW (3, th, tw) in [0,1]: bilinear resize to (nh, nw), pasted at (px, py) on a grey
 * canvas, with optional horizontal flip and brightness gain/bias (augmentation). */
API void wf_letterbox(const uint8_t *rgb, int h, int w, f32 *out, int th, int tw, int nh, int nw, int px, int py,
                      f32 fill, int flip, f32 gain, f32 bias) {
    long plane = (long)th * tw; f32 fv = fill / 255.f;
    for (long i = 0; i < 3 * plane; i++) out[i] = fv;
    for (int oy = 0; oy < nh; oy++) {
        f32 fy = ((f32)oy + 0.5f) * h / nh - 0.5f; if (fy < 0) fy = 0; if (fy > h - 1) fy = (f32)(h - 1);
        int y0 = (int)fy, y1 = y0 + 1 < h ? y0 + 1 : y0; f32 wy = fy - y0;
        for (int ox = 0; ox < nw; ox++) {
            f32 fx = ((f32)ox + 0.5f) * w / nw - 0.5f; if (fx < 0) fx = 0; if (fx > w - 1) fx = (f32)(w - 1);
            int x0 = (int)fx, x1 = x0 + 1 < w ? x0 + 1 : x0; f32 wx = fx - x0;
            const uint8_t *a = rgb + ((long)y0 * w + x0) * 3, *b = rgb + ((long)y0 * w + x1) * 3, *c = rgb + ((long)y1 * w + x0) * 3, *d = rgb + ((long)y1 * w + x1) * 3;
            int dx = flip ? tw - 1 - (px + ox) : px + ox;
            long o = (long)(py + oy) * tw + dx;
            for (int ch = 0; ch < 3; ch++) {
                f32 v = (a[ch] * (1 - wx) + b[ch] * wx) * (1 - wy) + (c[ch] * (1 - wx) + d[ch] * wx) * wy;
                v = v * gain + bias; v = v < 0 ? 0 : (v > 255 ? 255 : v);
                out[ch * plane + o] = v / 255.f;
            }
        }
    }
}
API int wf_abi(void) { return 1; }
API void wf_sum_ch(const f32 *x, f32 *out, int N, int C, long HW) {      /* out[c] += sum over n, h, w */
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) { const f32 *p = x + ((long)n * C + c) * HW; f32 s = 0; for (long i = 0; i < HW; i++) s += p[i]; out[c] += s; }
}
API void wf_add_ch(f32 *y, const f32 *b, int N, int C, long HW) {        /* y[n, c] += b[c] */
    for (int n = 0; n < N; n++) for (int c = 0; c < C; c++) { f32 *p = y + ((long)n * C + c) * HW; f32 v = b[c]; for (long i = 0; i < HW; i++) p[i] += v; }
}
API void wf_uniform(f32 *x, long n, f32 lo, f32 hi, uint64_t seed) {     /* xorshift64*, reproducible initialisation */
    uint64_t s = seed * 0x9E3779B97F4A7C15ULL + 0x632BE59BD9B4E019ULL;
    for (long i = 0; i < n; i++) { s ^= s >> 12; s ^= s << 25; s ^= s >> 27; x[i] = lo + (hi - lo) * (f32)(((s * 0x2545F4914F6CDD1DULL) >> 40) * (1.0 / 16777216.0)); }
}
