"""Differentiable operations. Each computes through the tensor's backend and records its backward step."""
from __future__ import annotations

from typing import List, Optional, Sequence, Tuple

from .tensor import Tensor, acc, record

RELU, LEAKY, SILU, SIGMOID = 0, 1, 2, 3


def out_size(size: int, k: int, s: int, p0: int, p1: int, d: int = 1) -> int:
    return (size + p0 + p1 - d * (k - 1) - 1) // s + 1


def conv2d(x: Tensor, w: Tensor, b: Optional[Tensor], stride=(1, 1), pad=(0, 0, 0, 0), dil=(1, 1), groups=1) -> Tensor:
    """``pad`` = (top, bottom, left, right). ``w`` is (out, in/groups, kh, kw)."""
    B = x.dev.be
    N, _, H, W = x.shape
    OC, _, KH, KW = w.shape
    cfg = (stride[0], stride[1], pad[0], pad[1], pad[2], pad[3], dil[0], dil[1], groups)
    oshape = (N, OC, out_size(H, KH, stride[0], pad[0], pad[1], dil[0]), out_size(W, KW, stride[1], pad[2], pad[3], dil[1]))
    y = B.conv_fwd(x, w, b, cfg, oshape)

    def bw():
        dy, y.grad = y.grad, None
        if dy is None:
            return
        if x.rg:
            acc(x, B.conv_bwd_data(dy, w, cfg, x.shape))
        if w.rg:
            dw, db = B.conv_bwd_weight(x, dy, cfg, w.shape, b is not None)
            acc(w, dw)
            if db is not None:
                acc(b, db)
    record([y], [x, w, b], bw)
    return y


def conv_transpose2d(x: Tensor, w: Tensor, b: Optional[Tensor], stride=(1, 1), pad=(0, 0, 0, 0), dil=(1, 1)) -> Tensor:
    """Transposed convolution. ``w`` is (in, out, kh, kw); ``pad`` = (top, bottom, left, right) pixels removed from
    the output."""
    B = x.dev.be
    N, Cin, H, W = x.shape
    _, Cout, KH, KW = w.shape
    OH = (H - 1) * stride[0] - pad[0] - pad[1] + dil[0] * (KH - 1) + 1
    OW = (W - 1) * stride[1] - pad[2] - pad[3] + dil[1] * (KW - 1) + 1
    cfg = (stride[0], stride[1], pad[0], pad[1], pad[2], pad[3], dil[0], dil[1], 1)
    oshape = (N, Cout, OH, OW)
    y = B.conv_bwd_data(x, w, cfg, oshape)          # the adjoint of the convolution (Cout,OH,OW) -> (Cin,H,W)
    if b is not None:
        B.add_ch(y, b)

    def bw():
        dy, y.grad = y.grad, None
        if dy is None:
            return
        if x.rg:
            acc(x, B.conv_fwd(dy, w, None, cfg, x.shape))
        if w.rg:
            dw, _ = B.conv_bwd_weight(dy, x, cfg, w.shape, False)
            acc(w, dw)
            if b is not None:
                acc(b, B.sum_ch(dy))
    record([y], [x, w, b], bw)
    return y


def batchnorm(x: Tensor, gamma: Tensor, beta: Tensor, rmean: Tensor, rvar: Tensor, train: bool,
              momentum: float = 0.03, eps: float = 1e-3) -> Tensor:
    B = x.dev.be
    y, mean, istd = B.bn_fwd(x, gamma, beta, rmean, rvar, momentum, eps, train)

    def bw():
        dy, y.grad = y.grad, None
        if dy is None:
            return
        dx, dg, db = B.bn_bwd(x, dy, gamma, mean, istd, rmean, rvar, eps, train)
        acc(x, dx)
        acc(gamma, dg)
        acc(beta, db)
    record([y], [x, gamma, beta], bw)
    return y


def act(kind: int, x: Tensor, slope: float = 0.0) -> Tensor:
    B = x.dev.be
    y = B.act_fwd(kind, x, slope)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.act_bwd(kind, x, y, dy, slope))
    record([y], [x], bw)
    return y


def maxpool(x: Tensor, k=(2, 2), s=(2, 2), p=(0, 0, 0, 0)) -> Tensor:
    """Max pooling. ``p`` = (top, bottom, left, right); padded positions never win."""
    B = x.dev.be
    N, C, H, W = x.shape
    oshape = (N, C, out_size(H, k[0], s[0], p[0], p[1]), out_size(W, k[1], s[1], p[2], p[3]))
    y, idx = B.maxpool_fwd(x, (k[0], k[1], s[0], s[1], p[0], p[2]), oshape)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.maxpool_bwd(dy, idx, x.shape))
    record([y], [x], bw)
    return y


def avgpool(x: Tensor, k=(2, 2), s=(2, 2), p=(0, 0, 0, 0)) -> Tensor:
    """Average pooling (padded positions count as zeros). ``p`` = (top, bottom, left, right)."""
    B = x.dev.be
    N, C, H, W = x.shape
    win = (k[0], k[1], s[0], s[1], p[0], p[2])
    oshape = (N, C, out_size(H, k[0], s[0], p[0], p[1]), out_size(W, k[1], s[1], p[2], p[3]))
    y = B.avgpool_fwd(x, win, oshape)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.avgpool_bwd(dy, win, x.shape))
    record([y], [x], bw)
    return y


def neg(x: Tensor) -> Tensor:
    B = x.dev.be
    if hasattr(B, "neg"):
        y = B.neg(x)
    else:
        y = B.clone(x)
        B.scale(y, -1.0)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            d = B.clone(dy)
            B.scale(d, -1.0)
            acc(x, d)
    record([y], [x], bw)
    return y


def minpool(x: Tensor, k=(2, 2), s=(2, 2), p=(0, 0, 0, 0)) -> Tensor:
    """Min pooling: the smallest value in each window (padded positions never win)."""
    return neg(maxpool(neg(x), k, s, p))


def global_avgpool(x: Tensor) -> Tensor:
    return avgpool(x, (x.shape[2], x.shape[3]), (1, 1), (0, 0, 0, 0))


def global_maxpool(x: Tensor) -> Tensor:
    return maxpool(x, (x.shape[2], x.shape[3]), (1, 1), (0, 0, 0, 0))


def upsample(x: Tensor, OH: int, OW: int) -> Tensor:
    """Nearest-neighbour resize to (OH, OW)."""
    B = x.dev.be
    y = B.upsample_fwd(x, OH, OW)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.upsample_bwd(dy, x.shape))
    record([y], [x], bw)
    return y


def add(a: Tensor, b: Tensor) -> Tensor:
    B = a.dev.be
    y = B.add(a, b)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(a, dy, own=False)
            acc(b, dy, own=True)
    record([y], [a, b], bw)
    return y


def mul(x: Tensor, s: Tensor) -> Tensor:
    """x * s where every dim of ``s`` equals x's or is 1 (e.g. per-channel or per-pixel scaling)."""
    B = x.dev.be
    y = B.mul_bc(x, s)

    def bw():
        dy, y.grad = y.grad, None
        if dy is None:
            return
        if x.rg:
            acc(x, B.mul_bc(dy, s))
        if s.rg:
            acc(s, B.mul_reduce(dy, x, s.shape))
    record([y], [x, s], bw)
    return y


def concat(xs: Sequence[Tensor]) -> Tensor:
    """Concatenate along channels."""
    xs = list(xs)
    B = xs[0].dev.be
    y = B.concat(xs)

    def bw():
        dy, y.grad = y.grad, None
        if dy is None:
            return
        off = 0
        for x in xs:
            if x.rg:
                acc(x, B.slice_ch(dy, off, x.shape[1]))
            off += x.shape[1]
    record([y], xs, bw)
    return y


def slice_channels(x: Tensor, off: int, c: int) -> Tensor:
    B = x.dev.be
    y = B.slice_ch(x, off, c)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.pad_ch(dy, off, x.shape[1]))
    record([y], [x], bw)
    return y


def channel_mean(x: Tensor) -> Tensor:
    B = x.dev.be
    y = B.chan_mean(x)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.chan_mean_bwd(dy, x.shape[1]))
    record([y], [x], bw)
    return y


def channel_max(x: Tensor) -> Tensor:
    B = x.dev.be
    y, idx = B.chan_max(x)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.chan_max_bwd(dy, idx, x.shape[1]))
    record([y], [x], bw)
    return y


def space_to_depth(x: Tensor) -> Tensor:
    B = x.dev.be
    y = B.s2d(x)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.s2d_bwd(dy))
    record([y], [x], bw)
    return y


def fake_quant(x: Tensor, scale: float, zero_point: float, qmin: float, qmax: float) -> Tensor:
    """Simulate uniform quantisation; gradients pass straight through inside the representable range."""
    B = x.dev.be
    y = B.fake_quant(x, scale, zero_point, qmin, qmax)

    def bw():
        dy, y.grad = y.grad, None
        if dy is not None:
            acc(x, B.fake_quant_bwd(x, dy, scale, zero_point, qmin, qmax))
    record([y], [x], bw)
    return y
