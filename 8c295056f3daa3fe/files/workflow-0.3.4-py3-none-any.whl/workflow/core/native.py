"""Locate, build and load the native C core (libwfcore)."""
from __future__ import annotations

import ctypes
import hashlib
import os
import platform
import shutil
import subprocess
import sys

from ..errors import BackendError

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "src", "wfcore.c")
ABI = 1


def _cpu_flags() -> set:
    try:
        with open("/proc/cpuinfo") as f:
            for line in f:
                if line.startswith(("flags", "Features")):
                    return set(line.split(":", 1)[1].split())
    except OSError:
        pass
    return set()


def target() -> str:
    """Platform tag of the library to use, e.g. macos-arm64, linux-x86_64-avx2, linux-aarch64."""
    sysname = {"Darwin": "macos", "Linux": "linux"}.get(platform.system(), platform.system().lower())
    mach = platform.machine().lower()
    mach = {"amd64": "x86_64", "arm64": "arm64" if sysname == "macos" else "aarch64"}.get(mach, mach)
    if mach == "x86_64" and sysname == "linux":
        fl = _cpu_flags()
        return f"linux-x86_64-{'avx2' if {'avx2', 'fma'} <= fl else 'avx' if 'avx' in fl else 'sse2'}"
    return f"{sysname}-{mach}"


def cflags(tag: str) -> list:
    extra = {"avx2": ["-mavx2", "-mfma"], "avx": ["-mavx"]}.get(tag.rsplit("-", 1)[-1], [])
    return ["-O3", "-fPIC", "-shared", "-fopenmp-simd", "-fno-math-errno", "-fvisibility=hidden", "-w"] + extra


def libname(tag: str) -> str:
    return "libwfcore.dylib" if tag.startswith("macos") else "libwfcore.so"


def build(tag: str, out_path: str) -> str:
    cc = os.environ.get("CC") or shutil.which("cc") or shutil.which("gcc") or shutil.which("clang")
    if not cc:
        raise BackendError(
            "Workflow's native core is not available for this machine.",
            f"there is no prebuilt library for '{tag}' and no C compiler was found to build it.",
            "install a C compiler (Linux: `sudo apt install gcc`; macOS: `xcode-select --install`) and import workflow again.")
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    tmp = out_path + f".{os.getpid()}.tmp"
    r = subprocess.run([cc] + cflags(tag) + ["-o", tmp, SRC, "-lm", "-lpthread"], capture_output=True, text=True)
    if r.returncode != 0:
        raise BackendError("building Workflow's native core failed.", r.stderr.strip()[-800:] or "the compiler returned an error.",
                           "check that the C compiler works (`cc --version`); set CC=/path/to/compiler to choose another one.")
    os.replace(tmp, out_path)
    return out_path


def load() -> ctypes.CDLL:
    tag = target()
    if platform.system() == "Windows":
        raise BackendError("Workflow's native core does not support Windows yet.",
                           "the CPU kernels use POSIX threads and no Windows build is shipped.",
                           "run Workflow under WSL2 (Linux on Windows), or on Linux/macOS.")
    candidates = [os.path.join(HERE, "lib", tag, libname(tag))]
    if tag.startswith("linux-x86_64"):                           # fall back to slower builds the CPU still supports
        order = ["avx2", "avx", "sse2"]
        for t in order[order.index(tag.rsplit("-", 1)[-1]) + 1:]:
            candidates.append(os.path.join(HERE, "lib", f"linux-x86_64-{t}", libname(tag)))
    for path in candidates:
        if os.path.exists(path):
            try:
                lib = ctypes.CDLL(path)
                if lib.wf_abi() == ABI:
                    return lib
            except OSError:
                continue                                         # e.g. built against a newer libc: build locally instead
    with open(SRC, "rb") as f:
        digest = hashlib.sha1(f.read()).hexdigest()[:12]
    cache = os.path.join(os.environ.get("WORKFLOW_CACHE") or os.path.join(os.path.expanduser("~"), ".cache", "workflow"),
                         f"{tag}-{digest}", libname(tag))
    if not os.path.exists(cache):
        build(tag, cache)
    try:
        return ctypes.CDLL(cache)
    except OSError as e:
        raise BackendError("Workflow's native core could not be loaded.", str(e),
                           f"delete {os.path.dirname(cache)} and import workflow again to rebuild it.") from None
