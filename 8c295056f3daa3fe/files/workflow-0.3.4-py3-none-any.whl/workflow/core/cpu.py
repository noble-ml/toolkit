"""CPU backend: ctypes bindings to the native C core."""
from __future__ import annotations

import ctypes as C
from typing import Tuple

from . import native
from .tensor import Buf, Tensor, numel

_T = {"p": C.c_void_p, "i": C.c_int, "l": C.c_long, "f": C.c_float, "d": C.c_double, "Q": C.c_uint64}
_I16 = "i" * 16
SIGS = {
    "wf_alloc": ("l", "p"), "wf_free": ("p", None), "wf_fill": ("plf", None), "wf_copy": ("ppl", None),
    "wf_axpy": ("pplf", None), "wf_scale": ("plf", None), "wf_add": ("pppl", None), "wf_ema": ("pplf", None),
    "wf_sumsq": ("pl", "d"), "wf_minmax": ("plp", None), "wf_adamw": ("pppplfffffi", None), "wf_sgd": ("ppplfff", None),
    "wf_act_fwd": ("ipplf", None), "wf_act_bwd": ("ipppplf", None),
    "wf_conv2d_fwd": ("pppp" + _I16, None), "wf_conv2d_bwd_data": ("ppp" + _I16, None),
    "wf_conv2d_bwd_weight": ("pppp" + _I16, None),
    "wf_bn_fwd": ("pppppppp" + "iilffi", None), "wf_bn_bwd": ("p" * 10 + "iilfi", None),
    "wf_maxpool_fwd": ("pppl" + "i" * 10, None), "wf_avgpool_fwd": ("ppl" + "i" * 10, None),
    "wf_maxpool_bwd": ("pppliiii", None), "wf_avgpool_bwd": ("ppl" + "i" * 10, None),
    "wf_upsample_fwd": ("ppliiii", None), "wf_upsample_bwd": ("ppliiii", None),
    "wf_copy_ch": ("piipiil", None), "wf_slice_ch": ("piipiil", None),
    "wf_mul_bc": ("ppp" + "i" * 8, None), "wf_mul_reduce": ("ppp" + "i" * 8, None),
    "wf_chan_mean": ("ppiil", None), "wf_chan_mean_bwd": ("ppiil", None),
    "wf_chan_max": ("pppiil", None), "wf_chan_max_bwd": ("pppiil", None),
    "wf_space_to_depth": ("ppiiiii", None),
    "wf_fake_quant": ("pplffff", None), "wf_fake_quant_bwd": ("ppplffff", None),
    "wf_quantize_i8": ("pplf", None), "wf_dequantize_i8": ("pplf", None),
    "wf_sum_ch": ("ppiil", None), "wf_add_ch": ("ppiil", None),
    "wf_det_loss": ("ipppp" + "iiii" + "pi" + "fff" + "p", "d"),
    "wf_decode": ("ippp" + "iiii" + "ff" + "ii" + "pp", None),
    "wf_letterbox": ("piip" + "iiiiii" + "f" + "i" + "ff", None),
    "wf_uniform": ("plffQ", None), "wf_set_threads": ("i", None), "wf_threads": ("", "i"),
}
_lib = None


def lib():
    global _lib
    if _lib is None:
        L = native.load()
        for name, (args, res) in SIGS.items():
            fn = getattr(L, name)
            fn.argtypes = [_T[c] for c in args]
            fn.restype = _T[res] if res else None
        _lib = L
    return _lib


class CpuBackend:
    name = "cpu"

    def __init__(self):
        self.L = lib()
        self.pool = {}
        self.pooled = 0

    # ---- memory
    def _alloc(self, n: int):
        free = self.pool.get(n)
        if free:
            self.pooled -= n
            return free.pop()
        p = self.L.wf_alloc(n)
        if not p:
            raise MemoryError(f"could not allocate {n * 4 / 2**20:.0f} MB")
        return p

    def release(self, h, n):
        if self.pooled + n <= 64 * 2**20:                       # keep up to 256 MB of buffers for reuse
            self.pool.setdefault(n, []).append(h)
            self.pooled += n
        else:
            self.L.wf_free(h)

    def empty(self, shape) -> Tensor:
        n = numel(shape)
        return Tensor(shape, self.dev, Buf(self, self._alloc(n), n))

    def zeros(self, shape) -> Tensor:
        t = self.empty(shape)
        C.memset(t.h, 0, t.size * 4)
        return t

    def from_bytes(self, shape, data) -> Tensor:
        t = self.empty(shape)
        if len(data) != t.size * 4:
            raise ValueError(f"expected {t.size * 4} bytes for shape {tuple(shape)}, got {len(data)}")
        C.memmove(t.h, bytes(data) if not isinstance(data, (bytes, bytearray)) else data, len(data))
        return t

    def tobytes(self, t) -> bytes:
        return C.string_at(t.h, t.size * 4)

    def clone(self, t) -> Tensor:
        o = self.empty(t.shape)
        self.L.wf_copy(o.h, t.h, t.size)
        return o

    def fill(self, t, v):
        self.L.wf_fill(t.h, t.size, v)

    def uniform(self, shape, lo, hi, seed) -> Tensor:
        t = self.empty(shape)
        self.L.wf_uniform(t.h, t.size, lo, hi, seed)
        return t

    def host(self, t) -> Tensor:
        """A CPU tensor holding the same values (identity here; a download on GPU backends)."""
        return t

    def sync(self):
        pass

    # ---- arithmetic
    def axpy(self, y, x, a):
        self.L.wf_axpy(y.h, x.h, y.size, a)

    def scale(self, x, a):
        self.L.wf_scale(x.h, x.size, a)

    def add(self, a, b) -> Tensor:
        y = self.empty(a.shape)
        self.L.wf_add(y.h, a.h, b.h, a.size)
        return y

    def sumsq(self, x) -> float:
        return self.L.wf_sumsq(x.h, x.size)

    def minmax(self, x) -> Tuple[float, float]:
        out = (C.c_float * 2)()
        self.L.wf_minmax(x.h, x.size, out)
        return out[0], out[1]

    def adamw(self, p, g, m, v, lr, b1, b2, eps, wd, step):
        self.L.wf_adamw(p.h, g.h, m.h, v.h, p.size, lr, b1, b2, eps, wd, step)

    def sgd(self, p, g, m, lr, mom, wd):
        self.L.wf_sgd(p.h, g.h, m.h, p.size, lr, mom, wd)

    def ema(self, shadow, p, d):
        self.L.wf_ema(shadow.h, p.h, p.size, d)

    # ---- convolution. cfg = (sh, sw, pt, pb, pl, pr, dh, dw, groups)
    @staticmethod
    def _cv(xs, ws, cfg):
        N, Cc, H, W = xs
        OC, _, KH, KW = ws
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        return (N, Cc, H, W, OC, KH, KW, sh, sw, pt, pb, pl, pr, dh, dw, G)

    def conv_fwd(self, x, w, b, cfg, oshape) -> Tensor:
        y = self.empty(oshape)
        self.L.wf_conv2d_fwd(x.h, w.h, b.h if b is not None else None, y.h, *self._cv(x.shape, w.shape, cfg))
        return y

    def conv_bwd_data(self, dy, w, cfg, xshape) -> Tensor:
        dx = self.zeros(xshape)
        self.L.wf_conv2d_bwd_data(dy.h, w.h, dx.h, *self._cv(xshape, w.shape, cfg))
        return dx

    def conv_bwd_weight(self, x, dy, cfg, wshape, bias: bool):
        dw = self.zeros(wshape)
        db = self.zeros((wshape[0],)) if bias else None
        self.L.wf_conv2d_bwd_weight(x.h, dy.h, dw.h, db.h if bias else None, *self._cv(x.shape, wshape, cfg))
        return dw, db

    def sum_ch(self, x) -> Tensor:
        N, Cc, H, W = x.shape
        o = self.zeros((Cc,))
        self.L.wf_sum_ch(x.h, o.h, N, Cc, H * W)
        return o

    def add_ch(self, y, b):
        N, Cc, H, W = y.shape
        self.L.wf_add_ch(y.h, b.h, N, Cc, H * W)

    # ---- normalisation / activations
    def bn_fwd(self, x, g, b, rm, rv, mom, eps, train):
        N, Cc, H, W = x.shape
        y = self.empty(x.shape)
        mean, istd = (self.empty((Cc,)), self.empty((Cc,))) if train else (None, None)
        self.L.wf_bn_fwd(x.h, g.h, b.h, rm.h, rv.h, y.h, mean.h if train else None, istd.h if train else None,
                         N, Cc, H * W, mom, eps, int(train))
        return y, mean, istd

    def bn_bwd(self, x, dy, g, mean, istd, rm, rv, eps, train):
        N, Cc, H, W = x.shape
        dx, dg, db = self.empty(x.shape), self.zeros((Cc,)), self.zeros((Cc,))
        self.L.wf_bn_bwd(x.h, dy.h, g.h, mean.h if train else None, istd.h if train else None, rm.h, rv.h,
                         dx.h, dg.h, db.h, N, Cc, H * W, eps, int(train))
        return dx, dg, db

    def act_fwd(self, kind, x, slope=0.0) -> Tensor:
        y = self.empty(x.shape)
        self.L.wf_act_fwd(kind, x.h, y.h, x.size, slope)
        return y

    def act_bwd(self, kind, x, y, dy, slope=0.0) -> Tensor:
        dx = self.empty(x.shape)
        self.L.wf_act_bwd(kind, x.h, y.h, dy.h, dx.h, x.size, slope)
        return dx

    # ---- pooling / resize.  win = (kh, kw, sh, sw, pt, pl)
    def maxpool_fwd(self, x, win, oshape):
        N, Cc, H, W = x.shape
        y, idx = self.empty(oshape), self.empty(oshape)
        self.L.wf_maxpool_fwd(x.h, y.h, idx.h, N * Cc, H, W, oshape[2], oshape[3], *win)
        return y, idx

    def maxpool_bwd(self, dy, idx, xshape) -> Tensor:
        N, Cc, H, W = xshape
        dx = self.zeros(xshape)
        self.L.wf_maxpool_bwd(dy.h, idx.h, dx.h, N * Cc, H, W, dy.shape[2], dy.shape[3])
        return dx

    def avgpool_fwd(self, x, win, oshape) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty(oshape)
        self.L.wf_avgpool_fwd(x.h, y.h, N * Cc, H, W, oshape[2], oshape[3], *win)
        return y

    def avgpool_bwd(self, dy, win, xshape) -> Tensor:
        N, Cc, H, W = xshape
        dx = self.zeros(xshape)
        self.L.wf_avgpool_bwd(dy.h, dx.h, N * Cc, H, W, dy.shape[2], dy.shape[3], *win)
        return dx

    def upsample_fwd(self, x, OH, OW) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty((N, Cc, OH, OW))
        self.L.wf_upsample_fwd(x.h, y.h, N * Cc, H, W, OH, OW)
        return y

    def upsample_bwd(self, dy, xshape) -> Tensor:
        N, Cc, H, W = xshape
        dx = self.zeros(xshape)
        self.L.wf_upsample_bwd(dy.h, dx.h, N * Cc, H, W, dy.shape[2], dy.shape[3])
        return dx

    # ---- channel ops and broadcasting
    def concat(self, xs) -> Tensor:
        N, _, H, W = xs[0].shape
        total = sum(x.shape[1] for x in xs)
        y = self.empty((N, total, H, W))
        off = 0
        for x in xs:
            self.L.wf_copy_ch(y.h, total, off, x.h, x.shape[1], N, H * W)
            off += x.shape[1]
        return y

    def slice_ch(self, x, off, c) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty((N, c, H, W))
        self.L.wf_slice_ch(x.h, Cc, off, y.h, c, N, H * W)
        return y

    def pad_ch(self, dy, off, total) -> Tensor:
        """Zeros of ``total`` channels with ``dy`` placed at channel ``off`` (backward of slice_ch)."""
        N, c, H, W = dy.shape
        dx = self.zeros((N, total, H, W))
        self.L.wf_copy_ch(dx.h, total, off, dy.h, c, N, H * W)
        return dx

    def mul_bc(self, x, s) -> Tensor:
        y = self.empty(x.shape)
        self.L.wf_mul_bc(x.h, s.h, y.h, *x.shape, *s.shape)
        return y

    def mul_reduce(self, a, b, sshape) -> Tensor:
        o = self.zeros(sshape)
        self.L.wf_mul_reduce(a.h, b.h, o.h, *a.shape, *sshape)
        return o

    def chan_mean(self, x) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty((N, 1, H, W))
        self.L.wf_chan_mean(x.h, y.h, N, Cc, H * W)
        return y

    def chan_mean_bwd(self, dy, Cc) -> Tensor:
        N, _, H, W = dy.shape
        dx = self.empty((N, Cc, H, W))
        self.L.wf_chan_mean_bwd(dy.h, dx.h, N, Cc, H * W)
        return dx

    def chan_max(self, x):
        N, Cc, H, W = x.shape
        y, idx = self.empty((N, 1, H, W)), self.empty((N, 1, H, W))
        self.L.wf_chan_max(x.h, y.h, idx.h, N, Cc, H * W)
        return y, idx

    def chan_max_bwd(self, dy, idx, Cc) -> Tensor:
        N, _, H, W = dy.shape
        dx = self.zeros((N, Cc, H, W))
        self.L.wf_chan_max_bwd(dy.h, idx.h, dx.h, N, Cc, H * W)
        return dx

    def s2d(self, x) -> Tensor:
        N, Cc, H, W = x.shape
        y = self.empty((N, 4 * Cc, H // 2, W // 2))
        self.L.wf_space_to_depth(x.h, y.h, N, Cc, H, W, 0)
        return y

    def s2d_bwd(self, dy) -> Tensor:
        N, C4, OH, OW = dy.shape
        dx = self.empty((N, C4 // 4, OH * 2, OW * 2))
        self.L.wf_space_to_depth(dx.h, dy.h, N, C4 // 4, OH * 2, OW * 2, 1)
        return dx

    # ---- quantisation
    def fake_quant(self, x, scale, zp, qmin, qmax) -> Tensor:
        y = self.empty(x.shape)
        self.L.wf_fake_quant(x.h, y.h, x.size, scale, zp, qmin, qmax)
        return y

    def fake_quant_bwd(self, x, dy, scale, zp, qmin, qmax) -> Tensor:
        dx = self.empty(x.shape)
        self.L.wf_fake_quant_bwd(x.h, dy.h, dx.h, x.size, scale, zp, qmin, qmax)
        return dx
