"""Tensors, devices and the autograd tape."""
from __future__ import annotations

import array
import struct
import threading
from contextlib import contextmanager
from typing import Callable, List, Optional, Sequence, Tuple


class Buf:
    """Owns one backend allocation; freed (returned to the backend's pool) when the last tensor drops it."""
    __slots__ = ("be", "h", "n")

    def __init__(self, be, h, n):
        self.be, self.h, self.n = be, h, n

    def __del__(self):
        try:
            self.be.release(self.h, self.n)
        except Exception:
            pass


def numel(shape: Sequence[int]) -> int:
    n = 1
    for v in shape:
        n *= int(v)
    return n


class Tensor:
    """A float32 array on a device. ``rg`` marks tensors that take part in gradient computation."""
    __slots__ = ("shape", "dev", "buf", "rg", "grad", "__weakref__")

    def __init__(self, shape, dev, buf):
        self.shape, self.dev, self.buf = tuple(int(s) for s in shape), dev, buf
        self.rg, self.grad = False, None

    # -- construction
    @staticmethod
    def zeros(shape, dev) -> "Tensor":
        return dev.be.zeros(shape)

    @staticmethod
    def full(shape, value, dev) -> "Tensor":
        t = dev.be.empty(shape)
        dev.be.fill(t, value)
        return t

    @staticmethod
    def from_bytes(shape, data, dev) -> "Tensor":
        return dev.be.from_bytes(shape, data)

    @staticmethod
    def from_list(values, shape, dev) -> "Tensor":
        return dev.be.from_bytes(shape, array.array("f", values).tobytes())

    # -- access
    @property
    def size(self) -> int:
        return numel(self.shape)

    @property
    def h(self):
        return self.buf.h

    def tobytes(self) -> bytes:
        return self.dev.be.tobytes(self)

    def tolist(self) -> List[float]:
        """Flat list of the values (row-major)."""
        return list(struct.unpack(f"<{self.size}f", self.tobytes()))

    def item(self) -> float:
        return self.tolist()[0]

    def clone(self) -> "Tensor":
        return self.dev.be.clone(self)

    def view(self, shape) -> "Tensor":
        """Same memory, another shape (no gradient tracking)."""
        return Tensor(shape, self.dev, self.buf)

    def to(self, dev) -> "Tensor":
        if dev is self.dev:
            return self
        host = self.dev.be.host(self)                       # a CPU tensor (identity on cpu)
        if dev.kind == "cpu":
            return host
        return dev.be.from_host(host) if hasattr(dev.be, "from_host") else dev.be.from_bytes(self.shape, host.tobytes())

    def __repr__(self):
        return f"Tensor(shape={self.shape}, device={self.dev})"


# ----------------------------------------------------------------- autograd tape
_state = threading.local()


def _tape() -> list:
    if not hasattr(_state, "tape"):
        _state.tape, _state.on = [], True
    return _state.tape


def grad_enabled() -> bool:
    _tape()
    return _state.on


@contextmanager
def no_grad():
    _tape()
    old, _state.on = _state.on, False
    try:
        yield
    finally:
        _state.on = old


def record(outs: Sequence[Tensor], inputs: Sequence[Optional[Tensor]], fn: Callable[[], None]) -> None:
    """Register ``fn`` to run during backward if any input needs a gradient."""
    if grad_enabled() and any(t is not None and t.rg for t in inputs):
        for o in outs:
            o.rg = True
        _tape().append(fn)


def acc(t: Optional[Tensor], g: Tensor, own: bool = True) -> None:
    """Accumulate gradient ``g`` into ``t.grad``. ``own=False`` copies ``g`` if it must be kept."""
    if t is None or not t.rg:
        return
    if t.grad is None:
        t.grad = g if own else g.clone()
    else:
        t.dev.be.axpy(t.grad, g, 1.0)


def backward() -> None:
    """Run the recorded operations in reverse. Seed gradients by setting ``.grad`` on the outputs first."""
    tape = _tape()
    try:
        for fn in reversed(tape):
            fn()
    finally:
        tape.clear()


def clear_tape() -> None:
    _tape().clear()
