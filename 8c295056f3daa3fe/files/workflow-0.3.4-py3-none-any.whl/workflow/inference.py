"""``wf.inference(source, model, output)``: run a model on anything and keep the evidence.

The source is detected automatically: an image, a video, a folder (of images and/or videos), a Felix dataset (its
``test`` split unless another is chosen), or a loaded Felix dataset / split. The output folder receives
``original/`` (the inputs, untouched), ``annotated/`` (boxes drawn) and ``predictions.json``.
"""
from __future__ import annotations

import json
import os
import random
import shutil
from datetime import datetime, timezone
from typing import Dict, List, Optional

from . import _ui
from .data import IMAGE_EXT
from .errors import DataError, WorkflowError
from .results import Predictions, Results

VIDEO_EXT = (".mp4", ".avi", ".mov", ".mkv", ".webm", ".m4v", ".mpg", ".mpeg", ".wmv")
SPLITS = ("train", "val", "test")


class Inference:
    """What ``wf.inference`` produced: ``images`` (a list of Results), ``videos`` ({name: per-frame detections}),
    ``output`` (the folder) and ``json`` (the contents of predictions.json)."""

    def __init__(self, output, images, videos, doc):
        self.output, self.images, self.videos, self.json = output, images, videos, doc
        self.json_path = os.path.join(output, "predictions.json")

    def __len__(self):
        return len(self.images) + len(self.videos)

    def __repr__(self):
        n_img = sum(len(r) for r in self.images)
        n_vid = sum(len(d) for frames in self.videos.values() for d in frames)
        parts = []
        if self.images:
            parts.append(f"{len(self.images)} image(s), {n_img} detections")
        if self.videos:
            parts.append(f"{len(self.videos)} video(s), {n_vid} detections")
        return f"Inference({'; '.join(parts) or 'nothing'} → {self.output})"


# ------------------------------------------------------------------ source detection
class _Item:
    """One thing to run: an image (from a file, a dataset or memory) or a video file."""

    def __init__(self, kind, name, src, original=None, dataset=None, stem=None):
        self.kind, self.name, self.src, self.original, self.dataset, self.stem = kind, name, src, original, dataset, stem


def _is_felix_dir(path):
    return os.path.isdir(path) and os.path.isfile(os.path.join(path, "metadata.yml")) and os.path.isdir(os.path.join(path, "annotations"))


def _pick_split(ds, split, label):
    """A Felix dataset → the requested split, else test (then val, then everything)."""
    if not hasattr(ds, "splits"):                       # already a split / subset
        return ds, getattr(ds, "name", "split")
    if split is not None:
        if split not in SPLITS:
            raise WorkflowError(f"unknown split {split!r}.", f"Felix datasets have {', '.join(SPLITS)}.", "use split='test', 'val' or 'train'.")
        chosen = getattr(ds, split)
        if not len(chosen):
            raise DataError(f"the {split} split of {label} is empty.", f"its splits are {ds.splits}.", "pick a split that has images.")
        return chosen, split
    for name in ("test", "val"):
        if len(getattr(ds, name)):
            return getattr(ds, name), name
    return ds, "all"


def _dataset_items(ds, label) -> List[_Item]:
    items = []
    for stem in ds.stems:
        ann = ds.annotation(stem)
        items.append(_Item("image", ann.get("image", f"{stem}.png"), None, dataset=ds, stem=stem))
    return items


def collect(source, split=None):
    """(items, description of what was found)."""
    if hasattr(source, "stems") and hasattr(source, "annotation"):           # a loaded Felix dataset or split
        ds, used = _pick_split(source, split, "the dataset")
        return _dataset_items(ds, "dataset"), f"Felix dataset · {used} split · {len(ds)} images"
    if isinstance(source, (list, tuple)):
        items, kinds = [], []
        for s in source:
            it, what = collect(s, split)
            items += it
            kinds.append(what)
        return items, f"{len(source)} sources"
    if not isinstance(source, (str, os.PathLike)):
        from .data import load_image
        load_image(source)                                                   # raises a clear DataError if unusable
        return [_Item("image", "image.png", source)], "1 image (in memory)"
    path = os.fspath(source)
    low = path.lower().rstrip("/\\")
    if not os.path.exists(path):
        raise DataError(f"nothing found at {path!r}.", "the path does not exist.", "check the spelling and that the file or folder exists.")
    if low.endswith(".felix") or _is_felix_dir(path):
        try:
            import felix
        except ImportError:
            raise DataError("this is a Felix dataset, but Felix is not installed.", "datasets are read through Felix.", "install felix.") from None
        ds = felix.load(path)
        sub, used = _pick_split(ds, split, os.path.basename(low))
        note = "" if split else (" (picked automatically)" if used != "all" else " (no splits, using every image)")
        return _dataset_items(sub, path), f"Felix dataset {os.path.basename(low)} · {used} split{note} · {len(sub)} images"
    if os.path.isdir(path):
        files = sorted(os.listdir(path))
        imgs = [f for f in files if f.lower().endswith(IMAGE_EXT)]
        vids = [f for f in files if f.lower().endswith(VIDEO_EXT)]
        if not imgs and not vids:
            raise DataError(f"no images or videos in {path!r}.",
                            f"inference looks for {', '.join(IMAGE_EXT)} images and {', '.join(VIDEO_EXT)} videos (not in subfolders).",
                            "point it at the folder that holds the files, or at a single file.")
        items = [_Item("image", f, os.path.join(path, f), original=os.path.join(path, f)) for f in imgs]
        items += [_Item("video", f, os.path.join(path, f), original=os.path.join(path, f)) for f in vids]
        return items, f"folder {os.path.basename(low)} · {len(imgs)} images, {len(vids)} videos"
    if low.endswith(IMAGE_EXT):
        return [_Item("image", os.path.basename(path), path, original=path)], "1 image"
    if low.endswith(VIDEO_EXT):
        return [_Item("video", os.path.basename(path), path, original=path)], "1 video"
    raise DataError(f"cannot tell what {os.path.basename(path)!r} is.",
                    f"inference reads images ({', '.join(IMAGE_EXT)}), videos ({', '.join(VIDEO_EXT)}), folders and Felix datasets.",
                    "convert the file to one of those formats.")


def _is_collection(source) -> bool:
    """A dataset or a folder (one item is picked unless all=True). Single files and lists you pass run as given."""
    if hasattr(source, "stems"):
        return True
    if isinstance(source, (str, os.PathLike)):
        path = os.fspath(source)
        return os.path.isdir(path) or path.lower().rstrip("/\\").endswith(".felix")
    return False


# ------------------------------------------------------------------ running
def _unique(name, used):
    stem, ext = os.path.splitext(name)
    out, n = name, 1
    while out.lower() in used:
        n += 1
        out = f"{stem}_{n}{ext}"
    used.add(out.lower())
    return out


def _video(model, item, out_dir, used, panel, settings):
    try:
        import cv2
        import numpy as np
    except ImportError:
        raise DataError(f"{item.name} is a video, which needs OpenCV.", "Workflow reads and writes video frames through OpenCV.",
                        "run `pip install opencv-python`.") from None
    cap = cv2.VideoCapture(item.src)
    if not cap.isOpened():
        raise DataError(f"could not open the video {item.name!r}.", "OpenCV could not decode it (damaged file or unsupported codec).",
                        "re-encode it as H.264 MP4, e.g. with ffmpeg.")
    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    row = panel.row(item.name, max(total, 1))
    name = _unique(os.path.splitext(item.name)[0] + ".mp4", used["annotated"])
    annotated = os.path.join(out_dir, "annotated", name)
    writer, frames, index = None, [], 0
    try:
        while True:
            batch = []
            for _ in range(settings["batch_size"]):
                ok, frame = cap.read()
                if not ok:
                    break
                batch.append(frame)
            if not batch:
                break
            rgb = [cv2.cvtColor(f, cv2.COLOR_BGR2RGB) for f in batch]
            res = model.predict(rgb, output=None, **settings["predict"])
            for r in res:
                drawn = np.asarray(r.plot())[:, :, ::-1]
                if writer is None:
                    h, w = drawn.shape[:2]
                    writer = cv2.VideoWriter(annotated, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
                writer.write(np.ascontiguousarray(drawn))
                frames.append([dict(d) for d in r])
                index += 1
            row.label = f"frame {index:,}" + (f"/{total:,}" if total else "")
            row.n = min(index, row.total)
            row.status = "running"
            panel.refresh()
    finally:
        cap.release()
        if writer is not None:
            writer.release()
    original = os.path.join(out_dir, "original", _unique(item.name, used["original"]))
    shutil.copy2(item.src, original)
    row.done()
    row.stats = panel.join(f"{index:,} frames", f"{sum(len(f) for f in frames):,} detections")
    return frames, {"video": item.name, "original": os.path.relpath(original, out_dir), "annotated": os.path.relpath(annotated, out_dir),
                    "fps": fps, "frames": index, "detections": frames}


def inference(source, model, output: str = "results/", all: bool = False, split: Optional[str] = None,
              confidence: float = 0.25, iou: float = 0.45, img_size=None, device: Optional[str] = None,
              batch_size: int = 16, quiet: bool = False) -> Inference:
    """Run ``model`` (a Workflow model or the path of a ``.nbm``) on ``source`` and save everything to ``output``.

    ``source`` is detected automatically: an image, a video, a folder of images/videos, a Felix dataset (its test split
    is picked unless you pass ``split="val"`` / ``"train"`` or a split such as ``data.val``), or a list of these.
    For a dataset or a folder, **one randomly chosen item** is run unless ``all=True``; single files and lists run as given.
    ``output`` receives ``original/`` (the inputs, untouched), ``annotated/`` (boxes drawn) and ``predictions.json``."""
    if isinstance(model, (str, os.PathLike)):
        from .nbm import load
        model_name, model = os.path.basename(os.fspath(model)), load(model)
    elif hasattr(model, "predict") and hasattr(model, "head"):
        model_name = "model"
    else:
        raise WorkflowError(f"the model argument is {type(model).__name__}, not a model.",
                            "wf.inference(source, model, output) needs a Workflow model or a .nbm path as its second argument.",
                            "pass model = wf.load('detector.nbm'), or the path itself.")
    model.head()
    items, found = collect(source, split)
    if _is_collection(source) and not all and len(items) > 1:
        pick = random.choice(items)
        found = f"{found} · 1 picked at random ({pick.name}); all=True runs every item"
        items = [pick]
    out_dir = os.fspath(output)
    for sub in ("original", "annotated"):
        os.makedirs(os.path.join(out_dir, sub), exist_ok=True)
    settings = {"batch_size": batch_size, "predict": dict(device=device, confidence=confidence, iou=iou, img_size=img_size)}
    images = [i for i in items if i.kind == "image"]
    videos = [i for i in items if i.kind == "video"]
    used = {"original": set(), "annotated": set()}
    panel = _ui.Panel("", quiet=quiet)
    panel.title = panel.join("Workflow inference", found, f"→ {out_dir}")
    panel.sub = panel.join(model_name, f"confidence {confidence}", f"iou {iou}")
    image_docs, image_results = [], Predictions()
    video_docs, video_frames = [], {}
    with panel:
        if images:
            row = panel.row("images", len(images))
            for start in range(0, len(images), batch_size):
                chunk = images[start:start + batch_size]
                srcs = [it.dataset.image(it.stem) if it.dataset is not None else it.src for it in chunk]
                res = model.predict(srcs, output=None, **settings["predict"])
                for it, r in zip(chunk, res):
                    base = os.path.splitext(it.name)[0]
                    if it.dataset is not None:                     # the dataset's own bytes, untouched
                        oname = _unique(it.name, used["original"])
                        with open(os.path.join(out_dir, "original", oname), "wb") as f:
                            f.write(it.dataset.image_bytes(it.stem))
                    elif it.original is not None:
                        oname = _unique(it.name, used["original"])
                        shutil.copy2(it.original, os.path.join(out_dir, "original", oname))
                    else:
                        from PIL import Image
                        oname = _unique(base + ".png", used["original"])
                        Image.frombytes("RGB", (r.width, r.height), r._rgb).save(os.path.join(out_dir, "original", oname))
                    aname = _unique(base + ".png", used["annotated"])
                    r.saved_to = r.save(os.path.join(out_dir, "annotated", aname))
                    r.path = r.path or it.name
                    image_results.append(r)
                    image_docs.append({"image": it.name, "original": f"original/{oname}", "annotated": f"annotated/{aname}",
                                       "width": r.width, "height": r.height, "detections": list(r)})
                row.n, row.status = min(start + len(chunk), row.total), "running"
                row.label = f"image {row.n:,}/{row.total:,}"
                panel.refresh()
            row.done()
            row.stats = panel.join(f"{sum(len(r) for r in image_results):,} detections", f"saved to {out_dir}")
        for it in videos:
            frames, doc = _video(model, it, out_dir, used, panel, settings)
            video_frames[it.name] = frames
            video_docs.append(doc)
    doc = {"model": model_name, "classes": model.class_names, "source": found,
           "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "settings": {"confidence": confidence, "iou": iou, "img_size": img_size}, "images": image_docs, "videos": video_docs}
    with open(os.path.join(out_dir, "predictions.json"), "w", encoding="utf-8") as f:
        json.dump(doc, f, indent=1)
    return Inference(out_dir, image_results, video_frames, doc)
