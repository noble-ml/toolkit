"""Composite architectural blocks: Bottleneck, CSP, SPP, SPPF, SE, CBAM, Focus."""
from __future__ import annotations

from typing import Optional, Sequence

from .compose import Stack, cba
from .core import ops
from .errors import ShapeError, WorkflowError
from .layer import Layer, positive, single
from .layers import Conv2D, MaxPool2D, PointwiseConv2D


class Bottleneck(Layer):
    """Residual bottleneck: 1x1 reduce → kxk spatial → 1x1 expand, plus a shortcut.

    ``wf.Bottleneck(filters=None, kernel_size=3, stride=1, reduction=2, shortcut=True)``

    The hidden width is ``filters / reduction``. With ``shortcut=True`` the input is added to the result: directly
    when the shape is unchanged, otherwise through a 1x1 Conv-BN projection (different ``filters`` or ``stride`` > 1),
    so the two paths always match. The sum is followed by SiLU."""

    def __init__(self, filters: Optional[int] = None, kernel_size: int = 3, stride: int = 1, reduction: int = 2, shortcut: bool = True):
        self.filters = positive(filters, "filters", optional=True)
        self.k, self.stride, self.reduction = positive(kernel_size, "kernel_size"), positive(stride, "stride"), positive(reduction, "reduction")
        if self.k % 2 == 0:
            raise WorkflowError(f"Bottleneck kernel_size={kernel_size} is even.", "the block pads by kernel_size//2 to keep sizes aligned, which needs an odd kernel.",
                                "use kernel_size=3 or 5.")
        self.shortcut = bool(shortcut)
        self.body = self.proj = None

    def children(self):
        return ([("body", self.body)] if self.body else []) + ([("proj", self.proj)] if self.proj else [])

    def infer(self, shape, ctx):
        c, h, w = single(shape, "Bottleneck")
        out_c = self.filters or c
        hidden = max(1, out_c // self.reduction)
        if self.body is None:
            self.body = Stack(*cba(hidden, 1), *cba(hidden, self.k, self.stride), *cba(out_c, 1, act=False))
            if self.shortcut and (out_c != c or self.stride != 1):
                self.proj = Stack(*cba(out_c, 1, self.stride, act=False))
        out = self.body.infer((c, h, w), ctx)
        if self.proj is not None:
            carried = self.proj.infer((c, h, w), ctx)
            if tuple(carried) != tuple(out):       # cannot happen with odd kernels; kept as a guard
                raise ShapeError("Bottleneck's shortcut does not match its body.", f"body {out}, shortcut {carried}.", "use an odd kernel_size.")
        return out

    def run(self, x, ctx):
        y = self.body.run(x, ctx)
        if self.shortcut:
            y = ops.add(y, self.proj.run(x, ctx) if self.proj is not None else x)
        return ops.act(ops.SILU, y)


class CSP(Layer):
    """Cross-stage-partial block: split in two paths, run ``n`` Bottlenecks on one, concatenate, fuse.

    ``wf.CSP(filters=None, n=1, shortcut=True)``; ``filters`` defaults to the input channels."""

    def __init__(self, filters: Optional[int] = None, n: int = 1, shortcut: bool = True):
        self.filters, self.n, self.shortcut = positive(filters, "filters", optional=True), positive(n, "n"), bool(shortcut)
        self.a = self.b = self.m = self.fuse = None

    def children(self):
        return [(k, v) for k, v in (("a", self.a), ("b", self.b), ("m", self.m), ("fuse", self.fuse)) if v]

    def infer(self, shape, ctx):
        c, h, w = single(shape, "CSP")
        out_c = self.filters or c
        hidden = max(1, out_c // 2)
        if self.a is None:
            self.a, self.b = Stack(*cba(hidden, 1)), Stack(*cba(hidden, 1))
            self.m = Stack(*[Bottleneck(hidden, reduction=1, shortcut=self.shortcut) for _ in range(self.n)])
            self.fuse = Stack(*cba(out_c, 1))
        ya = self.m.infer(self.a.infer((c, h, w), ctx), ctx)
        yb = self.b.infer((c, h, w), ctx)
        return self.fuse.infer((ya[0] + yb[0], h, w), ctx)

    def run(self, x, ctx):
        return self.fuse.run(ops.concat([self.m.run(self.a.run(x, ctx), ctx), self.b.run(x, ctx)]), ctx)


class SPP(Layer):
    """Spatial pyramid pooling: parallel max-pools of several sizes, concatenated with the input.

    ``wf.SPP(filters=None, kernels=(5, 9, 13))``; keeps the resolution."""

    def __init__(self, filters: Optional[int] = None, kernels: Sequence[int] = (5, 9, 13)):
        self.filters = positive(filters, "filters", optional=True)
        self.kernels = tuple(kernels)
        if not self.kernels or any(not isinstance(k, int) or k < 3 or k % 2 == 0 for k in self.kernels):
            raise WorkflowError(f"invalid SPP kernels {kernels!r}.", "each pooling kernel must be an odd integer of at least 3 so the size is kept.",
                                "use for example kernels=(5, 9, 13).")
        self.pre = self.post = None
        self.pools = [MaxPool2D(k, stride=1, padding=k // 2) for k in self.kernels]

    def children(self):
        return [(k, v) for k, v in (("pre", self.pre), ("post", self.post)) if v]

    def _chain(self):
        return False

    def infer(self, shape, ctx):
        c, h, w = single(shape, type(self).__name__)
        out_c = self.filters or c
        hidden = max(1, c // 2)
        if self.pre is None:
            self.pre, self.post = Stack(*cba(hidden, 1)), Stack(*cba(out_c, 1))
        s = self.pre.infer((c, h, w), ctx)
        return self.post.infer((s[0] * (len(self.pools) + 1), h, w), ctx)

    def run(self, x, ctx):
        x = self.pre.run(x, ctx)
        outs, cur = [x], x
        for p in self.pools:
            cur = p.run(cur if self._chain() else x, ctx)
            outs.append(cur)
        return self.post.run(ops.concat(outs), ctx)


class SPPF(SPP):
    """Fast SPP: three chained max-pools of one size (equivalent to growing kernels, cheaper).

    ``wf.SPPF(filters=None, kernel_size=5)``."""

    def __init__(self, filters: Optional[int] = None, kernel_size: int = 5):
        SPP.__init__(self, filters, (kernel_size,) * 3)

    def _chain(self):
        return True


class SE(Layer):
    """Squeeze-and-excitation: reweights channels using global context. ``wf.SE(reduction=16)``; keeps the shape."""

    def __init__(self, reduction: int = 16):
        self.reduction = positive(reduction, "reduction")
        self.fc1 = self.fc2 = None

    def children(self):
        return [(k, v) for k, v in (("fc1", self.fc1), ("fc2", self.fc2)) if v]

    def infer(self, shape, ctx):
        c, h, w = single(shape, "SE")
        if self.fc1 is None:
            self.fc1, self.fc2 = PointwiseConv2D(max(1, c // self.reduction)), PointwiseConv2D(c)
        self.fc2.infer(self.fc1.infer((c, 1, 1), ctx), ctx)
        return (c, h, w)

    def run(self, x, ctx):
        s = ops.act(ops.RELU, self.fc1.run(ops.global_avgpool(x), ctx))
        return ops.mul(x, ops.act(ops.SIGMOID, self.fc2.run(s, ctx)))


class CBAM(Layer):
    """Convolutional block attention: channel attention (avg + max pooled, shared MLP) then spatial attention
    (a kxk convolution over the channel-wise mean and max). ``wf.CBAM(reduction=16, kernel_size=7)``."""

    def __init__(self, reduction: int = 16, kernel_size: int = 7):
        self.reduction, self.k = positive(reduction, "reduction"), positive(kernel_size, "kernel_size")
        if self.k % 2 == 0:
            raise WorkflowError(f"CBAM kernel_size={kernel_size} is even.", "the spatial attention pads by kernel_size//2 to keep the size.", "use 3, 5 or 7.")
        self.fc1 = self.fc2 = self.spatial = None

    def children(self):
        return [(k, v) for k, v in (("fc1", self.fc1), ("fc2", self.fc2), ("spatial", self.spatial)) if v]

    def infer(self, shape, ctx):
        c, h, w = single(shape, "CBAM")
        if self.fc1 is None:
            self.fc1, self.fc2 = PointwiseConv2D(max(1, c // self.reduction)), PointwiseConv2D(c)
            self.spatial = Conv2D(1, kernel_size=self.k, padding=self.k // 2)
        self.fc2.infer(self.fc1.infer((c, 1, 1), ctx), ctx)
        self.spatial.infer((2, h, w), ctx)
        return (c, h, w)

    def _mlp(self, v, ctx):
        return self.fc2.run(ops.act(ops.RELU, self.fc1.run(v, ctx)), ctx)

    def run(self, x, ctx):
        ca = ops.act(ops.SIGMOID, ops.add(self._mlp(ops.global_avgpool(x), ctx), self._mlp(ops.global_maxpool(x), ctx)))
        x = ops.mul(x, ca)
        sa = ops.act(ops.SIGMOID, self.spatial.run(ops.concat([ops.channel_mean(x), ops.channel_max(x)]), ctx))
        return ops.mul(x, sa)


class Focus(Layer):
    """Space-to-depth stem: every 2x2 pixel block becomes 4 channels (no information lost), then a Conv-BN-SiLU.
    Halves height and width. ``wf.Focus(filters, kernel_size=3)``."""

    def __init__(self, filters: int, kernel_size: int = 3):
        self.filters, self.k = positive(filters, "filters"), positive(kernel_size, "kernel_size")
        self.conv = Stack(*cba(self.filters, self.k))

    def children(self):
        return [("conv", self.conv)]

    def infer(self, shape, ctx):
        c, h, w = single(shape, "Focus")
        if h % 2 or w % 2:
            raise ShapeError("Focus needs an even height and width.", f"the input is {h}x{w}; it is split into 2x2 blocks.",
                             "use an even input size (e.g. 640), or add padding before it.")
        return self.conv.infer((4 * c, h // 2, w // 2), ctx)

    def run(self, x, ctx):
        return self.conv.run(ops.space_to_depth(x), ctx)
