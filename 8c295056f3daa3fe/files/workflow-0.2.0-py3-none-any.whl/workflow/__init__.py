"""Workflow - Noble Engineering's CNN architecture and training framework."""
from ._version import __version__
from . import core
from .blocks import CBAM, CSP, SE, SPP, SPPF, Bottleneck, Focus
from .compose import FPN, PAN, Add, Concat, Feature, Head, Parallel, Residual, Stack
from .errors import (BackendError, DataError, DeviceError, RoutingError, SerializationError, ShapeError,
                     WorkflowError, WorkflowWarning)
from .layer import Layer
from .layers import (AvgPool2D, BatchNorm2D, Conv2D, DepthwiseConv2D, DilatedConv2D, LeakyReLU, MaxPool2D,
                     PointwiseConv2D, ReLU, SeparableConv2D, Sigmoid, SiLU, TransposeConv2D, Upsample)

# composition is written in lower case: wf.stack(...), wf.feature("p3"), wf.head(classes=80)
stack, parallel, feature, concat, add, head = Stack, Parallel, Feature, Concat, Add, Head

from .evaluate import Evaluation, evaluate as eval      # wf.eval(model) / wf.eval(model, dataset=val)
from .nbm import load
from .quant import QAT
from .results import Predictions, Results
