"""Apple GPU backend ('mps'), experimental: runs on Metal through MLX, Apple's open-source array library.

Tensors are MLX arrays in NCHW order. Gradients of the heavier operations use MLX's vector-Jacobian products.
"""
from __future__ import annotations

import array
from typing import Tuple

from ..errors import BackendError
from .tensor import Buf, Tensor, numel

_mx = None


def _load():
    global _mx
    if _mx is None:
        import mlx.core as mx
        _mx = mx
    return _mx


def probe() -> Tuple[bool, str]:
    try:
        mx = _load()
    except ImportError:
        return False, "MLX is not installed (it provides Apple GPU support)"
    try:
        if not mx.metal.is_available():
            return False, "this machine has no Metal GPU"
    except Exception as e:  # pragma: no cover
        return False, str(e)
    return True, "Apple GPU through MLX"


class MetalBackend:
    name = "mps"

    def __init__(self):
        ok, why = probe()
        if not ok:
            raise BackendError("the Apple GPU backend is not available.", why, "run `pip install mlx` on an Apple-silicon Mac, or use device='cpu'.")
        self.mx = _load()
        import mlx.nn as nn
        self.nn = nn
        from . import device as _device
        self.cpu = _device.get("cpu")

    # ---- plumbing
    def release(self, h, n):
        pass

    def T(self, a, shape=None) -> Tensor:
        return Tensor(tuple(shape if shape is not None else a.shape), self.dev, Buf(self, a, 0))

    def _set(self, t: Tensor, a):
        """In-place update: evaluate now so lazy graphs never grow across steps."""
        self.mx.eval(a)
        t.buf.h = a

    def empty(self, shape) -> Tensor:
        return self.zeros(shape)

    def zeros(self, shape) -> Tensor:
        return self.T(self.mx.zeros(tuple(shape), dtype=self.mx.float32), shape)

    def from_bytes(self, shape, data) -> Tensor:
        a = self.mx.array(memoryview(bytes(data)).cast("f")).reshape(tuple(shape))
        return self.T(a, shape)

    def from_host(self, t: Tensor) -> Tensor:
        return self.from_bytes(t.shape, t.tobytes())

    def host(self, t) -> Tensor:
        self.mx.eval(t.h)
        return self.cpu.be.from_bytes(t.shape, bytes(memoryview(t.h.astype(self.mx.float32))))

    def tobytes(self, t) -> bytes:
        self.mx.eval(t.h)
        return bytes(memoryview(t.h.astype(self.mx.float32)))

    def clone(self, t) -> Tensor:
        return self.T(t.h + 0, t.shape)

    def fill(self, t, v):
        self._set(t, self.mx.full(t.shape, float(v), dtype=self.mx.float32))

    def sync(self):
        self.mx.eval(self.mx.zeros((1,)))
        self.mx.synchronize() if hasattr(self.mx, "synchronize") else None

    # ---- arithmetic
    def axpy(self, y, x, a):
        self._set(y, y.h + float(a) * x.h)

    def scale(self, x, a):
        self._set(x, x.h * float(a))

    def add(self, a, b) -> Tensor:
        return self.T(a.h + b.h, a.shape)

    def sumsq(self, x) -> float:
        return float((x.h * x.h).sum().item())

    def minmax(self, x):
        return float(x.h.min().item()), float(x.h.max().item())

    def adamw(self, p, g, m, v, lr, b1, b2, eps, wd, step):
        mx = self.mx
        nm = b1 * m.h + (1 - b1) * g.h
        nv = b2 * v.h + (1 - b2) * g.h * g.h
        np_ = p.h - lr * ((nm / (1 - b1 ** step)) / (mx.sqrt(nv / (1 - b2 ** step)) + eps) + wd * p.h)
        mx.eval(nm, nv, np_)
        m.buf.h, v.buf.h, p.buf.h = nm, nv, np_

    def sgd(self, p, g, m, lr, mom, wd):
        nm = mom * m.h + g.h + wd * p.h
        np_ = p.h - lr * nm
        self.mx.eval(nm, np_)
        m.buf.h, p.buf.h = nm, np_

    def ema(self, shadow, p, d):
        self._set(shadow, d * shadow.h + (1 - d) * p.h)

    # ---- convolution (MLX convolutions are NHWC with weights (out, kh, kw, in/groups))
    def _conv(self, x, w, cfg):
        mx = self.mx
        sh, sw, pt, pb, pl, pr, dh, dw, G = cfg
        x = x.transpose(0, 2, 3, 1)
        if pt != pb or pl != pr:
            x = mx.pad(x, [(0, 0), (pt, pb), (pl, pr), (0, 0)])
            pad = (0, 0)
        else:
            pad = (pt, pl)
        y = mx.conv2d(x, w.transpose(0, 2, 3, 1), stride=(sh, sw), padding=pad, dilation=(dh, dw), groups=G)
        return y.transpose(0, 3, 1, 2)

    def conv_fwd(self, x, w, b, cfg, oshape) -> Tensor:
        y = self._conv(x.h, w.h, cfg)
        if b is not None:
            y = y + b.h.reshape(1, -1, 1, 1)
        return self.T(y, oshape)

    def conv_bwd_data(self, dy, w, cfg, xshape) -> Tensor:
        mx = self.mx
        _, g = mx.vjp(lambda x: self._conv(x, w.h, cfg), [mx.zeros(tuple(xshape))], [dy.h])
        return self.T(g[0], xshape)

    def conv_bwd_weight(self, x, dy, cfg, wshape, bias: bool):
        mx = self.mx
        _, g = mx.vjp(lambda w: self._conv(x.h, w, cfg), [mx.zeros(tuple(wshape))], [dy.h])
        return self.T(g[0], wshape), (self.sum_ch(dy) if bias else None)

    def sum_ch(self, x) -> Tensor:
        return self.T(x.h.sum(axis=(0, 2, 3)), (x.shape[1],))

    def add_ch(self, y, b):
        self._set(y, y.h + b.h.reshape(1, -1, 1, 1))

    # ---- normalisation / activations
    def bn_fwd(self, x, g, b, rm, rv, mom, eps, train):
        mx = self.mx
        r = lambda a: a.reshape(1, -1, 1, 1)
        if train:
            m = x.shape[0] * x.shape[2] * x.shape[3]
            mean = x.h.mean(axis=(0, 2, 3))
            var = ((x.h - r(mean)) ** 2).mean(axis=(0, 2, 3))
            istd = 1.0 / mx.sqrt(var + eps)
            self._set(rm, (1 - mom) * rm.h + mom * mean)
            self._set(rv, (1 - mom) * rv.h + mom * var * (m / (m - 1) if m > 1 else 1.0))
            y = (x.h - r(mean)) * r(istd) * r(g.h) + r(b.h)
            return self.T(y, x.shape), self.T(mean), self.T(istd)
        istd = 1.0 / mx.sqrt(rv.h + eps)
        return self.T((x.h - r(rm.h)) * r(istd * g.h) + r(b.h), x.shape), None, None

    def bn_bwd(self, x, dy, g, mean, istd, rm, rv, eps, train):
        mx = self.mx
        r = lambda a: a.reshape(1, -1, 1, 1)
        if train:
            mu, is_ = mean.h, istd.h
        else:
            mu, is_ = rm.h, 1.0 / mx.sqrt(rv.h + eps)
        xhat = (x.h - r(mu)) * r(is_)
        db = dy.h.sum(axis=(0, 2, 3))
        dg = (dy.h * xhat).sum(axis=(0, 2, 3))
        if train:
            m = x.shape[0] * x.shape[2] * x.shape[3]
            dx = r(g.h * is_) / m * (m * dy.h - r(db) - xhat * r(dg))
        else:
            dx = dy.h * r(g.h * is_)
        return self.T(dx, x.shape), self.T(dg), self.T(db)

    def act_fwd(self, kind, x, slope=0.0) -> Tensor:
        mx, v = self.mx, x.h
        y = mx.maximum(v, 0) if kind == 0 else mx.where(v > 0, v, slope * v) if kind == 1 else v * mx.sigmoid(v) if kind == 2 else mx.sigmoid(v)
        return self.T(y, x.shape)

    def act_bwd(self, kind, x, y, dy, slope=0.0) -> Tensor:
        mx, v, g = self.mx, x.h, dy.h
        if kind == 0:
            d = mx.where(v > 0, g, 0.0)
        elif kind == 1:
            d = mx.where(v > 0, g, slope * g)
        elif kind == 2:
            s = mx.sigmoid(v)
            d = g * s * (1 + v * (1 - s))
        else:
            d = g * y.h * (1 - y.h)
        return self.T(d, x.shape)

    # ---- pooling / resize. The "idx" returned by max-style ops is the input itself (used by the vjp).
    def _pool(self, a, win, kind):
        kh, kw, sh, sw, pt, pl = win
        mx = self.mx
        a = a.transpose(0, 2, 3, 1)
        if pt or pl:
            a = mx.pad(a, [(0, 0), (pt, pt), (pl, pl), (0, 0)], constant_values=float("-inf") if kind == "max" else 0.0)
        N, H, W, C = a.shape
        OH, OW = (H - kh) // sh + 1, (W - kw) // sw + 1
        cols = []
        for i in range(kh):
            for j in range(kw):
                cols.append(a[:, i:i + (OH - 1) * sh + 1:sh, j:j + (OW - 1) * sw + 1:sw, :])
        st = mx.stack(cols, axis=0)
        y = st.max(axis=0) if kind == "max" else st.sum(axis=0) / (kh * kw)
        return y.transpose(0, 3, 1, 2)

    def maxpool_fwd(self, x, win, oshape):
        return self.T(self._pool(x.h, win, "max"), oshape), (x, win)

    def maxpool_bwd(self, dy, idx, xshape) -> Tensor:
        x, win = idx
        _, g = self.mx.vjp(lambda a: self._pool(a, win, "max"), [x.h], [dy.h])
        return self.T(g[0], xshape)

    def avgpool_fwd(self, x, win, oshape) -> Tensor:
        return self.T(self._pool(x.h, win, "avg"), oshape)

    def avgpool_bwd(self, dy, win, xshape) -> Tensor:
        _, g = self.mx.vjp(lambda a: self._pool(a, win, "avg"), [self.mx.zeros(tuple(xshape))], [dy.h])
        return self.T(g[0], xshape)

    def _up(self, a, OH, OW):
        mx = self.mx
        H, W = a.shape[2], a.shape[3]
        rows = mx.array([i * H // OH for i in range(OH)])
        cols = mx.array([j * W // OW for j in range(OW)])
        return mx.take(mx.take(a, rows, axis=2), cols, axis=3)

    def upsample_fwd(self, x, OH, OW) -> Tensor:
        return self.T(self._up(x.h, OH, OW), (x.shape[0], x.shape[1], OH, OW))

    def upsample_bwd(self, dy, xshape) -> Tensor:
        OH, OW = dy.shape[2], dy.shape[3]
        _, g = self.mx.vjp(lambda a: self._up(a, OH, OW), [self.mx.zeros(tuple(xshape))], [dy.h])
        return self.T(g[0], xshape)

    # ---- channel ops and broadcasting
    def concat(self, xs) -> Tensor:
        return self.T(self.mx.concatenate([x.h for x in xs], axis=1))

    def slice_ch(self, x, off, c) -> Tensor:
        return self.T(x.h[:, off:off + c])

    def pad_ch(self, dy, off, total) -> Tensor:
        return self.T(self.mx.pad(dy.h, [(0, 0), (off, total - off - dy.shape[1]), (0, 0), (0, 0)]))

    def mul_bc(self, x, s) -> Tensor:
        return self.T(x.h * s.h, x.shape)

    def mul_reduce(self, a, b, sshape) -> Tensor:
        axes = tuple(i for i in range(4) if sshape[i] == 1 and a.shape[i] != 1)
        p = a.h * b.h
        return self.T(p.sum(axis=axes, keepdims=True) if axes else p, sshape)

    def chan_mean(self, x) -> Tensor:
        return self.T(x.h.mean(axis=1, keepdims=True))

    def chan_mean_bwd(self, dy, Cc) -> Tensor:
        N, _, H, W = dy.shape
        return self.T(self.mx.broadcast_to(dy.h / Cc, (N, Cc, H, W)) + 0)

    def chan_max(self, x):
        return self.T(x.h.max(axis=1, keepdims=True)), x

    def chan_max_bwd(self, dy, idx, Cc) -> Tensor:
        _, g = self.mx.vjp(lambda a: a.max(axis=1, keepdims=True), [idx.h], [dy.h])
        return self.T(g[0], idx.shape)

    def _s2d(self, a):
        return self.mx.concatenate([a[:, :, ::2, ::2], a[:, :, 1::2, ::2], a[:, :, ::2, 1::2], a[:, :, 1::2, 1::2]], axis=1)

    def s2d(self, x) -> Tensor:
        return self.T(self._s2d(x.h))

    def s2d_bwd(self, dy) -> Tensor:
        N, C4, OH, OW = dy.shape
        shape = (N, C4 // 4, OH * 2, OW * 2)
        _, g = self.mx.vjp(self._s2d, [self.mx.zeros(shape)], [dy.h])
        return self.T(g[0], shape)

    # ---- quantisation
    def fake_quant(self, x, scale, zp, qmin, qmax) -> Tensor:
        mx = self.mx
        return self.T((mx.clip(mx.round(x.h / scale + zp), qmin, qmax) - zp) * scale, x.shape)

    def fake_quant_bwd(self, x, dy, scale, zp, qmin, qmax) -> Tensor:
        q = x.h / scale + zp
        return self.T(self.mx.where((q >= qmin - 0.5) & (q <= qmax + 0.5), dy.h, 0.0), x.shape)
