"""Foundational layers: convolutions, normalisation, activations, pooling, upsampling."""
from __future__ import annotations

import math
from typing import Optional

from .core import ops
from .core.ops import out_size
from .errors import ShapeError, WorkflowError
from .layer import Ctx, Layer, fmt, padding4, pair, positive, single


class _Conv(Layer):
    """Shared implementation of the convolution family."""

    _depthwise = False

    def _setup(self, filters, kernel_size, stride, padding, dilation=1, bias=None):
        self.filters = positive(filters, "filters", optional=self._depthwise)
        self.k, self.s, self.d = pair(kernel_size, "kernel_size"), pair(stride, "stride"), pair(dilation, "dilation")
        self.p = padding4(padding)
        self.use_bias = bias            # None: decided by the stack (no bias right before BatchNorm2D)
        self.q = None                   # quantisation state, set when QAT / PTQ is active

    def label(self):
        t = f"{type(self).__name__} k{self.k[0]}" + (f"x{self.k[1]}" if self.k[0] != self.k[1] else "")
        t += f" s{self.s[0]}" if self.s != (1, 1) else ""
        t += f" p{self.p[0]}" if any(self.p) and len(set(self.p)) == 1 else (f" p{self.p}" if any(self.p) else "")
        return t + (f" d{self.d[0]}" if self.d != (1, 1) else "")

    def infer(self, shape, ctx: Ctx):
        c, h, w = single(shape, type(self).__name__)
        groups = c if self._depthwise else 1
        out_c = c if self._depthwise else self.filters
        have = self.P["weight"].shape[0 if self._depthwise else 1] if "weight" in self.P else c
        if have != c:
            raise ShapeError(f"{type(self).__name__} received {c} channels but was built for {have}.",
                             "the layer's weights were created for a different input.",
                             "feed it the same number of channels as before, or create a new layer.")
        oh = out_size(h, self.k[0], self.s[0], self.p[0], self.p[1], self.d[0])
        ow = out_size(w, self.k[1], self.s[1], self.p[2], self.p[3], self.d[1])
        if oh < 1 or ow < 1:
            span = (self.d[0] * (self.k[0] - 1) + 1, self.d[1] * (self.k[1] - 1) + 1)
            raise ShapeError(f"{type(self).__name__} does not fit its input.",
                             f"the input is {h}x{w} (padding {self.p}) but the kernel covers {span[0]}x{span[1]} pixels.",
                             "increase padding, use a smaller kernel_size or dilation, or feed a larger image.")
        fan_in = (c // groups) * self.k[0] * self.k[1]
        bound = 1.0 / math.sqrt(fan_in)
        self.param("weight", (out_c, c // groups, self.k[0], self.k[1]), -bound, bound)
        if self.use_bias is None:
            self.use_bias = True
        if self.use_bias:
            self.param("bias", (out_c,), -bound, bound)
        self.groups = groups
        ctx.macs += out_c * oh * ow * fan_in
        return (out_c, oh, ow)

    def run(self, x, ctx: Ctx):
        w = self.P["weight"]
        if ctx.quant is not None:
            x, w = ctx.quant.conv_inputs(self, x, w, ctx)
        return ops.conv2d(x, w, self.P.get("bias"), self.s, self.p, self.d, self.groups)


class Conv2D(_Conv):
    """``wf.Conv2D(filters, kernel_size=3, stride=1, padding=0)``. Input channels are inferred."""

    def __init__(self, filters: int, kernel_size=3, stride=1, padding=0):
        self._setup(filters, kernel_size, stride, padding)


class DilatedConv2D(_Conv):
    """Convolution with holes: ``dilation`` spreads the kernel taps apart (larger receptive field, same cost)."""

    def __init__(self, filters: int, kernel_size=3, dilation=2, stride=1, padding=0):
        self._setup(filters, kernel_size, stride, padding, dilation)


class DepthwiseConv2D(_Conv):
    """One filter per input channel (groups = channels). Keeps the channel count."""

    _depthwise = True

    def __init__(self, kernel_size=3, stride=1, padding=0):
        self._setup(None, kernel_size, stride, padding)


class PointwiseConv2D(_Conv):
    """1x1 convolution: mixes channels, keeps the resolution."""

    def __init__(self, filters: int):
        self._setup(filters, 1, 1, 0)


class SeparableConv2D(Layer):
    """Depthwise convolution followed by a pointwise (1x1) convolution."""

    def __init__(self, filters: int, kernel_size=3, stride=1, padding=0):
        self.depthwise = DepthwiseConv2D(kernel_size, stride, padding)
        self.depthwise.use_bias = False
        self.pointwise = PointwiseConv2D(filters)

    def children(self):
        return [("depthwise", self.depthwise), ("pointwise", self.pointwise)]

    def _set_bias(self, on):
        self.pointwise.use_bias = on

    def infer(self, shape, ctx):
        return self.pointwise.infer(self.depthwise.infer(single(shape, "SeparableConv2D"), ctx), ctx)

    def run(self, x, ctx):
        return self.pointwise.run(self.depthwise.run(x, ctx), ctx)


class TransposeConv2D(Layer):
    """Transposed ("up") convolution. Default kernel 2, stride 2 doubles the resolution."""

    def __init__(self, filters: int, kernel_size=2, stride=2, padding=0):
        self.filters = positive(filters, "filters")
        self.k, self.s = pair(kernel_size, "kernel_size"), pair(stride, "stride")
        p = padding4(padding)
        if p[0] != p[1] or p[2] != p[3]:
            raise WorkflowError("TransposeConv2D does not support asymmetric padding.",
                                f"padding {p} differs between opposite sides.", "use padding=n or padding=(height, width).")
        self.p = (p[0], p[2])
        self.use_bias = None

    def label(self):
        return f"TransposeConv2D k{self.k[0]} s{self.s[0]}" + (f" p{self.p[0]}" if any(self.p) else "")

    def infer(self, shape, ctx):
        c, h, w = single(shape, "TransposeConv2D")
        if "weight" in self.P and self.P["weight"].shape[0] != c:
            raise ShapeError(f"TransposeConv2D received {c} channels but was built for {self.P['weight'].shape[0]}.",
                             "the layer's weights were created for a different input.", "feed it the same number of channels.")
        oh = (h - 1) * self.s[0] - 2 * self.p[0] + self.k[0]
        ow = (w - 1) * self.s[1] - 2 * self.p[1] + self.k[1]
        if oh < 1 or ow < 1:
            raise ShapeError("TransposeConv2D would produce an empty output.", f"input {h}x{w} with padding {self.p} gives {oh}x{ow}.",
                             "reduce padding or increase kernel_size.")
        bound = 1.0 / math.sqrt(self.filters * self.k[0] * self.k[1])
        self.param("weight", (c, self.filters, self.k[0], self.k[1]), -bound, bound)
        if self.use_bias is None:
            self.use_bias = True
        if self.use_bias:
            self.param("bias", (self.filters,), -bound, bound)
        ctx.macs += c * h * w * self.filters * self.k[0] * self.k[1]
        return (self.filters, oh, ow)

    def run(self, x, ctx):
        return ops.conv_transpose2d(x, self.P["weight"], self.P.get("bias"), self.s, self.p)


class BatchNorm2D(Layer):
    """Batch normalisation over channels (eps 1e-3, momentum 0.03). Channels are inferred."""

    absorbs_bias = True

    def __init__(self):
        pass

    def infer(self, shape, ctx):
        c, h, w = single(shape, "BatchNorm2D")
        if "gamma" in self.P and self.P["gamma"].shape[0] != c:
            raise ShapeError(f"BatchNorm2D received {c} channels but was built for {self.P['gamma'].shape[0]}.",
                             "its scale and statistics were created for a different input.", "feed it the same number of channels.")
        self.param("gamma", (c,), 1.0, 1.0)
        self.param("beta", (c,), 0.0, 0.0)
        self.buffer("mean", (c,), 0.0)
        self.buffer("var", (c,), 1.0)
        return (c, h, w)

    def run(self, x, ctx):
        return ops.batchnorm(x, self.P["gamma"], self.P["beta"], self.Bf["mean"], self.Bf["var"], ctx.train)


class _Act(Layer):
    kind, slope = ops.RELU, 0.0

    def infer(self, shape, ctx):
        return single(shape, type(self).__name__)

    def run(self, x, ctx):
        return ops.act(self.kind, x, self.slope)


class ReLU(_Act):
    def __init__(self):
        pass


class LeakyReLU(_Act):
    """Leaky ReLU; ``slope`` is the gradient for negative inputs."""
    kind = ops.LEAKY

    def __init__(self, slope: float = 0.1):
        self.slope = float(slope)


class SiLU(_Act):
    kind = ops.SILU

    def __init__(self):
        pass


class Sigmoid(_Act):
    kind = ops.SIGMOID

    def __init__(self):
        pass


class _Pool(Layer):
    _max = True

    def _setup(self, kernel_size, stride, padding):
        self.k = pair(kernel_size, "kernel_size")
        self.s = self.k if stride is None else pair(stride, "stride")
        p = padding4(padding)
        self.p = (p[0], p[2])
        if p[0] != p[1] or p[2] != p[3] or self.p[0] * 2 > self.k[0] or self.p[1] * 2 > self.k[1]:
            raise WorkflowError(f"invalid pooling padding {padding!r} for kernel {self.k}.",
                                "pooling padding must be symmetric and at most half the kernel size.",
                                f"use padding between 0 and {self.k[0] // 2}.")

    def label(self):
        return f"{type(self).__name__} k{self.k[0]}" + (f" s{self.s[0]}" if self.s != self.k else "")

    def infer(self, shape, ctx):
        c, h, w = single(shape, type(self).__name__)
        oh, ow = out_size(h, self.k[0], self.s[0], self.p[0], self.p[0]), out_size(w, self.k[1], self.s[1], self.p[1], self.p[1])
        if oh < 1 or ow < 1:
            raise ShapeError(f"{type(self).__name__} does not fit its input.", f"the input is {h}x{w} but the window is {self.k[0]}x{self.k[1]}.",
                             "use a smaller kernel_size, add padding, or feed a larger image.")
        return (c, oh, ow)

    def run(self, x, ctx):
        return (ops.maxpool if self._max else ops.avgpool)(x, self.k, self.s, self.p)


class MaxPool2D(_Pool):
    """Max pooling. ``stride`` defaults to ``kernel_size``."""

    def __init__(self, kernel_size=2, stride=None, padding=0):
        self._setup(kernel_size, stride, padding)


class AvgPool2D(_Pool):
    """Average pooling. ``stride`` defaults to ``kernel_size``."""
    _max = False

    def __init__(self, kernel_size=2, stride=None, padding=0):
        self._setup(kernel_size, stride, padding)


class Upsample(Layer):
    """Nearest-neighbour upsampling by an integer factor."""

    def __init__(self, scale: int = 2):
        self.scale = positive(scale, "scale")

    def label(self):
        return f"Upsample x{self.scale}"

    def infer(self, shape, ctx):
        c, h, w = single(shape, "Upsample")
        return (c, h * self.scale, w * self.scale)

    def run(self, x, ctx):
        return ops.upsample(x, x.shape[2] * self.scale, x.shape[3] * self.scale)
