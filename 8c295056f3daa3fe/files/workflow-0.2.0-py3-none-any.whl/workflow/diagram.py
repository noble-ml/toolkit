"""Computation-graph drawing (PNG / SVG) with no external tools.

One row per layer, sequential arrows, blocks drawn with their real branches (residual shortcuts, CSP / SPP
splits, attention gates) and named features as red edges from ``wf.feature`` to the layers that read them.
"""
from __future__ import annotations

import html
import os
from typing import List, Tuple

from .errors import WorkflowError
from .layer import fmt, is_pyramid

BG, CARD, STROKE = "#0b0b0b", "#141414", "#3d3d3d"
BONE, ASH, RED = "#d9d4c7", "#8a8a8a", "#c1121f"
M, ROW, GAP, PAD, LANE = 28, 26, 8, 12, 14


class Scene:
    def __init__(self):
        self.items: List[tuple] = []
        self.w = self.h = 0

    def rect(self, x, y, w, h, fill=CARD, stroke=STROKE, r=6, sw=1):
        self.items.append(("rect", x, y, w, h, fill, stroke, r, sw))

    def text(self, x, y, s, size=12, color=BONE, anchor="start", bold=False):
        self.items.append(("text", x, y, s, size, color, anchor, bold))

    def line(self, pts, color=ASH, w=1.2, arrow=False, dash=False):
        self.items.append(("line", list(pts), color, w, arrow, dash))

    def circle(self, x, y, r, fill=CARD, stroke=ASH):
        self.items.append(("circle", x, y, r, fill, stroke))


def _tw(s, size):
    return 0.6 * size * len(s)


def _fit(s, w, size=10):
    n = int(w / (0.6 * size))
    return s if len(s) <= n else s[: max(1, n - 1)] + "…"


def _lbl(layer) -> str:
    from .compose import Stack
    from .layers import _Conv, TransposeConv2D
    if isinstance(layer, Stack):
        parts = [_lbl(l) for l in layer.layers]
        return " · ".join(parts) if len(parts) <= 3 else f"{parts[0]} … ({len(parts)} layers)"
    if isinstance(layer, (_Conv, TransposeConv2D)) and "weight" in layer.P:
        w = layer.P["weight"].shape
        cin, cout = (w[0], w[1]) if isinstance(layer, TransposeConv2D) else (w[1] * getattr(layer, "groups", 1), w[0])
        return layer.label().replace(type(layer).__name__, f"{type(layer).__name__} {cin}→{cout}", 1)
    return layer.label()


def _rows(stack) -> List[str]:
    return [_lbl(l) for l in stack.layers] if stack is not None else []


def describe(layer):
    """(pre rows, parallel paths, merge symbol, post rows) for layers with real branches, else None."""
    from . import blocks as B
    from .compose import Parallel, Residual, Stack
    if isinstance(layer, Residual):
        return [], [_rows(layer.body), _rows(layer.shortcut)], "+", []
    if isinstance(layer, Parallel):
        return [], [_rows(b) if isinstance(b, Stack) else [_lbl(b)] for b in layer.branches], "©" if layer.merge == "concat" else "+", []
    if isinstance(layer, B.Bottleneck) and layer.body is not None:
        paths = [_rows(layer.body)] + ([_rows(layer.proj) if layer.proj is not None else []] if layer.shortcut else [])
        return [], paths, "+", ["SiLU"]
    if isinstance(layer, B.CSP) and layer.a is not None:
        return [], [[_lbl(layer.a), f"Bottleneck ×{len(layer.m.layers)}"], [_lbl(layer.b)]], "©", [_lbl(layer.fuse)]
    if isinstance(layer, B.SPP) and layer.pre is not None:
        if layer._chain():
            k = layer.kernels[0]
            paths = [[]] + [[f"MaxPool k{k}" + (f" ×{i}" if i > 1 else "")] for i in range(1, len(layer.kernels) + 1)]
        else:
            paths = [[]] + [[f"MaxPool k{k}"] for k in layer.kernels]
        return [_lbl(layer.pre)], paths, "©", [_lbl(layer.post)]
    if isinstance(layer, B.SE) and layer.fc1 is not None:
        return [], [[], ["GlobalAvgPool", f"1×1 → {layer.fc1.filters} · ReLU", f"1×1 → {layer.fc2.filters} · Sigmoid"]], "×", []
    if isinstance(layer, B.CBAM) and layer.fc1 is not None:
        return [], [[], ["avg + max pool → MLP → Sigmoid"]], "×", ["× spatial gate (mean, max → " f"k{layer.k} conv → Sigmoid)"]
    return None


_NOTES = {"FPN": ["1×1 lateral per map", "top-down: resize + add", "3×3 refine per level"],
          "PAN": ["bottom-up: stride-2 conv + add", "3×3 refine per level"],
          "Head": ["per map: 2× (3×3 Conv·BN·SiLU)", "1×1 → box(4) · conf(1) · classes"],
          "Focus": ["2×2 space-to-depth → 4× channels", "Conv·BN·SiLU"]}


def build(model, detail: str = "layers") -> Scene:
    if detail not in ("layers", "compact"):
        raise WorkflowError(f"unknown detail={detail!r}.", "graphs come in two levels of detail.", "use detail='layers' or detail='compact'.")
    from .compose import Feature
    model._ensure()
    S = Scene()
    recs = model._records
    widest = max([len(_lbl(r[1])) for r in recs] + [30])
    CW = max(460, int(_tw("x" * widest, 12) + 170))
    x0, cx = M, M + CW / 2
    anchors, wants = {}, []
    y = M
    S.rect(cx - 110, y, 220, 30, CARD, STROKE, 15)
    S.text(cx, y + 15, f"input  {fmt(model.input)}", 12, BONE, "middle")
    y += 30
    top = y + 22
    S.line([(cx, y), (cx, top)], ASH, 1.4, arrow=True)
    idx = len(S.items)
    cy = top + PAD
    ix, iw = x0 + PAD, CW - 2 * PAD
    for k, (i, layer, _, out, _) in enumerate(recs):
        if k:
            S.line([(cx, cy), (cx, cy + GAP)], ASH, 1.1, arrow=True)
            cy += GAP
        cy += _draw(S, layer, out, ix, cy, iw, anchors, wants, detail)
    h = cy + PAD - top
    S.items.insert(idx, ("rect", x0, top, CW, h, CARD, STROKE, 8, 1))
    y = top + h
    S.line([(cx, y), (cx, y + 22)], ASH, 1.4, arrow=True)
    S.text(cx, y + 36, "output  " + fmt(model.output_shape), 11, BONE, "middle")
    y += 52
    lanes: List[List[Tuple[float, float]]] = []
    for name, tx, ty in sorted(wants, key=lambda w: w[2]):
        if name not in anchors:
            continue
        px, py = anchors[name]
        lo, hi = min(py, ty) - 4, max(py, ty) + 4
        lane = next((j for j, iv in enumerate(lanes) if all(hi < a or lo > b for a, b in iv)), None)
        if lane is None:
            lanes.append([])
            lane = len(lanes) - 1
        lanes[lane].append((lo, hi))
        lx = x0 + CW + 18 + lane * LANE
        S.line([(px, py), (lx, py), (lx, ty), (tx, ty)], RED, 1.4, arrow=True)
    S.w = int(x0 + CW + 18 + max(1, len(lanes)) * LANE + 30)
    S.h = int(y + M)
    return S


def _draw(S, layer, out, x, y, w, anchors, wants, detail) -> float:
    from .compose import Feature, _Neck, Concat
    name = type(layer).__name__
    if isinstance(layer, Feature):
        S.rect(x + 40, y, w - 80, 20, "#101010", RED, 10)
        S.text(x + w / 2, y + 10, "feature  " + ", ".join(layer.names), 10, RED, "middle")
        for n in layer.names:
            anchors[n] = (x + w - 40, y + 10)
        return 20
    desc = describe(layer) if detail == "layers" else None
    ins = list(getattr(layer, "names", ())) if isinstance(layer, (Concat, _Neck)) else []
    if desc is None:
        notes = _NOTES.get(name, []) if detail == "layers" else []
        h = max(ROW, 14 * len(ins) + 12, 30 + 12 * len(notes) + 4 if notes else 0)
        S.rect(x, y, w, h, "#101010", STROKE, 5)
        S.text(x + 10, y + 13, _lbl(layer), 12, BONE)
        S.text(x + w - 10, y + 13 + (14 * len(ins) if ins else 0), _fit(fmt(out), w / 2), 11, ASH, "end")
        for j, t in enumerate(notes):
            S.text(x + 10, y + 28 + 12 * j, t, 9, ASH)
        for j, n in enumerate(ins):
            py = y + 12 + 14 * j
            S.circle(x + w, py, 3, RED, RED)
            S.text(x + w - 9, py, n, 10, RED, "end")
            wants.append((n, x + w, py))
        return h
    pre, paths, merge, post = desc
    top = y
    S.text(x + 10, y + 13, _lbl(layer), 12, BONE, bold=True)
    S.text(x + w - 10, y + 13, fmt(out), 11, ASH, "end")
    cy, cxm = y + 26, x + w / 2
    for t in pre:
        cy += _row(S, cxm, cy, w - 40, t) + 6
    colw = (w - 16) / len(paths)
    tops, ends, hmax = cy + 14, [], cy + 14
    for j, rows in enumerate(paths):
        px = x + 8 + colw * (j + 0.5)
        S.line([(cxm, cy), (cxm, cy + 7), (px, cy + 7), (px, tops)], ASH, 1.1)
        yy = tops
        for t in rows:
            yy += _row(S, px, yy, colw - 10, t) + 8
        if not rows:
            S.text(px + 4, yy + 8, "skip", 9, ASH)
            yy += 18
        ends.append((px, yy))
        hmax = max(hmax, yy)
    by = hmax + 4
    for px, yy in ends:
        S.line([(px, yy - (8 if yy > tops else 0)), (px, by), (cxm, by), (cxm, by + 8)], ASH, 1.1)
    S.circle(cxm, by + 16, 10, CARD, ASH)
    S.text(cxm, by + 16, merge, 11, BONE, "middle")
    cy = by + 28
    for t in post:
        S.line([(cxm, cy - 2), (cxm, cy + 4)], ASH, 1.1)
        cy += 4 + _row(S, cxm, cy + 4, w - 40, t)
    h = cy + 8 - top
    first = next(k for k in range(len(S.items) - 1, -1, -1)
                 if S.items[k][0] == "text" and S.items[k][1] == x + 10 and S.items[k][2] == top + 13)
    S.items.insert(first, ("rect", x, top, w, h, "#101010", STROKE, 5, 1))
    return h


def _row(S, cx, y, w, text) -> float:
    w = max(80, w)
    S.rect(cx - w / 2, y, w, 22, CARD, STROKE, 4)
    S.text(cx, y + 11, _fit(text, w - 8), 10, BONE, "middle")
    return 22


# ----------------------------------------------------------------- renderers
def _fonts(size):
    from PIL import ImageFont
    for name in ("Menlo.ttc", "DejaVuSansMono.ttf", "Consolas.ttf", "LiberationMono-Regular.ttf",
                 "/System/Library/Fonts/Menlo.ttc", "/System/Library/Fonts/Monaco.ttf", "cour.ttf"):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


def render_png(scene: Scene, scale: int = 2):
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        raise WorkflowError("drawing graphs needs Pillow.", "Pillow renders the PNG.", "run `pip install Pillow`, or export an .svg instead.") from None
    S = scale
    img = Image.new("RGB", (scene.w * S, scene.h * S), BG)
    d = ImageDraw.Draw(img)
    cache = {}
    for it in scene.items:
        k = it[0]
        if k == "rect":
            _, x, y, w, h, fill, stroke, r, sw = it
            d.rounded_rectangle([x * S, y * S, (x + w) * S, (y + h) * S], r * S, fill=fill, outline=stroke, width=max(1, int(sw * S / 1.5)))
        elif k == "circle":
            _, x, y, r, fill, stroke = it
            d.ellipse([(x - r) * S, (y - r) * S, (x + r) * S, (y + r) * S], fill=fill, outline=stroke, width=S)
        elif k == "line":
            _, pts, color, w, arrow, dash = it
            P = [(a * S, b * S) for a, b in pts]
            d.line(P, fill=color, width=max(1, int(w * S)), joint="curve")
            if arrow:
                (x1, y1), (x2, y2) = P[-2], P[-1]
                dx, dy = x2 - x1, y2 - y1
                n = max(1e-6, (dx * dx + dy * dy) ** 0.5)
                ux, uy = dx / n, dy / n
                a = 5 * S
                d.polygon([(x2, y2), (x2 - ux * a * 1.6 - uy * a, y2 - uy * a * 1.6 + ux * a),
                           (x2 - ux * a * 1.6 + uy * a, y2 - uy * a * 1.6 - ux * a)], fill=color)
        else:
            _, x, y, s, size, color, anchor, bold = it
            f = cache.setdefault(size, _fonts(int(size * S * 1.0)))
            tw = d.textlength(s, font=f)
            bb = f.getbbox("Ag")
            px = x * S - (tw if anchor == "end" else tw / 2 if anchor == "middle" else 0)
            py = y * S - (bb[1] + bb[3]) / 2
            d.text((px, py), s, font=f, fill=color)
            if bold:
                d.text((px + 0.7 * S, py), s, font=f, fill=color)
    return img


def render_svg(scene: Scene) -> str:
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{scene.w}" height="{scene.h}" viewBox="0 0 {scene.w} {scene.h}">',
         f'<rect width="100%" height="100%" fill="{BG}"/>',
         '<defs>' + ''.join(f'<marker id="a{c[1:]}" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">'
                            f'<path d="M0,0 L8,4 L0,8 z" fill="{c}"/></marker>' for c in (ASH, RED)) + '</defs>']
    for it in scene.items:
        k = it[0]
        if k == "rect":
            _, x, y, w, h, fill, stroke, r, sw = it
            o.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{r}" fill="{fill}" stroke="{stroke}" stroke-width="{sw}"/>')
        elif k == "circle":
            _, x, y, r, fill, stroke = it
            o.append(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{fill}" stroke="{stroke}"/>')
        elif k == "line":
            _, pts, color, w, arrow, dash = it
            p = " ".join(f"{a},{b}" for a, b in pts)
            m = f' marker-end="url(#a{color[1:]})"' if arrow else ""
            o.append(f'<polyline points="{p}" fill="none" stroke="{color}" stroke-width="{w}"{m}/>')
        else:
            _, x, y, s, size, color, anchor, bold = it
            o.append(f'<text x="{x}" y="{y}" fill="{color}" font-size="{size}" text-anchor="{anchor}" '
                     f'dominant-baseline="central" font-family="Menlo,Consolas,DejaVu Sans Mono,monospace"'
                     f'{" font-weight=\'bold\'" if bold else ""}>{html.escape(s)}</text>')
    o.append("</svg>")
    return "\n".join(o)


def export(model, path, detail="layers", scale=2) -> str:
    path = os.fspath(path)
    ext = os.path.splitext(path)[1].lower()
    if ext not in (".png", ".svg"):
        raise WorkflowError(f"cannot draw a graph as {ext or path!r}.", "graphs are written as PNG or SVG.", "use a .png or .svg file name.")
    scene = build(model, detail)
    if ext == ".svg":
        with open(path, "w", encoding="utf-8") as f:
            f.write(render_svg(scene))
    else:
        render_png(scene, scale).save(path)
    return path
