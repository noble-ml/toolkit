"""``fx.sources.local(path)``: images on this computer: one image, a folder of images (any nesting), an archive, or an
existing dataset (Felix, COCO, YOLO), whose labels, splits and provenance come along."""
from __future__ import annotations

import json
import os
import tarfile
import zipfile
from pathlib import Path
from typing import Optional

from .. import _images, _yaml
from .._session import session
from ..errors import FelixError
from ._base import Collector, Source

OWN = "own files (rights: yours to confirm)"
ARCHIVES = (".zip", ".tar", ".tgz", ".tar.gz", ".tar.bz2", ".tbz2", ".tar.xz", ".txz")
SPLIT_NAMES = {"train": "train", "training": "train", "val": "val", "valid": "val", "validation": "val",
               "test": "test", "testing": "test"}


class local(Source):
    """Images from a path. ``labels="folders"`` reads a folder of class folders (cat/, dog/, …) as image labels;
    otherwise sub-folders are just where images live. ``recursive=False`` only takes images directly inside.
    ``license``: the images' licence if you know it (default: your own files; imported datasets keep their own)."""

    kind = "local"

    def __init__(self, path, recursive: bool = True, labels: Optional[str] = None, license: Optional[str] = None):
        self.path = os.fspath(path)
        self.license = license
        if labels not in (None, "folders"):
            raise FelixError("sources.local: labels must be None or 'folders' (one folder per class)")
        self.recursive, self.labels = recursive, labels

    def label(self):
        return f"local {self.path}"

    def describe(self):
        return {"type": "local", "path": os.path.abspath(self.path)}

    def collect(self, c: Collector, progress):
        p = Path(self.path)
        if not p.exists():
            raise FelixError(f"sources.local: {self.path} does not exist")
        if p.is_file():
            low = p.name.lower()
            if _images.is_image_name(p.name):
                c.add(path=str(p), name=p.name, source=self._src(p, p.name))
                return progress(1, 1)
            if low.endswith((".felix", ".sh_felix")):
                return _import_felix(str(p), c, progress, self._src(p, None))
            if low.endswith(ARCHIVES):
                return self._collect_dir(_extract(p), c, progress, archive=p)
            raise FelixError(f"sources.local: {p.name} is not an image, a dataset or an archive ({', '.join(ARCHIVES)})")
        return self._collect_dir(p, c, progress)

    def _src(self, root: Path, rel, archive=None):
        s = {"type": "local", "path": os.path.abspath(self.path), "license": self.license or OWN}
        if rel:
            s["original_filename"] = str(rel)
        if archive is not None:
            s["archive"] = os.path.abspath(str(archive))
        return s

    def _collect_dir(self, root: Path, c: Collector, progress, archive=None):
        from ..store import dataset_kind
        kind = dataset_kind(root)
        if kind in ("folder", "shards"):
            return _import_felix(str(root), c, progress, self._src(root, None, archive))
        coco = _find_coco(root)
        if coco:
            return _import_coco(root, coco, c, progress, self._src(root, None, archive))
        yolo = _find_yolo(root)
        if yolo:
            return _import_yolo(root, yolo, c, progress, self._src(root, None, archive))
        if self.labels == "folders":
            if kind != "classes":
                raise FelixError(f"sources.local: {root} is not a folder of class folders (cat/, dog/, … with images)")
            return _import_felix(str(root), c, progress, self._src(root, None, archive))
        files = []
        for d, dirs, names in os.walk(root):
            dirs[:] = sorted(x for x in dirs if not x.startswith((".", "__MACOSX")))
            files += [os.path.join(d, n) for n in sorted(names) if _images.is_image_name(n)]
            if not self.recursive:
                break
        if not files:
            raise FelixError(f"sources.local: no images in {root} ({', '.join(_images.IMAGE_EXT)})")
        for i, f in enumerate(files):
            rel = os.path.relpath(f, root)
            c.add(path=f, name=rel.replace(os.sep, "_"), source=self._src(root, rel, archive))
            progress(i + 1, len(files))


# ---------------------------------------------------------------------------------------------------------- archives
def _extract(archive: Path) -> Path:
    """Unpack into the working folder, refusing paths that would land outside it."""
    dest = Path(session().work) / "archives" / f"{len(os.listdir(session().work))}_{archive.stem}"
    dest.mkdir(parents=True, exist_ok=True)
    base = dest.resolve()

    def safe(name):
        target = (dest / name).resolve()
        if base not in target.parents and target != base:
            raise FelixError(f"{archive.name}: unsafe path inside the archive ({name})")
        return target
    try:
        if zipfile.is_zipfile(archive):
            with zipfile.ZipFile(archive) as z:
                for m in z.infolist():
                    safe(m.filename)
                z.extractall(dest)
        else:
            with tarfile.open(archive) as t:
                members = []
                for m in t.getmembers():
                    if m.issym() or m.islnk() or m.isdev():
                        continue                         # no links or devices from archives
                    safe(m.name)
                    members.append(m)
                t.extractall(dest, members=members)
    except (zipfile.BadZipFile, tarfile.TarError, EOFError) as e:
        raise FelixError(f"{archive.name}: damaged archive ({e})") from None
    return dest


# ---------------------------------------------------------------------------------------------------------- Felix
def _import_felix(path: str, c: Collector, progress, src: dict):
    from ..store import ClassFolderReader, DirReader, Dataset
    ds = Dataset(path)
    try:
        split_of = {s: k for k in ("train", "val", "test") for s in getattr(ds, k).stems} if len(ds) >= 10 or ds.metadata.get("splits") else {}
        name = os.path.basename(path.rstrip("/\\"))
        n = len(ds)
        for i, (stem, ann) in enumerate(ds):
            img = ann.get("image", f"{stem}.png")
            given = ann.get("source")
            source = dict(given) if isinstance(given, dict) else dict(src, dataset=name, original_filename=img)
            status = (ann.get("annotation") or {}).get("status")
            objects = None
            if ann.get("objects") is not None or status in ("model", "negative", "dataset"):
                objects = [{k: v for k, v in o.items() if k not in ("class_id",)} for o in ann.get("objects") or []]
            label = ann.get("class") if "class_id" in ann and "objects" not in ann else None
            if status == "none":
                objects, label = None, None
            r = ds._r
            if isinstance(r, (DirReader, ClassFolderReader)):
                kw = {"path": str((r.root / "images" / img) if isinstance(r, DirReader) else r.root.joinpath(*img.split("/")))}
            else:
                kw = {"data": r.read("images/" + img), "ext": os.path.splitext(img)[1]}
            it = c.add(name=stem.replace("/", "_"), source=source, objects=objects, label=label,
                       split=split_of.get(stem), keep_orientation=True, **kw)
            if it is not None:
                if status in ("model", "negative"):
                    it.status = status
                    it.model = (ann.get("annotation") or {}).get("model")
                if isinstance(ann.get("history"), list):
                    it.history = list(ann["history"])
                if isinstance(ann.get("privacy"), dict):
                    it.privacy = dict(ann["privacy"])
            progress(i + 1, n)
    finally:
        ds.close()


# ---------------------------------------------------------------------------------------------------------- COCO
def _find_coco(root: Path):
    found = []
    for f in sorted(root.rglob("*.json")):
        if f.stat().st_size > 2 * 2**30:
            continue
        if f.name == "_annotations.coco.json" or "instances" in f.name or "annotations" in f.name or "coco" in f.name.lower():
            try:
                with open(f, encoding="utf-8") as h:
                    head = h.read(4096)
                if '"images"' in head or '"annotations"' in head or '"categories"' in head or '"info"' in head:
                    found.append(f)
            except OSError:
                pass
    return found


def _import_coco(root: Path, files, c: Collector, progress, src: dict):
    total = 0
    loaded = []
    for f in files:
        try:
            d = json.loads(f.read_text("utf-8"))
        except ValueError as e:
            raise FelixError(f"{f}: invalid COCO JSON ({e})") from None
        if not isinstance(d, dict) or "images" not in d:
            continue
        loaded.append((f, d))
        total += len(d["images"])
    if not loaded:
        raise FelixError(f"{root}: the JSON files are not COCO annotations")
    done = 0
    for f, d in loaded:
        cats = {cat["id"]: cat["name"] for cat in d.get("categories", [])}
        # Roboflow adds an unused parent category named after the dataset: it simply never gets boxes
        by_img = {}
        for a in d.get("annotations", []):
            by_img.setdefault(a.get("image_id"), []).append(a)
        split = SPLIT_NAMES.get(f.parent.name.lower()) if f.parent != root else None
        info = d.get("info") or {}
        lic = {l.get("id"): l for l in d.get("licenses", []) if isinstance(l, dict)}
        for im in d["images"]:
            done += 1
            fn = im.get("file_name", "")
            path = (f.parent / fn) if (f.parent / fn).is_file() else (root / fn) if (root / fn).is_file() else None
            if path is None:
                hits = list(root.rglob(os.path.basename(fn))) if fn else []
                path = hits[0] if hits else None
            if path is None:
                c.skip(fn or str(im.get("id")), "image file listed in the COCO JSON is missing")
                continue
            objs = []
            for a in by_img.get(im.get("id"), []):
                if a.get("category_id") not in cats or not a.get("bbox"):
                    continue
                o = {"class": cats[a["category_id"]], "bbox": [float(v) for v in a["bbox"][:4]]}
                seg = a.get("segmentation")
                if isinstance(seg, list) and seg and isinstance(seg[0], list):
                    o["segmentation"] = [[float(v) for v in poly] for poly in seg if len(poly) >= 6]
                if a.get("iscrowd"):
                    o["attributes"] = {"crowd": True}
                objs.append(o)
            source = dict(src, format="coco", annotation_file=str(f.relative_to(root)), original_filename=fn)
            l = lic.get(im.get("license"))
            if l:
                source["license"] = l.get("name") or l.get("url")
                if l.get("url"):
                    source["license_url"] = l["url"]
            if info.get("url") or info.get("description"):
                source["dataset"] = info.get("description") or info.get("url")
            for k in ("coco_url", "flickr_url"):
                if im.get(k):
                    source.setdefault("url", im[k])
            c.add(path=str(path), name=os.path.basename(fn), source=source, objects=objs, split=split,
                  keep_orientation=True)
            progress(done, total)


# ---------------------------------------------------------------------------------------------------------- YOLO
def _find_yolo(root: Path):
    for name in ("data.yaml", "data.yml", "dataset.yaml"):
        f = root / name
        if f.is_file():
            try:
                d = _yaml.loads(f.read_text("utf-8")) or {}
            except Exception:
                continue
            if "names" in d:
                return ("yaml", f, d)
    if (root / "labels").is_dir() and (root / "images").is_dir() and (root / "classes.txt").is_file():
        names = [l.strip() for l in (root / "classes.txt").read_text("utf-8").splitlines() if l.strip()]
        return ("txt", root / "classes.txt", {"names": names})
    return None


def _import_yolo(root: Path, found, c: Collector, progress, src: dict):
    _, cfg_file, d = found
    names = d["names"]
    names = [names[k] for k in sorted(names)] if isinstance(names, dict) else list(names)
    base = (cfg_file.parent / d["path"]) if isinstance(d.get("path"), str) and (cfg_file.parent / d["path"]).is_dir() else cfg_file.parent
    dirs = []
    for key in ("train", "val", "test"):
        v = d.get(key)
        for rel in (v if isinstance(v, list) else [v] if v else []):
            p = (base / rel) if not os.path.isabs(rel) else Path(rel)
            if not p.exists() and (cfg_file.parent / rel).exists():
                p = cfg_file.parent / rel
            if p.is_dir():
                dirs.append((SPLIT_NAMES.get(key), p))
    if not dirs:
        dirs = [(None, root / "images" if (root / "images").is_dir() else root)]
    files = []
    for split, folder in dirs:
        for dp, sub, fs in os.walk(folder):
            sub.sort()
            files += [(split, Path(dp) / f) for f in sorted(fs) if _images.is_image_name(f)]
    for i, (split, img) in enumerate(files):
        parts = list(img.parts)
        lbl = None
        for k in range(len(parts) - 1, -1, -1):
            if parts[k] == "images":
                lbl = Path(*parts[:k], "labels", *parts[k + 1:]).with_suffix(".txt")
                break
        w, h, _ = _images.probe(str(img))
        objs = []
        if lbl is not None and lbl.is_file():
            for line in lbl.read_text("utf-8").splitlines():
                v = line.split()
                if len(v) < 5:
                    continue
                k = int(float(v[0]))
                nums = [float(x) for x in v[1:]]
                cls = names[k] if 0 <= k < len(names) else str(k)
                if len(nums) == 4:
                    xc, yc, bw, bh = nums
                    objs.append({"class": cls, "bbox": [(xc - bw / 2) * w, (yc - bh / 2) * h, bw * w, bh * h]})
                elif len(nums) >= 6:                     # segmentation polygon
                    xs, ys = [x * w for x in nums[0::2]], [y * h for y in nums[1::2]]
                    poly = [round(v, 2) for p in zip(xs, ys) for v in p]
                    objs.append({"class": cls, "bbox": [min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)],
                                 "segmentation": [poly]})
        c.add(path=str(img), name=img.name, source=dict(src, format="yolo", original_filename=str(img.relative_to(root))),
              objects=objs, split=split, keep_orientation=True)
        progress(i + 1, len(files))
