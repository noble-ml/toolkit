# API reference

`import felix as fx`. The calls build a dataset step by step; `fx.export` runs them in the order they were made.

## `fx.load_class(path)` → list of class names
Load the target classes from YAML:

```yaml
classes:
  - leaf                                # just a name
  - name: fruit
    prompt: a ripe tomato on the vine   # for open-vocabulary models (default: the name)
    aliases: [tomato, Tomato]           # names that mean this class in imported data / model labels
    confidence: 0.4                     # optional minimum model confidence for this class
confidence: 0.25                        # optional default
```

A bare list (`classes: [leaf, fruit]` or a top-level list) works too. Class ids follow the file's order. Imported boxes
and detections are mapped onto these names (case-insensitive, through aliases); others are left out. Without a class
file, every class is kept and models detect all they know.

## `fx.acquire(sources, blur_faces=False)`
Add sources (a list of [`fx.sources`](sources.md); call again to add more). Nothing downloads yet. `blur_faces=True`
puts `fx.transform.blur_faces()` first, so every image is blurred before any other step.

## `fx.sampling`
`auto(threshold=0.04, min_gap=0.5, max_gap=None, check_fps=4, limit=None)`, `interval(seconds, start=0, limit=None)`,
`random(count, seed=0)`: which video frames to keep (see [Sources](sources.md#sampling)).

## `fx.transform`
Each call adds a step. Boxes and segmentation polygons move with the pixels; boxes keeping less than
`min_visibility` of their area after a crop are dropped.

| Step | What it does |
|---|---|
| `center_crop(size=640, min_visibility=0.3)` | the central region at the target shape (`640` or `(w, h)`), resized |
| `letterbox(size=640, fill=(114, 114, 114))` | the whole picture, resized to fit and padded; nothing is cut |
| `consequential(size=640, negative_rate=0.15, margin=0.25, min_visibility=0.3, overlap=0.6, seed=0)` | square crops around the annotated objects plus negative crops (see below). Must follow annotation; final for geometry |
| `dedupe(threshold=4)` | drops near-duplicates (64-bit difference hash; `threshold` bits may differ) |
| `map_classes({"Car": "vehicle"})` | renames classes; mapping to `None` removes them |
| `filter_classes(keep=[...])` / `(drop=[...])` | keeps only / removes boxes of some classes |
| `filter_images(min_width=0, min_height=0, max_aspect=None, require_objects=False, where=None)` | drops images |
| `blur_faces(strength=1.0, min_size=20)` | blurs faces found by OpenCV's face detectors (best effort) |
| `custom(fn, geometry=False, name=None)` | your own: `fn(image, objects) -> (image, objects)` or `None` to drop |

**consequential.** For each object not already well covered by a crop, a square around it with `margin` of its size on
each side, at least `size` pixels where the image allows (small objects are not blown up), kept inside the image
(grey padding only for objects larger than the short side). Every object inside a crop keeps its box. A crop
overlapping an earlier crop of the same image by more than `overlap` (IoU) is skipped. Negatives (squares touching no
object, from the same images or from annotated images without objects) are added so they make up `negative_rate` of
the output. Images whose annotation failed are left out, never used as negatives. Calling it before `fx.annotate`, or
a geometry step after it, raises an error at once.

## `fx.annotate(model, confidence=0.25, replace=False, batch_size=8)`
Boxes for every image without labels. `model`:
- a Workflow model: `wf.load("custom.nbm")` (detection gives boxes; a classification model gives image labels);
- a built-in model: `fx.models.yolo26n` (also `yolo26s/m/l/x`, `yolo26n_seg`), `fx.models.yoloe` (open vocabulary:
  prompted with classes.yml's prompts; without a class file, its prompt-free version), `fx.models.sam` (adds masks to
  existing boxes); call one to choose other weights, e.g. `fx.models.yolo26n("yolo26s.pt")`;
- a function `fn(image) -> [{"class", "bbox": [x, y, w, h] or "xyxy": [x1, y1, x2, y2], "confidence"}]`.

`replace=True` also re-annotates images that came with labels (otherwise model boxes are added only to unlabelled
images). Each box records its confidence and origin; each image records the model. An image the model fails on is
marked `failed`, reported, and left out of the export.

## `fx.export(path, pairs=None, *, license=None, title=None, authors=None, description=None, version=None, strict=False, shard_size=1000, overwrite=False, quiet=False)` → summary dict
Runs everything and writes the dataset:
- `path`: `name.felix` (one file), a folder, or `name.sh_felix` (the folder `name/` of shards, `shard_size` pairs each);
- `pairs`: stop after this many image/annotation pairs; `None` = until the sources run out, or Ctrl+C / `kill`,
  after which the dataset written so far is closed properly;
- `license`: `None` (closed: all rights reserved for the compilation), an open licence id (`"CC-BY-4.0"`,
  `"CC-BY-SA-4.0"`, `"CC0-1.0"`, `"CC-BY-NC-4.0"`, `"ODbL-1.0"`, …) or `"auto"` (the most permissive one every image
  allows); `strict=True` leaves out images whose licence does not fit; see [Licences](licensing.md);
- `title`, `authors`, `description`, `version`: for LICENSE.txt and CITATION.cff.

Images without a split get a stable 80 / 10 / 10 train / val / test split from their name; imported splits are kept.
Returns `{"pairs", "path", "license", "splits", "licence_issues", "failed", "stopped", "sources"}`.

## `fx.reset()`
Forget the class file, sources and steps (start another dataset in the same program).

## Reading and managing datasets
- `fx.load(path)` → `Dataset`: a `.felix` file, a folder, a folder of shards, a single `.sh_felix`, or class folders.
  `len(ds)`, `ds.stems`, `ds.classes`, `ds.metadata`, `ds.task`, `ds.splits`, `ds.train` / `ds.val` / `ds.test`,
  `ds.annotation(stem)`, `ds.image(stem)` (a Pillow image), `ds.image_bytes(stem)`; shards also `ds.shards`,
  `ds.shard_of`, `ds.load_shard(i)` / `ds.release_shard(i)`.
- `fx.split(source, fraction=None, output=None, *, size=None, seed=0)`: a smaller copy (same share of every split and
  class).
- `fx.partition(source, output=None, parts=None, ratio=None, size=None, by_split=False, …)`: several smaller datasets.
- `fx.shard(source, output=None, *, size=None, shards=None)`: a folder of `.sh_felix` shards.

## Errors
Every problem raises `fx.FelixError` with a message saying what to change.
