from __future__ import annotations

import argparse
import os
import runpy
import sys

from . import _ui
from ._ui import Panel, fmt_n
from ._version import __version__
from .errors import FelixError
from .store import Dataset, open_reader, open_writer


def _transfer(src, dst, verb, overwrite):
    r = open_reader(src)
    names = r.names()
    w = open_writer(dst, overwrite)
    panel = Panel("")
    panel.title = panel.join(f"Felix {verb}", f"{src} → {dst}" if panel.uni else f"{src} -> {dst}")
    panel.sub = panel.join("Worker running", f"{fmt_n(len(names))} files")
    row = panel.row("files", len(names))
    try:
        with panel:
            for i, n in enumerate(names):
                w.write(n, r.read(n))
                row.label = f"file {fmt_n(i + 1)}/{fmt_n(len(names))}"
                row.advance()
            w.close()
            row.done()
            row.foot = f"written to {dst}"
    except BaseException:
        w.abort()
        raise
    finally:
        r.close()


def _info(path):
    ds = Dataset(path)
    panel = Panel("")
    panel.title = panel.join("Felix info", path)
    m = ds.metadata
    cls = ds.task == "classification"
    panel.sub = panel.join(f"{fmt_n(len(ds))} {'images' if cls else 'pairs'}",
                           "classification" if cls else "detection",
                           m.get("layout") or f"felix {m.get('felix_version', '?')}",
                           f"created {m['created']}" if m.get("created") else "")
    row = panel.row("annotations", len(ds))
    counts, sizes, per_split = {}, {}, {}
    split_of = {s: k for k in ("train", "val", "test") for s in getattr(ds, k).stems}
    with panel:
        for i, (stem, a) in enumerate(ds):
            if cls:
                c = a.get("class")
                counts[c] = counts.get(c, 0) + 1
                key = (c, split_of.get(stem, "train"))
                per_split[key] = per_split.get(key, 0) + 1
            else:
                sizes[(a.get("width"), a.get("height"))] = sizes.get((a.get("width"), a.get("height")), 0) + 1
                for o in a.get("objects") or []:
                    counts[o["class"]] = counts.get(o["class"], 0) + 1
            row.label = f"file {fmt_n(i + 1)}/{fmt_n(len(ds))}"
            row.advance()
        row.done()
        if cls:
            row.stats = panel.join(f"{len(counts)} classes",
                                   *(f"{k} {fmt_n(n)}" for k, n in ds.splits.items() if n))
        else:
            row.stats = panel.join(f"{fmt_n(sum(counts.values()))} boxes",
                                   *(f"{w}x{h} ×{n}" if panel.uni else f"{w}x{h} x{n}" for (w, h), n in sizes.items()))
    classes = m.get("classes") or [{"id": i, "name": n, "set": "?"} for i, n in enumerate(sorted(counts))]
    if cls:
        panel.table(["id", "class", "images", "train", "val", "test"],
                    [(c["id"], c["name"], fmt_n(counts.get(c["name"], 0)),
                      *(fmt_n(per_split.get((c["name"], k), 0)) for k in ("train", "val", "test"))) for c in classes])
    else:
        panel.table(["id", "class", "set", "boxes"],
                    [(c["id"], c["name"], c.get("set", ""), fmt_n(counts.get(c["name"], 0))) for c in classes])
    ds.close()


def _run(script, rest):
    if not os.path.isfile(script):
        raise FelixError(f"{script} not found")
    sys.argv = [script] + rest
    sys.path.insert(0, os.path.dirname(os.path.abspath(script)))
    runpy.run_path(script, run_name="__main__")


def build_parser():
    p = argparse.ArgumentParser(prog="felix", description="Felix dataset pipeline generator.")
    p.add_argument("--version", action="version", version=f"felix {__version__}")
    sub = p.add_subparsers(dest="cmd", metavar="command")
    s = sub.add_parser("run", help="run a pipeline script")
    s.add_argument("script")
    s.add_argument("args", nargs=argparse.REMAINDER)
    s = sub.add_parser("library", help="browse every function and command, with explanations; type to search")
    s.add_argument("query", nargs="*", help="start with this search, e.g. felix library split")
    s = sub.add_parser("pack", help="compress a dataset folder into one .felix file")
    s.add_argument("folder")
    s.add_argument("-o", "--output")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("unpack", help="expand a .felix file into a folder")
    s.add_argument("file")
    s.add_argument("-o", "--output")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("info", help="summarise a dataset (folder or .felix)")
    s.add_argument("path")
    s = sub.add_parser("partition", help="split a dataset into several smaller datasets")
    s.add_argument("source", help="dataset folder or .felix file")
    s.add_argument("-o", "--output", help="folder for the pieces (default: <source>_parts)")
    how = s.add_mutually_exclusive_group(required=True)
    how.add_argument("--parts", type=int, metavar="N", help="N equal pieces")
    how.add_argument("--ratio", metavar="A,B,...", help="proportional pieces, e.g. 80,10,10")
    how.add_argument("--size", type=int, metavar="K", help="pieces of at most K pairs")
    how.add_argument("--by-split", action="store_true", help="one piece per train/val/test split")
    s.add_argument("--names", metavar="A,B,...", help="names for the pieces (default: part1, part2, ...)")
    s.add_argument("--shuffle", action="store_true", help="shuffle before splitting (default: keep order)")
    s.add_argument("--seed", type=int, default=0, help="seed for --shuffle (default 0)")
    kind = s.add_mutually_exclusive_group()
    kind.add_argument("--pack", action="store_true", help="write .felix files (default for a .felix source)")
    kind.add_argument("--folders", action="store_true", help="write folders (default for a folder source)")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("split", help="make a smaller copy of a dataset (e.g. 0.5 = half) for quick experiments",
                       description="Copy a share of a dataset into a new one; the original is not changed. "
                                   "Each train/val/test split keeps the same share, picked at random.",
                       usage="felix split source fraction [-o OUTPUT] [--seed N]   or   felix split source --size N")
    s.add_argument("source", help="dataset folder or .felix file")
    s.add_argument("fraction", nargs="?", type=float, help="share to keep, e.g. 0.5 (half) or 0.1 (a tenth)")
    s.add_argument("--size", type=int, metavar="N", help="keep N pairs instead of a fraction")
    s.add_argument("-o", "--output", help="where to write it (default: <name>_split_<percent>.felix next to the source)")
    s.add_argument("--seed", type=int, default=0, help="which random subset (default 0; same seed, same subset)")
    s.add_argument("--overwrite", action="store_true")
    s = sub.add_parser("convert", help="convert other dataset formats into Felix")
    cs = s.add_subparsers(dest="fmt", metavar="format", required=True)
    c = cs.add_parser("coco", help="Roboflow / COCO export (folder or .zip)")
    c.add_argument("source")
    c.add_argument("-o", "--output", required=True, help="output folder, or a .felix file")
    c.add_argument("--png", action="store_true", help="re-encode images to PNG (much larger files)")
    c.add_argument("--overwrite", action="store_true")
    c = cs.add_parser("folders", aliases=["imagenet", "classes"],
                      help="ImageNet-style class folders (cat/, dog/, … optionally inside train/ val/ test/), for classification")
    c.add_argument("source")
    c.add_argument("-o", "--output", help="output .felix file or folder (default: SOURCE.felix)")
    c.add_argument("--overwrite", action="store_true")
    return p


def main(argv=None):
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(errors="replace")
        except Exception:
            pass
    p = build_parser()
    a = p.parse_args(argv)
    try:
        if a.cmd == "run":
            _run(a.script, a.args)
        elif a.cmd == "library":
            from . import tui
            return tui.run(" ".join(a.query))
        elif a.cmd == "pack":
            src = a.folder.rstrip("/\\")
            _transfer(a.folder, a.output or src + ".felix", "pack", a.overwrite)
        elif a.cmd == "unpack":
            out = a.output or (a.file[:-6] if a.file.lower().endswith(".felix") else a.file + "_unpacked")
            _transfer(a.file, out, "unpack", a.overwrite)
        elif a.cmd == "info":
            _info(a.path)
        elif a.cmd == "split":
            from .split import split
            if a.fraction is None and a.size is None:
                raise FelixError("say how much to keep: a fraction such as 0.5, or --size N")
            split(a.source, a.fraction, a.output, size=a.size, seed=a.seed, overwrite=a.overwrite)
        elif a.cmd == "partition":
            from .partition import partition
            try:
                ratio = [float(v) for v in a.ratio.split(",")] if a.ratio else None
            except ValueError:
                raise FelixError(f"--ratio must be numbers separated by commas, got {a.ratio!r}") from None
            partition(a.source, a.output, parts=a.parts, ratio=ratio, size=a.size, by_split=a.by_split,
                      names=a.names.split(",") if a.names else None, shuffle=a.shuffle, seed=a.seed,
                      pack=True if a.pack else False if a.folders else None, overwrite=a.overwrite)
        elif a.cmd == "convert" and a.fmt == "coco":
            from .coco import convert_coco
            convert_coco(a.source, a.output, not a.png, a.overwrite)
        elif a.cmd == "convert":                    # class folders: the same files, plus the annotations Felix makes up
            from .store import class_folder_layout
            src = a.source.rstrip("/\\")
            if class_folder_layout(src) is None:
                raise FelixError(f"{a.source} is not a folder of class folders: expected cat/, dog/, … with images "
                                 "inside (optionally within train/ val/ test/)")
            _transfer(src, a.output or src + ".felix", "convert", a.overwrite)
        else:
            _ui.banner(__version__, [("run", "run a pipeline script"), ("library", "browse every function and command; search"), ("pack", "folder → single .felix"),
                                     ("unpack", ".felix → folder"), ("info", "summarise a dataset"), ("partition", "split a dataset into pieces"), ("split", "smaller copy for experiments (e.g. 0.5)"),
                                     ("convert", "import coco / roboflow datasets, or class folders")])
    except FelixError as e:
        _ui.error(str(e))
        return 1
    except KeyboardInterrupt:
        _ui.error("interrupted")
        return 130
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
