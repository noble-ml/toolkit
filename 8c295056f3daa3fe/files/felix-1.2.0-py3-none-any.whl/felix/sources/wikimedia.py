"""``fx.sources.wikimedia(query=, limit=)``: freely licensed photos from Wikimedia Commons, with their licence and
attribution (https://commons.wikimedia.org, MediaWiki Action API)."""
from __future__ import annotations

import html
import os
import re
import urllib.parse
from typing import Optional, Sequence

from .. import _http
from ..errors import FelixError
from ._base import Collector, Source

API = "https://commons.wikimedia.org/w/api.php"
META = "LicenseShortName|LicenseUrl|Artist|Credit|AttributionRequired|UsageTerms|Copyrighted|Attribution|ObjectName|DateTimeOriginal"


def _plain(v) -> Optional[str]:
    if v is None:
        return None
    t = html.unescape(re.sub(r"<[^>]+>", "", str(v)))
    return re.sub(r"\s+", " ", t).strip() or None


class wikimedia(Source):
    """Search Wikimedia Commons (File namespace, bitmap images) for ``query`` and download up to ``limit`` images.
    Without a query: random files from Commons (photos and other bitmaps), until ``limit`` or the export has enough.

    ``limit``: at most this many images (None: keep going through the search results until the export has enough).
    ``licenses``: keep only these licences, matched against the start of Commons' short licence name, e.g.
    ``["CC0", "Public domain", "CC BY 4.0", "CC BY-SA"]``; None keeps all (Commons only hosts freely licensed files, but
    most require attribution and some share-alike). ``max_side``: download a scaled copy no wider than this (Commons
    serves thumbnails), instead of originals that can be 50 megapixels. ``min_side``: skip small images.
    The API is called one request at a time with ``maxlag`` (Wikimedia's etiquette); set FELIX_CONTACT so the
    User-Agent includes a way to reach you, as Wikimedia's policy asks."""

    kind = "wikimedia"

    def __init__(self, query: Optional[str] = None, limit: Optional[int] = None, licenses: Optional[Sequence[str]] = None, max_side: int = 2048,
                 min_side: int = 256):
        if query is not None and not str(query).strip():
            raise FelixError("sources.wikimedia: query must not be empty (or None for random files)")
        if limit is not None and (not isinstance(limit, int) or limit < 1):
            raise FelixError("sources.wikimedia: limit must be a positive whole number (or None: as many as there are)")
        self.query, self.limit, self.max_side, self.min_side = (str(query) if query else None), limit, max_side, min_side
        self.licenses = [l.lower() for l in licenses] if licenses else None

    def label(self):
        return f"wikimedia “{self.query}”" if self.query else "wikimedia (random files)"

    def describe(self):
        return {"type": "wikimedia", "query": self.query, "limit": self.limit}

    def _pages(self):
        cont, seen, stale = {}, set(), 0
        while True:
            q = {"action": "query", "format": "json", "formatversion": "2",
                 "prop": "imageinfo", "iiprop": "url|size|mime|extmetadata", "iiurlwidth": str(self.max_side),
                 "iiextmetadatafilter": META, "maxlag": "5"}
            if self.query:
                q.update({"generator": "search", "gsrsearch": f"{self.query} filetype:bitmap", "gsrnamespace": "6", "gsrlimit": "50"})
                q.update(cont)
            else:                                     # no query: random files, as many as wanted
                q.update({"generator": "random", "grnnamespace": "6", "grnlimit": "50"})
            d = _http.get_json(API + "?" + urllib.parse.urlencode(q), interval=1.0)
            if "error" in d:
                err = d["error"]
                if err.get("code") == "maxlag":
                    continue                              # the request helper already paces; just ask again
                raise FelixError(f"Wikimedia API error: {err.get('info') or err.get('code')}")
            pages = sorted((d.get("query") or {}).get("pages") or [], key=lambda p: p.get("index", 0))
            new = [pg for pg in pages if pg.get("title") not in seen]
            for pg in new:
                seen.add(pg.get("title"))
                yield pg
            if not self.query:
                stale = 0 if new else stale + 1
                if stale >= 5:                            # nothing new five times running: Commons has no more for us
                    return
                continue
            if "continue" not in d:
                return
            cont = {k: v for k, v in d["continue"].items()}

    def _collect_query(self, c: Collector, progress):
        got = 0
        for page in self._pages():
            if c.reached(self.limit):
                break
            info = (page.get("imageinfo") or [{}])[0]
            title = page.get("title", "")
            mime = info.get("mime", "")
            if mime not in ("image/jpeg", "image/png", "image/webp"):
                continue
            if min(info.get("width", 0), info.get("height", 0)) < self.min_side:
                continue
            meta = {k: (v or {}).get("value") for k, v in (info.get("extmetadata") or {}).items()}
            lic = _plain(meta.get("LicenseShortName")) or "unknown"
            if self.licenses and not any(lic.lower().startswith(l) for l in self.licenses):
                continue
            big = max(info.get("width", 0), info.get("height", 0)) > self.max_side
            url = info.get("thumburl") if big and info.get("thumburl") else info.get("url")
            if not url:
                continue
            artist = _plain(meta.get("Attribution")) or _plain(meta.get("Artist"))
            src = {"type": "wikimedia", "title": title, "url": url, "page": info.get("descriptionurl"),
                   "original_url": info.get("url"), "original_size": [info.get("width"), info.get("height")],
                   "license": lic, "license_url": meta.get("LicenseUrl"), "author": artist,
                   "credit": _plain(meta.get("Credit")), "usage_terms": _plain(meta.get("UsageTerms")),
                   "attribution_required": str(meta.get("AttributionRequired", "")).lower() in ("true", "1", "yes"),
                   "query": self.query}
            src["attribution"] = f"{title.replace('File:', '')} by {artist or 'unknown author'}, {lic}, via Wikimedia Commons ({info.get('descriptionurl')})"
            name = os.path.basename(urllib.parse.unquote(urllib.parse.urlsplit(info.get("url", "")).path)) or title
            from ._base import fetch
            fetch(c, url, name, src)
            got = c.taken
            progress(c.count, self.limit)
        c.drain()
        if self.limit is not None and c.count < self.limit:
            c.skip(f"wikimedia “{self.query}”", f"only {c.count} suitable images found (asked for {self.limit})")
