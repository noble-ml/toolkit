"""Openly licensed collections: Openverse, iNaturalist, GBIF, NASA, the Art Institute of Chicago and the
Smithsonian. (The Met is not included: its image server only serves browsers, not programs.) None needs an account (the Smithsonian works with a free api.data.gov key; a shared demo key otherwise).
Every image keeps its licence, creator and the page it came from."""
from __future__ import annotations

import os
import urllib.parse
from typing import Optional, Sequence

from .. import _http
from ..errors import FelixError
from ._base import Collector, Source, fetch, need_int


def _q(params) -> str:
    return urllib.parse.urlencode({k: v for k, v in params.items() if v is not None}, doseq=True)


class _Search(Source):
    """A keyword search over a paged API; ``limit`` None = as many as the provider gives. ``query=None``: no target,
    whatever the provider lists."""

    def __init__(self, query: Optional[str] = None, limit: Optional[int] = None):
        if query is not None and not str(query).strip():
            raise FelixError(f"sources.{self.kind}: query must not be empty (or None for anything)")
        self.query, self.limit = (str(query) if query else None), need_int(limit, f"sources.{self.kind}: limit")

    def label(self):
        return f"{self.kind} “{self.query}”" if self.query else f"{self.kind} (anything)"

    def describe(self):
        return {"type": self.kind, "query": self.query, "limit": self.limit}

    def done(self, c: Collector) -> bool:
        return c.reached(self.limit)


# ---------------------------------------------------------------------------------------------------------- Openverse
class openverse(_Search):
    """Openverse (openverse.org): openly licensed images from Flickr, Wikimedia, museums and more, searched in one
    place. ``licenses``: e.g. ["cc0", "pdm", "by", "by-sa"]; ``commercial=True`` (default) keeps only licences that
    allow commercial use. Anonymous access is rate-limited by Openverse; the request pace here stays well under it."""

    kind = "openverse"
    API = "https://api.openverse.org/v1/images/"

    def __init__(self, query=None, limit=None, licenses: Optional[Sequence[str]] = None, commercial: bool = True,
                 source: Optional[str] = None):
        super().__init__(query, limit)
        self.licenses, self.commercial, self.provider = licenses, commercial, source

    def _collect_query(self, c: Collector, progress):
        page = 1
        while not self.done(c):
            d = _http.get_json(self.API + "?" + _q({
                "q": self.query, "page": page, "page_size": 20, "license": ",".join(self.licenses) if self.licenses else None,
                "license_type": "commercial" if self.commercial and not self.licenses else None, "source": self.provider,
                "extension": "jpg,png,webp"}),                    # photos only: no SVG drawings or GIFs
                interval=1.0)
            results = d.get("results") or []
            if not results:
                return
            for r in results:
                if self.done(c):
                    return
                lic = f"CC {r.get('license', '').upper()} {r.get('license_version') or ''}".strip()
                if r.get("license") in ("cc0", "pdm"):
                    lic = {"cc0": "CC0 1.0", "pdm": "Public Domain Mark 1.0"}[r["license"]]
                fetch(c, r["url"], os.path.basename(urllib.parse.urlsplit(r["url"]).path) or f"{r.get('id')}.jpg",
                      {"type": "openverse", "id": r.get("id"), "url": r.get("url"), "page": r.get("foreign_landing_url"),
                       "provider": r.get("provider"), "title": r.get("title"), "author": r.get("creator"),
                       "author_page": r.get("creator_url"), "license": lic, "license_url": r.get("license_url"),
                       "attribution": r.get("attribution"), "query": self.query})
                progress(c.count, self.limit)
            if page >= int(d.get("page_count") or page):
                return
            page += 1


# ---------------------------------------------------------------------------------------------------------- iNaturalist
def _inat_license(code: str) -> str:
    """iNaturalist's codes (cc0, cc-by, cc-by-sa, …) are Creative Commons 4.0 licences (CC0 1.0)."""
    if code == "cc0":
        return "CC0 1.0"
    return "CC " + code[3:].upper() + " 4.0"

class inaturalist(Source):
    """Research-grade observation photos from iNaturalist, by taxon (``taxon="Quercus"`` or a common name; None: any
    species).
    ``licenses``: photo licences to accept (default commercial-friendly: cc0, cc-by, cc-by-sa). ``size``: "large"
    (1024 px, default), "medium", "original". ``label=True`` labels each image with its taxon (classification)."""

    kind = "inaturalist"
    API = "https://api.inaturalist.org/v1/observations"

    def __init__(self, taxon: Optional[str] = None, limit: Optional[int] = None, licenses=("cc0", "cc-by", "cc-by-sa"),
                 size: str = "large", quality: str = "research", label: bool = False, place_id: Optional[int] = None):
        if taxon is not None and not str(taxon).strip():
            raise FelixError("sources.inaturalist: taxon must not be empty (or None for any species)")
        if size not in ("small", "medium", "large", "original"):
            raise FelixError("sources.inaturalist: size must be small, medium, large or original")
        self.taxon, self.limit, self.licenses, self.size = taxon, need_int(limit, "sources.inaturalist: limit"), list(licenses), size
        self.quality, self.as_label, self.place_id = quality, label, place_id

    def label(self):
        return f"inaturalist {self.taxon or '(any species)'}"

    def describe(self):
        return {"type": "inaturalist", "taxon": self.taxon, "licenses": self.licenses, "limit": self.limit}

    def collect(self, c: Collector, progress):
        page, wanted = 1, set(self.licenses)
        while self.limit is None or not c.reached(self.limit):
            d = _http.get_json(self.API + "?" + _q({
                "taxon_name": self.taxon, "photo_license": ",".join(self.licenses), "quality_grade": self.quality,
                "per_page": 50, "page": page, "place_id": self.place_id, "photos": "true", "order_by": "id"}), interval=1.0)
            res = d.get("results") or []
            if not res:
                return
            for o in res:
                taxon = (o.get("taxon") or {}).get("name") or self.taxon
                for p in o.get("photos") or []:
                    if c.reached(self.limit):
                        return
                    if p.get("license_code") not in wanted:
                        continue                            # observation licence and photo licence can differ
                    url = (p.get("url") or "").replace("/square.", f"/{self.size}.")
                    fetch(c, url, f"inat_{p.get('id')}.jpg",
                          {"type": "inaturalist", "observation": o.get("uri"), "photo_id": p.get("id"), "url": url,
                           "license": _inat_license(p["license_code"]),
                           "attribution": p.get("attribution"), "author": (o.get("user") or {}).get("login"),
                           "taxon": taxon}, interval=0.0,
                          label=taxon if self.as_label else None)
                    progress(c.count, self.limit)
            if page * 50 >= min(int(d.get("total_results") or 0), 10000):
                return                                       # iNaturalist pages stop at 10,000 results
            page += 1


# ---------------------------------------------------------------------------------------------------------- GBIF
class gbif(Source):
    """Occurrence images from GBIF (gbif.org, the Global Biodiversity Information Facility), by scientific name and/or
    free text (neither: any occurrence with an image). ``licenses``: GBIF licence codes to accept (default CC0_1_0 and CC_BY_4_0; add CC_BY_NC_4_0 for
    non-commercial use). The image licence is recorded as given by the publishing institution."""

    kind = "gbif"
    API = "https://api.gbif.org/v1/occurrence/search"

    def __init__(self, scientific_name: Optional[str] = None, query: Optional[str] = None, limit: Optional[int] = None,
                 licenses=("CC0_1_0", "CC_BY_4_0"), country: Optional[str] = None):
        self.name, self.query, self.limit = scientific_name, query, need_int(limit, "sources.gbif: limit")
        self.licenses, self.country = list(licenses), country

    def label(self):
        return f"gbif {self.name or self.query or '(any)'}"

    def describe(self):
        return {"type": "gbif", "scientific_name": self.name, "query": self.query, "licenses": self.licenses}

    def collect(self, c: Collector, progress):
        offset = 0
        while self.limit is None or not c.reached(self.limit):
            d = _http.get_json(self.API + "?" + _q({"mediaType": "StillImage", "scientificName": self.name, "q": self.query,
                                                    "license": self.licenses, "country": self.country,
                                                    "limit": 100, "offset": offset}), interval=0.5)
            for r in d.get("results") or []:
                for m in r.get("media") or []:
                    if c.reached(self.limit):
                        return
                    if m.get("type") != "StillImage" or not m.get("identifier"):
                        continue
                    fetch(c, m["identifier"], f"gbif_{r.get('key')}.jpg",
                          {"type": "gbif", "occurrence": f"https://www.gbif.org/occurrence/{r.get('key')}",
                           "url": m["identifier"], "page": m.get("references"), "license": m.get("license") or r.get("license"),
                           "record_license": r.get("license"), "author": m.get("creator") or r.get("recordedBy"),
                           "rights_holder": m.get("rightsHolder") or r.get("rightsHolder"), "publisher": r.get("publisher"),
                           "taxon": r.get("scientificName")}, interval=0.3)
                    progress(c.count, self.limit)
            if d.get("endOfRecords", True):
                return
            offset += 100


# ---------------------------------------------------------------------------------------------------------- NASA
class nasa(_Search):
    """The NASA Image and Video Library (images.nasa.gov). NASA imagery is generally not copyrighted in the US, but
    some items are third-party or show people/logos with restrictions: see NASA's media usage guidelines.
    ``size``: "large" (default), "medium", "orig"."""

    kind = "nasa"
    API = "https://images-api.nasa.gov"

    def __init__(self, query=None, limit=None, size: str = "large"):
        super().__init__(query, limit)
        if size not in ("small", "medium", "large", "orig"):
            raise FelixError("sources.nasa: size must be small, medium, large or orig")
        self.size = size

    def _collect_query(self, c: Collector, progress):
        page = 1
        while not self.done(c):
            d = _http.get_json(f"{self.API}/search?" + _q({"q": self.query, "media_type": "image", "page": page,
                                                         "page_size": 100}), interval=0.5)
            items = (d.get("collection") or {}).get("items") or []
            if not items:
                return
            for it in items:
                if self.done(c):
                    return
                meta = (it.get("data") or [{}])[0]
                nid = meta.get("nasa_id")
                try:
                    assets = _http.get_json(it["href"], interval=0.2)
                except (FelixError, KeyError):
                    continue
                hrefs = assets if isinstance(assets, list) else [a.get("href") for a in (assets.get("collection") or {}).get("items", [])]
                pick = next((h for want in (f"~{self.size}.", "~large.", "~orig.", "~medium.")
                             for h in hrefs if isinstance(h, str) and want in h and h.lower().endswith((".jpg", ".jpeg", ".png"))), None)
                if not pick:
                    continue
                fetch(c, pick.replace("http://", "https://", 1), f"{nid}.jpg",
                      {"type": "nasa", "query": self.query, "id": nid, "url": pick, "page": f"https://images.nasa.gov/details/{nid}",
                       "title": meta.get("title"), "center": meta.get("center"), "author": meta.get("photographer") or meta.get("secondary_creator"),
                       "date": meta.get("date_created"),
                       "license": "NASA media (generally not copyrighted in the US; see https://www.nasa.gov/nasa-brand-center/images-and-media/)"},
                      interval=0.0)
                progress(c.count, self.limit)
            page += 1


# ---------------------------------------------------------------------------------------------------------- Art Institute of Chicago
class artic(_Search):
    native_anything = False                                 # no "anything" listing we can rely on: vocabulary only
    """The Art Institute of Chicago: public-domain artworks (CC0), images through its IIIF server (843 px wide, the
    size the museum asks API users to request)."""

    kind = "artic"
    API = "https://api.artic.edu/api/v1/artworks/search"

    def _collect_query(self, c: Collector, progress):
        page = 1
        hdr = {"AIC-User-Agent": _http.user_agent()}
        while not self.done(c):
            d = _http.get_json(self.API + "?" + _q({"q": self.query, "query[term][is_public_domain]": "true", "limit": 100,
                                                    "page": page, "fields": "id,title,image_id,artist_display,is_public_domain"}),
                               interval=1.0, headers=hdr)
            rows = d.get("data") or []
            iiif = (d.get("config") or {}).get("iiif_url") or "https://www.artic.edu/iiif/2"
            if not rows:
                return
            for r in rows:
                if self.done(c):
                    return
                if not r.get("is_public_domain") or not r.get("image_id"):
                    continue
                url = f"{iiif}/{r['image_id']}/full/843,/0/default.jpg"
                fetch(c, url, f"artic_{r['id']}.jpg",
                      {"type": "artic", "query": self.query, "id": r["id"], "url": url, "page": f"https://www.artic.edu/artworks/{r['id']}",
                       "title": r.get("title"), "author": r.get("artist_display"), "license": "CC0 1.0 (public domain)"},
                      interval=0.5, headers=hdr)
                progress(c.count, self.limit)
            if page >= int((d.get("pagination") or {}).get("total_pages") or page):
                return
            page += 1


# ---------------------------------------------------------------------------------------------------------- Smithsonian
class smithsonian(_Search):
    """Smithsonian Open Access: CC0 images from the Smithsonian's museums and archives. Uses an api.data.gov key
    (free: https://api.data.gov/signup) from ``api_key=``, the API_DATA_GOV_KEY environment variable or
    ``api_data_gov_key:`` in the credentials file; without one, the shared DEMO_KEY (a few requests per hour)."""

    kind = "smithsonian"
    API = "https://api.si.edu/openaccess/api/v1.0/search"

    def __init__(self, query=None, limit=None, api_key: Optional[str] = None):
        super().__init__(query, limit)
        self._key = api_key

    def _collect_query(self, c: Collector, progress):
        try:
            key = _http.credential("api_data_gov_key", self._key, "API_DATA_GOV_KEY", "sources.smithsonian")
        except FelixError:
            key = "DEMO_KEY"
        start = 0
        while not self.done(c):
            q = f'{self.query} AND online_media_type:"Images"' if self.query else 'online_media_type:"Images"'
            d = _http.get_json(self.API + "?" + _q({"q": q, "rows": 100,
                                                    "start": start, "api_key": key}), interval=1.0)
            rows = (d.get("response") or {}).get("rows") or []
            if not rows:
                return
            for r in rows:
                dn = (r.get("content") or {}).get("descriptiveNonRepeating") or {}
                for m in (dn.get("online_media") or {}).get("media") or []:
                    if self.done(c):
                        return
                    if m.get("type") != "Images" or not m.get("content"):
                        continue
                    if ((m.get("usage") or {}).get("access") or (dn.get("metadata_usage") or {}).get("access")) != "CC0":
                        continue                           # only Open Access (CC0) media
                    fetch(c, m["content"], f"si_{r.get('id', 'item')}.jpg",
                          {"type": "smithsonian", "query": self.query, "id": r.get("id"), "url": m["content"], "page": dn.get("record_link"),
                           "title": r.get("title"), "unit": r.get("unitCode"), "license": "CC0 1.0 (Smithsonian Open Access)",
                           "usage_terms": (m.get("usage") or {}).get("text")})
                    progress(c.count, self.limit)
            start += 100
