"""Stock photo services with free API keys: Unsplash, Pexels and Flickr. Each needs your own key (see each class),
and each has terms that go with its photos; they are recorded with every image and in the exported licence files."""
from __future__ import annotations

import urllib.parse
from typing import Optional, Sequence

from .. import _http
from ..errors import FelixError
from ._base import Collector, Source, fetch, need_int


def _q(params) -> str:
    return urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})


class unsplash(Source):
    """Unsplash photos (unsplash.com). Key: an Unsplash app's Access Key (unsplash.com/oauth/applications) via
    ``api_key=``, UNSPLASH_ACCESS_KEY or ``unsplash_access_key:`` in the credentials file. Demo apps get 50 requests
    an hour. As Unsplash's API guidelines require, every download is reported to Unsplash's download endpoint.
    Photos are under the Unsplash License (free use, no selling unaltered copies, no building a competing service)."""

    kind = "unsplash"
    API = "https://api.unsplash.com"

    def __init__(self, query: Optional[str] = None, limit: Optional[int] = None, size: str = "regular",
                 orientation: Optional[str] = None, api_key: Optional[str] = None):
        if size not in ("regular", "full", "small"):
            raise FelixError("sources.unsplash: size must be regular (1080 px), full or small")
        self.query, self.limit, self.size, self.orientation, self._key = query, need_int(limit, "sources.unsplash: limit"), size, orientation, api_key

    def label(self):
        return f"unsplash “{self.query}”" if self.query else "unsplash (latest photos)"

    def describe(self):
        return {"type": "unsplash", "query": self.query, "limit": self.limit}

    def _collect_query(self, c: Collector, progress):
        key = _http.credential("unsplash_access_key", self._key, "UNSPLASH_ACCESS_KEY", "sources.unsplash")
        hdr = {"Authorization": f"Client-ID {key}", "Accept-Version": "v1"}
        page = 1
        while self.limit is None or not c.reached(self.limit):
            if self.query:
                d = _http.get_json(f"{self.API}/search/photos?" + _q({"query": self.query, "page": page, "per_page": 30,
                                                                    "orientation": self.orientation}), interval=1.0, headers=hdr)
                res = d.get("results") or []
            else:                                      # no query: the photo feed, newest first
                res = _http.get_json(f"{self.API}/photos?" + _q({"page": page, "per_page": 30, "order_by": "latest"}),
                                     interval=1.0, headers=hdr) or []
                d = {"total_pages": page + 1 if res else page}
            if not res:
                return
            for p in res:
                if c.reached(self.limit):
                    return
                user = p.get("user") or {}
                url = (p.get("urls") or {}).get(self.size)
                if not url:
                    continue
                track = (p.get("links") or {}).get("download_location")

                def tracked(it, track=track):                # required by Unsplash: report every download
                    if track:
                        try:
                            _http.request(track, headers=hdr, interval=1.0)
                        except FelixError:
                            pass
                fetch(c, url, f"unsplash_{p.get('id')}.jpg",
                      {"type": "unsplash", "query": self.query, "id": p.get("id"), "url": url, "page": (p.get("links") or {}).get("html"),
                       "author": user.get("name"), "author_page": (user.get("links") or {}).get("html"),
                       "license": "Unsplash License", "license_url": "https://unsplash.com/license",
                       "attribution": f"Photo by {user.get('name')} on Unsplash"}, after=tracked)
                progress(c.count, self.limit)
            if page >= int(d.get("total_pages") or page):
                return
            page += 1


class pexels(Source):
    """Pexels photos (pexels.com). Key: free from pexels.com/api, via ``api_key=``, PEXELS_API_KEY or
    ``pexels_api_key:`` in the credentials file (200 requests an hour). Photos are under the Pexels License; Pexels
    asks for credit ("Photo by … on Pexels"), which is recorded with every image."""

    kind = "pexels"
    API = "https://api.pexels.com/v1/search"

    def __init__(self, query: Optional[str] = None, limit: Optional[int] = None, size: str = "large2x",
                 orientation: Optional[str] = None, api_key: Optional[str] = None):
        if size not in ("original", "large2x", "large", "medium"):
            raise FelixError("sources.pexels: size must be original, large2x, large or medium")
        self.query, self.limit, self.size, self.orientation, self._key = query, need_int(limit, "sources.pexels: limit"), size, orientation, api_key

    def label(self):
        return f"pexels “{self.query}”" if self.query else "pexels (curated photos)"

    def describe(self):
        return {"type": "pexels", "query": self.query, "limit": self.limit}

    def _collect_query(self, c: Collector, progress):
        key = _http.credential("pexels_api_key", self._key, "PEXELS_API_KEY", "sources.pexels")
        hdr = {"Authorization": key}
        page = 1
        while self.limit is None or not c.reached(self.limit):
            url = (self.API + "?" + _q({"query": self.query, "page": page, "per_page": 80, "orientation": self.orientation})
                   if self.query else "https://api.pexels.com/v1/curated?" + _q({"page": page, "per_page": 80}))
            d = _http.get_json(url, interval=18.0, headers=hdr)
            photos = d.get("photos") or []
            if not photos:
                return
            for p in photos:
                if c.reached(self.limit):
                    return
                url = (p.get("src") or {}).get(self.size)
                if not url:
                    continue
                fetch(c, url, f"pexels_{p.get('id')}.jpg",
                      {"type": "pexels", "query": self.query, "id": p.get("id"), "url": url, "page": p.get("url"), "author": p.get("photographer"),
                       "author_page": p.get("photographer_url"), "license": "Pexels License",
                       "license_url": "https://www.pexels.com/license/", "attribution": f"Photo by {p.get('photographer')} on Pexels"},
                      interval=0.2)
                progress(c.count, self.limit)
            if not d.get("next_page"):
                return
            page += 1


FLICKR_LICENSES = {0: "All Rights Reserved", 1: "CC BY-NC-SA 2.0", 2: "CC BY-NC 2.0", 3: "CC BY-NC-ND 2.0", 4: "CC BY 2.0",
                   5: "CC BY-SA 2.0", 6: "CC BY-ND 2.0", 7: "No known copyright restrictions", 8: "United States Government Work",
                   9: "CC0 1.0", 10: "Public Domain Mark 1.0", 11: "CC BY 4.0", 12: "CC BY-SA 4.0", 13: "CC BY-ND 4.0",
                   14: "CC BY-NC 4.0", 15: "CC BY-NC-SA 4.0", 16: "CC BY-NC-ND 4.0"}


class flickr(Source):
    """Flickr photos found by text search, filtered by licence. Key: flickr.com/services/api/keys via ``api_key=``,
    FLICKR_API_KEY or ``flickr_api_key:`` in the credentials file. Note Flickr's API is for non-commercial use unless
    arranged with Flickr. ``licenses``: Flickr licence ids; the default (4, 5, 7, 8, 9, 10, 11, 12) keeps licences that
    allow commercial use and changes (CC BY, CC BY-SA, CC0, public domain, US government works).
    Flickr returns at most 4,000 results per search."""

    kind = "flickr"
    API = "https://api.flickr.com/services/rest/"

    def __init__(self, query: Optional[str] = None, limit: Optional[int] = None,
                 licenses: Sequence[int] = (4, 5, 7, 8, 9, 10, 11, 12), api_key: Optional[str] = None):
        bad = [l for l in licenses if l not in FLICKR_LICENSES]
        if bad:
            raise FelixError(f"sources.flickr: unknown licence ids {bad} (see flickr.photos.licenses.getInfo)")
        self.query, self.limit, self.licenses, self._key = query, need_int(limit, "sources.flickr: limit"), list(licenses), api_key

    def label(self):
        return f"flickr “{self.query}”" if self.query else "flickr (recent photos)"

    def describe(self):
        return {"type": "flickr", "query": self.query, "licenses": [FLICKR_LICENSES[l] for l in self.licenses]}

    def _collect_query(self, c: Collector, progress):
        key = _http.credential("flickr_api_key", self._key, "FLICKR_API_KEY", "sources.flickr")
        page = 1
        while self.limit is None or not c.reached(self.limit):
            if self.query:
                params = {"method": "flickr.photos.search", "text": self.query, "license": ",".join(map(str, self.licenses)),
                          "content_types": "0", "media": "photos", "safe_search": "1"}
            else:                                      # no query: recent uploads (licences filtered below)
                params = {"method": "flickr.photos.getRecent"}
            d = _http.get_json(self.API + "?" + _q(dict(params, api_key=key, extras="license,owner_name,url_l,url_o",
                                                        per_page=250, page=page, format="json", nojsoncallback="1")), interval=1.0)
            if d.get("stat") != "ok":
                raise FelixError(f"Flickr API: {d.get('message') or d}")
            photos = (d.get("photos") or {}).get("photo") or []
            if not photos:
                return
            for p in photos:
                if c.reached(self.limit):
                    return
                url = p.get("url_l") or p.get("url_o")
                if not url or int(p.get("license", 0)) not in self.licenses:
                    continue
                lic = FLICKR_LICENSES.get(int(p.get("license", 0)), "unknown")
                fetch(c, url, f"flickr_{p.get('id')}.jpg",
                      {"type": "flickr", "query": self.query, "id": p.get("id"), "url": url, "page": f"https://www.flickr.com/photos/{p.get('owner')}/{p.get('id')}",
                       "title": p.get("title"), "author": p.get("ownername"), "author_page": f"https://www.flickr.com/people/{p.get('owner')}",
                       "license": lic, "attribution": f"“{p.get('title') or 'Untitled'}” by {p.get('ownername')}, {lic}, via Flickr"},
                      interval=0.3)
                progress(c.count, self.limit)
            if page >= int((d.get("photos") or {}).get("pages") or page) or (self.query and page * 250 >= 4000):
                return
            page += 1
