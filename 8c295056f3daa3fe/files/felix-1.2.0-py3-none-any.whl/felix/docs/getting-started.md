# Getting started

A Felix script is five kinds of lines, run top to bottom: **classes → acquire → transform → annotate → export**.
Nothing happens until `fx.export`: the earlier lines describe the dataset, export builds it.

## 1. Classes

**Toddler words:** write the shopping list: the things you want boxes for.

```yaml
# classes.yml
classes:
  - name: leaf
    prompt: a green plant leaf           # what an open-vocabulary model (fx.models.yoloe) looks for
    aliases: [Leaf, leaves]              # names that mean "leaf" in datasets you import or in a model's labels
  - name: flower
confidence: 0.3                          # minimum model confidence (optional; per class too)
```

```python
import felix as fx

fx.load_class("./classes.yml")
```

Imported boxes and model detections are mapped onto these classes; anything else is left out. Without a class file,
every class is kept and models detect everything they know.

## 2. Acquire

**Toddler words:** say where the pictures come from: your folder, a video, free picture libraries.

```python
fx.acquire([
    fx.sources.local("./raw/leaves"),                       # a folder of photos, as it is
    fx.sources.video("./greenhouse.mp4", sampling=fx.sampling.auto()),
    fx.sources.wikimedia(query="plant leaves", limit=500),
])
```

Any mix of [sources](sources.md). Local folders need no preparation; existing datasets (COCO, YOLO, Felix) bring their
labels and splits along. Online sources download many pictures at once, ask each provider's API as politely as its
rules say, and keep each image's licence, author and page. Leave out the query to take whatever a source has.

## 3. Transform

**Toddler words:** tidy the pictures up: same size, no copies, faces blurred.

```python
fx.transform.center_crop(size=640)       # or letterbox(size=640), dedupe(), blur_faces(), …
```

Steps run in the order written. Boxes and masks move with the pixels.

## 4. Annotate

**Toddler words:** a helper draws the boxes on every picture that has none.

```python
import workflow as wf

fx.annotate(model=wf.load("./models/leaf-detector.nbm"))   # your own model
# fx.annotate(model=fx.models.yolo26n)                     # or a built-in one
```

Only images without labels are annotated (`replace=True` to redo all). An image the model fails on is marked failed
and left out of the dataset, not saved as "no objects".

## 5. Export

**Toddler words:** run everything and pack the finished dataset into a box, with a label saying what's inside and who to credit.

```python
fx.export("./datasets/leaves.felix")                       # until the sources run out
fx.export("./datasets/leaves.felix", pairs=2000)           # exactly 2,000 image/annotation pairs
fx.export("./datasets/leaves", license="CC-BY-4.0")        # a folder, released openly
fx.export("./datasets/leaves.sh_felix")                    # a folder of shards, for very large datasets
```

The dataset comes with LICENSE.txt, ATTRIBUTIONS.md (every image's licence and credit) and CITATION.cff. Workflow
trains from it directly: `model.train("./datasets/leaves.felix")`.

To start a new dataset in the same program, call `fx.reset()`.
