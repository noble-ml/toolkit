# Felix cookbook

Every Felix tool, explained like you're three, then *why* you'd reach for it and where it goes. After the tools come
**recipes**: whole datasets, start to finish, that you can copy and change.

How to read an entry:

- **Toddler words**: what it is.
- **Why you'd use it**: the reasoning, and where it usually sits.
- **Example**: the main arguments shown, with their defaults.
- **Watch out**: the one mistake people make (when there is one).

A Felix program is a list of steps, in order. Nothing downloads or changes until `fx.export` runs them:

```python
import felix as fx

fx.load_class("./classes.yml")          # 1. what we are looking for       (optional)
fx.acquire([...])                       # 2. where the pictures come from
fx.transform.center_crop(size=640)      # 3. change the pictures            (any number, in order)
fx.annotate(model=fx.models.yoloe)      # 4. draw the boxes                 (if the pictures have none)
fx.transform.augment(copies=2)          # 5. more changes, after the boxes  (optional)
fx.export("./datasets/leaves.felix")    # 6. run it all and write the dataset
```

---

## Part 1 · What to look for

### `fx.load_class`

**Toddler words:** the shopping list. Before going out, write down what you're looking for: "leaf", "tomato", "white
tiger". Felix only keeps boxes for things on the list.

**Why you'd use it:** it decides the dataset's classes (and their ids, in file order). An open-vocabulary model such
as `fx.models.yoloe` is asked to find exactly these, by name or by `prompt`. `aliases` say which names in other
datasets or in a model's labels mean the same thing.

```python
fx.load_class("./classes.yml")
```
```yaml
classes:
  - leaf                                  # the name is also the prompt
  - tomato
  - name: white tiger
    prompt: a white bengal tiger          # optional: a more precise description for the model
  - name: dog
    prompt: [dog, puppy, a dog lying down]   # optional: several ways to say it; any of them finds a dog
    aliases: [White tiger, tiger_white]   # optional: other names that mean this class
    confidence: 0.3                       # optional: this class's own minimum score
confidence: 0.25                          # optional: the default minimum score
```

**Several prompts:** when one description misses things, give a few. The model looks for each, every box is named after
the class, and two prompts boxing the same dog become one box.

**Watch out:** without a class file, everything is kept: a COCO import brings all 80 classes, and a model labels
everything it knows. Good for "collect anything", noisy for a focused detector. A prompt can belong to one class only.

---

## Part 2 · Where the pictures come from

### `fx.acquire`

**Toddler words:** the shopping trip. Point at the places pictures come from; Felix goes there when the dataset is
built.

**Why you'd use it:** real datasets mix sources: your own photos, a video, a museum, a public dataset. Every picture
remembers where it came from, its licence and who to credit. Call `fx.acquire` again to add more sources.

```python
fx.acquire([
    fx.sources.local("./raw/leaves"),
    fx.sources.wikimedia(query="plant leaves", limit=500),
], blur_faces=False)
```

`blur_faces=True` blurs every face before anything else happens (see `blur_faces` below).

### `fx.sources.local`

**Toddler words:** the pictures already in your drawer.

**Why you'd use it:** your own photos, a zip someone sent you, or a dataset you downloaded. COCO, YOLO and Felix
datasets are recognised by their content and bring their boxes and splits. A folder of class folders (`cat/`,
`dog/`) becomes a classification dataset.

```python
fx.sources.local("./raw/leaves", recursive=True, labels=None, license=None)
fx.sources.local("./downloads/roboflow-export.zip")          # COCO inside: boxes come along
fx.sources.local("./pets", labels="folders")                  # cat/, dog/ → image labels
fx.sources.local("./bought-photos", license="CC BY 4.0")      # say the licence when you know it
```

**Watch out:** with no `license`, Felix records the files as your own. Say so if they are not.

### `fx.sources.video`

**Toddler words:** a flip book. A video is thousands of pictures in a row; Felix keeps some pages, not all.

**Why you'd use it:** your own footage (a greenhouse walk, a dashcam) is the closest thing to what the model will see
later. Each frame remembers its video, frame number and time.

```python
fx.sources.video("./greenhouse.mp4", sampling=fx.sampling.auto())
fx.sources.video("./drive.mp4", sampling=fx.sampling.interval(seconds=2))
```

**Watch out:** video needs OpenCV: `pip install "felix[video]"`.

### `fx.sources.camera`

**Toddler words:** a camera that keeps taking pictures while you watch, and Felix keeps the good ones.

**Why you'd use it:** collect data live from a webcam, a USB camera or a network stream, right where the model will
be used.

```python
fx.sources.camera(device=0, sampling=fx.sampling.interval(seconds=1), count=500, duration=None)
fx.sources.camera("rtsp://192.168.1.20/stream", sampling=fx.sampling.auto(), duration=600)
```

**Watch out:** it runs until `count`, `duration`, the export's `pairs`, or Ctrl+C. `fx.sampling.random` can't be used
(there is no "whole video" to pick from).

### `fx.sampling.auto`

**Toddler words:** only turn the page when something changed. A still scene gives one picture, not a hundred copies.

**Why you'd use it:** the best default. A minute of video is 1,800 frames, nearly all the same; `auto` keeps more
frames when things move and fewer when nothing happens.

```python
fx.sampling.auto(threshold=0.04, min_gap=0.5, max_gap=None, check_fps=4, limit=None)
```

**Watch out:** if it keeps too few frames, lower `threshold` (0.02); too many, raise it. `max_gap=10` forces a frame
at least every 10 seconds.

### `fx.sampling.interval`

**Toddler words:** take a picture every few seconds, like a clock.

**Why you'd use it:** predictable spacing, e.g. one frame a second from a camera, or every 2 seconds of a drive.

```python
fx.sampling.interval(seconds=2, start=0, limit=None)
```

### `fx.sampling.random`

**Toddler words:** close your eyes and point at a thousand pages of the flip book.

**Why you'd use it:** frames spread over the whole video, the same ones every time (`seed`). Good for long videos
where you want a fixed number of frames.

```python
fx.sampling.random(count=1000, seed=42)
```

**Watch out:** not available for live cameras (there is no "whole video" to pick from).

### `fx.sources.urls`

**Toddler words:** a list of addresses; Felix goes to each one and brings back the picture.

**Why you'd use it:** you already have links to the pictures you want (from a spreadsheet, a scrape you're allowed to
do, a partner's list).

```python
fx.sources.urls("./leaf_urls.txt", license=None, attribution=None)
fx.sources.urls(["https://example.org/a.jpg", "https://example.org/b.jpg"], license="CC0-1.0")
```

**Watch out:** "public on the internet" is not "free to use". These licences are unknown unless you say; export
reminds you.

### Choosing an online source

**Toddler words:** libraries of free pictures. Ask for "oak trees" and they hand you oak trees, with a note saying
who took each one and how you may use it.

**Why you'd use it:** lots of real, varied pictures with clear licences, for free. Pick by what you need:

| Need | Source |
|---|---|
| anything, any topic | `wikimedia`, `openverse`, `flickr` |
| plants and animals | `inaturalist` (by taxon), `gbif` |
| space, science | `nasa` |
| art, objects, history | `artic`, `smithsonian` |
| high-quality stock photos | `unsplash`, `pexels` (keys needed) |
| street scenes | `mapillary` |
| already labelled | `open_images`, `coco`, `roboflow`, `huggingface`, `kaggle` |

**Several searches in one source:** give a list. The searches run side by side, share the `limit` equally, and a
picture found by two of them is taken once. Each picture records which search found it.

```python
fx.sources.wikimedia(query=["oak leaf", "maple leaf", "beech leaf"], limit=900)    # 300 of each
fx.sources.inaturalist(taxon=["Quercus", "Acer", "Fagus"], limit=1500, label=True)
fx.sources.gbif(scientific_name=["Pica pica", "Corvus corax"], limit=400)
```

**No target: take whatever comes.** Leave the query out and a source gives you whatever it has: its own "anything"
feed (random Commons files, the newest Unsplash photos, any species on iNaturalist). A source without such a feed, or
once its feed runs dry, works through a built-in vocabulary of about 4,600 subjects: the tag list of Recognize
Anything (RAM++), from "abacus" to "wind turbine", plus everyday subjects. It asks for them in shuffled order, at most
25 pictures per subject, so no subject takes over.

```python
fx.acquire([fx.sources.wikimedia(), fx.sources.openverse(), fx.sources.artic()])
fx.sources.openverse(limit=500).using(vocabulary="general")                          # ~150 everyday subjects only
fx.sources.openverse(limit=500).using(vocabulary=["oak", "maple", "pine"], per_term=50)   # your own subjects
```

**Watch out:** a slow or paused provider never holds up the others: it waits in the background while the rest keep
going, and gives up quietly when the export is done.

### `fx.sources.wikimedia`

**Toddler words:** the picture library behind Wikipedia: millions of photos anyone may reuse, each with a note saying
who made it.

**Why you'd use it:** almost every subject, mostly real photos, clear licences. Without a query: random files.

```python
fx.sources.wikimedia(query="plant leaves", limit=500, licenses=["CC0", "CC BY"], max_side=2048, min_side=256)
fx.sources.wikimedia(limit=1000)                         # random Commons pictures
```

**Watch out:** set `FELIX_CONTACT` (your email or a URL) first; Wikimedia refuses programs that don't say how to reach
their operator.

### `fx.sources.openverse`

**Toddler words:** one search box over many free picture libraries at once (Flickr, Wikimedia, museums).

**Why you'd use it:** the widest single search for openly licensed photos, no key needed, attribution text included.

```python
fx.sources.openverse(query="tomato plant", limit=500, licenses=None, commercial=True, source=None)
fx.sources.openverse(query="bicycle", source="flickr")    # only one of its providers
```

**Watch out:** `commercial=True` (the default) keeps only licences that allow commercial use.

### `fx.sources.flickr`

**Toddler words:** the giant photo-sharing site, but only the photos their owners said everyone may reuse.

**Why you'd use it:** huge variety of everyday photos. Without a query: recent uploads with reusable licences.

```python
fx.sources.flickr(query="street market", limit=1000, licenses=(4, 5, 7, 8, 9, 10, 11, 12), api_key=None)
```

**Watch out:** needs a free API key (`FLICKR_API_KEY`); a search returns at most 4,000 results; the API is for
non-commercial use unless you arrange otherwise with Flickr.

### `fx.sources.unsplash`

**Toddler words:** a shop of beautiful, free professional photos.

**Why you'd use it:** sharp, well-lit pictures. Without a query: the newest photos.

```python
fx.sources.unsplash(query="coffee cup", limit=200, size="regular", orientation=None, api_key=None)
```

**Watch out:** needs a key (`UNSPLASH_ACCESS_KEY`); demo keys allow 50 requests an hour. Its licence forbids building
a competing photo service, so export flags Unsplash photos in openly released datasets.

### `fx.sources.pexels`

**Toddler words:** another shop of free professional photos.

**Why you'd use it:** like Unsplash, more stock-style subjects. Without a query: Pexels' curated photos.

```python
fx.sources.pexels(query="kitchen", limit=200, size="large2x", orientation=None, api_key=None)
```

**Watch out:** needs a key (`PEXELS_API_KEY`); 200 requests an hour, so pages come about 18 seconds apart. Same
licence caveat as Unsplash.

### `fx.sources.inaturalist`

**Toddler words:** nature lovers' photos of plants and animals, each checked by experts so the species name is right.

**Why you'd use it:** the best source for species: real photos in the wild, with the species name, which
`label=True` turns into the image's class.

```python
fx.sources.inaturalist(taxon="Quercus", limit=500, licenses=("cc0", "cc-by", "cc-by-sa"), size="large",
                       quality="research", label=False, place_id=None)
fx.sources.inaturalist(limit=1000)                       # any species
```

**Watch out:** each search stops at 10,000 results; use narrower taxa for more. A name means exactly that taxon
and everything under it ("Pinus": every pine; "red oak": *Quercus rubra*); a name iNaturalist doesn't know stops with
the closest matches.

### `fx.sources.gbif`

**Toddler words:** the world's big list of "where was this plant or animal seen", from museums and scientists, with
photos.

**Why you'd use it:** museum specimens and field photos, including species iNaturalist has few of.

```python
fx.sources.gbif(scientific_name="Pica pica", query=None, limit=500, licenses=("CC0_1_0", "CC_BY_4_0"), country=None)
```

**Watch out:** many pictures are herbarium sheets or drawers of pinned insects: great for some tasks, odd for others.

### `fx.sources.nasa`

**Toddler words:** NASA's photo album: rockets, planets, astronauts, Earth from space.

```python
fx.sources.nasa(query="mars rover", limit=200, size="large")
fx.sources.nasa(limit=500)                               # anything
```

**Watch out:** generally not copyrighted in the US, but some items are third-party or show people and logos.

### `fx.sources.artic`

**Toddler words:** the Art Institute of Chicago's paintings and objects that belong to everyone (public domain).

```python
fx.sources.artic(query="still life", limit=300)
```

**Watch out:** its API sits behind a bot check that sometimes refuses programs for a while; Felix then says so.
Images are 843 pixels wide, as the museum asks.

### `fx.sources.smithsonian`

**Toddler words:** the Smithsonian museums' free pictures: fossils, planes, stamps, art, animals.

```python
fx.sources.smithsonian(query="aircraft", limit=300, api_key=None)
```

**Watch out:** works without a key on a shared demo key; get your own (`API_DATA_GOV_KEY`) for anything sizeable.

### `fx.sources.open_images`

**Toddler words:** Google's huge box of photos that already have boxes drawn on them, 600 kinds of things.

**Why you'd use it:** ready-labelled pictures. Without `classes`: your classes.yml's classes it has, or all 600.

```python
fx.sources.open_images(classes=["Car", "Person"], split="validation", limit=1000, seed=0, group_of=True)
```

**Watch out:** the `train` split's annotation tables are several GB (downloaded once); `validation` is ~40 MB.

### `fx.sources.coco`

**Toddler words:** the most famous box of labelled photos: everyday scenes, 80 kinds of things.

```python
fx.sources.coco(split="val2017", limit=None)             # 5,000 images, ~1 GB
```

**Watch out:** `train2017` is 118,000 images (~18 GB). With a class file only images containing those classes come.

### `fx.sources.roboflow`

**Toddler words:** a dataset you (or someone on Roboflow Universe) already made, fetched with its boxes.

```python
fx.sources.roboflow("my-workspace/leaves", version=3, workspace=None, api_key=None)
```

**Watch out:** needs `ROBOFLOW_API_KEY`. A Universe project without a licence means all rights reserved.

### `fx.sources.huggingface`

**Toddler words:** a dataset from the Hugging Face hub; only the rows you take are downloaded.

```python
fx.sources.huggingface("cats_vs_dogs", split="train", config=None, limit=2000, label_column=None, bbox_format="xywh")
```

**Watch out:** gated or private datasets need `HF_TOKEN`.

### `fx.sources.kaggle`

**Toddler words:** a dataset from Kaggle, downloaded and opened like a folder on your computer.

```python
fx.sources.kaggle("owner/dataset-name", labels=None)     # labels="folders" for class folders
```

**Watch out:** needs your Kaggle API key (`~/.kaggle/kaggle.json`). Check the dataset's licence on its Kaggle page.

### `fx.sources.mapillary`

**Toddler words:** street pictures taken by people driving and walking around, pinned on a map.

```python
fx.sources.mapillary(bbox=(13.40, 52.51, 13.41, 52.52), limit=500, access_token=None)   # lon/lat box
```

**Watch out:** the map area must be smaller than 0.01° on each side; needs `MAPILLARY_TOKEN`. Images are CC BY-SA.

### Credentials

**Toddler words:** some libraries want a membership card (a key) before they hand out pictures.

**Why you'd use it:** Unsplash, Pexels, Flickr, Roboflow, Mapillary and Kaggle need one; Smithsonian and Hugging
Face work better with one. Put keys in the call, an environment variable, or one file:

```yaml
# ~/.config/felix/credentials.yml
contact: you@example.com
unsplash_access_key: ...
pexels_api_key: ...
flickr_api_key: ...
```

**Watch out:** never put keys in a script you share; use the file or environment variables.

### How fast does it go?

**Toddler words:** Felix sends many helpers at once, each fetching a picture, instead of one helper doing every trip.

Each source downloads up to 16 pictures at a time over reused connections, different sources run side by side, and
search APIs are still asked as politely as their rules say. A server that says "slow down" pauses only itself.
Downloaded pictures are kept in `~/.cache/felix/images`, so running the same export again (after changing a
transform or the model) is almost instant. See [Sources → Speed](sources.md#speed).

```python
fx.acquire([fx.sources.open_images(classes=["Car"], limit=2000)])
fx.export("./datasets/cars.felix")        # first run: downloads, 16 at a time
# change a transform, then run again: pictures come from ~/.cache/felix/images
```
```bash
FELIX_IMAGE_CACHE_GB=50 python make_cars.py   # a bigger download cache
FELIX_IMAGE_CACHE=0 python make_cars.py       # no cache at all
```

---

## Part 3 · Changing the pictures

### `fx.transform`

**Toddler words:** the workbench. Each line puts one tool on the bench (crop, resize, copy, blur…), and every picture
goes past the tools in the order you wrote them.

**Why you'd use it:** raw pictures are all sizes and shapes; models want them tidy. The boxes always move with the
pixels, and a box that loses most of its area (`min_visibility`) is dropped.

```python
fx.transform.dedupe()                     # 1. no copies
fx.transform.center_crop(size=640)        # 2. same size
fx.annotate(model=fx.models.yoloe)        #    (boxes)
fx.transform.augment(copies=2)            # 3. more variety
```

**Watch out:** order matters. Crop *before* annotating (faster, and the model sees what the dataset keeps); augment
*after* (copies inherit the boxes); nothing that resizes or turns pixels after `consequential`.

### `fx.transform.center_crop`

**Toddler words:** cut the edges off so every picture is the same size, keeping the middle.

**Why you'd use it:** shrink big photos before annotating (faster, and the subject is usually in the middle). Boxes
cut off at the edge are trimmed, or dropped if most of them is gone.

```python
fx.transform.center_crop(size=640, min_visibility=0.3)
fx.transform.center_crop(size=(800, 600))
```

**Watch out:** things near the edge are lost. If they matter, use `letterbox`.

### `fx.transform.letterbox`

**Toddler words:** shrink the whole picture to fit the frame and fill the empty strips with grey, like a widescreen
film on an old TV.

**Why you'd use it:** nothing is cut, so every object survives. Suits general detectors and wide street scenes.

```python
fx.transform.letterbox(size=640, fill=(114, 114, 114))
```

**Watch out:** tall or wide pictures get large grey bars, so their objects end up smaller.

### `fx.transform.consequential`

**Toddler words:** zoom in on each toy and take a photo of it, plus a few photos of empty floor so the brain learns
what "nothing" looks like.

**Why you'd use it:** in a 4,000-pixel photo a leaf may be 40 pixels: resized to 640 for training it nearly vanishes.
Crops around each object keep them big enough to learn; `negative_rate` of the crops show no objects.

```python
fx.annotate(model=model)                                   # first: it needs the boxes
fx.transform.consequential(size=640, negative_rate=0.15, margin=0.25, min_visibility=0.3, overlap=0.6, seed=0)
```

**Watch out:** it must come after `fx.annotate`, and nothing that resizes, turns or shifts pixels may follow it
(`augment` with only flips and colour may). Felix stops you if the order is wrong.

### `fx.transform.augment`

**Toddler words:** take each photo and make a few funny copies: flipped like in a mirror, a little turned, darker,
brighter, blurrier. It's still the same leaf, and the box moves with it.

**Why you'd use it:** a model that only ever saw leaves facing left, in sunshine, gets confused by a leaf facing
right on a cloudy day. Copies that vary the things that *shouldn't* matter teach it to ignore them. Most useful when
you have few pictures.

```python
fx.annotate(model=model)                     # first: label the real pictures, the copies inherit the labels
fx.transform.augment(
    copies=2,                # new versions per picture; the original stays (keep_original=True)
    flip=0.5,                # chance of a mirror image
    vflip=0.0,               # chance of upside down (aerial photos: yes; street scenes: no)
    rotate=10,               # up to ±10 degrees
    scale=0.2,               # 80 % to 120 % size
    translate=0.1,           # shifted up to 10 % of the size
    brightness=0.2, contrast=0.2, saturation=0.2, hue=5,
    blur=0.05, noise=0.0, grayscale=0.02, jpeg=0.0,
    cutout=0.0,              # chance of a grey patch (teaches "a partly hidden leaf is still a leaf")
    seed=0,
)
```

**Watch out:** only vary what really varies where the model will be used. Upside-down street scenes or purple
tomatoes teach it things that never happen. Copies always stay in their original's train / val / test pile, so the
final exam is never seen during learning.

### `fx.transform.mosaic`

**Toddler words:** four photos glued into one, like a window with four panes.

**Why you'd use it:** each picture shows more objects, at smaller sizes, against more different backgrounds. That
helps detectors see small things and stop relying on the background.

```python
fx.transform.mosaic(size=640, rate=0.25, seed=0)    # one mosaic for every four pictures, originals kept
```

**Watch out:** only pictures from the same train / val / test pile are glued together. Each mosaic credits all four
of its parts.

### `fx.transform.dedupe`

**Toddler words:** throw away the second copy of the same photo.

**Why you'd use it:** web searches and videos are full of near-copies. Copies make the model over-learn some
pictures, and copies across train and test make test scores lie.

```python
fx.transform.dedupe(threshold=4)        # higher = also drop pictures that are only nearly the same
```

### `fx.transform.map_classes`

**Toddler words:** rename things: "Car" and "Truck" both become "vehicle".

**Why you'd use it:** datasets and models name things differently; this merges them into your names. `None` deletes
a class's boxes.

```python
fx.transform.map_classes({"Car": "vehicle", "Truck": "vehicle", "Person": None})
```

### `fx.transform.filter_classes`

**Toddler words:** keep only the boxes you care about, or throw away the ones you don't.

```python
fx.transform.filter_classes(keep=["vehicle", "bicycle"])
fx.transform.filter_classes(drop=["person"])
```

**Watch out:** the picture stays even if all its boxes go; add `filter_images(require_objects=True)` to drop those too.

### `fx.transform.filter_images`

**Toddler words:** throw away pictures that are too small, oddly shaped, or don't pass your own test.

```python
fx.transform.filter_images(min_width=320, min_height=320, max_aspect=3.0, require_objects=False)
fx.transform.filter_images(where=lambda image, objects: len(objects) <= 50)   # your own rule
```

### `fx.transform.blur_faces`

**Toddler words:** put a fuzzy sticker over everyone's face.

**Why you'd use it:** street, shop or crowd pictures show people who never agreed to be in your dataset. Each image
records that it was blurred.

```python
fx.transform.blur_faces(strength=1.0, min_size=20)
fx.acquire([...], blur_faces=True)        # the same, as the very first step
```

**Watch out:** it's best effort. Small or turned-away faces can be missed: check before publishing.

### `fx.transform.custom`

**Toddler words:** your own magic trick, done to every picture.

```python
def sepia(image, objects):
    from PIL import ImageOps
    return ImageOps.colorize(image.convert("L"), "#402010", "#f0e0c0"), objects   # or None to drop the image

fx.transform.custom(sepia, geometry=False, name="sepia")
```

**Watch out:** if your trick moves pixels, set `geometry=True` and move the boxes yourself.

---

## Part 4 · Drawing the boxes

### `fx.annotate`

**Toddler words:** a helper who looks at every picture and draws the boxes for you.

**Why you'd use it:** drawing boxes by hand takes forever. Pick a helper:

| Helper | Knows | Use it when |
|---|---|---|
| `fx.models.yolo26n` (also `s/m/l/x`) | 80 everyday things (people, cars, dogs, cups…) | your classes are among them |
| `fx.models.yoloe` | whatever classes.yml names; without it, ~4,600 things | your classes are anything else |
| `fx.models.sam` | outlines for boxes that already exist | you need masks, not only boxes |
| `wf.load("model.nbm")` | what you trained it on | you have your own Workflow model |
| your function | whatever you write | another tool or a rule of your own |

```python
fx.annotate(model=fx.models.yoloe, confidence=None, replace=False, batch_size=8)
fx.annotate(model=wf.load("./models/leaf-detector.nbm"))
fx.annotate(model=lambda image: [{"class": "leaf", "xyxy": [10, 10, 80, 90], "confidence": 0.9}])
```

**Watch out:** a picture the model chokes on is marked failed and left out, never saved as "nothing here". Pictures
that arrived with boxes (COCO, Open Images, …) keep them unless `replace=True`.

### `fx.models.yolo26n`

**Toddler words:** a fast helper who already knows 80 everyday things: people, cars, dogs, chairs, cups, phones.

**Why you'd use it:** your classes are among those 80. It's small, quick, works offline (it comes inside Felix) and is
very sure of itself on what it knows.

```python
fx.load_class("./classes.yml")            # e.g. classes: [person, car] (aliases map other names)
fx.annotate(model=fx.models.yolo26n)
fx.annotate(model=fx.models.yolo26n(device="cuda", imgsz=1280))   # bigger input: small objects found more often
```

**Watch out:** it only finds those 80 classes; Felix tells you if none of your classes is one of them.

### `fx.models.yolo26s`

**Toddler words:** the same helper's bigger, more careful siblings: s (small), m, l, x (extra large).

**Why you'd use it:** more accurate boxes when speed matters less. Downloaded once into `~/.cache/felix/models`.

```python
fx.annotate(model=fx.models.yolo26s)
fx.annotate(model=fx.models.yolo26x(device="cuda"))
```

### `fx.models.yoloe`

**Toddler words:** a helper you can *tell* what to look for. Write "white tiger" in your list and it looks for white
tigers. Give it no list and it names whatever it recognises, out of about 4,600 things.

**Why you'd use it:** your classes are not everyday COCO things: leaves, tomatoes, a particular tool. The prompts are
your class names (or `prompt:` from classes.yml), and its boxes come back with your class names.

```python
fx.load_class("./classes.yml")            # classes: [leaf, tomato, white tiger]
fx.annotate(model=fx.models.yoloe)        # prompted with those three
fx.annotate(model=fx.models.yoloe("yoloe-26l-seg.pt"))   # larger: better on hard prompts
```

**Watch out:** prompted scores run low (0.1–0.4 is normal), so its default minimum is 0.1. Whole objects work best;
parts ("bus window") are often missed. The first prompt downloads a ~254 MB text encoder once.

### `fx.models.sam`

**Toddler words:** a helper who colours in exactly the shape of each thing inside a box someone already drew.

**Why you'd use it:** segmentation datasets (outlines, not only boxes). Use it after a box model, or on a dataset that
came with boxes.

```python
fx.annotate(model=fx.models.yoloe)        # boxes first
fx.annotate(model=fx.models.sam)          # then outlines for them
```

**Watch out:** it adds masks to existing boxes and never finds new objects; pictures without boxes are left as they
are.

## Part 5 · Writing the dataset

### `fx.export`

**Toddler words:** pack the box and write the label on it: what's inside, where each picture came from, and who may
use it.

**Why you'd use it:** it runs every step above and writes the dataset Workflow trains from, plus LICENSE.txt,
ATTRIBUTIONS.md and CITATION.cff. `pairs=` stops at a number; without it, it keeps going until the sources run out
or you press Ctrl+C (the dataset is still closed properly).

```python
fx.export("./datasets/leaves.felix", pairs=None, license=None, title=None, authors=None, strict=False)
fx.export("./datasets/leaves", license="CC-BY-4.0", title="Leaves", authors=["Ann Lee"])   # a folder, released openly
fx.export("./datasets/leaves.sh_felix", shard_size=1000)   # a folder of shards
```

**Watch out:** `license=None` means closed (all rights reserved). For an open dataset, read the ⚠ lines in
ATTRIBUTIONS.md, or use `license="auto"` (the most open licence every picture allows) and `strict=True` (leave out
pictures that don't fit). See [Licences](licensing.md).

### `fx.load` and its splits

**Toddler words:** open the box. It already has three piles: `train` (learn from these), `val` (check while
learning), `test` (the final exam).

```python
data = fx.load("./datasets/leaves.felix")
data.train, data.val, data.test, data.classes, data.splits
```

Imported datasets keep their piles; everything else is split 80 / 10 / 10, the same way every time. Copies, crops and
mosaics follow their original.

### `fx.split`

**Toddler words:** photocopy the pile, then keep only part of the copy. The big pile stays as it was.

**Why you'd use it:** quick experiments on a tenth of the data; every split and class keeps its share.

```python
fx.split("leaves.felix", 0.1, output="leaves-small.felix", size=None, seed=0)
fx.split("leaves.felix", size=500)                                 # exactly 500 pairs
```

### `fx.partition`

**Toddler words:** cut the pile into several smaller piles, each a complete dataset.

**Why you'd use it:** sharing work between people or machines, or separate datasets per split.

```python
fx.partition("leaves.felix", parts=4)
fx.partition("leaves.felix", ratio=[70, 30], names=["big", "small"], shuffle=True)
fx.partition("leaves.felix", by_split=True)                       # one per train / val / test
```

### `fx.shard`

**Toddler words:** spread a huge pile over many small boxes, so you only carry one box at a time.

**Why you'd use it:** datasets too big for memory or one file. Workflow trains from the folder, one shard at a time.

```python
fx.shard("leaves.felix", output=None, size=1000)
fx.export("./datasets/big.sh_felix", shard_size=1000)             # or export straight into shards
```

### `fx.reset`

**Toddler words:** wipe the whiteboard: forget the shopping list, the places and the tools, and start a new dataset.

```python
fx.export("./datasets/leaves.felix")
fx.reset()                                # the next lines describe a different dataset
fx.acquire([fx.sources.nasa(query="rocket", limit=200)])
fx.export("./datasets/rockets.felix")
```

### `fx.FelixError`

**Toddler words:** when something's wrong, Felix stops and tells you, in plain words, what to change.

```python
try:
    fx.export("./datasets/leaves.felix")
except fx.FelixError as e:
    print("fix this:", e)
```

**Watch out:** problems with single pictures (a dead link, an unreadable file) never stop the run: they're counted
and reported at the end.

### `felix run`

**Toddler words:** "do the recipe in this file".

```
felix run make_leaves.py
felix run make_leaves.py --pairs 500          # extra words go to the script (sys.argv)
```

### `felix info`

**Toddler words:** read the label on the box: how many pictures, which classes, which piles.

```
felix info leaves.felix
felix info ./animals                          # class folders: images per class and split
```

### `felix pack`

**Toddler words:** put a folder of pictures into one tidy box (one `.felix` file) that's easy to copy.

```
felix pack ./leaves -o leaves.felix
felix pack ./leaves_shards -o leaves.felix    # shards back into one file
```

### `felix unpack`

**Toddler words:** open the box and spread everything out in a folder.

```
felix unpack leaves.felix -o ./leaves
```

### `felix convert`

**Toddler words:** take someone else's box (COCO, YOLO, class folders, a zip of pictures) and repack it the Felix way.

```
felix convert ./roboflow-export -o data.felix
felix convert ./pets --labels folders -o pets.felix --license CC0-1.0
```

### `felix split`

**Toddler words:** photocopy the pile, then keep only part of the copy. The big pile stays as it was.

**Why you'd use it:** quick experiments on a tenth of the data; every split and class keeps its share.

```
felix split leaves.felix 0.1 -o leaves-small.felix
```

### `felix partition`

**Toddler words:** cut the pile into several smaller piles, each a complete dataset.

```
felix partition leaves.felix --parts 4
felix partition leaves.felix --ratio 70,30 --names big,small --shuffle
felix partition leaves.felix --by-split          # one dataset per train / val / test
```

### `felix shard`

**Toddler words:** spread a huge pile over many small boxes, so you only carry one box at a time.

**Why you'd use it:** datasets too big for memory or one file. Workflow trains from the folder, one shard at a time.

```
felix shard leaves.felix --size 1000
felix shard leaves.felix --shards 16
```

### `felix library`

**Toddler words:** this book, in your terminal: every tool, with what it is, why, and an example. Type to search.

```
felix library
felix library augment
```

## Part 6 · Recipes

### 1. A detector for your own thing, from your own photos

**Toddler words:** Your own photos, a helper draws the boxes, you zoom in on each fruit, and make a few funny copies.

You have 300 photos of tomato plants and want a fruit detector. YOLOE draws the first boxes, crops keep small fruit
big, and augmentation stretches 300 photos further.

```python
import felix as fx

fx.load_class("./classes.yml")              # classes: [tomato]
fx.acquire([fx.sources.local("./raw/tomatoes")])
fx.annotate(model=fx.models.yoloe)
fx.transform.consequential(size=640, negative_rate=0.15)
fx.transform.augment(copies=2, flip=0.5, scale=0, translate=0, brightness=0.25, hue=4)   # after crops: flips + colour
fx.export("./datasets/tomatoes.felix")
```

### 2. Topping up with the web

**Toddler words:** Your photos are a good start; borrow more from free libraries so the model sees more kinds of tomato.

Same classes, more variety: your photos plus openly licensed ones, without copies.

```python
fx.load_class("./classes.yml")
fx.acquire([
    fx.sources.local("./raw/tomatoes"),
    fx.sources.openverse(query=["tomato plant", "cherry tomatoes", "tomato harvest"], limit=1500),
    fx.sources.inaturalist(taxon="Solanum lycopersicum", limit=1000),
    fx.sources.open_images(classes=["Tomato"], limit=1000),     # already labelled: kept as they are
])
fx.transform.dedupe()
fx.transform.center_crop(size=1024)
fx.annotate(model=fx.models.yoloe)
fx.export("./datasets/tomatoes-plus.felix")
```

### 3. A general-purpose dataset of anything

**Toddler words:** Grab whatever pictures the libraries have and let the helper name everything it sees.

No class file and no queries: random pictures from several collections, labelled with whatever the prompt-free
model recognises. Runs until 10,000 pairs (or Ctrl+C).

```python
fx.acquire([fx.sources.wikimedia(), fx.sources.openverse(), fx.sources.nasa(), fx.sources.open_images()])
fx.transform.dedupe()
fx.transform.letterbox(size=640)
fx.annotate(model=fx.models.yoloe)
fx.export("./datasets/anything.sh_felix", pairs=10_000, shard_size=1000)
```

### 4. A species classifier

**Toddler words:** One word per picture ("oak", "maple", "beech") instead of boxes, straight from nature photographers.

One label per picture instead of boxes: iNaturalist names each photo's species.

```python
fx.acquire([
    fx.sources.inaturalist(taxon=["Quercus robur", "Acer pseudoplatanus", "Fagus sylvatica"], limit=2400, label=True),
])
fx.transform.center_crop(size=384)
fx.transform.augment(copies=1, flip=0.5, rotate=15, brightness=0.2)
fx.export("./datasets/trees.felix")
```

### 5. From a video to a dataset

**Toddler words:** Film it once; Felix keeps the frames where something changed and blurs faces.

```python
fx.load_class("./classes.yml")
fx.acquire([fx.sources.video("./greenhouse.mp4", sampling=fx.sampling.auto())], blur_faces=True)
fx.annotate(model=wf.load("./models/leaf-detector.nbm"))
fx.export("./datasets/greenhouse.felix")
```

### 6. Releasing a dataset openly

**Toddler words:** Share it with the world, with only the pictures everyone may reuse, and a note crediting every photographer.

Let Felix pick the most open licence every picture allows, and leave out any picture that doesn't fit.

```python
fx.acquire([fx.sources.wikimedia(query="bicycle", limit=2000), fx.sources.openverse(query="bicycle", limit=2000)])
fx.annotate(model=fx.models.yolo26n)
fx.export("./release/bicycles", license="auto", strict=True, title="Bicycles", authors=["Ann Lee"], version="1.0")
```

### 7. Training on it, then fine-tuning

**Toddler words:** Teach the brain with the new box of pictures, starting from what it already knows.

The dataset goes straight into Workflow (its train / val piles are used as they are). To adapt a model you
already trained to the new dataset, fine-tune it: the backbone stays frozen and only the later layers learn.

```python
import workflow as wf
model = wf.fine_tune("./models/leaf-detector.nbm", "./datasets/tomatoes.felix", epochs=30, freeze="backbone")
```

### 8. Trying different settings quickly

**Toddler words:** The pictures are already in the cupboard (the cache), so trying another setting takes seconds.

The first export downloads; every later run of the same sources comes from the download cache. Change a transform
or the model and run again: it takes seconds, not minutes.

```python
fx.reset()                                  # forget the previous steps (same program)
fx.acquire([fx.sources.open_images(classes=["Tomato"], limit=1000, seed=0)])   # same seed: same pictures
fx.transform.letterbox(size=512)
fx.export("./datasets/try-512.felix", overwrite=True)
```
