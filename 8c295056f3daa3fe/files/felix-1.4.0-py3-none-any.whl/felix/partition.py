"""Split a dataset into several smaller, self-contained datasets."""
from __future__ import annotations

import os
import random
from typing import List, Optional, Sequence

from . import _yaml
from ._ui import Panel, fmt_n
from .errors import FelixError
from .store import EXT, SHARD_EXT, Dataset, open_writer


def _counts_from_ratio(n: int, ratio: Sequence[float]) -> List[int]:
    if any(r <= 0 for r in ratio):
        raise FelixError(f"every ratio must be > 0, got {list(ratio)}")
    total = float(sum(ratio))
    exact = [n * r / total for r in ratio]
    counts = [int(e) for e in exact]
    for i in sorted(range(len(ratio)), key=lambda i: exact[i] - counts[i], reverse=True)[: n - sum(counts)]:
        counts[i] += 1                                      # largest remainders get the leftovers
    return counts


def plan(ds: Dataset, parts=None, ratio=None, size=None, by_split=False, names=None,
         shuffle=False, seed=0):
    """Decide the pieces: returns [(name, [stems])]. Exactly one of parts / ratio / size / by_split."""
    chosen = [k for k, v in (("parts", parts), ("ratio", ratio), ("size", size), ("by_split", by_split)) if v]
    if len(chosen) != 1:
        raise FelixError("choose exactly one way to partition: parts=N, ratio=(...), size=K or by_split=True"
                         + (f" (got {', '.join(chosen)})" if chosen else ""))
    stems = list(ds.stems)
    n = len(stems)
    if n == 0:
        raise FelixError("the dataset is empty")
    if by_split:
        if shuffle:
            raise FelixError("shuffle does not apply to by_split (the splits already decide the pieces)")
        groups = [(k, list(getattr(ds, k).stems)) for k in ("train", "val", "test")]
        groups = [(k, g) for k, g in groups if g]
        default = [k for k, _ in groups]
        pieces = [g for _, g in groups]
    else:
        if shuffle:
            random.Random(seed).shuffle(stems)
        if parts:
            if not isinstance(parts, int) or parts < 1:
                raise FelixError(f"parts must be a positive integer, got {parts!r}")
            if parts > n:
                raise FelixError(f"cannot split {n} pairs into {parts} pieces")
            counts = _counts_from_ratio(n, [1] * parts)
        elif ratio:
            if len(ratio) < 2:
                raise FelixError("ratio needs at least two numbers, e.g. 80,10,10")
            counts = _counts_from_ratio(n, ratio)
            if 0 in counts:
                raise FelixError(f"ratio {list(ratio)} leaves a piece empty with only {n} pairs")
        else:
            if not isinstance(size, int) or size < 1:
                raise FelixError(f"size must be a positive integer, got {size!r}")
            counts = [min(size, n - i) for i in range(0, n, size)]
        pieces, i = [], 0
        for c in counts:
            pieces.append(stems[i:i + c])
            i += c
        default = [f"part{k + 1}" for k in range(len(pieces))]
    if names:
        names = list(names)
        if len(names) != len(pieces):
            raise FelixError(f"{len(names)} names given for {len(pieces)} pieces")
        if len(set(names)) != len(names) or any(not s or "/" in s or "\\" in s for s in names):
            raise FelixError(f"piece names must be distinct, non-empty and without slashes: {names}")
    return list(zip(names or default, pieces))


def partition(source, output=None, parts: Optional[int] = None, ratio: Optional[Sequence[float]] = None,
              size: Optional[int] = None, by_split: bool = False, names: Optional[Sequence[str]] = None,
              shuffle: bool = False, seed: int = 0, pack: Optional[bool] = None,
              overwrite: bool = False, quiet: bool = False) -> List[str]:
    """Split ``source`` into pieces, each a complete dataset. Returns the paths written.

    Choose one of: ``parts=N`` (N equal pieces), ``ratio=(80, 10, 10)`` (proportional pieces),
    ``size=K`` (pieces of at most K pairs) or ``by_split=True`` (one piece per train/val/test split).
    Pairs keep their order unless ``shuffle=True`` (reproducible with ``seed``). Pieces are written to
    the folder ``output`` (default ``<source>_parts``) as ``.felix`` files when ``pack`` is true
    (default: same kind as the source) or as folders. Files keep their names, so pieces can be traced
    back to the source.
    """
    ds = source if isinstance(source, Dataset) else Dataset(source)
    try:
        pieces = plan(ds, parts, ratio, size, by_split, names, shuffle, seed)
        src = ds.path.rstrip("/\\")
        if pack is None:
            pack = src.lower().endswith(EXT)
        stem = src[:-len(SHARD_EXT)] if src.lower().endswith(SHARD_EXT) else src[:-len(EXT)] if src.lower().endswith(EXT) else src
        out_dir = str(output) if output else stem + "_parts"
        paths = [os.path.join(out_dir, name + (EXT if pack else "")) for name, _ in pieces]
        panel = Panel("", quiet=quiet)
        panel.title = panel.join("Felix partition", ds.path, f"{fmt_n(len(ds))} pairs", f"{len(pieces)} pieces")
        panel.sub = panel.join("Worker running", "shuffled, seed %d" % seed if shuffle else "original order",
                               ".felix files" if pack else "folders")
        rows = [panel.row(name, len(st)) for name, st in pieces]
        for r, (_, st) in zip(rows, pieces):
            r.label = f"{fmt_n(len(st))} pairs"
        writers = []
        try:
            with panel:
                for i, ((name, stems), path, row) in enumerate(zip(pieces, paths, rows)):
                    w = open_writer(path, overwrite)
                    writers.append(w)
                    split_counts = {}
                    for stem in stems:
                        raw = ds._r.read(f"annotations/{stem}.yml")
                        ann = _yaml.loads(raw.decode("utf-8"))
                        w.write(f"images/{ann['image']}", ds._r.read("images/" + ann["image"]))
                        w.write(f"annotations/{stem}.yml", raw)
                        if "split" in ann:
                            split_counts[ann["split"]] = split_counts.get(ann["split"], 0) + 1
                        row.advance()
                    meta = dict(ds.metadata)
                    meta["pairs"] = len(stems)
                    if "splits" in meta:
                        meta["splits"] = split_counts
                    meta["partition"] = {"source": os.path.basename(src), "name": name, "index": i + 1,
                                         "of": len(pieces)}
                    w.write("metadata.yml", _yaml.dumps(meta).encode("utf-8"))
                    w.close()
                    row.done()
                    row.foot = f"written to {path}"
        except BaseException:
            for w in writers:
                w.abort()
            raise
        return paths
    finally:
        if not isinstance(source, Dataset):
            ds.close()
