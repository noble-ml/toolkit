"""The working dataset that ``fx.load_class / acquire / transform / annotate / export`` build up, step by step.

Users never see this object: the public functions act on the one session of the running program. Images stay where
they are when possible (local files are referenced, not copied); downloads, video frames and transformed images go
into a private working folder that is removed when the program ends.
"""
from __future__ import annotations

import atexit
import os
import shutil
import tempfile
import threading
from typing import Dict, List, Optional

from .errors import FelixError


class Item:
    """One image of the working dataset.

    ``objects``: [{"class", "bbox": [x, y, w, h] in pixels, "confidence"?, "segmentation"?: [[x, y, ...], ...],
    "origin": "dataset" | "model", "attributes"?}].  ``label``: an image-level class (classification datasets).
    ``status``: "none" (not annotated), "dataset" (labels came with the data), "model" (annotated by a model),
    "negative" (deliberately empty), "failed" (the model could not process it: never exported as a negative).
    """

    __slots__ = ("id", "path", "width", "height", "objects", "label", "status", "model", "error", "split", "source",
                 "history", "privacy", "owned", "ext", "group")

    def __init__(self, id, path, width, height, source, ext=None, owned=False):
        self.id, self.path, self.width, self.height = id, path, width, height
        self.objects: List[dict] = []
        self.label: Optional[dict] = None
        self.status, self.model, self.error = "none", None, None
        self.split: Optional[str] = None
        self.source = dict(source)
        self.history: List[str] = []
        self.privacy: Optional[dict] = None
        self.owned = owned                          # the file lives in the working folder (may be replaced)
        self.group = None                           # the original image this one was made from (same split)
        self.ext = (ext or os.path.splitext(path)[1] or ".png").lower()

    @property
    def annotated(self) -> bool:
        return self.status in ("dataset", "model", "negative")


class Session:
    def __init__(self):
        self.classes: Optional[list] = None         # from load_class: [{"name", "prompt", "aliases", "confidence"}]
        self.class_file: Optional[str] = None
        self.default_confidence: Optional[float] = None
        self.items: List[Item] = []
        self.ids = set()
        self.sources: list = []                     # fx.acquire: where images come from
        self.steps: list = []                       # transforms and annotation, in the order they were asked for
        self.terminal: Optional[str] = None         # set by consequential: no geometry changes after it
        self._work: Optional[str] = None
        self._lock = threading.Lock()
        self._n = 0

    # ---- working folder
    @property
    def work(self) -> str:
        if self._work is None:
            self._work = tempfile.mkdtemp(prefix="felix-")
            atexit.register(shutil.rmtree, self._work, True)
        return self._work

    def new_path(self, ext: str, sub: str = "img") -> str:
        with self._lock:
            self._n += 1
            n = self._n
        d = os.path.join(self.work, sub)
        os.makedirs(d, exist_ok=True)
        return os.path.join(d, f"{n:08d}{ext}")

    # ---- items
    def unique_id(self, base: str) -> str:
        import re
        base = re.sub(r"[^A-Za-z0-9._-]+", "_", base).strip("._") or "image"
        base = base[:80]
        cand, k = base, 1
        with self._lock:
            while cand in self.ids:
                k += 1
                cand = f"{base}_{k}"
            self.ids.add(cand)
        return cand

    def add(self, item: Item) -> None:
        self.items.append(item)

    def replace_items(self, items: List[Item]) -> None:
        self.items = items
        self.ids = {i.id for i in items}

    # ---- class configuration
    def class_names(self) -> List[str]:
        """The configured classes, else every class seen so far (in order of first appearance)."""
        if self.classes is not None:
            return [c["name"] for c in self.classes]
        seen: Dict[str, None] = {}
        for it in self.items:
            for o in it.objects:
                seen.setdefault(o["class"], None)
            if it.label:
                seen.setdefault(it.label["class"], None)
        return list(seen)

    def resolve(self, name: str) -> Optional[str]:
        """The configured class a dataset / model class name stands for (None: not wanted). Without a class file every
        class is kept as it is."""
        if self.classes is None:
            return name
        key = str(name).strip().lower()
        for c in self.classes:
            if key == c["name"].lower() or key in (a.lower() for a in c.get("aliases", [])):
                return c["name"]
        return None

    def confidence_for(self, name: str, default: float) -> float:
        if self.classes is not None:
            for c in self.classes:
                if c["name"] == name and c.get("confidence") is not None:
                    return float(c["confidence"])
        return self.default_confidence if self.default_confidence is not None else default

    def require_items(self, what: str):
        if not self.items:
            raise FelixError(f"{what}: there are no images yet. Call fx.acquire([...]) first.")

    def log(self, step: str, **info) -> None:
        pass


S = Session()


def reset() -> None:
    """Start over: forget the class file, the images and everything done to them (the working folder is cleared)."""
    global S
    old = S
    S = Session()
    if old._work:
        shutil.rmtree(old._work, ignore_errors=True)


def session() -> Session:
    return S
