"""HTTP for online sources: a descriptive User-Agent, polite per-host pacing, retries that honour Retry-After, size
limits, and credentials from arguments, environment variables or ~/.config/felix/credentials.yml."""
from __future__ import annotations

import json
import os
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from typing import Dict, Optional

from ._version import __version__
from .errors import FelixError

MAX_BYTES = 60 * 2**20                          # one image may not be larger than this
CONFIG = os.path.join(os.path.expanduser("~"), ".config", "felix", "credentials.yml")


def user_agent() -> str:
    """Wikimedia and others require a User-Agent naming the tool and a way to reach its operator. Set FELIX_CONTACT
    (an email or URL) or ``contact:`` in ~/.config/felix/credentials.yml to include yours."""
    contact = os.environ.get("FELIX_CONTACT") or _config().get("contact")
    who = f"; {contact}" if contact else ""
    return f"felix/{__version__} (computer-vision dataset toolkit{who})"


_cfg = None


def _config() -> Dict:
    global _cfg
    if _cfg is None:
        _cfg = {}
        if os.path.isfile(CONFIG):
            from . import _yaml
            try:
                with open(CONFIG, encoding="utf-8") as f:
                    _cfg = _yaml.loads(f.read()) or {}
            except Exception:
                _cfg = {}
    return _cfg


def credential(name: str, given: Optional[str], env: str, how: str) -> str:
    """An API key from the argument, the environment variable ``env``, or the credentials file (key ``name``)."""
    key = given or os.environ.get(env) or _config().get(name)
    if not key:
        raise FelixError(f"{how} needs an API key: pass api_key=..., set the {env} environment variable, or add "
                         f"'{name}: <key>' to {CONFIG}")
    return str(key)


#: set when an export ends: every waiting request (paused host, back-off, pacing) gives up at once
CANCEL = threading.Event()


def _sleep(seconds: float):
    """Sleep, unless the export has ended (then stop waiting)."""
    if seconds > 0 and CANCEL.wait(seconds):
        raise FelixError("stopped: the export has finished")


class _Pacer:
    """At most one request per ``interval`` seconds to each host (requests to one host go one after another)."""

    def __init__(self):
        self.last: Dict[str, float] = {}
        self.lock = threading.Lock()

    def wait(self, host: str, interval: float):
        with self.lock:
            now = time.monotonic()
            t = max(now, self.last.get(host, 0.0) + interval)
            self.last[host] = t
        if t > now:
            _sleep(t - now)


_pacer = _Pacer()


def safe_url(url: str) -> str:
    """Percent-encode what servers put unencoded in URLs (spaces, non-ASCII) without touching what is already encoded."""
    return urllib.parse.quote(url, safe=":/?&=%#~+,;@!$'()*[]")


# ---------------------------------------------------------------------------------------------------------- speed
# Image hosts (CDNs, storage buckets) take parallel requests; APIs are asked one request at a time. Connections are
# kept alive and reused per thread and host (no new TLS handshake per image).
HOST_LIMITS = {"open-images-dataset.s3.amazonaws.com": 16, "inaturalist-open-data.s3.amazonaws.com": 16,
               "images.cocodataset.org": 16, "live.staticflickr.com": 8, "images.unsplash.com": 8,
               "images.pexels.com": 8, "images-assets.nasa.gov": 8, "datasets-server.huggingface.co": 8,
               "upload.wikimedia.org": 2, "www.artic.edu": 2}
DEFAULT_LIMIT = 4
_host_sem: Dict[str, threading.Semaphore] = {}
_host_pause: Dict[str, float] = {}
_noted: set = set()
_sem_lock = threading.Lock()
_local = threading.local()


def _semaphore(host: str) -> threading.Semaphore:
    with _sem_lock:
        if host not in _host_sem:
            _host_sem[host] = threading.Semaphore(HOST_LIMITS.get(host, DEFAULT_LIMIT))
        return _host_sem[host]


def _wait_if_paused(host: str):
    until = _host_pause.get(host, 0.0)
    if until > time.time():
        _sleep(until - time.time())


def _pause(host: str, seconds: float):
    """A host asked us to slow down (429 / 503): every request to it waits, the other hosts carry on."""
    seconds = max(1.0, min(seconds, 300.0))
    _host_pause[host] = max(_host_pause.get(host, 0.0), time.time() + seconds)
    if host not in _noted:
        _noted.add(host)
        from ._ui import note
        note(f"{host} asked Felix to slow down: pausing requests to it for {seconds:.0f} s (other sources continue)"
             + ("; set FELIX_CONTACT so Wikimedia can tell who you are" if "wikimedia" in host and not
                (os.environ.get("FELIX_CONTACT") or _config().get("contact")) else ""))


def _connection(scheme: str, host: str, timeout: float):
    import http.client
    import ssl
    pool = _local.__dict__.setdefault("pool", {})
    key = (scheme, host)
    c = pool.get(key)
    if c is None:
        if scheme == "https":
            c = http.client.HTTPSConnection(host, timeout=timeout, context=ssl.create_default_context())
        else:
            c = http.client.HTTPConnection(host, timeout=timeout)
        pool[key] = c
    return c


def _drop(scheme: str, host: str):
    c = _local.__dict__.get("pool", {}).pop((scheme, host), None)
    if c is not None:
        try:
            c.close()
        except Exception:
            pass


class _Response:
    def __init__(self, status, headers, body, reason=""):
        self.status, self.headers, self.body, self.reason = status, headers, body, reason


def _fetch(url: str, headers: dict, timeout: float, max_bytes: int) -> _Response:
    """One GET over a kept-alive connection, following redirects. Uses urllib (and its proxy support) when a proxy is
    configured."""
    import gzip
    import http.client
    if urllib.request.getproxies():
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers=headers), timeout=timeout) as r:
                body = r.read(max_bytes + 1)
                return _Response(r.status, r.headers, body)
        except urllib.error.HTTPError as e:
            return _Response(e.code, e.headers, b"", e.reason)
    for _ in range(6):                                   # redirects
        u = urllib.parse.urlsplit(url)
        path = (u.path or "/") + (f"?{u.query}" if u.query else "")
        for attempt in (0, 1):                           # a kept-alive connection the server closed: reconnect once
            c = _connection(u.scheme, u.netloc, timeout)
            try:
                c.request("GET", path, headers=dict(headers, Host=u.netloc))
                r = c.getresponse()
                size = r.getheader("Content-Length")
                if size and int(size) > max_bytes:
                    _drop(u.scheme, u.netloc)
                    raise FelixError(f"too large ({int(size) / 2**20:.0f} MB, limit {max_bytes / 2**20:.0f} MB)")
                body = r.read(max_bytes + 1)
                break
            except (http.client.RemoteDisconnected, http.client.BadStatusLine, http.client.CannotSendRequest,
                    http.client.ResponseNotReady, ConnectionResetError, BrokenPipeError) as e:
                _drop(u.scheme, u.netloc)
                if attempt:
                    raise ConnectionError(str(e) or type(e).__name__)
        if r.getheader("Content-Encoding") == "gzip":
            body = gzip.decompress(body)
        if r.status in (301, 302, 303, 307, 308) and r.getheader("Location"):
            url = urllib.parse.urljoin(url, r.getheader("Location"))
            continue
        return _Response(r.status, r.msg, body, r.reason)
    raise FelixError("too many redirects")


def request(url: str, *, headers=None, interval: float = 0.0, retries: int = 4, timeout: float = 60,
            max_bytes: int = MAX_BYTES, expect_image: bool = False, gzip_ok: bool = False) -> bytes:
    """GET ``url``. Requests to one host share a concurrency cap (HOST_LIMITS) and, with ``interval``, a minimum gap
    (APIs); 429 / 5xx pause that host for its Retry-After (other hosts continue) and the request is retried."""
    url = safe_url(url)
    host = urllib.parse.urlsplit(url).netloc
    h = {"User-Agent": user_agent(), "Accept": "*/*", "Accept-Encoding": "gzip" if gzip_ok else "identity",
         "Connection": "keep-alive"}
    h.update(headers or {})
    delay = 2.0
    for attempt in range(retries + 1):
        _wait_if_paused(host)
        if interval:
            _pacer.wait(host, interval)
        try:
            with _semaphore(host):
                r = _fetch(url, h, timeout, max_bytes)
        except FelixError:
            raise
        except (OSError, TimeoutError, ConnectionError) as e:
            _drop(urllib.parse.urlsplit(url).scheme, host)
            if attempt < retries:
                _sleep(delay)
                delay *= 2
                continue
            raise FelixError(f"network error ({getattr(e, 'reason', None) or e})") from None
        if r.status == 429 and "wikimedia" in host and not (os.environ.get("FELIX_CONTACT") or _config().get("contact")):
            raise FelixError("Wikimedia refuses programs that do not say how to reach their operator: set FELIX_CONTACT "
                             "to your email or a URL (or contact: in ~/.config/felix/credentials.yml) and run again")
        if r.status in (429, 500, 502, 503, 504):
            if attempt < retries:
                wait = r.headers.get("Retry-After") if r.headers else None
                try:
                    pause = float(wait) if wait else delay
                except ValueError:
                    pause = delay
                if r.status in (429, 503):
                    _pause(host, pause)
                else:
                    _sleep(min(pause, 30))
                delay *= 2
                continue
        if r.status >= 400:
            raise FelixError(f"HTTP {r.status} {r.reason}".strip())
        ctype = r.headers.get("Content-Type", "") if r.headers else ""
        if expect_image and ctype and not ctype.startswith("image/") and "octet-stream" not in ctype:
            raise FelixError(f"not an image (the server sent {ctype.split(';')[0]})")
        if len(r.body) > max_bytes:
            raise FelixError(f"too large (over {max_bytes / 2**20:.0f} MB)")
        return r.body
    raise FelixError("gave up after retries")


def get_json(url: str, **kw):
    kw.setdefault("interval", 0.5)                       # APIs: one request at a time, spaced
    try:
        data = request(url, max_bytes=200 * 2**20, gzip_ok=True, **kw)
    except FelixError as e:
        if "403" in str(e) or "503" in str(e):
            raise FelixError(f"{urllib.parse.urlsplit(url).netloc} refused the request ({e}); providers behind bot checks "
                             "sometimes block programs for a while: try again later") from None
        raise
    if data[:200].lstrip().startswith(b"<") and (b"Just a moment" in data[:2000] or b"captcha" in data[:4000].lower()):
        raise FelixError(f"{urllib.parse.urlsplit(url).netloc} answered with a bot check instead of data: it is blocking "
                         "automated requests right now; try again later")
    try:
        return json.loads(data.decode("utf-8"))
    except ValueError:
        raise FelixError(f"the server did not return JSON ({data[:120]!r})") from None


# ---------------------------------------------------------------------------------------------------------- image cache
_cache_writes = [0]


def image_cache_get(url: str) -> Optional[bytes]:
    if os.environ.get("FELIX_IMAGE_CACHE", "1") == "0":
        return None
    import hashlib
    p = os.path.join(cache_dir("images"), hashlib.sha1(url.encode("utf-8")).hexdigest())
    if os.path.isfile(p):
        try:
            os.utime(p)                                  # recently used: evicted last
            with open(p, "rb") as f:
                return f.read()
        except OSError:
            return None
    return None


def image_cache_put(url: str, data: bytes) -> None:
    """Keep a downloaded image so a re-run of the export needs no network. Capped (FELIX_IMAGE_CACHE_GB, default 10):
    the least recently used images go first. FELIX_IMAGE_CACHE=0 turns the cache off."""
    if os.environ.get("FELIX_IMAGE_CACHE", "1") == "0":
        return
    import hashlib
    d = cache_dir("images")
    p = os.path.join(d, hashlib.sha1(url.encode("utf-8")).hexdigest())
    tmp = f"{p}.{threading.get_ident()}.part"
    try:
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, p)
    except OSError:
        return
    _cache_writes[0] += 1
    if _cache_writes[0] % 500 == 0:
        limit = float(os.environ.get("FELIX_IMAGE_CACHE_GB", "10")) * 2**30
        files = [(e.stat().st_mtime, e.stat().st_size, e.path) for e in os.scandir(d) if e.is_file()]
        total = sum(f[1] for f in files)
        for _, size, path in sorted(files):
            if total <= limit:
                break
            try:
                os.remove(path)
                total -= size
            except OSError:
                pass


def download(url: str, path: str, *, interval: float = 0.5, max_bytes: int = 20 * 2**30, chunk: int = 2**20,
             headers=None) -> str:
    """Stream a large file (archives, metadata CSVs) to ``path`` via a .part file."""
    url = safe_url(url)
    host = urllib.parse.urlsplit(url).netloc
    _pacer.wait(host, interval)
    h = {"User-Agent": user_agent(), "Accept": "*/*"}
    h.update(headers or {})
    tmp = path + ".part"
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=h), timeout=120) as r, open(tmp, "wb") as f:
            done = 0
            while True:
                b = r.read(chunk)
                if not b:
                    break
                done += len(b)
                if done > max_bytes:
                    raise FelixError(f"download larger than {max_bytes / 2**30:.0f} GB")
                f.write(b)
        os.replace(tmp, path)
        return path
    except urllib.error.HTTPError as e:
        raise FelixError(f"HTTP {e.code} {e.reason} while downloading") from None
    except (urllib.error.URLError, OSError) as e:
        raise FelixError(f"download failed ({getattr(e, 'reason', e)})") from None
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def cache_dir(*parts) -> str:
    d = os.path.join(os.environ.get("FELIX_CACHE") or os.path.join(os.path.expanduser("~"), ".cache", "felix"), *parts)
    os.makedirs(d, exist_ok=True)
    return d
