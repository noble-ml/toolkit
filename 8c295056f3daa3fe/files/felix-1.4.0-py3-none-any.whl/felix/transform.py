"""``fx.transform``: what happens to the images (and their labels) between acquiring and exporting.

Geometry:   center_crop(size), letterbox(size), consequential(size, negative_rate)
Labels:     map_classes({...}), filter_classes(keep=[...] / drop=[...])
Images:     filter_images(...), dedupe(), blur_faces()
Your own:   custom(fn)

Each call adds a step; steps run in the order they were written, on every image, when ``fx.export`` runs. Boxes and
segmentation polygons move with the pixels. ``consequential`` is final: nothing that changes geometry may follow it.
"""
from __future__ import annotations

import os
import random as _random
from typing import Callable, Dict, List, Optional, Sequence

from . import _images
from ._session import Item, session
from .errors import FelixError


class Step:
    """One transformation. ``process`` gets a batch of images and returns the images that continue."""

    name = "step"
    geometry = False                 # changes pixels' positions (so boxes move)

    def start(self):
        pass

    def process(self, batch: List[Item]) -> List[Item]:
        return [it for it in batch if self.one(it) is not False]

    def one(self, it: Item):
        raise NotImplementedError

    def finish(self) -> Optional[str]:
        """A line for the report at the end of the export (or None)."""
        return None

    def describe(self) -> dict:
        return {"step": self.name}


def _register(step: Step) -> Step:
    S = session()
    if S.terminal and step.geometry:
        raise FelixError(f"transform.{step.name} changes geometry, but transform.consequential already ran: it must be "
                         "the last geometric step (move this before it)")
    if isinstance(step, consequential):
        S.terminal = "consequential"
    S.steps.append(step)
    return step


def _size(size, what):
    if isinstance(size, int) and not isinstance(size, bool) and size >= 8:
        return (size, size)
    if isinstance(size, (tuple, list)) and len(size) == 2 and all(isinstance(v, int) and v >= 8 for v in size):
        return (int(size[0]), int(size[1]))
    raise FelixError(f"transform.{what}: size must be a whole number (square, e.g. 640) or (width, height), at least 8")


def _replace(it: Item, im, note: str, objects=None):
    """Store new pixels for ``it`` in the working folder (the previous working copy is removed)."""
    S = session()
    ext = _images.out_ext(it.ext)
    path = S.new_path(ext)
    _images.save(im, path)
    if it.owned and os.path.exists(it.path):
        os.remove(it.path)
    it.path, it.ext, it.owned = path, ext, True
    it.width, it.height = im.size
    if objects is not None:
        it.objects = objects
    it.history.append(note)


def _resample():
    from PIL import Image
    return Image.Resampling.LANCZOS if hasattr(Image, "Resampling") else Image.LANCZOS


# ---------------------------------------------------------------------------------------------------------- geometry
class center_crop(Step):
    """The central region at the target shape, resized to ``size`` (640 or (width, height)). Boxes are moved;
    boxes with less than ``min_visibility`` of their area left are dropped. Good for shrinking large photos before
    annotating."""

    name, geometry = "center_crop", True

    def __init__(self, size=640, min_visibility: float = 0.3):
        self.size, self.min_visibility = _size(size, "center_crop"), min_visibility
        _register(self)

    def describe(self):
        return {"step": self.name, "size": list(self.size), "min_visibility": self.min_visibility}

    def one(self, it):
        W, H = self.size
        im = _images.open_rgb(it.path)
        w, h = im.size
        scale = max(W / w, H / h)
        cw, ch = W / scale, H / scale
        x, y = (w - cw) / 2, (h - ch) / 2
        out = im.resize((W, H), _resample(), box=(x, y, x + cw, y + ch))
        objs, _ = _images.remap_objects(it.objects, (x, y, cw, ch), (scale, scale), (0, 0), (W, H), self.min_visibility)
        _replace(it, out, f"center_crop {W}x{H}", objs)


class letterbox(Step):
    """The whole picture, resized to fit ``size`` with its aspect ratio kept, padded with ``fill`` (grey 114 by
    default, as detectors are trained). Nothing is cut off; boxes are moved."""

    name, geometry = "letterbox", True

    def __init__(self, size=640, fill=(114, 114, 114)):
        self.size = _size(size, "letterbox")
        self.fill = tuple(fill) if isinstance(fill, (tuple, list)) else (int(fill),) * 3
        _register(self)

    def describe(self):
        return {"step": self.name, "size": list(self.size), "fill": list(self.fill)}

    def one(self, it):
        from PIL import Image
        W, H = self.size
        im = _images.open_rgb(it.path)
        w, h = im.size
        s = min(W / w, H / h)
        nw, nh = max(1, round(w * s)), max(1, round(h * s))
        px, py = (W - nw) // 2, (H - nh) // 2
        canvas = Image.new("RGB", (W, H), self.fill)
        canvas.paste(im.resize((nw, nh), _resample()), (px, py))
        objs, _ = _images.remap_objects(it.objects, (0, 0, w, h), (nw / w, nh / h), (px, py), (W, H), 0.0)
        _replace(it, canvas, f"letterbox {W}x{H}", objs)


class consequential(Step):
    """Object-focused square crops from annotated images, resized to ``size``, plus negative crops (no objects) so
    that they make up ``negative_rate`` of the output.

    For every object not already well covered: a square around it with ``margin`` of its size on each side, at least
    ``size`` pixels where the image allows it (small objects are not blown up), shifted to stay inside the image (padded
    with grey only if the object is larger than the image's short side). Every object inside a crop keeps its box
    (cut-off ones need ``min_visibility`` of their area). A crop overlapping an earlier crop of the same image by more
    than ``overlap`` (IoU) is skipped as a duplicate. Negatives are random squares that touch no object, from the same
    images or from annotated images without objects. Needs annotations (run ``fx.annotate`` first); images whose
    annotation failed are left out, never used as negatives. Final: no geometry step may follow."""

    name, geometry = "consequential", True

    def __init__(self, size=640, negative_rate: float = 0.15, margin: float = 0.25, min_visibility: float = 0.3,
                 overlap: float = 0.6, seed: int = 0):
        if not 0 <= negative_rate < 1:
            raise FelixError("transform.consequential: negative_rate must be in [0, 1) (0.15 = 15% negative samples)")
        self.size = _size(size, "consequential")
        if self.size[0] != self.size[1]:
            raise FelixError("transform.consequential makes square crops: give one size, e.g. 640")
        self.rate, self.margin, self.min_visibility, self.overlap, self.seed = negative_rate, margin, min_visibility, overlap, seed
        annotated_before = any(s.__class__.__name__ == "AnnotateStep" for s in session().steps)
        self.needs_annotation_step = not annotated_before
        _register(self)

    def describe(self):
        return {"step": self.name, "size": self.size[0], "negative_rate": self.rate, "margin": self.margin,
                "min_visibility": self.min_visibility, "overlap": self.overlap, "seed": self.seed}

    def start(self):
        self.rng = _random.Random(self.seed)
        self.pos = self.neg = 0
        self.unannotated = self.failed = self.short = 0

    def _square(self, cx, cy, side, W, H):
        x = min(max(cx - side / 2, 0), W - side) if side <= W else (W - side) / 2
        y = min(max(cy - side / 2, 0), H - side) if side <= H else (H - side) / 2
        return [x, y, side, side]

    def _crop(self, parent: Item, im, region, k, kind):
        from PIL import Image
        S = session()
        x, y, side, _ = region
        n = self.size[0]
        canvas = Image.new("RGB", (round(side), round(side)), (114, 114, 114))
        src = (max(0, x), max(0, y), min(im.size[0], x + side), min(im.size[1], y + side))
        canvas.paste(im.crop(tuple(round(v) for v in src)), (round(src[0] - x), round(src[1] - y)))
        out = canvas.resize((n, n), _resample())
        s = n / side
        objs, _ = _images.remap_objects(parent.objects, (x, y, side, side), (s, s), (0, 0), (n, n), self.min_visibility)
        if kind == "negative":
            objs = []
        it = Item(S.unique_id(f"{parent.id}_{'c' if kind == 'object' else 'n'}{k}"), "", n, n,
                  dict(parent.source, crop_of=parent.id, crop=[round(v, 1) for v in region]), ext=parent.ext)
        it.status = "negative" if kind == "negative" else parent.status
        it.model, it.split, it.privacy = parent.model, parent.split, parent.privacy
        it.group = parent.group or parent.id
        it.history = parent.history + [f"consequential {kind} crop of {parent.id}"]
        _replace(it, out, "consequential", objs)
        it.history.pop()                                   # _replace adds a generic note; the specific one is above
        return it

    def process(self, batch):
        out = []
        for it in batch:
            if it.status == "failed":
                self.failed += 1
                continue
            if not it.annotated:
                if self.needs_annotation_step:
                    raise FelixError("transform.consequential needs annotated images: call fx.annotate(model=...) before "
                                     "fx.transform.consequential(...), or acquire a dataset that has labels")
                self.unannotated += 1
                continue
            im = _images.open_rgb(it.path)
            W, H = im.size
            n = self.size[0]
            crops = []
            for o in sorted(it.objects, key=lambda o: -o["bbox"][2] * o["bbox"][3]):
                bx, by, bw, bh = o["bbox"]
                if any(_images.fraction_inside(o["bbox"], c) > 0.99 and max(bw, bh) >= 0.15 * c[2] for c in crops):
                    continue                               # already well inside an earlier crop
                side = max(bw, bh) * (1 + 2 * self.margin)
                side = max(side, min(n, W, H))
                region = self._square(bx + bw / 2, by + bh / 2, side, W, H)
                if any(_images.iou(region, c) > self.overlap for c in crops):
                    continue
                crops.append(region)
            for k, region in enumerate(crops):
                out.append(self._crop(it, im, region, k, "object"))
                self.pos += 1
            # negatives: keep the running share at negative_rate
            want = lambda: self.rate > 0 and self.neg < self.rate / (1 - self.rate) * max(1, self.pos)
            tries, made = 0, 0
            boxes = [[o["bbox"][0] - 0.1 * o["bbox"][2], o["bbox"][1] - 0.1 * o["bbox"][3], o["bbox"][2] * 1.2, o["bbox"][3] * 1.2]
                     for o in it.objects]
            while want() and tries < 30:
                tries += 1
                short = min(W, H)
                side = self.rng.uniform(min(n, short), short)
                region = [self.rng.uniform(0, W - side), self.rng.uniform(0, H - side), side, side]
                if any(_images.intersects(region, b) for b in boxes):
                    continue
                out.append(self._crop(it, im, region, made, "negative"))
                self.neg += 1
                made += 1
            if it.owned and os.path.exists(it.path):
                os.remove(it.path)
        return out

    def finish(self):
        total = self.pos + self.neg
        parts = [f"consequential: {self.pos} object crops + {self.neg} negatives"
                 + (f" ({100 * self.neg / total:.0f}% negative)" if total else "")]
        if total and self.rate and self.neg / total < self.rate - 0.02:
            parts.append(f"fewer negatives than asked ({self.rate:.0%}): the images left little background without objects")
        if self.failed:
            parts.append(f"{self.failed} image(s) whose annotation failed were left out")
        if self.unannotated:
            parts.append(f"{self.unannotated} unannotated image(s) were left out")
        return "; ".join(parts)


# ---------------------------------------------------------------------------------------------------------- labels
class map_classes(Step):
    """Rename classes: ``{"Car": "vehicle", "Truck": "vehicle"}``. A class mapped to None is removed."""

    name = "map_classes"

    def __init__(self, mapping: Dict[str, Optional[str]]):
        if not isinstance(mapping, dict) or not mapping:
            raise FelixError("transform.map_classes: give a dict such as {'Car': 'vehicle'}")
        self.mapping = {str(k): v for k, v in mapping.items()}
        _register(self)

    def describe(self):
        return {"step": self.name, "mapping": self.mapping}

    def one(self, it):
        objs = []
        for o in it.objects:
            new = self.mapping.get(o["class"], o["class"])
            if new is not None:
                objs.append(dict(o, **{"class": str(new)}))
        it.objects = objs
        if it.label:
            new = self.mapping.get(it.label["class"], it.label["class"])
            it.label = dict(it.label, **{"class": str(new)}) if new is not None else None


class filter_classes(Step):
    """Keep only boxes of ``keep`` classes, or remove ``drop`` classes. Images are kept (now with fewer boxes)."""

    name = "filter_classes"

    def __init__(self, keep: Optional[Sequence[str]] = None, drop: Optional[Sequence[str]] = None):
        if (keep is None) == (drop is None):
            raise FelixError("transform.filter_classes: give keep=[...] or drop=[...]")
        self.keep, self.drop = (set(keep) if keep else None), (set(drop) if drop else None)
        _register(self)

    def describe(self):
        return {"step": self.name, "keep": sorted(self.keep) if self.keep else None, "drop": sorted(self.drop) if self.drop else None}

    def one(self, it):
        ok = (lambda c: c in self.keep) if self.keep is not None else (lambda c: c not in self.drop)
        it.objects = [o for o in it.objects if ok(o["class"])]


# ---------------------------------------------------------------------------------------------------------- images
class filter_images(Step):
    """Drop images that are too small, too stretched, without objects, or that ``where(item)`` rejects."""

    name = "filter_images"

    def __init__(self, min_width: int = 0, min_height: int = 0, max_aspect: Optional[float] = None,
                 require_objects: bool = False, where: Optional[Callable] = None):
        self.min_width, self.min_height, self.max_aspect = min_width, min_height, max_aspect
        self.require_objects, self.where = require_objects, where
        _register(self)

    def describe(self):
        return {"step": self.name, "min_width": self.min_width, "min_height": self.min_height, "max_aspect": self.max_aspect,
                "require_objects": self.require_objects}

    def start(self):
        self.dropped = 0

    def one(self, it):
        a = max(it.width, it.height) / max(1, min(it.width, it.height))
        ok = (it.width >= self.min_width and it.height >= self.min_height and (self.max_aspect is None or a <= self.max_aspect)
              and (not self.require_objects or it.objects) and (self.where is None or self.where(it)))
        if not ok:
            self.dropped += 1
            if it.owned and os.path.exists(it.path):
                os.remove(it.path)
            return False

    def finish(self):
        return f"filter_images: {self.dropped} image(s) dropped" if self.dropped else None


class dedupe(Step):
    """Drop near-duplicate images (a 64-bit difference hash; ``threshold`` = how many of the 64 bits may differ).
    The first one seen is kept. Catches re-uploads, resized copies and near-identical video frames."""

    name = "dedupe"

    def __init__(self, threshold: int = 4):
        if not isinstance(threshold, int) or not 0 <= threshold <= 16:
            raise FelixError("transform.dedupe: threshold must be a whole number from 0 to 16")
        self.threshold = threshold
        _register(self)

    def describe(self):
        return {"step": self.name, "threshold": self.threshold}

    def start(self):
        self.parts = self.threshold + 1                # pigeonhole: a match agrees exactly on at least one part
        self.buckets = [dict() for _ in range(self.parts)]
        self.dropped = 0

    def _hash(self, path):
        im = _images.open_rgb(path).convert("L").resize((9, 8), _resample())
        px = list(im.tobytes())                         # mode L: one byte per pixel
        bits = 0
        for r in range(8):
            for col in range(8):
                bits = (bits << 1) | (px[r * 9 + col] > px[r * 9 + col + 1])
        return bits

    def one(self, it):
        h = self._hash(it.path)
        width = 64 // self.parts
        keys = [(h >> (k * width)) & ((1 << width) - 1) for k in range(self.parts)]
        for k, key in enumerate(keys):
            for other in self.buckets[k].get(key, ()):
                if bin(h ^ other).count("1") <= self.threshold:
                    self.dropped += 1
                    if it.owned and os.path.exists(it.path):
                        os.remove(it.path)
                    return False
        for k, key in enumerate(keys):
            self.buckets[k].setdefault(key, []).append(h)

    def finish(self):
        return f"dedupe: {self.dropped} near-duplicate image(s) dropped" if self.dropped else None


YUNET = ("face_detection_yunet_2023mar.onnx",
         "https://github.com/opencv/opencv_zoo/raw/main/models/face_detection_yunet/face_detection_yunet_2023mar.onnx")


class blur_faces(Step):
    """Blur faces before images are stored (privacy). Faces are found with OpenCV (``pip install opencv-python``):
    its YuNet face detector where available (OpenCV 4.5.4 and later; the small model file is downloaded once into the
    cache), otherwise its Haar cascade detectors. This is best effort: small, turned or covered faces can be missed, so
    check sensitive data yourself. ``strength`` scales the blur."""

    name = "blur_faces"

    def __init__(self, strength: float = 1.0, min_size: int = 20, score: float = 0.6):
        self.strength, self.min_size, self.score = strength, min_size, score
        _register(self)

    def describe(self):
        return {"step": self.name, "detector": getattr(self, "detector", "OpenCV"), "strength": self.strength}

    def start(self):
        try:
            import cv2
        except ImportError:
            raise FelixError("transform.blur_faces needs OpenCV: pip install opencv-python") from None
        self.cv2, self.faces, self.yunet, self.cascades = cv2, 0, None, []
        if hasattr(cv2, "FaceDetectorYN"):
            from . import _http
            path = os.path.join(_http.cache_dir("models"), YUNET[0])
            try:
                if not os.path.isfile(path):
                    _http.download(YUNET[1], path)
                self.yunet = cv2.FaceDetectorYN.create(path, "", (320, 320), self.score, 0.3, 5000)
                self.detector = "OpenCV YuNet"
            except Exception:
                self.yunet = None
        if self.yunet is None and hasattr(cv2, "CascadeClassifier"):
            root = cv2.data.haarcascades
            self.cascades = [cv2.CascadeClassifier(os.path.join(root, f)) for f in
                             ("haarcascade_frontalface_default.xml", "haarcascade_profileface.xml")]
            self.detector = "OpenCV Haar cascades"
        if self.yunet is None and not self.cascades:
            raise FelixError("transform.blur_faces: this OpenCV has no Haar face detector and the YuNet model could not be "
                             f"downloaded ({YUNET[1]}); download it into {os.path.join(_http.cache_dir('models'))} or "
                             "install opencv-python 4.x")

    def _find(self, rgb):
        cv2 = self.cv2
        found = []
        if self.yunet is not None:
            bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
            self.yunet.setInputSize((bgr.shape[1], bgr.shape[0]))
            _, faces = self.yunet.detect(bgr)
            for f in (faces if faces is not None else []):
                x, y, w, h = (int(v) for v in f[:4])
                if min(w, h) >= self.min_size:
                    found.append((x, y, w, h))
            return found
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        for d in self.cascades:
            for flip in (False, True):
                g = gray[:, ::-1] if flip else gray
                for (x, y, w, h) in d.detectMultiScale(g, scaleFactor=1.1, minNeighbors=5, minSize=(self.min_size, self.min_size)):
                    x = g.shape[1] - x - w if flip else x
                    found.append((int(x), int(y), int(w), int(h)))
        return found

    def one(self, it):
        from PIL import ImageFilter
        import numpy as np
        im = _images.open_rgb(it.path)
        found = self._find(np.asarray(im))
        if found:
            for (x, y, w, h) in found:
                pad = int(0.15 * max(w, h))
                box = (max(0, x - pad), max(0, y - pad), min(im.size[0], x + w + pad), min(im.size[1], y + h + pad))
                if box[2] <= box[0] or box[3] <= box[1]:
                    continue
                region = im.crop(box).filter(ImageFilter.GaussianBlur(radius=max(4, self.strength * max(w, h) / 6)))
                im.paste(region, box)
            _replace(it, im, f"blur_faces {len(found)}")
            self.faces += len(found)
        it.privacy = {"faces_blurred": len(found), "detector": f"{self.detector} (best effort)"}

    def finish(self):
        return f"blur_faces: {self.faces} face region(s) blurred with {self.detector} (best effort: check sensitive images yourself)"


class custom(Step):
    """Your own step: ``fn(image, objects) -> (image, objects)`` with a Pillow image and the list of boxes
    ([x, y, w, h] pixels), or None to drop the image. ``geometry=True`` if it moves pixels (then you are responsible
    for moving the boxes, and it cannot follow consequential)."""

    name = "custom"

    def __init__(self, fn: Callable, geometry: bool = False, name: Optional[str] = None):
        if not callable(fn):
            raise FelixError("transform.custom: fn must be a function (image, objects) -> (image, objects)")
        self.fn, self.geometry, self.label = fn, geometry, name or getattr(fn, "__name__", "custom")
        _register(self)

    def describe(self):
        return {"step": f"custom:{self.label}", "geometry": self.geometry}

    def one(self, it):
        res = self.fn(_images.open_rgb(it.path), [dict(o) for o in it.objects])
        if res is None:
            if it.owned and os.path.exists(it.path):
                os.remove(it.path)
            return False
        im, objs = res
        W, H = im.size
        clean = []
        for o in objs or []:
            b = _images.clip_box(o["bbox"], W, H)
            if b is not None:
                clean.append(dict(o, bbox=b))
        _replace(it, im, f"custom {self.label}", clean)


__all__ = ["center_crop", "letterbox", "consequential", "map_classes", "filter_classes", "filter_images", "dedupe",
           "blur_faces", "custom", "Step"]


# ---------------------------------------------------------------------------------------------------------- augmentation
def _affine_matrix(W, H, flip, vflip, angle, scale, tx, ty):
    """Forward 3x3 matrix mapping source pixels to output pixels: about the centre, flip → scale → rotate → shift."""
    import math
    c, s = math.cos(math.radians(angle)), math.sin(math.radians(angle))
    fx_, fy_ = (-1 if flip else 1) * scale, (-1 if vflip else 1) * scale
    cx, cy = W / 2, H / 2
    a, b = c * fx_, -s * fy_
    d, e = s * fx_, c * fy_
    return (a, b, cx + tx - a * cx - b * cy, d, e, cy + ty - d * cx - e * cy)


def _apply(m, x, y):
    return m[0] * x + m[1] * y + m[2], m[3] * x + m[4] * y + m[5]


def _inverse(m):
    a, b, c, d, e, f = m
    det = a * e - b * d
    ia, ib, id_, ie = e / det, -b / det, -d / det, a / det
    return (ia, ib, -(ia * c + ib * f), id_, ie, -(id_ * c + ie * f))


def _move_objects(objects, m, W, H, min_visibility):
    out = []
    for o in objects:
        x, y, w, h = o["bbox"]
        if o.get("segmentation"):
            polys = [[v for k in range(0, len(p) - 1, 2) for v in _apply(m, p[k], p[k + 1])] for p in o["segmentation"]]
            xs = [p[k] for p in polys for k in range(0, len(p), 2)]
            ys = [p[k] for p in polys for k in range(1, len(p), 2)]
        else:
            polys = None
            pts = [_apply(m, px, py) for px, py in ((x, y), (x + w, y), (x, y + h), (x + w, y + h))]
            xs, ys = [p[0] for p in pts], [p[1] for p in pts]
        full = [min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)]
        b = _images.clip_box(full, W, H)
        if b is None or b[2] * b[3] < min_visibility * max(1e-9, full[2] * full[3]):
            continue
        n = dict(o, bbox=[round(v, 2) for v in b])
        if polys:
            clipped = [cp for cp in (_images.clip_polygon(p, W, H) for p in polys) if len(cp) >= 6]
            if clipped:
                n["segmentation"] = clipped
            else:
                n.pop("segmentation", None)
        out.append(n)
    return out


class augment(Step):
    """Extra, randomly changed versions of every image (the labels follow). ``copies`` new versions per image; the
    original stays unless ``keep_original=False``. Copies stay in the same train / val / test split as their original.

    Geometry (boxes and masks move with it): ``flip`` / ``vflip`` (probabilities), ``rotate`` (± degrees), ``scale``
    (± fraction: 0.2 = 80–120 %), ``translate`` (± fraction of the size). Colour: ``brightness``, ``contrast``,
    ``saturation`` (± fraction), ``hue`` (± degrees). Damage: ``blur``, ``grayscale``, ``jpeg`` (probabilities: a slight
    blur, no colour, heavy JPEG compression), ``noise`` (largest noise, fraction of the brightness range), ``cutout``
    (probability of erasing a random patch; boxes hidden by more than 60 % are dropped). Boxes keeping less than
    ``min_visibility`` of their area are dropped. With ``rotate``, ``scale`` and ``translate`` at 0 (flips are fine) it may follow ``consequential``."""

    name = "augment"

    def __init__(self, copies: int = 1, keep_original: bool = True, flip: float = 0.5, vflip: float = 0.0,
                 rotate: float = 0.0, scale: float = 0.1, translate: float = 0.1, brightness: float = 0.2,
                 contrast: float = 0.2, saturation: float = 0.2, hue: float = 5.0, blur: float = 0.05, noise: float = 0.0,
                 grayscale: float = 0.02, jpeg: float = 0.0, cutout: float = 0.0, min_visibility: float = 0.3, seed: int = 0):
        if not isinstance(copies, int) or copies < 0 or (copies == 0 and not keep_original):
            raise FelixError("transform.augment: copies must be a whole number ≥ 0 (and at least 1 without the original)")
        for k, v in (("flip", flip), ("vflip", vflip), ("blur", blur), ("grayscale", grayscale), ("jpeg", jpeg), ("cutout", cutout)):
            if not 0 <= v <= 1:
                raise FelixError(f"transform.augment: {k} is a probability between 0 and 1")
        for k, v in (("scale", scale), ("translate", translate), ("brightness", brightness), ("contrast", contrast),
                     ("saturation", saturation), ("noise", noise)):
            if not 0 <= v < 1:
                raise FelixError(f"transform.augment: {k} is a fraction between 0 and 1 (e.g. 0.2)")
        self.o = dict(flip=flip, vflip=vflip, rotate=abs(rotate), scale=scale, translate=translate, brightness=brightness,
                      contrast=contrast, saturation=saturation, hue=abs(hue), blur=blur, noise=noise, grayscale=grayscale,
                      jpeg=jpeg, cutout=cutout)
        self.copies, self.keep, self.min_visibility, self.seed = copies, keep_original, min_visibility, seed
        self.geometry = bool(rotate or scale or translate)      # flips keep every crop's size and boxes: allowed after consequential
        _register(self)

    def describe(self):
        return {"step": self.name, "copies": self.copies, "keep_original": self.keep, **self.o, "seed": self.seed}

    def start(self):
        self.rng = _random.Random(self.seed)
        self.made = 0

    def _one_copy(self, it: Item, k: int) -> Item:
        from PIL import Image, ImageChops, ImageEnhance, ImageFilter
        S, o, r = session(), self.o, self.rng
        im = _images.open_rgb(it.path)
        W, H = im.size
        objs = [dict(x) for x in it.objects]
        flip, vflip = r.random() < o["flip"], r.random() < o["vflip"]
        angle = r.uniform(-o["rotate"], o["rotate"]) if o["rotate"] else 0.0
        sc = r.uniform(1 - o["scale"], 1 + o["scale"]) if o["scale"] else 1.0
        tx = r.uniform(-o["translate"], o["translate"]) * W if o["translate"] else 0.0
        ty = r.uniform(-o["translate"], o["translate"]) * H if o["translate"] else 0.0
        if flip or vflip or angle or sc != 1.0 or tx or ty:
            m = _affine_matrix(W, H, flip, vflip, angle, sc, tx, ty)
            im = im.transform((W, H), Image.AFFINE, _inverse(m), resample=Image.BILINEAR, fillcolor=(114, 114, 114))
            objs = _move_objects(objs, m, W, H, self.min_visibility)
        for kind, Enh in (("brightness", ImageEnhance.Brightness), ("contrast", ImageEnhance.Contrast),
                          ("saturation", ImageEnhance.Color)):
            if o[kind]:
                im = Enh(im).enhance(r.uniform(1 - o[kind], 1 + o[kind]))
        if o["hue"]:
            shift = round(r.uniform(-o["hue"], o["hue"]) / 360 * 255)
            if shift:
                h_, s_, v_ = im.convert("HSV").split()
                h_ = h_.point(lambda p: (p + shift) % 256)
                im = Image.merge("HSV", (h_, s_, v_)).convert("RGB")
        if r.random() < o["grayscale"]:
            im = im.convert("L").convert("RGB")
        if r.random() < o["blur"]:
            im = im.filter(ImageFilter.GaussianBlur(radius=r.uniform(0.5, 1.5)))
        if o["noise"]:
            sigma = r.uniform(0, o["noise"]) * 255
            if sigma >= 1:
                n = Image.effect_noise((W, H), sigma)
                im = ImageChops.add(im, Image.merge("RGB", (n, n, n)), 1.0, -128)
        if r.random() < o["cutout"]:
            cw, ch = int(W * r.uniform(0.1, 0.3)), int(H * r.uniform(0.1, 0.3))
            cx, cy = r.randint(0, max(0, W - cw)), r.randint(0, max(0, H - ch))
            im.paste((114, 114, 114), (cx, cy, cx + cw, cy + ch))
            hole = [cx, cy, cw, ch]
            objs = [x for x in objs if _images.fraction_inside(x["bbox"], hole) <= 0.6]
        ext = _images.out_ext(it.ext)
        if r.random() < o["jpeg"]:
            import io
            buf = io.BytesIO()
            im.save(buf, format="JPEG", quality=r.randint(25, 60))
            im = Image.open(io.BytesIO(buf.getvalue())).convert("RGB")
        n = Item(S.unique_id(f"{it.id}_aug{k}"), "", W, H, dict(it.source, augmented_from=it.id), ext=ext)
        n.status, n.model, n.split, n.privacy, n.label = it.status, it.model, it.split, it.privacy, it.label
        n.group = it.group or it.id
        n.history = it.history + [f"augment copy {k} of {it.id}"]
        _replace(n, im, "augment", objs)
        n.history.pop()
        return n

    def process(self, batch):
        out = []
        for it in batch:
            if it.status == "failed":                       # never multiply images without trustworthy labels
                out.append(it)
                continue
            for k in range(self.copies):
                out.append(self._one_copy(it, k))
                self.made += 1
            if self.keep:
                out.append(it)
            elif it.owned and os.path.exists(it.path):
                os.remove(it.path)
        return out

    def finish(self):
        return f"augment: {self.made} augmented cop{'y' if self.made == 1 else 'ies'}"


class mosaic(Step):
    """2 × 2 mosaics: four images (each resized to fit a quarter of ``size`` and kept whole) in one picture, with all
    their boxes. ``rate``: extra mosaics per input image (0.25 = one mosaic for every four images); the originals stay.
    Only images of the same train / val / test split are combined. A mosaic lists its four parts (and their licences)
    as its source, so attribution and licence checks cover every part."""

    name, geometry = "mosaic", True

    def __init__(self, size=640, rate: float = 0.25, seed: int = 0):
        self.size = _size(size, "mosaic")
        if not 0 < rate <= 4:
            raise FelixError("transform.mosaic: rate is mosaics per input image, above 0 (0.25 = one per four images)")
        self.rate, self.seed = rate, seed
        _register(self)

    def describe(self):
        return {"step": self.name, "size": list(self.size), "rate": self.rate, "seed": self.seed}

    def start(self):
        self.rng = _random.Random(self.seed)
        self.pool, self.made, self.debt = {}, 0, 0.0

    def _build(self, parts):
        from PIL import Image
        from .export import _split_for
        S = session()
        W, H = self.size
        canvas = Image.new("RGB", (W, H), (114, 114, 114))
        objs = []
        for q, it in enumerate(parts):
            ox, oy = (q % 2) * (W // 2), (q // 2) * (H // 2)
            cw, ch = W // 2, H // 2
            im = _images.open_rgb(it.path)
            s = min(cw / im.size[0], ch / im.size[1])
            nw, nh = max(1, round(im.size[0] * s)), max(1, round(im.size[1] * s))
            px, py = ox + (cw - nw) // 2, oy + (ch - nh) // 2
            canvas.paste(im.resize((nw, nh), _resample()), (px, py))
            moved, _ = _images.remap_objects(it.objects, (0, 0, im.size[0], im.size[1]), (nw / im.size[0], nh / im.size[1]),
                                             (px, py), (W, H), 0.0)
            objs += moved
        first = parts[0]
        src = {"type": "mosaic", "parts": [dict(p.source, image=p.id) for p in parts],
               "license": "; ".join(dict.fromkeys(str(p.source.get("license") or "unknown") for p in parts))}
        n = Item(S.unique_id(f"mosaic_{'_'.join(p.id[:12] for p in parts[:2])}"), "", W, H, src, ext=".jpg")
        statuses = {p.status for p in parts}
        n.status = "model" if "model" in statuses else ("dataset" if "dataset" in statuses else next(iter(statuses)))
        n.split, n.group = _split_for(first), first.group or first.id
        n.history = [f"mosaic of {', '.join(p.id for p in parts)}"]
        _replace(n, canvas, "mosaic", objs)
        n.history.pop()
        return n

    def process(self, batch):
        from .export import _split_for
        out = list(batch)
        import shutil
        for it in batch:
            if not it.annotated:
                continue
            # the export deletes working copies once written: the pool keeps its own copy of each image
            keep = Item(it.id, session().new_path(it.ext, "mosaic_pool"), it.width, it.height, it.source, ext=it.ext, owned=True)
            shutil.copyfile(it.path, keep.path)
            keep.objects, keep.status, keep.split, keep.group = [dict(o) for o in it.objects], it.status, it.split, it.group
            self.pool.setdefault(_split_for(it), []).append(keep)
            self.debt += self.rate
        for split, pool in self.pool.items():
            while self.debt >= 1 and len(pool) >= 4:
                parts = self.rng.sample(pool, 4)
                out.append(self._build(parts))
                self.made += 1
                self.debt -= 1
            if len(pool) > 64:                              # keep a small recent pool per split
                for old in pool[:-64]:
                    if os.path.exists(old.path):
                        os.remove(old.path)
                del pool[:-64]
        return out

    def finish(self):
        return f"mosaic: {self.made} mosaic image(s)"


__all__ += ["augment", "mosaic"]
