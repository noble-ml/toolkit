"""Store a dataset as a folder of ``.sh_felix`` shards (and back: ``felix pack shards/ -o all.felix``)."""
from __future__ import annotations

import math
import os
from typing import Optional

from ._ui import Panel, fmt_n
from .errors import FelixError
from .store import EXT, SHARD_EXT, SHARD_SIZE, Dataset, ShardWriter


def shard(source, output: Optional[str] = None, *, size: Optional[int] = None, shards: Optional[int] = None,
          overwrite: bool = False, quiet: bool = False) -> str:
    """Write ``source`` as a folder of shards and return the folder. The source is not changed.

    ``size`` pairs per shard (default 1000), or ``shards`` = how many shards (equal sizes). Pairs keep their order, names
    and splits; every shard is a complete ``.sh_felix`` file (a zip like ``.felix``). ``fx.load(folder)`` reads the
    folder as one dataset, and Workflow trains from it one shard at a time."""
    if size is not None and shards is not None:
        raise FelixError("give size= (pairs per shard) or shards= (how many), not both")
    ds = source if isinstance(source, Dataset) else Dataset(source)
    try:
        n = len(ds)
        if n == 0:
            raise FelixError("the dataset is empty")
        if shards is not None:
            if not isinstance(shards, int) or shards < 1:
                raise FelixError(f"shards must be a positive whole number, got {shards!r}")
            size = math.ceil(n / min(shards, n))
        size = SHARD_SIZE if size is None else size
        if not isinstance(size, int) or size < 1:
            raise FelixError(f"size must be a positive whole number of pairs, got {size!r}")
        src = ds.path.rstrip("/\\")
        low = src.lower()
        base = src[:-len(SHARD_EXT)] if low.endswith(SHARD_EXT) else src[:-len(EXT)] if low.endswith(EXT) else src
        path = str(output) if output else f"{base}_shards"
        if os.path.abspath(path) == os.path.abspath(src):
            raise FelixError("the output would replace the source; choose another folder")
        count = math.ceil(n / size)
        panel = Panel("", quiet=quiet)
        panel.title = panel.join("Felix shard", os.path.basename(src), f"{fmt_n(n)} pairs",
                                 f"{fmt_n(count)} shards of {fmt_n(size)}")
        panel.sub = panel.join("Worker running", f"→ {path}")
        row = panel.row(os.path.basename(path.rstrip('/\\')) or path, n)
        # splits worked out from the dataset's seed stay the same: the shards hold the same pairs and the same seed
        w = ShardWriter(path, size, overwrite)
        try:
            with panel:
                for stem in ds.stems:
                    ann = ds.annotation(stem)
                    w.write(f"images/{ann['image']}", ds._r.read("images/" + ann["image"]))
                    w.write(f"annotations/{stem}.yml", ds._r.read(f"annotations/{stem}.yml"))
                    row.advance()
                meta = dict(ds.metadata)
                meta.pop("shards", None)
                meta["sharded_from"] = os.path.basename(src)
                from . import _yaml
                w.write("metadata.yml", _yaml.dumps(meta).encode("utf-8"))
                w.close()
                row.done()
                row.foot = f"{fmt_n(count)} × {SHARD_EXT} in {path}  ·  {os.path.basename(src)} is unchanged"
        except BaseException:
            w.abort()
            raise
        return path
    finally:
        if not isinstance(source, Dataset):
            ds.close()
