"""``fx.export(path)``: run everything that was set up (acquire → transforms → annotation, in order) and write the
dataset in Felix's format, with its licence, attributions and citation.

The images stream: sources download in the background (one thread each, so different providers work in parallel
while each provider is asked one request at a time), and each batch goes through the steps and is written at once.
``pairs=N`` stops after N image/annotation pairs; without it, the export runs until every source is exhausted, or
until you stop it (Ctrl+C, ``kill``): the dataset written so far is then closed properly and usable.
"""
from __future__ import annotations

import os
import queue
import shutil
import signal
import threading
import time
import zlib
from datetime import datetime, timezone
from typing import Dict, List, Optional

from . import _http

from . import _images, _yaml, licensing
from ._session import Item, session
from ._ui import Panel, fmt_n, note
from ._version import __version__
from .errors import FelixError
from .sources._base import Collector, Stopped
from .store import EXT, SHARD_EXT, SHARD_SIZE, open_writer

_END = object()
BATCH = 16


def _split_for(it: Item) -> str:
    if it.split in ("train", "val", "test"):
        return it.split
    key = it.group or it.id                               # copies and crops follow their original: no split leakage
    h = zlib.crc32(key.encode("utf-8")) % 100           # stable 80 / 10 / 10 from the original image's name
    return "train" if h < 80 else "val" if h < 90 else "test"


class _Stop:
    """Ctrl+C / SIGTERM: finish the current batch, then close the dataset properly. A second Ctrl+C stops at once
    (the dataset is still closed and usable)."""

    def __init__(self):
        self.asked, self.old = False, {}

    def __enter__(self):
        if threading.current_thread() is threading.main_thread():
            for sig in (signal.SIGINT, getattr(signal, "SIGTERM", None)):
                if sig is not None:
                    try:
                        self.old[sig] = signal.signal(sig, self._handle)
                    except (ValueError, OSError):
                        pass
        return self

    def _handle(self, sig, frame):
        if self.asked:
            raise KeyboardInterrupt
        self.asked = True
        note("stopping after this batch and closing the dataset… (Ctrl+C again to stop at once)")

    def __exit__(self, *exc):
        for sig, h in self.old.items():
            signal.signal(sig, h)
        return False


def export(path, pairs: Optional[int] = None, *, license: Optional[str] = None, title: Optional[str] = None,
           authors=None, description: Optional[str] = None, version: Optional[str] = None, strict: bool = False,
           shard_size: int = SHARD_SIZE, overwrite: bool = False, quiet: bool = False) -> dict:
    """Write the dataset to ``path``: a ``.felix`` file, a folder, or ``name.sh_felix`` for a folder ``name/`` of
    shards (``shard_size`` pairs each). See the module docs for ``pairs``.

    Licence: ``license=None`` (default) makes a closed dataset: the compilation is all rights reserved and the
    third-party images keep their licences. An open licence id ("CC-BY-4.0", "CC-BY-SA-4.0", "CC0-1.0", …) makes it
    open; ``"auto"`` picks the most permissive open licence every image allows. Images whose licence does not fit are
    reported (``strict=True`` leaves them out). LICENSE.txt, ATTRIBUTIONS.md and CITATION.cff are written with the
    data. Returns a summary dict."""
    S = session()
    if not S.sources:
        raise FelixError("export: nothing to export yet; call fx.acquire([...]) first")
    if pairs is not None and (not isinstance(pairs, int) or isinstance(pairs, bool) or pairs < 1):
        raise FelixError("export: pairs must be a positive whole number (or None: until the sources run out or you stop)")
    spdx, open_ = licensing.resolve_dataset_license(license)
    target = os.fspath(path)
    low = target.lower()
    sharded = low.endswith(SHARD_EXT)
    out_path = target[:-len(SHARD_EXT)] if sharded else target
    if not low.endswith(EXT) and not sharded and os.path.isfile(target):
        raise FelixError(f"export: {target} is a file; give a .felix file, a folder, or name.sh_felix")
    title = title or os.path.splitext(os.path.basename(out_path.rstrip("/\\")))[0]
    authors = [authors] if isinstance(authors, str) else list(authors or [])
    transformed = any(getattr(s, "geometry", False) for s in S.steps)
    if open_ and spdx not in (None, "auto"):
        bad_now = [s.label() for s in S.sources if s.kind in ("pexels", "unsplash")]
        if bad_now:
            note(f"{', '.join(bad_now)}: these photo licences do not clearly allow redistributing photos in a dataset; "
                 "they are flagged in ATTRIBUTIONS.md")

    writer = open_writer(out_path, overwrite, shard_size if sharded else None)
    panel = Panel("", quiet=quiet)
    panel.title = panel.join("Felix export", os.path.basename(out_path.rstrip("/\\")) + (SHARD_EXT if sharded else ""),
                             f"{fmt_n(pairs)} pairs" if pairs else "until the sources run out or you stop it")
    panel.sub = panel.join(f"{len(S.sources)} source{'s' * (len(S.sources) != 1)}",
                           " → ".join(s.describe().get("step", s.name) for s in S.steps) or "no transforms",
                           "open: " + str(spdx) if open_ else "closed dataset")
    rows = [panel.row(s.label(), s.limit if getattr(s, "limit", None) else None) for s in S.sources]
    out_row = panel.row("export", pairs)

    stop_sources = threading.Event()
    queues = [queue.Queue(maxsize=BATCH * 2) for _ in S.sources]
    collectors, errors, threads = [], {}, []

    def run(k, src):
        c = collectors[k]
        try:
            def progress(done, total=None):
                rows[k].n, rows[k].status = done, "running"
                if total:
                    rows[k].total = total
            src.collect(c, progress)
            c.drain()                                  # its downloads still running
        except Stopped:
            pass
        except BaseException as e:                       # a broken source is reported; the others carry on
            errors[k] = f"{type(e).__name__}: {e}" if not isinstance(e, FelixError) else str(e)
        finally:
            while True:
                try:
                    queues[k].put(_END, timeout=0.2)
                    break
                except queue.Full:
                    if stop_sources.is_set():
                        try:
                            while True:
                                queues[k].get_nowait()
                        except queue.Empty:
                            pass

    def sink_for(k):
        def sink(it):
            while True:
                if stop_sources.is_set():
                    raise Stopped()
                try:
                    queues[k].put(it, timeout=0.2)
                    return
                except queue.Full:
                    continue
        return sink

    for k, src in enumerate(S.sources):
        collectors.append(Collector(src.label(), sink=sink_for(k), stop=stop_sources))
    for st in S.steps:
        st.start()

    class_ids: Dict[str, int] = {}
    if S.classes is not None:
        class_ids = {c["name"]: i for i, c in enumerate(S.classes)}
    written, split_counts, kinds, rows_attr, licences, excluded = 0, {}, set(), [], [], {"failed": 0, "licence": 0, "unannotated": 0}
    source_summary = {}
    t0 = time.time()

    def write(it: Item):
        nonlocal written
        ext = it.ext if it.ext in _images.KEEP_EXT else ".png"
        fname = f"{it.id}{'.jpg' if ext == '.jpeg' else ext}"
        if ext == it.ext:
            with open(it.path, "rb") as f:
                data = f.read()
        else:
            import io
            buf = io.BytesIO()
            _images.open_rgb(it.path).save(buf, format="PNG")
            data = buf.getvalue()
        split = _split_for(it)
        objs = []
        for o in it.objects:
            b = _images.clip_box(o["bbox"], it.width, it.height)     # integrity: inside the image, positive size
            if b is None:
                continue
            cid = class_ids.setdefault(o["class"], len(class_ids))
            n = {"class": o["class"], "class_id": cid, "bbox": [_images.num(v) for v in b]}
            for k in ("confidence", "segmentation", "attributes", "origin"):
                if o.get(k) is not None:
                    n[k] = o[k]
            objs.append(n)
        ann = {"image": fname, "width": it.width, "height": it.height, "split": split}
        if it.label:
            ann["class"] = it.label["class"]
            ann["class_id"] = class_ids.setdefault(it.label["class"], len(class_ids))
            if it.label.get("confidence") is not None:
                ann["confidence"] = it.label["confidence"]
            kinds.add("classification")
        if it.objects or not it.label:
            ann["objects"] = objs
            kinds.add("detection")
        a = {"status": it.status}
        if it.status == "none":
            excluded["unannotated"] += 1
        if it.model:
            a["model"] = it.model.get("name")
        ann["annotation"] = a
        ann["source"] = it.source
        if it.history:
            ann["history"] = it.history
        if it.privacy:
            ann["privacy"] = it.privacy
        writer.write(f"images/{fname}", data)
        writer.write(f"annotations/{it.id}.yml", _yaml.dumps(ann).encode("utf-8"))
        written += 1
        split_counts[split] = split_counts.get(split, 0) + 1
        for k, part in enumerate(it.source.get("parts") or [it.source]):   # a mosaic: every part credited and checked
            rows_attr.append(dict(part, id=f"{it.id}#{k}" if "parts" in it.source else it.id, file=fname))
            licences.append({"id": f"{it.id}#{k}" if "parts" in it.source else it.id, "license": part.get("license")})
        t = it.source.get("type", "unknown")
        source_summary[t] = source_summary.get(t, 0) + 1
        out_row.n = written
        dt = max(1e-9, time.time() - t0)
        out_row.stats = panel.join(f"{fmt_n(written)} pairs", f"{written / dt:,.1f}/s",
                                   f"{excluded['failed']} failed" if excluded["failed"] else "")

    def drop(it: Item):
        if it.owned and os.path.exists(it.path):
            os.remove(it.path)

    stop = _Stop()
    interrupted = False
    _http.CANCEL.clear()
    try:
        with panel, stop:
            for k, src in enumerate(S.sources):
                th = threading.Thread(target=run, args=(k, src), daemon=True, name=f"felix-source-{k}")
                th.start()
                threads.append(th)
            alive = set(range(len(S.sources)))
            turn = 0
            while alive and not stop.asked and (pairs is None or written < pairs):
                batch = []
                idle_rounds = 0
                while len(batch) < BATCH and alive:
                    k = sorted(alive)[turn % len(alive)]
                    turn += 1
                    try:
                        got = queues[k].get(timeout=0.05)
                    except queue.Empty:
                        idle_rounds += 1
                        if batch and idle_rounds > 2 * len(alive):
                            break                         # sources are slow: process what we have
                        panel.refresh()
                        if stop.asked:
                            break
                        continue
                    if got is _END:
                        alive.discard(k)
                        rows[k].done()
                        if k in errors:
                            rows[k].status = "failed"
                            rows[k].foot = errors[k][:200]
                        continue
                    batch.append(got)
                if not batch:
                    continue
                for st in S.steps:
                    batch = st.process(batch)
                for it in batch:
                    if pairs is not None and written >= pairs:
                        drop(it)
                        continue
                    if it.status == "failed":
                        excluded["failed"] += 1
                        drop(it)
                        continue
                    if strict and any(licensing.problem(p.get("license"), None if spdx == "auto" else spdx, open_, transformed)
                                      for p in (it.source.get("parts") or [it.source])):
                        excluded["licence"] += 1
                        drop(it)
                        continue
                    write(it)
                    drop(it)
                panel.refresh()
    except KeyboardInterrupt:
        interrupted = True
    except BaseException:
        stop_sources.set()
        writer.abort()
        raise
    finally:
        stop_sources.set()

    if stop.asked or interrupted:
        note(f"stopped: closing the dataset with the {fmt_n(written)} pair(s) written so far")
    _http.CANCEL.set()                                   # paused / retrying downloads give up instead of waiting
    deadline = time.time() + 5                           # sources still waiting on a slow server are left behind
    for th in threads:
        th.join(timeout=max(0.0, deadline - time.time()))
    if written == 0:
        writer.abort()
        detail = "; ".join([f"{S.sources[k].label()}: {e}" for k, e in errors.items()]
                           + [line for line in (st.finish() for st in S.steps) if line and "failed" in line])
        raise FelixError("export: no images made it into the dataset"
                         + (f" ({detail})" if detail else " (all sources were empty, filtered out, or failed annotation)"))

    # ---- licences
    problems, lic_counts, suggest = licensing.assess(licences, spdx if spdx != "auto" else None, open_, transformed)
    if spdx == "auto":
        spdx = suggest
        problems, lic_counts, _ = licensing.assess(licences, spdx, True, transformed)
    if strict and excluded["licence"]:
        note(f"strict: {excluded['licence']} image(s) whose licence does not fit this release were left out")
    names = S.class_names() if S.classes is not None else list(class_ids)
    for n in class_ids:
        if n not in names:
            names.append(n)
    classes = []
    for n in names:
        entry = {"id": class_ids.get(n, len(class_ids)), "name": n}
        cfg = next((c for c in (S.classes or []) if c["name"] == n), None)
        if cfg and len(cfg.get("prompts") or []) > 1:
            entry["prompts"] = list(cfg["prompts"])
        elif cfg and cfg["prompt"] != n:
            entry["prompt"] = cfg["prompt"]
        classes.append(entry)
    classes.sort(key=lambda c: c["id"])
    meta = {"felix_version": __version__, "created": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "title": title, "pairs": written, "task": "classification" if kinds == {"classification"} else "detection",
            "bbox_format": "xywh", "classes": classes, "splits": split_counts,
            "sources": [dict(S.sources[k].describe(), label=S.sources[k].label(), images=collectors[k].count,
                             skipped=len(collectors[k].skipped), **({"error": errors[k]} if k in errors else {}))
                        for k in range(len(S.sources))],
            "steps": [s.describe() for s in S.steps],
            "license": {"dataset": spdx if open_ else "proprietary", "access": "open" if open_ else "closed",
                        "images": lic_counts, "issues": len(problems),
                        "files": ["LICENSE.txt", "ATTRIBUTIONS.md", "CITATION.cff"]},
            "excluded": {"annotation_failed": excluded["failed"], "licence": excluded["licence"]}}
    if excluded["unannotated"]:
        meta["unannotated"] = excluded["unannotated"]          # trainers can tell "no labels yet" from "no objects"
    if S.class_file:
        meta["class_file"] = os.path.basename(S.class_file)
    if stop.asked or interrupted:
        meta["stopped_early"] = True
    if problems:
        meta["license"]["problem_images"] = problems if len(problems) <= 1000 else {"count": len(problems)}
    texts = {"LICENSE.txt": licensing.license_text(title, spdx, open_, ", ".join(authors) or None, lic_counts),
             "ATTRIBUTIONS.md": licensing.attributions(rows_attr, problems),
             "CITATION.cff": licensing.citation_cff(title, authors, spdx, open_, version, description, [s.describe() for s in S.sources])}
    writer.write("metadata.yml", _yaml.dumps(meta).encode("utf-8"))
    if not sharded:
        for name, text in texts.items():
            writer.write(name, text.encode("utf-8"))
    writer.close()
    if sharded:
        for name, text in texts.items():
            with open(os.path.join(out_path, name), "w", encoding="utf-8") as f:
                f.write(text)

    # ---- report
    for st in S.steps:
        line = st.finish()
        if line:
            note(line)
    for k, c in enumerate(collectors):
        if c.skipped:
            note(f"{S.sources[k].label()}: {len(c.skipped)} skipped (e.g. {c.skipped[0][:120]})")
        if c.unmapped:
            note(f"{S.sources[k].label()}: boxes of classes not in classes.yml left out: "
                       + ", ".join(f"{n} ×{v}" for n, v in list(c.unmapped.items())[:8]))
    for k, e in errors.items():
        note(f"{S.sources[k].label()} failed: {e}")
    unknown = sum(v for n, v in lic_counts.items() if licensing.classify(n)["kind"] == "unknown")
    if unknown:
        note(f"{unknown} image(s) have an unknown licence: check your rights before using or sharing them")
    if problems:
        note(f"{len(problems)} image(s) have licence issues for this release; see ATTRIBUTIONS.md (⚠)")
    dest = out_path + (os.sep if sharded else "")
    if not quiet:
        print(f"wrote {fmt_n(written)} pairs to {dest}  ·  {'open, ' + str(spdx) if open_ else 'closed dataset'}  ·  "
              f"splits {split_counts}")
    return {"pairs": written, "path": out_path, "license": spdx if open_ else "proprietary", "splits": split_counts,
            "licence_issues": len(problems), "failed": excluded["failed"], "stopped": bool(stop.asked or interrupted),
            "sources": {S.sources[k].label(): collectors[k].count for k in range(len(S.sources))}}
