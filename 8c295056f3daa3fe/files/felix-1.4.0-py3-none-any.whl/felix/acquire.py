"""``fx.acquire([...])``: where the dataset's images come from (any mix of ``fx.sources``). Nothing is downloaded
yet: ``fx.export`` pulls images from every source in turn while it builds the dataset."""
from __future__ import annotations

from typing import Sequence

from ._session import session
from .errors import FelixError
from .sources import Source


def acquire(sources: Sequence[Source], blur_faces: bool = False) -> None:
    """Add sources to the dataset (call again to add more). ``blur_faces=True`` blurs faces in every image as it
    arrives, before any other step (see ``fx.transform.blur_faces``: best effort)."""
    if isinstance(sources, Source):
        sources = [sources]
    if not isinstance(sources, (list, tuple)) or not sources:
        raise FelixError("acquire: give a list of sources, e.g. fx.acquire([fx.sources.local('./images')])")
    bad = [s for s in sources if not isinstance(s, Source)]
    if bad:
        raise FelixError(f"acquire: {bad[0]!r} is not a source; use fx.sources.local(...), fx.sources.urls(...), …")
    S = session()
    if S.steps and not blur_faces:
        from ._ui import note
        note("acquire after transforms: the new images still go through every step, in order")
    S.sources.extend(sources)
    if blur_faces and not any(type(s).__name__ == "blur_faces" for s in S.steps):
        from .transform import blur_faces as _blur
        step = _blur()
        S.steps.remove(step)
        S.steps.insert(0, step)                          # first, so nothing downstream sees the faces
