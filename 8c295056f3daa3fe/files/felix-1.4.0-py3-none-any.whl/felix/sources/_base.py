"""What every source shares: turning files or downloaded bytes into images of the working dataset."""
from __future__ import annotations

import os
from datetime import datetime, timezone
from typing import List, Optional

from .. import _images
from .._session import Item, session
from ..errors import FelixError


def now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


class Stopped(Exception):
    """Raised inside a source when the export has what it needs (or was stopped): the source just ends."""


class _DaemonPool:
    """A small pool of daemon worker threads: unlike ThreadPoolExecutor's workers, a download stuck in a slow server
    never keeps the program from finishing."""

    def __init__(self, n: int, name: str):
        import queue
        import threading
        self.q = queue.Queue()
        for i in range(n):
            threading.Thread(target=self._work, daemon=True, name=f"{name}-{i}").start()

    def _work(self):
        while True:
            fn = self.q.get()
            fn()

    def submit(self, fn):
        self.q.put(fn)
        return None


class Collector:
    """Receives the images one source produces (``sink``: hands each to the export as soon as it exists), with counts
    for the report. ``stop``: a threading.Event; once set, the next ``add`` ends the source."""

    def __init__(self, source_name: str, sink=None, stop=None):
        self.name = source_name
        self.sink, self.stop = sink, stop
        self.count = 0
        self.require_objects = False              # skip dataset images with none of the wanted classes
        self.items: List[Item] = []
        import threading
        self._lock = threading.Lock()
        self.inflight = 0                          # downloads started but not finished (they count towards limits)
        self._pool, self._futures, self._slots = None, [], threading.BoundedSemaphore(32)
        self.seen_urls = set()
        self.skipped: List[str] = []              # "what: why"
        self.dropped_boxes = 0
        self.unmapped = {}                        # dataset class name -> boxes left out (not in classes.yml)
        self.licence_skipped = {}                 # reason -> images left out for fx.export(use=...)

    @property
    def taken(self) -> int:
        """Images added plus downloads under way: what a source compares with its ``limit``."""
        return self.count + self.inflight

    def reached(self, limit) -> bool:
        """True once ``limit`` images are in. While downloads are under way that could reach it, waits for them: a
        failed download frees its place, and the source then asks for another image instead of ending short."""
        import time
        if limit is None:
            return False
        while True:
            if self.count >= limit:
                return True
            if self.count + self.inflight < limit:
                return False
            if self.stop is not None and self.stop.is_set():
                return True
            time.sleep(0.05)

    def run_async(self, fn, *args, name: str = "image", **kw):
        """Run ``fn`` (a download, then ``add``) on this source's worker threads; at most 32 waiting at a time.
        Per-host limits in _http decide how many really talk to one server at once."""
        if self.stop is not None and self.stop.is_set():
            raise Stopped()
        while not self._slots.acquire(timeout=0.2):          # all 32 places taken: wait, but notice a stop
            if self.stop is not None and self.stop.is_set():
                raise Stopped()
        with self._lock:
            if self._pool is None:
                self._pool = _DaemonPool(16, f"felix-dl-{self.name[:12]}")
            self.inflight += 1

        def job():
            try:
                return fn(*args, **kw)
            except Stopped:
                return None
            except FelixError as e:
                self.skip(name, str(e))
            finally:
                with self._lock:
                    self.inflight -= 1
                self._slots.release()
        self._pool.submit(job)

    def drain(self):
        """Wait for every download this source started (only this source's thread waits; the export goes on with
        the other sources). Returns early when the export stops."""
        import time
        while self.inflight > 0:
            if self.stop is not None and self.stop.is_set():
                return
            time.sleep(0.05)
        self._futures = []

    def skip(self, what: str, why: str):
        self.skipped.append(f"{what}: {why}")

    def refused(self, source: dict) -> bool:
        """True (and counted) when this image's licence does not fit ``fx.export(use=...)``: it is left out before
        anything is downloaded."""
        from .. import licensing
        why = licensing.refuse(source.get("license"), session().use)
        if why is None:
            return False
        key = f"{why} ({source.get('license') or 'none given'})" if why != "licence unknown" else why
        with self._lock:
            self.licence_skipped[key] = self.licence_skipped.get(key, 0) + 1
        return True

    def add(self, *, path: Optional[str] = None, data: Optional[bytes] = None, ext: Optional[str] = None,
            name: str, source: dict, objects=None, label=None, split=None, keep_orientation: bool = False) -> Optional[Item]:
        """Add one image. ``path``: a file that already exists (referenced, not copied); ``data``: bytes to store in
        the working folder. ``objects`` (dataset boxes, [x, y, w, h] pixels) or ``label`` (image class) make the image
        count as labelled by its dataset."""
        if self.stop is not None and self.stop.is_set():
            raise Stopped()
        if self.refused(source):
            return None
        S = session()
        try:
            if data is not None:
                w, h, orient = _images.probe(data)
                ext = (ext or ".jpg").lower()
                path = S.new_path(ext if ext in _images.IMAGE_EXT else ".jpg")
                with open(path, "wb") as f:
                    f.write(data)
                owned = True
            else:
                w, h, orient = _images.probe(path)
                ext = os.path.splitext(path)[1].lower()
                owned = False
        except FelixError as e:
            self.skip(name, str(e).replace("not a readable image", "unreadable"))
            return None
        if w < 2 or h < 2:
            self.skip(name, f"too small ({w}x{h})")
            return None
        src = dict(source)
        src.setdefault("acquired", now())
        if orient not in (1, 0) and not keep_orientation and objects is None:
            # stored sideways (camera EXIF): keep the picture as people see it
            im = _images.upright(path)
            new = S.new_path(_images.out_ext(ext))
            _images.save(im, new)
            path, ext, owned = new, _images.out_ext(ext), True
            w, h = im.size
            src["exif_rotation_applied"] = True
        it = Item(S.unique_id(os.path.splitext(os.path.basename(name))[0]), path, w, h, src, ext=ext, owned=owned)
        if objects is not None:
            kept = []
            for o in objects:
                cls = S.resolve(o["class"])
                if cls is None:
                    self.unmapped[o["class"]] = self.unmapped.get(o["class"], 0) + 1
                    continue
                b = _images.clip_box(o["bbox"], w, h)
                if b is None:
                    self.dropped_boxes += 1
                    continue
                kept.append(dict(o, **{"class": cls, "bbox": [_images.num(v) for v in b], "origin": "dataset"}))
            if not kept and objects and self.require_objects:
                self.skip(name, "none of its boxes are of the wanted classes")
                return None
            it.objects, it.status = kept, "dataset"
        if label is not None:
            cls = S.resolve(label)
            if cls is not None:
                it.label, it.status = {"class": cls, "origin": "dataset"}, "dataset"
            else:
                self.unmapped[label] = self.unmapped.get(label, 0) + 1
        if split:
            it.split = split
        with self._lock:
            self.count += 1
        if self.sink is not None:
            self.sink(it)                                # blocks while the export is busy (bounded queue)
        else:
            self.items.append(it)
        return it


class Source:
    """A place images come from. Subclasses implement ``collect(collector, progress)``."""

    kind = "source"

    def describe(self) -> dict:
        return {"type": self.kind}

    def label(self) -> str:
        return self.kind

    def using(self, vocabulary=None, per_term: int = None):
        """For a search source without a query: which subjects to ask for. ``vocabulary``: "default" (RAM++ tags plus
        everyday subjects, ~4,600), "ram++", "general" (~150 everyday subjects) or your own list;
        ``per_term``: images per subject before moving on.
        ``fx.sources.openverse(limit=500).using(vocabulary=["oak", "maple", "pine"])``"""
        if vocabulary is not None:
            from .vocabulary import resolve
            if not isinstance(vocabulary, str) and not all(isinstance(v, str) and v.strip() for v in vocabulary):
                raise FelixError("using: vocabulary is a name ('default', 'ram++', 'general') or a list of words")
            self.vocabulary = resolve(vocabulary)
        if per_term is not None:
            self.per_term = need_int(per_term, "using: per_term", allow_none=False)
        return self

    #: search sources: True when the provider has its own "anything" feed (random files, newest, curated, ...)
    native_anything = True
    #: images taken per vocabulary term before moving on, so no single subject dominates
    per_term = 25
    vocabulary = None
    #: the argument that holds the search (query, taxon, scientific_name …); a list runs several searches
    query_attr = "query"
    #: False: without a query the provider's own feed is all there is (no vocabulary)
    uses_vocabulary = True

    def _collect_many(self, qs, c: Collector, progress) -> None:
        """Several searches side by side, each on its own thread and collector, sharing the limit equally and the
        duplicate check. Their counts and reports are merged into ``c`` at the end."""
        import copy
        import threading
        limit = getattr(self, "limit", None)
        n = len(qs)
        shares = [limit // n + (1 if i < limit % n else 0) for i in range(n)] if limit is not None else [None] * n
        kids, errors = [], []

        def total(*_a, **_k):
            progress(sum(k[1].count for k in kids), limit)

        def run(child, cc, q):
            try:
                child._collect_query(cc, total)
                cc.drain()
            except Stopped:
                pass
            except FelixError as e:
                errors.append(f"“{q}”: {e}")
                cc.skip(f"{self.kind} “{q}”", str(e))
        threads = []
        for q, share in zip(qs, shares):
            if share == 0:
                continue
            child = copy.copy(self)
            setattr(child, self.query_attr, q)
            child.limit = share
            cc = Collector(c.name, sink=c.sink, stop=c.stop)
            cc._lock, cc.seen_urls, cc.require_objects = c._lock, c.seen_urls, c.require_objects
            kids.append((child, cc))
            th = threading.Thread(target=run, args=(child, cc, q), daemon=True, name=f"felix-query-{q[:20]}")
            th.start()
            threads.append(th)
        for th in threads:
            while th.is_alive():
                th.join(timeout=0.2)
                if c.stop is not None and c.stop.is_set():
                    break
        for _, cc in kids:
            c.count += cc.count
            c.skipped.extend(cc.skipped)
            c.dropped_boxes += cc.dropped_boxes
            for k, v in cc.licence_skipped.items():
                c.licence_skipped[k] = c.licence_skipped.get(k, 0) + v
            for k, v in cc.unmapped.items():
                c.unmapped[k] = c.unmapped.get(k, 0) + v
        if errors and len(errors) == len(kids):
            raise FelixError("every query failed: " + "; ".join(errors)[:400])

    def collect(self, c: Collector, progress) -> None:
        """Search sources implement ``_collect_query`` (using ``self.query``). With a query, that runs once. Without
        one: the provider's own "anything" feed first (if it has one), then the general vocabulary, term after term
        (shuffled, at most ``per_term`` images each), until ``limit``, the export's ``pairs``, or the end of it."""
        if not hasattr(self, "_collect_query"):
            raise NotImplementedError
        q = getattr(self, self.query_attr, None)
        if isinstance(q, list):
            return self._collect_many(q, c, progress)
        if q or not self.uses_vocabulary:
            return self._collect_query(c, progress)
        import random
        from .vocabulary import DEFAULT
        terms = list(self.vocabulary or DEFAULT)
        random.Random(f"{self.kind}-{len(terms)}").shuffle(terms)
        limit = getattr(self, "limit", None)
        plan = ([None] if self.native_anything else []) + terms
        for term in plan:
            if c.reached(limit) or (c.stop is not None and c.stop.is_set()):
                return
            self.query = term
            if term is not None:                          # cap each term, within the overall limit
                start = c.count
                self.limit = min(limit, start + self.per_term) if limit is not None else start + self.per_term
            try:
                self._collect_query(c, progress)
                c.drain()
            except Stopped:
                raise
            except FelixError as e:                        # one term failing (no results, a refusal) is not the end
                c.skip(f"{self.kind} “{term or 'anything'}”", str(e))
                if "refused" in str(e) or "bot check" in str(e) or "FELIX_CONTACT" in str(e):
                    raise
            finally:
                self.query, self.limit = None, limit


def fetch(c: Collector, url: str, name: str, source: dict, interval: float = 0.0, headers=None, after=None, **add):
    """Download one image (in parallel with the source's other downloads) and add it; a failed download is reported,
    not fatal. Downloaded images are cached by URL, so a re-run needs no network. ``after(item)`` runs once it is added
    (e.g. a provider's download-tracking call)."""
    if c.refused(source):                              # its licence does not fit fx.export(use=...): not downloaded
        return None
    with c._lock:                                       # the same picture found by two searches: once is enough
        if url in c.seen_urls:
            return None
        c.seen_urls.add(url)

    def job():
        import os
        from .. import _http
        data = _http.image_cache_get(url)
        if data is None:
            data = _http.request(url, interval=interval, expect_image=True, headers=headers)
            _http.image_cache_put(url, data)
        ext = os.path.splitext(url.split("?")[0])[1].lower()
        it = c.add(data=data, ext=ext if ext in _images.IMAGE_EXT else ".jpg", name=name,
                   source={k: v for k, v in source.items() if v not in (None, "")}, **add)
        if it is not None and after is not None:
            after(it)
        return it
    if getattr(c, "run_async", None) is None:            # a plain collector (tests): synchronous
        return job()
    c.run_async(job, name=name)
    return None


def queries(value, what: str, empty: str = "None for anything"):
    """A query argument: None, one text, or a list of texts (several searches). One-item lists become the text."""
    if value is None:
        return None
    if isinstance(value, (list, tuple)):
        items = list(dict.fromkeys(str(v).strip() for v in value if v is not None and str(v).strip()))
        if not items:
            raise FelixError(f"{what}: the list of queries is empty ({empty})")
        if len(items) != len([v for v in value if v is not None]):
            raise FelixError(f"{what}: every query must be a non-empty text, given once")
        return items[0] if len(items) == 1 else items
    if not str(value).strip():
        raise FelixError(f"{what}: must not be empty ({empty})")
    return str(value).strip()


def shown(value) -> str:
    """A query for labels: "oak" or "oak / maple / pine"."""
    if isinstance(value, list):
        return " / ".join(value[:4]) + (f" / … ({len(value)} queries)" if len(value) > 4 else "")
    return value or ""


def need_int(value, what, allow_none=True):
    if value is None and allow_none:
        return None
    if not isinstance(value, int) or isinstance(value, bool) or value < 1:
        raise FelixError(f"{what} must be a positive whole number" + (" (or None)" if allow_none else ""))
    return value
