"""``fx.sources.open_images(classes=[...])``: images and boxes from Google's Open Images V7 for the given classes.

Annotations come from the official CSVs (cached in ~/.cache/felix/open_images; the validation split needs about 40 MB,
test about 120 MB, train several GB); images from the public open-images-dataset bucket. Every image keeps its own
licence, author and original page from Open Images' metadata."""
from __future__ import annotations

import csv
import difflib
import os
import random
from typing import Optional, Sequence

from .. import _http
from ..errors import FelixError
from ._base import Collector, Source

BASE = "https://storage.googleapis.com/openimages"
CLASSES = f"{BASE}/v7/oidv7-class-descriptions-boxable.csv"
BOXES = {"train": f"{BASE}/v6/oidv6-train-annotations-bbox.csv", "validation": f"{BASE}/v5/validation-annotations-bbox.csv",
         "test": f"{BASE}/v5/test-annotations-bbox.csv"}
IMAGES = {"train": f"{BASE}/2018_04/train/train-images-boxable-with-rotation.csv",
          "validation": f"{BASE}/2018_04/validation/validation-images-with-rotation.csv",
          "test": f"{BASE}/2018_04/test/test-images-with-rotation.csv"}
BUCKET = "https://open-images-dataset.s3.amazonaws.com"
SPLIT = {"train": "train", "validation": "val", "test": "test"}


def _cached(url: str) -> str:
    path = os.path.join(_http.cache_dir("open_images"), url.rsplit("/", 1)[1])
    if not os.path.isfile(path):
        _http.download(url, path)
    return path


class open_images(Source):
    """Images of Open Images V7 that contain any of ``classes`` (display names such as "Car", "Person"; see the
    boxable class list), with every box of those classes. Without ``classes``: the class file's classes that Open Images
    has (names or aliases), or with no class file every one of its 600 box classes. ``split``: "validation" (default, ~42k boxed images),
    "test" or "train" (1.7M images; its box file is several GB). ``limit``: at most this many images, chosen at random
    with ``seed``. Group boxes ("a crowd of people") are kept and marked ``group_of``; ``group_of=False`` drops them."""

    kind = "open_images"

    def __init__(self, classes: Optional[Sequence[str]] = None, split: str = "validation", limit: Optional[int] = None,
                 seed: int = 0, group_of: bool = True):
        if isinstance(classes, str):
            classes = [classes]
        if split not in BOXES:
            raise FelixError("sources.open_images: split must be 'validation', 'test' or 'train'")
        self.classes, self.split, self.limit, self.seed, self.group_of = (list(classes) if classes else None), split, limit, seed, group_of

    def label(self):
        return f"open images {', '.join(self.classes) if self.classes else 'all classes'} ({self.split})"

    def describe(self):
        return {"type": "open_images", "classes": self.classes, "split": self.split, "limit": self.limit}

    def collect(self, c: Collector, progress):
        with open(_cached(CLASSES), newline="", encoding="utf-8") as f:
            table = {row[0]: row[1] for row in csv.reader(f) if len(row) >= 2 and row[0] != "LabelName"}
        by_name = {v.lower(): k for k, v in table.items()}
        mids = {}
        wanted = self.classes
        if wanted is None:
            from .._session import session
            S = session()
            if S.classes is not None:                    # the class file's names and aliases that Open Images has
                wanted = [n for c in S.classes for n in [c["name"]] + c.get("aliases", []) if n.lower() in by_name]
                if not wanted:
                    raise FelixError("sources.open_images: none of the classes in classes.yml is an Open Images class; "
                                     "pass classes=[...] or add aliases with Open Images names (e.g. 'Car')")
            else:
                mids = dict(table)                        # no target: every box class
        for name in (wanted or []):
            mid = by_name.get(name.lower())
            if mid is None:
                close = difflib.get_close_matches(name, list(table.values()), n=3)
                raise FelixError(f"sources.open_images: {name!r} is not an Open Images box class"
                                 + (f" (did you mean {', '.join(close)}?)" if close else ""))
            mids[mid] = table[mid]
        if self.split == "train":
            from .._ui import note
            note("Open Images train: the box file is several GB; downloading it once into the cache")
        boxes = {}
        with open(_cached(BOXES[self.split]), newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row["LabelName"] in mids and (self.group_of or row.get("IsGroupOf") != "1"):
                    boxes.setdefault(row["ImageID"], []).append(row)
        ids = sorted(boxes)
        if self.limit is not None and len(ids) > self.limit:
            ids = sorted(random.Random(self.seed).sample(ids, self.limit))
        meta = {}
        wanted = set(ids)
        with open(_cached(IMAGES[self.split]), newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row["ImageID"] in wanted:
                    meta[row["ImageID"]] = row
        def one(iid):
            m = meta.get(iid, {})
            url = f"{BUCKET}/{self.split}/{iid}.jpg"
            data = _http.image_cache_get(url)
            if data is None:
                data = _http.request(url, expect_image=True)
                _http.image_cache_put(url, data)
            from .._images import probe
            w, h, _ = probe(data)
            objs = []
            for r in boxes[iid]:
                x1, x2, y1, y2 = (float(r[k]) for k in ("XMin", "XMax", "YMin", "YMax"))
                o = {"class": mids[r["LabelName"]], "bbox": [x1 * w, y1 * h, (x2 - x1) * w, (y2 - y1) * h]}
                attrs = {k: r.get(f"Is{k}") == "1" for k in ("Occluded", "Truncated", "GroupOf", "Depiction")}
                attrs = {("group_of" if k == "GroupOf" else k.lower()): True for k, v in attrs.items() if v}
                if attrs:
                    o["attributes"] = attrs
                objs.append(o)
            src = {"type": "open_images", "dataset": f"Open Images V7 ({self.split})", "image_id": iid,
                   "url": url, "original_url": m.get("OriginalURL"),
                   "page": m.get("OriginalLandingURL"), "license": m.get("License") or "CC BY 2.0 (as listed by Open Images)",
                   "author": m.get("Author"), "author_page": m.get("AuthorProfileURL"), "title": m.get("Title"),
                   "annotation_license": "CC BY 4.0 (Google LLC)"}
            c.add(data=data, ext=".jpg", name=f"{iid}.jpg", source={k: v for k, v in src.items() if v},
                  objects=objs, split=SPLIT[self.split], keep_orientation=True)

        for i, iid in enumerate(ids):
            rot = (meta.get(iid, {}).get("Rotation") or "").strip()
            if rot not in ("", "0", "0.0", "nan"):
                c.skip(iid, f"stored rotated by {rot}° in Open Images (its boxes may not line up); skipped")
                continue
            if getattr(c, "run_async", None):
                c.run_async(one, iid, name=iid)
            else:
                one(iid)
            progress(c.count, len(ids))
