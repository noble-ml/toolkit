"""``fx.sources.urls(...)``: images at given web addresses (one URL, a list, or a text file with one URL per line)."""
from __future__ import annotations

import os
import urllib.parse
from typing import Optional

from .. import _http, _images
from ..errors import FelixError
from ._base import Collector, Source


class urls(Source):
    """Download images from URLs. Nothing is known about their licences: pass ``license=`` / ``attribution=`` if you
    know them (they are recorded with every image), otherwise they are marked unknown and export reminds you to check
    your rights. Up to four downloads run at once per host; ``interval`` (seconds) spaces them further."""

    kind = "urls"

    def __init__(self, source, license: Optional[str] = None, attribution: Optional[str] = None, interval: float = 0.0):
        self.source, self.license, self.attribution, self.interval = source, license, attribution, interval

    def label(self):
        return f"urls {self.source if isinstance(self.source, str) else f'({len(self.source)})'}"

    def _list(self):
        s = self.source
        if isinstance(s, (list, tuple)):
            return [str(u).strip() for u in s if str(u).strip()]
        s = os.fspath(s)
        if s.startswith(("http://", "https://")):
            return [s]
        if not os.path.isfile(s):
            raise FelixError(f"sources.urls: {s} is neither a URL nor a file of URLs")
        with open(s, encoding="utf-8") as f:
            return [l.strip() for l in f if l.strip() and not l.lstrip().startswith("#")]

    def describe(self):
        d = {"type": "urls"}
        if isinstance(self.source, str) and not self.source.startswith("http"):
            d["list"] = os.path.abspath(self.source)
        return d

    def collect(self, c: Collector, progress):
        todo = list(dict.fromkeys(self._list()))
        if not todo:
            raise FelixError("sources.urls: no URLs")
        for i, u in enumerate(todo):
            if not u.startswith(("http://", "https://")):
                c.skip(u, "not an http(s) URL")
                continue
            name = os.path.basename(urllib.parse.urlsplit(u).path) or "image"
            src = {"type": "url", "url": u, "original_filename": name, "license": self.license or "unknown"}
            if self.attribution:
                src["attribution"] = self.attribution
            from ._base import fetch
            fetch(c, u, u, src, interval=self.interval)        # parallel; the name in reports is the URL
            progress(i + 1, len(todo))
