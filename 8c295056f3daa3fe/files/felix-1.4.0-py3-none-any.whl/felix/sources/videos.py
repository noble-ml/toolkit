"""Videos from the web, sampled into frames like local videos: ``pexels_videos``, ``pixabay_videos``,
``wikimedia_videos``, ``nasa_videos`` and ``archive_videos`` (the Internet Archive).

Each search lists videos with their licence and author; a video whose licence does not fit ``fx.export(use=...)``
is skipped before it is downloaded. The others are downloaded once into Felix's cache (~/.cache/felix/videos, a re-run
needs no network), and ``sampling`` picks the frames (default ``fx.sampling.auto()``: only when the scene changes),
at most ``per_video`` from one video so no single clip fills the dataset. ``limit`` counts frames.

Videos longer than ``max_seconds`` (when the provider says), larger than ``max_mb`` or slower to download than three
minutes are skipped, so one huge file never holds the source up; ``max_height`` picks the version (720p default)."""
from __future__ import annotations

import os
import re
import urllib.parse
from typing import Iterator, Optional

from .. import _http
from .. import sampling as S
from ..errors import FelixError
from ._base import Collector, Source, need_int, queries, shown
from .media import _cv2, _jpeg, sample_file, video_file


def _q(params) -> str:
    return urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})


class _Videos(Source):
    """Shared by the video searches: subclasses yield videos from ``_videos()`` as dicts with ``url`` (the file to
    download), ``id``, ``license`` and whatever else should be recorded (page, author, attribution, duration …)."""

    kind = "videos"
    what = "videos"

    def __init__(self, query=None, limit: Optional[int] = None, sampling: Optional[S.Sampling] = None,
                 per_video: Optional[int] = 20, max_seconds: Optional[float] = 600, max_height: int = 720,
                 max_mb: float = 150):
        self.query = queries(query, f"sources.{self.kind}: query")
        self.limit = need_int(limit, f"sources.{self.kind}: limit")
        self.sampling = sampling or S.auto()
        if not isinstance(self.sampling, S.Sampling):
            raise FelixError(f"sources.{self.kind}: sampling must be fx.sampling.auto(), interval(seconds=) or random(count=)")
        self.per_video = need_int(per_video, f"sources.{self.kind}: per_video")
        self.max_seconds, self.max_height, self.max_mb = max_seconds, int(max_height), float(max_mb)

    def label(self):
        return f"{self.kind} “{shown(self.query)}”" if self.query else f"{self.kind} ({self.what})"

    def describe(self):
        return {"type": self.kind, "query": self.query, "limit": self.limit, "per_video": self.per_video,
                **self.sampling.describe()}

    def _videos(self) -> Iterator[dict]:
        raise NotImplementedError

    def _collect_query(self, c: Collector, progress):
        cv2 = _cv2()
        seen = 0
        for v in self._videos():
            if c.reached(self.limit) or (c.stop is not None and c.stop.is_set()):
                return
            seen += 1
            dur = v.get("duration")
            if self.max_seconds and dur and float(dur) > self.max_seconds:
                continue
            info = {"type": self.kind, "query": self.query, **{k: x for k, x in v.items() if x not in (None, "")}}
            info["video_url"] = info.pop("url")
            if c.refused(info):                       # not downloaded: its licence does not fit fx.export(use=)
                continue
            with c._lock:
                if info["video_url"] in c.seen_urls:  # found by two searches
                    continue
                c.seen_urls.add(info["video_url"])
            try:
                path = video_file(info["video_url"], self.max_mb)
            except FelixError as e:
                if "FELIX_CONTACT" in str(e):           # every other download would be refused too
                    raise
                c.skip(f"{self.kind} video {v.get('id')}", str(e))
                continue
            room = None if self.limit is None else self.limit - c.count
            caps = [x for x in (self.per_video, room) if x is not None]
            base = f"{self.kind}_{re.sub(r'[^A-Za-z0-9_-]+', '_', str(v.get('id')))[:60]}"

            def emit(frame, idx, t, fps, info=info, base=base):
                c.add(data=_jpeg(cv2, frame), ext=".jpg", name=f"{base}_f{idx:06d}.jpg",
                      source={**info, "frame": idx, "time": round(t, 3), "fps": round(fps, 3), **self.sampling.describe()})
                progress(c.count, self.limit)
            try:
                sample_file(path, self.sampling, emit, cap=min(caps) if caps else None)
            except FelixError as e:
                c.skip(f"{self.kind} video {v.get('id')}", str(e))
        if seen == 0 and self.query:
            c.skip(f"{self.kind} “{self.query}”", "no videos found")


def _best(files, max_height, height="height", ok=lambda f: True):
    """The tallest file no taller than ``max_height`` (else the smallest one)."""
    files = [f for f in files if ok(f) and f.get(height)]
    under = [f for f in files if int(f[height]) <= max_height]
    if under:
        return max(under, key=lambda f: int(f[height]))
    return min(files, key=lambda f: int(f[height])) if files else None


# ---------------------------------------------------------------------------------------------------------- Pexels
class pexels_videos(_Videos):
    """Stock videos from Pexels (pexels.com/videos). Key: the same free Pexels API key as ``fx.sources.pexels``
    (``api_key=``, PEXELS_API_KEY or ``pexels_api_key:`` in the credentials file). Without a query: popular videos.
    Pexels License (free, commercial use allowed); Pexels asks for credit, which is recorded with every frame."""

    kind = "pexels_videos"
    what = "popular videos"
    API = "https://api.pexels.com/videos"

    def __init__(self, query=None, limit=None, sampling=None, per_video=20, max_seconds=600, max_height=720,
                 orientation: Optional[str] = None, api_key: Optional[str] = None):
        super().__init__(query, limit, sampling, per_video, max_seconds, max_height)
        self.orientation, self._key = orientation, api_key

    def _videos(self):
        key = _http.credential("pexels_api_key", self._key, "PEXELS_API_KEY", "sources.pexels_videos")
        hdr, page = {"Authorization": key}, 1
        while True:
            if self.query:
                url = f"{self.API}/search?" + _q({"query": self.query, "page": page, "per_page": 80,
                                                  "orientation": self.orientation})
            else:
                url = f"{self.API}/popular?" + _q({"page": page, "per_page": 80})
            d = _http.get_json(url, interval=18.0, headers=hdr)        # 200 requests an hour
            vids = d.get("videos") or []
            if not vids:
                return
            for v in vids:
                f = _best(v.get("video_files") or [], self.max_height,
                          ok=lambda f: (f.get("file_type") or "").startswith("video/mp4"))
                if not f:
                    continue
                user = v.get("user") or {}
                yield {"id": v.get("id"), "url": f.get("link"), "page": v.get("url"), "duration": v.get("duration"),
                       "size": [f.get("width"), f.get("height")], "author": user.get("name"), "author_page": user.get("url"),
                       "license": "Pexels License", "license_url": "https://www.pexels.com/license/",
                       "attribution": f"Video by {user.get('name')} on Pexels"}
            if not d.get("next_page"):
                return
            page += 1


# ---------------------------------------------------------------------------------------------------------- Pixabay
class pixabay_videos(_Videos):
    """Stock videos from Pixabay (pixabay.com/videos). Key: free from pixabay.com/api/docs (``api_key=``,
    PIXABAY_API_KEY or ``pixabay_api_key:`` in the credentials file). Without a query: Pixabay's popular videos.
    Pixabay Content License (free, commercial use allowed, no credit required; credit is still recorded)."""

    kind = "pixabay_videos"
    what = "popular videos"
    API = "https://pixabay.com/api/videos/"

    def __init__(self, query=None, limit=None, sampling=None, per_video=20, max_seconds=600, max_height=720,
                 api_key: Optional[str] = None):
        super().__init__(query, limit, sampling, per_video, max_seconds, max_height)
        self._key = api_key

    def _videos(self):
        key = _http.credential("pixabay_api_key", self._key, "PIXABAY_API_KEY", "sources.pixabay_videos")
        page = 1
        while True:
            d = _http.get_json(self.API + "?" + _q({"key": key, "q": self.query, "page": page, "per_page": 200,
                                                    "safesearch": "true", "order": "popular"}), interval=1.0)
            hits = d.get("hits") or []
            if not hits:
                return
            for h in hits:
                files = [dict(f, kind=k) for k, f in (h.get("videos") or {}).items() if isinstance(f, dict) and f.get("url")]
                f = _best(files, self.max_height)
                if not f:
                    continue
                yield {"id": h.get("id"), "url": f["url"], "page": h.get("pageURL"), "duration": h.get("duration"),
                       "size": [f.get("width"), f.get("height")], "tags": h.get("tags"), "author": h.get("user"),
                       "author_page": f"https://pixabay.com/users/{h.get('user')}-{h.get('user_id')}/",
                       "license": "Pixabay Content License", "license_url": "https://pixabay.com/service/license-summary/",
                       "attribution": f"Video by {h.get('user')} from Pixabay"}
            if page * 200 >= min(int(d.get("totalHits") or 0), 500):   # the API pages through at most 500 hits
                return
            page += 1


# ---------------------------------------------------------------------------------------------------------- Wikimedia
class wikimedia_videos(_Videos):
    """Videos from Wikimedia Commons (freely licensed; most need credit, some are share-alike). Commons' own
    transcodes (WebM) are used, no taller than ``max_height``. Set FELIX_CONTACT so the requests say how to reach you,
    as Wikimedia's policy asks. Without a query: Felix's general vocabulary, a few videos per subject."""

    kind = "wikimedia_videos"
    what = "videos on everyday subjects"
    native_anything = False                       # random files are almost never videos: use the vocabulary
    per_term = 40                                 # frames per subject (two videos at the default per_video)

    def _videos(self):
        from .wikimedia import API, META, _plain
        cont = {}
        while True:
            q = {"action": "query", "format": "json", "formatversion": "2", "prop": "videoinfo",
                 "viprop": "url|size|mime|extmetadata|derivatives", "viextmetadatafilter": META, "maxlag": "5",
                 "generator": "search", "gsrsearch": f"{self.query} filetype:video", "gsrnamespace": "6", "gsrlimit": "20"}
            q.update(cont)
            d = _http.get_json(API + "?" + urllib.parse.urlencode(q), interval=1.0)
            if "error" in d:
                if (d["error"] or {}).get("code") == "maxlag":
                    continue
                raise FelixError(f"Wikimedia API error: {d['error'].get('info') or d['error'].get('code')}")
            pages = sorted((d.get("query") or {}).get("pages") or [], key=lambda p: p.get("index", 0))
            for pg in pages:
                info = (pg.get("videoinfo") or [{}])[0]
                derivs = [x for x in info.get("derivatives") or [] if x.get("src") and "video" in (x.get("type") or "")]
                f = _best(derivs, self.max_height)
                if not f:
                    continue
                meta = {k: (v or {}).get("value") for k, v in (info.get("extmetadata") or {}).items()}
                lic = _plain(meta.get("LicenseShortName")) or "unknown"
                artist = _plain(meta.get("Attribution")) or _plain(meta.get("Artist"))
                title = pg.get("title", "")
                yield {"id": title.replace("File:", ""), "url": f["src"], "page": info.get("descriptionurl"),
                       "title": title, "duration": info.get("duration"), "size": [f.get("width"), f.get("height")],
                       "license": lic, "license_url": meta.get("LicenseUrl"), "author": artist,
                       "attribution": f"{title.replace('File:', '')} by {artist or 'unknown author'}, {lic}, via Wikimedia Commons"}
            if "continue" not in d:
                return
            cont = dict(d["continue"])


# ---------------------------------------------------------------------------------------------------------- NASA
class nasa_videos(_Videos):
    """Videos from the NASA Image and Video Library (images.nasa.gov): generally not copyrighted in the US (see
    NASA's media usage guidelines; some items are third-party). Without a query: Felix's general vocabulary."""

    kind = "nasa_videos"
    what = "videos on everyday subjects"
    native_anything = False
    per_term = 40
    API = "https://images-api.nasa.gov"
    SIZES = (("~mobile.", 360), ("~small.", 480), ("~medium.", 720), ("~large.", 1080), ("~orig.", 4320))

    def _videos(self):
        page = 1
        while True:
            d = _http.get_json(f"{self.API}/search?" + _q({"q": self.query, "media_type": "video", "page": page,
                                                         "page_size": 50}), interval=0.5)
            items = (d.get("collection") or {}).get("items") or []
            if not items:
                return
            for it in items:
                meta = (it.get("data") or [{}])[0]
                try:
                    assets = _http.get_json(it["href"], interval=0.2)
                except (FelixError, KeyError):
                    continue
                hrefs = [h for h in (assets if isinstance(assets, list) else []) if isinstance(h, str) and h.lower().endswith(".mp4")]
                sized = [{"href": h, "height": hgt} for tag, hgt in self.SIZES for h in hrefs if tag in h]
                f = _best(sized, self.max_height)
                if not f:
                    continue
                nid = meta.get("nasa_id")
                yield {"id": nid, "url": f["href"].replace("http://", "https://", 1), "page": f"https://images.nasa.gov/details/{nid}",
                       "title": meta.get("title"), "center": meta.get("center"), "date": meta.get("date_created"),
                       "author": meta.get("photographer") or meta.get("secondary_creator"),
                       "license": "NASA media (generally not copyrighted in the US; see https://www.nasa.gov/nasa-brand-center/images-and-media/)"}
            page += 1


# ---------------------------------------------------------------------------------------------------------- Internet Archive
def _cc_name(url: Optional[str]) -> str:
    """A licence URL (creativecommons.org/…) as a name Felix's licence check reads: "CC BY-SA 4.0", "CC0 1.0" …"""
    u = (url or "").lower()
    if not u:
        return "unknown"
    if "publicdomain/zero" in u:
        return "CC0 1.0"
    if "publicdomain/mark" in u or "publicdomain" in u:
        return "Public Domain Mark 1.0"
    m = re.search(r"licenses/([a-z-]+)/(\d(?:\.\d)?)", u)
    if m:
        return f"CC {m.group(1).upper()} {m.group(2)}"
    return url


class archive_videos(_Videos):
    """Videos from the Internet Archive (archive.org, "movies"), only items that state a licence (public domain or
    Creative Commons). Its MPEG-4 versions are used. Without a query: the most downloaded licensed videos."""

    kind = "archive_videos"
    what = "most downloaded licensed videos"
    uses_vocabulary = False
    API = "https://archive.org"

    def __init__(self, query=None, limit=None, sampling=None, per_video=20, max_seconds=600, max_height=720,
                 max_mb: float = 150):
        super().__init__(query, limit, sampling, per_video, max_seconds, max_height, max_mb)

    def _videos(self):
        q = "mediatype:movies AND licenseurl:*" + (f" AND ({self.query})" if self.query else "")
        page = 1
        while True:
            d = _http.get_json(f"{self.API}/advancedsearch.php?" + urllib.parse.urlencode(
                [("q", q), ("fl[]", "identifier"), ("fl[]", "title"), ("fl[]", "creator"), ("fl[]", "licenseurl"),
                 ("sort[]", "downloads desc"), ("rows", "50"), ("page", str(page)), ("output", "json")]), interval=1.0)
            docs = (d.get("response") or {}).get("docs") or []
            if not docs:
                return
            for doc in docs:
                ident = doc.get("identifier")
                lic = _cc_name(doc.get("licenseurl"))
                from .. import licensing
                from .._session import session
                if licensing.refuse(lic, session().use):     # no need to look at its files
                    yield {"id": ident, "url": f"{self.API}/details/{ident}", "license": lic}
                    continue
                try:
                    meta = _http.get_json(f"{self.API}/metadata/{ident}", interval=0.5)
                except FelixError:
                    continue
                files = [f for f in meta.get("files") or [] if f.get("name", "").lower().endswith((".mp4", ".m4v"))
                         and int(f.get("size") or 0) <= self.max_mb * 2**20]
                if not files:
                    continue
                f = _best([dict(x, height=int(x.get("height") or 480)) for x in files], self.max_height)
                creator = doc.get("creator")
                creator = ", ".join(creator) if isinstance(creator, list) else creator
                title = doc.get("title")
                yield {"id": ident, "url": f"{self.API}/download/{ident}/{urllib.parse.quote(f['name'])}",
                       "page": f"{self.API}/details/{ident}", "title": title, "author": creator,
                       "duration": float(f["length"]) if re.fullmatch(r"[\d.]+", str(f.get("length") or "")) else None,
                       "license": lic, "license_url": doc.get("licenseurl"),
                       "attribution": f"“{title or ident}” by {creator or 'unknown'}, {lic}, via the Internet Archive"}
            page += 1
