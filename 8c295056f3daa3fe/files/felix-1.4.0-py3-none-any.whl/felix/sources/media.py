"""``fx.sources.video(path, sampling=)`` and ``fx.sources.camera(device, sampling=)``: frames from video files, webcams,
USB cameras and network streams (RTSP / HTTP), through OpenCV (``pip install opencv-python``)."""
from __future__ import annotations

import os
import time
from typing import Optional

from .. import sampling as S
from ..errors import FelixError
from ._base import Collector, Source, need_int, now


def _cv2():
    try:
        import cv2
    except ImportError:
        raise FelixError("video and camera sources need OpenCV: pip install opencv-python") from None
    return cv2


def _thumb(cv2, frame):
    """A 32 x 18 colour thumbnail: colour, because a change can keep the brightness (red on green looks grey)."""
    small = cv2.resize(frame, (32, 18), interpolation=cv2.INTER_AREA)
    return small.flatten().tolist()


def _jpeg(cv2, frame) -> bytes:
    ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
    if not ok:
        raise FelixError("could not encode a frame")
    return buf.tobytes()


class video(Source):
    """Frames of a video file, picked by ``sampling`` (default ``fx.sampling.auto()``: only when the scene changes)."""

    kind = "video"

    def __init__(self, path, sampling: Optional[S.Sampling] = None):
        self.path = os.fspath(path)
        self.sampling = sampling or S.auto()
        if not isinstance(self.sampling, S.Sampling):
            raise FelixError("sources.video: sampling must be fx.sampling.auto(), interval(seconds=) or random(count=)")

    def label(self):
        return f"video {os.path.basename(self.path)}"

    def describe(self):
        return {"type": "video", "path": os.path.abspath(self.path), **self.sampling.describe()}

    def collect(self, c: Collector, progress):
        cv2 = _cv2()
        if not os.path.isfile(self.path):
            raise FelixError(f"sources.video: {self.path} does not exist")
        cap = cv2.VideoCapture(self.path)
        if not cap.isOpened():
            raise FelixError(f"sources.video: OpenCV cannot open {self.path} (unsupported codec or damaged file)")
        fps = cap.get(cv2.CAP_PROP_FPS) or 0
        fps = fps if 1 <= fps <= 1000 else 30.0
        total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
        base = os.path.splitext(os.path.basename(self.path))[0]
        smp = self.sampling
        if isinstance(smp, S.random):
            if total <= 0:                                # some containers do not say: count the frames once
                while cap.grab():
                    total += 1
                cap.release()
                cap = cv2.VideoCapture(self.path)
            picks = set(smp.pick(max(1, total)))
        keep = smp.keeper() if isinstance(smp, S.auto) else None
        step = max(1, round(fps / smp.check_fps)) if isinstance(smp, S.auto) else 1
        next_t = smp.start if isinstance(smp, S.interval) else None
        limit = getattr(smp, "limit", None)
        idx, kept = -1, 0
        try:
            while True:
                if not cap.grab():
                    break
                idx += 1
                t = idx / fps
                take = False
                if isinstance(smp, S.random):
                    take = idx in picks
                elif isinstance(smp, S.interval):
                    take = t + 1e-9 >= next_t
                elif idx % step == 0:
                    ok, frame = cap.retrieve()
                    if not ok:
                        continue
                    take = keep(t, _thumb(cv2, frame))
                    if take:
                        self._emit(c, cv2, frame, base, idx, t, fps)
                        kept += 1
                    take = False
                if take:
                    ok, frame = cap.retrieve()
                    if ok:
                        self._emit(c, cv2, frame, base, idx, t, fps)
                        kept += 1
                    if isinstance(smp, S.interval):
                        next_t += smp.seconds
                progress(idx + 1, total or None)
                if limit is not None and kept >= limit:
                    break
        finally:
            cap.release()

    def _emit(self, c, cv2, frame, base, idx, t, fps):
        c.add(data=_jpeg(cv2, frame), ext=".jpg", name=f"{base}_f{idx:06d}.jpg",
              source={"type": "video", "license": "own recording (rights: yours to confirm)", "video": os.path.abspath(self.path), "video_filename": os.path.basename(self.path),
                      "frame": idx, "time": round(t, 3), "fps": round(fps, 3), **self.sampling.describe()})


class camera(Source):
    """Frames from a camera: ``device`` is a camera number (0 = the first webcam / USB camera) or a stream URL
    (``rtsp://…``, ``http://…/video.mjpg``). ``sampling``: ``interval(seconds=)`` (default 1 s) or ``auto()``;
    ``count`` / ``duration`` (seconds) end it, otherwise it runs until the export has enough pairs or is stopped."""

    kind = "camera"

    def __init__(self, device=0, sampling: Optional[S.Sampling] = None, count: Optional[int] = None,
                 duration: Optional[float] = None, warmup: float = 1.0):
        self.device = device
        self.sampling = sampling or S.interval(seconds=1.0)
        if isinstance(self.sampling, S.random):
            raise FelixError("sources.camera: random sampling needs the whole video in advance; use interval() or auto()")
        self.count, self.duration, self.warmup = need_int(count, "sources.camera: count"), duration, warmup

    def label(self):
        return f"camera {self.device}"

    def describe(self):
        return {"type": "camera", "device": str(self.device), **self.sampling.describe()}

    def collect(self, c: Collector, progress):
        cv2 = _cv2()
        cap = cv2.VideoCapture(self.device)
        if not cap.isOpened():
            raise FelixError(f"sources.camera: cannot open camera {self.device!r} (in use, not connected, or no permission)")
        smp = self.sampling
        keep = smp.keeper() if isinstance(smp, S.auto) else None
        t0, last, kept, fails = time.time(), None, 0, 0
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    fails += 1
                    if fails > 50:
                        raise FelixError(f"sources.camera: camera {self.device!r} stopped sending frames")
                    time.sleep(0.05)
                    continue
                fails = 0
                t = time.time() - t0
                if t < self.warmup:                       # let exposure / white balance settle
                    continue
                if self.duration is not None and t >= self.duration:
                    break
                if isinstance(smp, S.interval):
                    take = last is None or t - last >= smp.seconds
                else:
                    take = keep(t, _thumb(cv2, frame))
                if take:
                    last = t
                    c.add(data=_jpeg(cv2, frame), ext=".jpg", name=f"camera{self.device}_{kept:06d}.jpg" if isinstance(self.device, int) else f"stream_{kept:06d}.jpg",
                          source={"type": "camera", "license": "own recording (rights: yours to confirm)", "device": str(self.device), "time": now(), "seconds": round(t, 3),
                                  **smp.describe()})
                    kept += 1
                    progress(kept, self.count)
                    limit = self.count if self.count is not None else getattr(smp, "limit", None)
                    if limit is not None and kept >= limit:
                        break
        finally:
            cap.release()
