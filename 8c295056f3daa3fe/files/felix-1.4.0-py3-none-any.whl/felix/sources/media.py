"""``fx.sources.video(path, sampling=)`` and ``fx.sources.camera(device, sampling=)``: frames from video files, webcams,
USB cameras and network streams (RTSP / HTTP), through OpenCV (``pip install opencv-python``)."""
from __future__ import annotations

import os
import time
from typing import Optional

from .. import sampling as S
from ..errors import FelixError
from ._base import Collector, Source, need_int, now


def _cv2():
    try:
        import cv2
    except ImportError:
        raise FelixError("video and camera sources need OpenCV: pip install opencv-python") from None
    return cv2


def _thumb(cv2, frame):
    """A 32 x 18 colour thumbnail: colour, because a change can keep the brightness (red on green looks grey)."""
    small = cv2.resize(frame, (32, 18), interpolation=cv2.INTER_AREA)
    return small.flatten().tolist()


def _jpeg(cv2, frame) -> bytes:
    ok, buf = cv2.imencode(".jpg", frame, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
    if not ok:
        raise FelixError("could not encode a frame")
    return buf.tobytes()


def sample_file(path: str, smp: S.Sampling, emit, progress=None, cap: Optional[int] = None) -> int:
    """Go through a video file and call ``emit(frame, index, seconds, fps)`` for each frame ``smp`` keeps (at most
    ``cap``, and at most the sampling's own ``limit``). Returns how many were kept."""
    cv2 = _cv2()
    video_cap = cv2.VideoCapture(path)
    if not video_cap.isOpened():
        raise FelixError(f"OpenCV cannot open {os.path.basename(path)} (unsupported codec or damaged file)")
    fps = video_cap.get(cv2.CAP_PROP_FPS) or 0
    fps = fps if 1 <= fps <= 1000 else 30.0
    total = int(video_cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    if isinstance(smp, S.random):
        if total <= 0:                                # some containers do not say: count the frames once
            while video_cap.grab():
                total += 1
            video_cap.release()
            video_cap = cv2.VideoCapture(path)
        picks = set(smp.pick(max(1, total)))
    if cap and total > 0 and isinstance(smp, (S.auto, S.interval)):
        # a cap on frames per video: spread them over the whole video instead of taking its first seconds
        import copy
        gap = (total / fps) / cap
        if isinstance(smp, S.auto) and gap > smp.min_gap:
            smp = copy.copy(smp)
            smp.min_gap = gap
        elif isinstance(smp, S.interval) and gap > smp.seconds:
            smp = copy.copy(smp)
            smp.seconds = gap
    keep = smp.keeper() if isinstance(smp, S.auto) else None
    step = max(1, round(fps / smp.check_fps)) if isinstance(smp, S.auto) else 1
    next_t = smp.start if isinstance(smp, S.interval) else None
    limits = [x for x in (getattr(smp, "limit", None), cap) if x is not None]
    limit = min(limits) if limits else None
    idx, kept = -1, 0
    try:
        while True:
            if limit is not None and kept >= limit:
                break
            if not video_cap.grab():
                break
            idx += 1
            t = idx / fps
            take = False
            if isinstance(smp, S.random):
                take = idx in picks
            elif isinstance(smp, S.interval):
                take = t + 1e-9 >= next_t
            elif idx % step == 0:
                ok, frame = video_cap.retrieve()
                if ok and keep(t, _thumb(cv2, frame)):
                    emit(frame, idx, t, fps)
                    kept += 1
            if take:
                ok, frame = video_cap.retrieve()
                if ok:
                    emit(frame, idx, t, fps)
                    kept += 1
                if isinstance(smp, S.interval):
                    next_t += smp.seconds
            if progress is not None:
                progress(idx + 1, total or None)
    finally:
        video_cap.release()
    return kept


def _is_url(p) -> bool:
    return isinstance(p, str) and p.lower().startswith(("http://", "https://"))


def video_file(url: str, max_mb: float = 150, deadline: Optional[float] = 180) -> str:
    """A downloaded video in Felix's cache (~/.cache/felix/videos, FELIX_VIDEO_CACHE_GB, default 20; the least
    recently used go first). A re-run needs no download."""
    import hashlib
    import urllib.parse
    from .. import _http
    d = _http.cache_dir("videos")
    ext = os.path.splitext(urllib.parse.urlsplit(url).path)[1].lower()
    ext = ext if ext in (".mp4", ".webm", ".ogv", ".mov", ".mkv", ".m4v", ".avi", ".mpeg", ".mpg") else ".mp4"
    p = os.path.join(d, hashlib.sha1(url.encode("utf-8")).hexdigest() + ext)
    if os.path.isfile(p) and os.path.getsize(p) > 0:
        os.utime(p)
        return p
    _http.download(url, p, interval=0.5, max_bytes=int(max_mb * 2**20), chunk=2**18, deadline=deadline)
    limit = float(os.environ.get("FELIX_VIDEO_CACHE_GB", "20")) * 2**30
    files = sorted((e.stat().st_mtime, e.stat().st_size, e.path) for e in os.scandir(d) if e.is_file() and e.path != p)
    total = sum(f[1] for f in files) + os.path.getsize(p)
    for _, size, old in files:
        if total <= limit:
            break
        try:
            os.remove(old)
            total -= size
        except OSError:
            pass
    return p


class video(Source):
    """Frames of a video file or a video URL, picked by ``sampling`` (default ``fx.sampling.auto()``: only when the
    scene changes). ``license``: the video's licence; a local file defaults to your own recording, a URL to unknown
    (which ``fx.export``'s default ``use="commercial"`` leaves out, so say it when you know it)."""

    kind = "video"

    def __init__(self, path, sampling: Optional[S.Sampling] = None, license: Optional[str] = None,
                 attribution: Optional[str] = None):
        self.path = path if _is_url(path) else os.fspath(path)
        self.sampling = sampling or S.auto()
        self.license, self.attribution = license, attribution
        if not isinstance(self.sampling, S.Sampling):
            raise FelixError("sources.video: sampling must be fx.sampling.auto(), interval(seconds=) or random(count=)")

    def label(self):
        return f"video {os.path.basename(self.path.split('?')[0])}"

    def describe(self):
        where = self.path if _is_url(self.path) else os.path.abspath(self.path)
        return {"type": "video", "path": where, **self.sampling.describe()}

    def collect(self, c: Collector, progress):
        _cv2()
        url = self.path if _is_url(self.path) else None
        lic = self.license or ("unknown" if url else "own recording (rights: yours to confirm)")
        info = {"type": "video", "license": lic, "attribution": self.attribution}
        if url:
            info.update(url=url, video_url=url)
            if c.refused(info):                        # say why before downloading anything
                return
            path = video_file(url)
        else:
            if not os.path.isfile(self.path):
                raise FelixError(f"sources.video: {self.path} does not exist")
            path = self.path
            info.update(video=os.path.abspath(path))
        name = os.path.basename((url or path).split("?")[0])
        base = os.path.splitext(name)[0]
        info["video_filename"] = name
        cv2 = _cv2()

        def emit(frame, idx, t, fps):
            c.add(data=_jpeg(cv2, frame), ext=".jpg", name=f"{base}_f{idx:06d}.jpg",
                  source={**{k: v for k, v in info.items() if v is not None}, "frame": idx, "time": round(t, 3),
                          "fps": round(fps, 3), **self.sampling.describe()})
        try:
            sample_file(path, self.sampling, emit, progress)
        except FelixError as e:
            raise FelixError(f"sources.video: {e}") from None


class camera(Source):
    """Frames from a camera: ``device`` is a camera number (0 = the first webcam / USB camera) or a stream URL
    (``rtsp://…``, ``http://…/video.mjpg``). ``sampling``: ``interval(seconds=)`` (default 1 s) or ``auto()``;
    ``count`` / ``duration`` (seconds) end it, otherwise it runs until the export has enough pairs or is stopped."""

    kind = "camera"

    def __init__(self, device=0, sampling: Optional[S.Sampling] = None, count: Optional[int] = None,
                 duration: Optional[float] = None, warmup: float = 1.0):
        self.device = device
        self.sampling = sampling or S.interval(seconds=1.0)
        if isinstance(self.sampling, S.random):
            raise FelixError("sources.camera: random sampling needs the whole video in advance; use interval() or auto()")
        self.count, self.duration, self.warmup = need_int(count, "sources.camera: count"), duration, warmup

    def label(self):
        return f"camera {self.device}"

    def describe(self):
        return {"type": "camera", "device": str(self.device), **self.sampling.describe()}

    def collect(self, c: Collector, progress):
        cv2 = _cv2()
        cap = cv2.VideoCapture(self.device)
        if not cap.isOpened():
            raise FelixError(f"sources.camera: cannot open camera {self.device!r} (in use, not connected, or no permission)")
        smp = self.sampling
        keep = smp.keeper() if isinstance(smp, S.auto) else None
        t0, last, kept, fails = time.time(), None, 0, 0
        try:
            while True:
                ok, frame = cap.read()
                if not ok:
                    fails += 1
                    if fails > 50:
                        raise FelixError(f"sources.camera: camera {self.device!r} stopped sending frames")
                    time.sleep(0.05)
                    continue
                fails = 0
                t = time.time() - t0
                if t < self.warmup:                       # let exposure / white balance settle
                    continue
                if self.duration is not None and t >= self.duration:
                    break
                if isinstance(smp, S.interval):
                    take = last is None or t - last >= smp.seconds
                else:
                    take = keep(t, _thumb(cv2, frame))
                if take:
                    last = t
                    c.add(data=_jpeg(cv2, frame), ext=".jpg", name=f"camera{self.device}_{kept:06d}.jpg" if isinstance(self.device, int) else f"stream_{kept:06d}.jpg",
                          source={"type": "camera", "license": "own recording (rights: yours to confirm)", "device": str(self.device), "time": now(), "seconds": round(t, 3),
                                  **smp.describe()})
                    kept += 1
                    progress(kept, self.count)
                    limit = self.count if self.count is not None else getattr(smp, "limit", None)
                    if limit is not None and kept >= limit:
                        break
        finally:
            cap.release()
