"""``fx.sources.roboflow(project=, version=)``: a dataset version from Roboflow (your workspace or Roboflow Universe),
downloaded as a COCO export through Roboflow's REST API and imported with its boxes and splits."""
from __future__ import annotations

import os
import time
import urllib.parse
from pathlib import Path
from typing import Optional

from .. import _http
from ..errors import FelixError
from ._base import Collector, Source

API = "https://api.roboflow.com"


class roboflow(Source):
    """A Roboflow dataset version. ``project`` is the project's URL name; for a Universe dataset of another workspace
    write ``"workspace/project"`` or pass ``workspace=`` (without one, your API key's own workspace is used).

    Needs an API key (Roboflow: Settings → API Keys): ``api_key=``, the ROBOFLOW_API_KEY environment variable, or
    ``roboflow_api_key:`` in ~/.config/felix/credentials.yml. The export is cached in ~/.cache/felix/roboflow."""

    kind = "roboflow"

    def __init__(self, project: str, version: int, workspace: Optional[str] = None, api_key: Optional[str] = None,
                 timeout: float = 900):
        if "/" in str(project) and workspace is None:
            workspace, project = str(project).split("/", 1)
        if not project:
            raise FelixError("sources.roboflow: project is required")
        if not isinstance(version, int) or version < 1:
            raise FelixError("sources.roboflow: version must be a positive whole number (the dataset version)")
        self.project, self.version, self.workspace, self._key, self.timeout = project, version, workspace, api_key, timeout

    def label(self):
        return f"roboflow {self.workspace + '/' if self.workspace else ''}{self.project}/{self.version}"

    def describe(self):
        return {"type": "roboflow", "workspace": self.workspace, "project": self.project, "version": self.version}

    def _get(self, path, key, **params):
        q = urllib.parse.urlencode(dict(params, api_key=key))
        return _http.get_json(f"{API}/{path}?{q}", interval=0.5)

    def collect(self, c: Collector, progress):
        key = _http.credential("roboflow_api_key", self._key, "ROBOFLOW_API_KEY", "sources.roboflow")
        ws = self.workspace
        if not ws:
            ws = (self._get("", key) or {}).get("workspace")
            if not ws:
                raise FelixError("sources.roboflow: could not tell the workspace from the API key; write project='workspace/project'")
            self.workspace = ws
        folder = Path(_http.cache_dir("roboflow", ws, self.project, str(self.version)))
        zip_path = folder / "coco.zip"
        meta = {}
        try:
            meta = self._get(f"{ws}/{self.project}", key) or {}
        except FelixError:
            pass                                         # licence info is optional; the export decides success
        if not zip_path.is_file():
            t0 = time.time()
            while True:                                  # 202 + progress while Roboflow prepares the export
                d = self._get(f"{ws}/{self.project}/{self.version}/coco", key, nocache="true")
                link = (d.get("export") or {}).get("link")
                if link:
                    break
                if time.time() - t0 > self.timeout:
                    raise FelixError("sources.roboflow: the export was still being prepared after "
                                     f"{self.timeout / 60:.0f} minutes; try again later")
                progress(int(100 * float(d.get("progress") or 0)), 100)
                time.sleep(2)
            _http.download(link, str(zip_path))          # the signed link is never printed
        project = meta.get("project") or {}
        lic = project.get("license") or meta.get("license")
        src = {"type": "roboflow", "dataset": f"{ws}/{self.project}/{self.version}",
               "url": f"https://universe.roboflow.com/{ws}/{self.project}/dataset/{self.version}",
               "license": lic or "see the project page (Roboflow: no licence listed means all rights reserved)"}
        from .local import _extract, _find_coco, _import_coco
        root = _extract(zip_path)
        coco = _find_coco(root)
        if not coco:
            raise FelixError("sources.roboflow: the downloaded export has no COCO annotations")
        _import_coco(root, coco, c, progress, src)
