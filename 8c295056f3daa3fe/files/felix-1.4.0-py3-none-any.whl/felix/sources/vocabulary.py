"""What a search source asks for when it is given no query and has no "anything" feed of its own (or that feed has run
dry).

    DEFAULT   about 4,600 subjects: the Recognize Anything (RAM++) tag list merged with GENERAL. Very diverse: objects,
              animals, plants, food, places, scenes, activities, materials, weather, styles.
    RAM_PLUS  the 4,585 RAM++ tags alone (Apache-2.0, bundled: felix/vocab/ram_plus_tags.txt, see NOTICE.md there)
    GENERAL   ~150 hand-picked everyday subjects (people, animals, vehicles, places, food, objects, nature)

Choose per source: ``fx.sources.openverse().using(vocabulary="general")``, ``"ram++"``, or your own list.
"""
import os

GENERAL = [
    # people and activities
    "person", "people", "crowd", "child", "portrait", "worker", "sport", "running", "cyclist", "musician",
    # animals
    "dog", "cat", "bird", "horse", "cow", "sheep", "fish", "insect", "butterfly", "deer", "elephant", "monkey",
    "duck", "chicken", "bee", "lizard", "frog", "squirrel", "bear", "lion",
    # vehicles and transport
    "car", "bus", "truck", "bicycle", "motorcycle", "train", "boat", "ship", "airplane", "tram", "tractor",
    "traffic", "road", "bridge", "railway station", "parking lot",
    # places and buildings
    "street", "city", "house", "building", "church", "castle", "market", "shop", "kitchen", "living room",
    "office", "classroom", "library", "factory", "farm", "garden", "park", "playground", "harbour", "airport",
    # nature and landscapes
    "tree", "forest", "flower", "leaf", "grass", "mountain", "river", "lake", "beach", "sea", "desert", "snow",
    "field", "sky", "clouds", "rock", "waterfall", "island",
    # food and drink
    "food", "fruit", "vegetable", "bread", "apple", "banana", "tomato", "cake", "pizza", "coffee", "meal",
    "restaurant",
    # everyday objects
    "chair", "table", "sofa", "bed", "lamp", "door", "window", "clock", "book", "bottle", "cup", "bag", "shoe",
    "hat", "umbrella", "phone", "computer", "television", "camera", "toy", "ball", "tool", "kite", "bench",
    "sign", "traffic light", "fire hydrant", "mailbox",
    # art, culture and science
    "painting", "sculpture", "statue", "museum", "map", "poster", "machine", "engine", "microscope", "telescope",
]


def _load_ram_plus():
    p = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "vocab", "ram_plus_tags.txt")
    with open(p, encoding="utf-8") as f:
        return [t.strip() for t in f if t.strip()]


RAM_PLUS = _load_ram_plus()
DEFAULT = list(dict.fromkeys(GENERAL + RAM_PLUS))
NAMED = {"default": DEFAULT, "ram++": RAM_PLUS, "ram_plus": RAM_PLUS, "ram": RAM_PLUS, "general": GENERAL}


def resolve(vocabulary):
    """A vocabulary name ("default", "ram++", "general") or a list of words → the list."""
    if vocabulary is None:
        return DEFAULT
    if isinstance(vocabulary, str):
        if vocabulary.lower() not in NAMED:
            from ..errors import FelixError
            raise FelixError(f"vocabulary: unknown name {vocabulary!r} (use 'default', 'ram++', 'general' or a list)")
        return NAMED[vocabulary.lower()]
    return list(vocabulary)
