"""Where images come from. Pass any mix of these to ``fx.acquire([...])``.

On this computer:     local (images, folders, archives, Felix / COCO / YOLO datasets), video, camera
On the web:           urls, wikimedia, openverse, flickr, unsplash, pexels
Open collections:     inaturalist, gbif, nasa, artic, smithsonian
Dataset hubs:         roboflow, open_images, coco, huggingface, kaggle, mapillary

Every image keeps where it came from, its licence and who to credit (as far as the provider says)."""
from ._base import Source
from .collections import artic, gbif, inaturalist, nasa, openverse, smithsonian
from .datasets import coco, huggingface, kaggle, mapillary
from .local import local
from .media import camera, video
from .open_images import open_images
from .roboflow import roboflow
from .stock import flickr, pexels, unsplash
from .web import urls
from .wikimedia import wikimedia

__all__ = ["Source", "local", "video", "camera", "urls", "wikimedia", "openverse", "flickr", "unsplash", "pexels",
           "inaturalist", "gbif", "nasa", "artic", "smithsonian", "roboflow", "open_images", "coco",
           "huggingface", "kaggle", "mapillary"]
