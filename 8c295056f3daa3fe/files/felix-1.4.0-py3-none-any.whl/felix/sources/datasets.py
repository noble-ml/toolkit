"""Public dataset hubs: Hugging Face, COCO 2017, Kaggle and Mapillary street-level imagery."""
from __future__ import annotations

import base64
import json
import os
import urllib.parse
from pathlib import Path
from typing import Optional, Sequence

from .. import _http
from ..errors import FelixError
from ._base import Collector, Source, fetch, need_int


def _q(params) -> str:
    return urllib.parse.urlencode({k: v for k, v in params.items() if v is not None})


# ---------------------------------------------------------------------------------------------------------- Hugging Face
class huggingface(Source):
    """An image dataset on the Hugging Face Hub, read through the Dataset Viewer API (no download of whole files).

    The first Image column gives the pictures. A ClassLabel column (or ``label_column=``) becomes the image's class;
    an ``objects`` column with ``bbox`` and ``category`` gives boxes (``bbox_format`` "xywh", as in COCO, or "xyxy").
    Gated or private datasets need a token: ``token=``, HF_TOKEN, or ``huggingface_token:`` in the credentials file.
    Only datasets the viewer has converted to Parquet work (most public ones)."""

    kind = "huggingface"
    API = "https://datasets-server.huggingface.co"

    def __init__(self, dataset: str, split: str = "train", config: Optional[str] = None, limit: Optional[int] = None,
                 label_column: Optional[str] = None, bbox_format: str = "xywh", token: Optional[str] = None):
        if "/" not in dataset:
            raise FelixError("sources.huggingface: dataset is 'owner/name', e.g. 'AI-Lab-Makerere/beans'")
        if bbox_format not in ("xywh", "xyxy"):
            raise FelixError("sources.huggingface: bbox_format must be 'xywh' or 'xyxy'")
        self.dataset, self.split, self.config, self.limit = dataset, split, config, need_int(limit, "sources.huggingface: limit")
        self.label_column, self.bbox_format, self._token = label_column, bbox_format, token

    def label(self):
        return f"huggingface {self.dataset} ({self.split})"

    def describe(self):
        return {"type": "huggingface", "dataset": self.dataset, "split": self.split, "config": self.config}

    def collect(self, c: Collector, progress):
        token = self._token or os.environ.get("HF_TOKEN") or _http._config().get("huggingface_token")
        hdr = {"Authorization": f"Bearer {token}"} if token else None
        config = self.config
        if config is None:
            sp = _http.get_json(f"{self.API}/splits?" + _q({"dataset": self.dataset}), headers=hdr, interval=0.5)
            if sp.get("error"):
                raise FelixError(f"Hugging Face: {sp['error']}")
            configs = [s["config"] for s in sp.get("splits", []) if s["split"] == self.split]
            if not configs:
                raise FelixError(f"Hugging Face: {self.dataset} has no split {self.split!r} "
                                 f"(it has {sorted({s['split'] for s in sp.get('splits', [])})})")
            config = configs[0]
        lic = None
        try:
            info = _http.get_json(f"https://huggingface.co/api/datasets/{self.dataset}", headers=hdr, interval=0.5)
            lic = (info.get("cardData") or {}).get("license")
            if isinstance(lic, list):
                lic = ", ".join(lic)
        except FelixError:
            pass
        offset, image_col, label_col, names = 0, None, self.label_column, None
        split = {"train": "train", "validation": "val", "val": "val", "valid": "val", "test": "test"}.get(self.split)
        while self.limit is None or not c.reached(self.limit):
            d = _http.get_json(f"{self.API}/rows?" + _q({"dataset": self.dataset, "config": config, "split": self.split,
                                                       "offset": offset, "length": 100}), headers=hdr, interval=0.5)
            if d.get("error"):
                raise FelixError(f"Hugging Face: {d['error'][:300]}")
            if image_col is None:
                feats = {f["name"]: f["type"] for f in d.get("features", [])}
                image_col = next((n for n, t in feats.items() if isinstance(t, dict) and t.get("_type") == "Image"), None)
                if image_col is None:
                    raise FelixError(f"Hugging Face: {self.dataset} has no Image column")
                if label_col is None:
                    label_col = next((n for n, t in feats.items() if isinstance(t, dict) and t.get("_type") == "ClassLabel"), None)
                if label_col and isinstance(feats.get(label_col), dict):
                    names = feats[label_col].get("names")
                obj = feats.get("objects")
                self._obj_names = None
                if isinstance(obj, dict):
                    cat = (obj.get("feature") or obj).get("category") if isinstance(obj.get("feature") or obj, dict) else None
                    if isinstance(cat, dict):
                        self._obj_names = (cat.get("feature") or cat).get("names")
            rows = d.get("rows") or []
            if not rows:
                return
            for r in rows:
                if c.reached(self.limit):
                    return
                row = r.get("row") or {}
                img = row.get(image_col) or {}
                url = img.get("src") if isinstance(img, dict) else None
                if not url:
                    continue
                label, objects = None, None
                if label_col and row.get(label_col) is not None:
                    v = row[label_col]
                    label = names[v] if names and isinstance(v, int) and 0 <= v < len(names) else str(v)
                o = row.get("objects")
                if isinstance(o, dict) and "bbox" in o:
                    objects = []
                    cats = o.get("category") or o.get("label") or []
                    for k, b in enumerate(o["bbox"]):
                        cv = cats[k] if k < len(cats) else None
                        cls = self._obj_names[cv] if self._obj_names and isinstance(cv, int) and cv < len(self._obj_names) else str(cv)
                        x, y, a, bb = (float(t) for t in b[:4])
                        objects.append({"class": cls, "bbox": [x, y, a - x, bb - y] if self.bbox_format == "xyxy" else [x, y, a, bb]})
                    label = None
                fetch(c, url, f"{self.dataset.split('/')[-1]}_{r.get('row_idx')}.jpg",
                      {"type": "huggingface", "dataset": self.dataset, "config": config, "split": self.split,
                       "row": r.get("row_idx"), "page": f"https://huggingface.co/datasets/{self.dataset}",
                       "license": lic or "see the dataset card"}, interval=0.0, label=label, objects=objects, split=split)
                progress(c.count, self.limit)
            offset += len(rows)
            if offset >= int(d.get("num_rows_total") or 0):
                return


# ---------------------------------------------------------------------------------------------------------- COCO 2017
class coco(Source):
    """The COCO 2017 dataset (cocodataset.org) from its official files: ``split="val2017"`` (5k images, ~0.8 GB +
    0.25 GB annotations) or ``"train2017"`` (118k images, ~18 GB). With a class file, only images containing those
    classes are kept. Annotations are CC BY 4.0; each image keeps its own Flickr licence from the COCO metadata."""

    kind = "coco"
    BASE = "http://images.cocodataset.org"

    def __init__(self, split: str = "val2017", limit: Optional[int] = None):
        if split not in ("val2017", "train2017"):
            raise FelixError("sources.coco: split must be 'val2017' or 'train2017'")
        self.split, self.limit = split, need_int(limit, "sources.coco: limit")

    def label(self):
        return f"coco {self.split}"

    def describe(self):
        return {"type": "coco", "split": self.split}

    def collect(self, c: Collector, progress):
        import zipfile
        cache = Path(_http.cache_dir("coco"))
        ann_zip, img_zip = cache / "annotations_trainval2017.zip", cache / f"{self.split}.zip"
        for url, path in ((f"{self.BASE}/annotations/annotations_trainval2017.zip", ann_zip),
                          (f"{self.BASE}/zips/{self.split}.zip", img_zip)):
            if not path.is_file():
                from .._ui import note
                note(f"downloading {url.rsplit('/', 1)[1]} once into {cache} (large)")
                _http.download(url, str(path))
        root = cache / self.split
        if not (root / "images").is_dir():
            with zipfile.ZipFile(img_zip) as z:
                z.extractall(root)
            os.rename(root / self.split, root / "images")
        ann = root / f"instances_{self.split}.json"
        if not ann.is_file():
            with zipfile.ZipFile(ann_zip) as z:
                ann.write_bytes(z.read(f"annotations/instances_{self.split}.json"))
        from .local import _import_coco
        c.require_objects = True
        split = "train" if self.split.startswith("train") else "val"

        def limited(done, total):
            progress(done, total)
            if c.reached(self.limit):
                from ._base import Stopped
                raise Stopped()
        src = {"type": "coco", "dataset": f"COCO {self.split}", "annotation_license": "CC BY 4.0 (COCO Consortium)"}
        _import_coco(root / "images", [ann], c, limited, src)
        for it in c.items:
            it.split = it.split or split


# ---------------------------------------------------------------------------------------------------------- Kaggle
class kaggle(Source):
    """A Kaggle dataset ("owner/dataset"), downloaded as a zip and imported like a local folder (Felix, COCO, YOLO
    or plain images, detected automatically). Credentials: your Kaggle username and key (Kaggle → Settings → API →
    Create Legacy API Key, which saves ~/.kaggle/kaggle.json), or KAGGLE_USERNAME / KAGGLE_KEY. Check the dataset's
    licence on its Kaggle page: it is recorded as given there when Kaggle reports it."""

    kind = "kaggle"

    def __init__(self, dataset: str, labels: Optional[str] = None):
        if "/" not in dataset:
            raise FelixError("sources.kaggle: dataset is 'owner/dataset-name'")
        self.dataset, self.labels = dataset, labels

    def label(self):
        return f"kaggle {self.dataset}"

    def describe(self):
        return {"type": "kaggle", "dataset": self.dataset}

    def collect(self, c: Collector, progress):
        user, key = os.environ.get("KAGGLE_USERNAME"), os.environ.get("KAGGLE_KEY")
        cfg = Path.home() / ".kaggle" / "kaggle.json"
        if (not user or not key) and cfg.is_file():
            d = json.loads(cfg.read_text("utf-8"))
            user, key = d.get("username"), d.get("key")
        if not user or not key:
            raise FelixError("sources.kaggle needs Kaggle credentials: ~/.kaggle/kaggle.json (Kaggle → Settings → API) "
                             "or the KAGGLE_USERNAME and KAGGLE_KEY environment variables")
        auth = {"Authorization": "Basic " + base64.b64encode(f"{user}:{key}".encode()).decode()}
        owner, name = self.dataset.split("/", 1)
        path = Path(_http.cache_dir("kaggle", owner)) / f"{name}.zip"
        if not path.is_file():
            _http.download(f"https://www.kaggle.com/api/v1/datasets/download/{owner}/{name}", str(path), headers=auth)
        lic = None
        try:
            meta = _http.get_json(f"https://www.kaggle.com/api/v1/datasets/view/{owner}/{name}", headers=auth)
            lic = meta.get("licenseName") or ((meta.get("licenses") or [{}])[0].get("name"))
        except FelixError:
            pass
        from .local import local
        src = local(str(path), labels=self.labels)
        sub = Collector(c.name, sink=c.sink, stop=c.stop)
        sub.require_objects = c.require_objects
        # the archive's own provenance plus where it came from
        orig_add = sub.add

        def add(**kw):
            kw["source"] = dict(kw["source"], type="kaggle", dataset=self.dataset,
                                page=f"https://www.kaggle.com/datasets/{self.dataset}",
                                license=lic or kw["source"].get("license") or "see the dataset page on Kaggle")
            return orig_add(**kw)
        sub.add = add
        try:
            src.collect(sub, progress)
        finally:
            c.count += sub.count
            c.skipped += sub.skipped
            c.items += sub.items


# ---------------------------------------------------------------------------------------------------------- Mapillary
class mapillary(Source):
    """Street-level photos from Mapillary inside a small map area: ``bbox=(min_lon, min_lat, max_lon, max_lat)``,
    smaller than 0.01° on a side (Mapillary's limit). Token: a client token from mapillary.com/dashboard/developers via
    ``access_token=``, MAPILLARY_TOKEN or ``mapillary_token:`` in the credentials file. Imagery is published by
    Mapillary under CC BY-SA 4.0 (check Mapillary's terms for your use)."""

    kind = "mapillary"
    API = "https://graph.mapillary.com/images"

    def __init__(self, bbox: Sequence[float], limit: Optional[int] = None, access_token: Optional[str] = None):
        if len(bbox) != 4 or not (bbox[0] < bbox[2] and bbox[1] < bbox[3]):
            raise FelixError("sources.mapillary: bbox is (min_lon, min_lat, max_lon, max_lat)")
        if bbox[2] - bbox[0] > 0.01 or bbox[3] - bbox[1] > 0.01:
            raise FelixError("sources.mapillary: the area must be smaller than 0.01° on each side (Mapillary's limit); "
                             "use several sources for a larger area")
        self.bbox, self.limit, self._token = [float(v) for v in bbox], need_int(limit, "sources.mapillary: limit"), access_token

    def label(self):
        return f"mapillary {','.join(f'{v:.4f}' for v in self.bbox)}"

    def describe(self):
        return {"type": "mapillary", "bbox": self.bbox}

    def collect(self, c: Collector, progress):
        token = _http.credential("mapillary_token", self._token, "MAPILLARY_TOKEN", "sources.mapillary")
        d = _http.get_json(self.API + "?" + _q({"bbox": ",".join(map(str, self.bbox)), "limit": min(2000, self.limit or 2000),
                                                "fields": "id,thumb_2048_url,captured_at,creator"}),
                           headers={"Authorization": f"OAuth {token}"}, interval=0.5)
        for r in d.get("data") or []:
            if c.reached(self.limit):
                return
            url = r.get("thumb_2048_url")
            if not url:
                continue
            fetch(c, url, f"mapillary_{r['id']}.jpg",
                  {"type": "mapillary", "id": r["id"], "page": f"https://www.mapillary.com/app/?pKey={r['id']}",
                   "author": (r.get("creator") or {}).get("username"), "captured_at": r.get("captured_at"),
                   "license": "CC BY-SA 4.0 (Mapillary)"})
            progress(c.count, self.limit)
