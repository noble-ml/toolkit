"""Licences of the exported dataset: what each image's licence allows, whether the dataset's own licence fits them,
and the files that go with the dataset (LICENSE.txt, ATTRIBUTIONS.md, CITATION.cff).

This is guidance from the licence names the providers report, not legal advice."""
from __future__ import annotations

import re
from datetime import date
from typing import Dict, List, Optional

OPEN = {  # dataset licences Felix knows how to describe: spdx id -> (name, url, attribution, sharealike, noncommercial)
    "CC0-1.0": ("CC0 1.0 Universal", "https://creativecommons.org/publicdomain/zero/1.0/", False, False, False),
    "CC-BY-4.0": ("Creative Commons Attribution 4.0", "https://creativecommons.org/licenses/by/4.0/", True, False, False),
    "CC-BY-SA-4.0": ("Creative Commons Attribution-ShareAlike 4.0", "https://creativecommons.org/licenses/by-sa/4.0/", True, True, False),
    "CC-BY-NC-4.0": ("Creative Commons Attribution-NonCommercial 4.0", "https://creativecommons.org/licenses/by-nc/4.0/", True, False, True),
    "CC-BY-NC-SA-4.0": ("Creative Commons Attribution-NonCommercial-ShareAlike 4.0", "https://creativecommons.org/licenses/by-nc-sa/4.0/", True, True, True),
    "ODbL-1.0": ("Open Data Commons Open Database License 1.0", "https://opendatacommons.org/licenses/odbl/1-0/", True, True, False),
    "CDLA-Permissive-2.0": ("Community Data License Agreement – Permissive 2.0", "https://cdla.dev/permissive-2-0/", True, False, False),
}
CLOSED = ("proprietary", "closed", "all-rights-reserved", "private", "internal")


def classify(name: Optional[str]) -> Dict:
    """What a licence name allows. Keys: name, kind (free / attribution / restricted / unknown), attribution,
    sharealike, noncommercial, noderivatives, redistribute (True / False / None = unclear)."""
    n = (name or "").strip()
    low = n.lower().replace("_", " ").replace("-", " ")
    r = {"name": n or "unknown", "attribution": False, "sharealike": False, "noncommercial": False, "noderivatives": False,
         "redistribute": True, "kind": "attribution"}
    if low.startswith(("own files", "own recording")):
        return dict(r, kind="own", redistribute=None)
    if not n or low.startswith(("unknown", "see ")):
        return dict(r, kind="unknown", redistribute=None)
    if "all rights reserved" in low or low in ("arr", "copyright"):
        return dict(r, kind="restricted", redistribute=False)
    if re.search(r"\bcc ?0\b|cc zero|public ?domain|pdm|no known copyright|government work|not copyrighted", low):
        return dict(r, kind="free")
    if "unsplash license" in low or "pexels license" in low or "pixabay" in low:
        # free to use, but they forbid compiling their photos into a similar or competing service; datasets are unclear
        return dict(r, kind="restricted", redistribute=None)
    if low.startswith(("cc ", "cc by", "creative commons")) or "creativecommons.org" in low or " by " in f" {low} ":
        nc, nd, sa = " nc" in f" {low}", " nd" in f" {low}", " sa" in f" {low}"
        return dict(r, attribution=True, noncommercial=nc, noderivatives=nd, sharealike=sa,
                    kind="restricted" if nc or nd else "attribution")
    if "attribution" in low and ("license" in low or "licence" in low):    # "Attribution-NonCommercial License" (COCO)
        nc = "noncommercial" in low.replace(" ", "") or "non commercial" in low
        nd = "noderiv" in low.replace(" ", "") or "no deriv" in low
        sa = "sharealike" in low.replace(" ", "") or "share alike" in low
        return dict(r, attribution=True, noncommercial=nc, noderivatives=nd, sharealike=sa,
                    kind="restricted" if nc or nd else "attribution")
    if "gfdl" in low or "gnu free documentation" in low:
        return dict(r, attribution=True, sharealike=True)
    if re.search(r"\b(mit|apache|bsd|odc by|cdla)\b", low):
        return dict(r, attribution=True)
    return dict(r, kind="unknown", redistribute=None)


#: what a dataset is for, and so which image licences ``fx.export(use=...)`` lets in (the rest is skipped before it
#: is downloaded). "commercial" is the default because it is the safest: it fits a closed-source commercial product.
USES = {
    "commercial": "a closed-source commercial product: public domain / CC0, CC BY (credit kept), Pexels / Pixabay / "
                  "Unsplash licences and your own files; no non-commercial, no-derivatives, share-alike or unknown licences",
    "open": "an openly shared dataset: as 'commercial', plus share-alike (release it with license='auto')",
    "research": "non-commercial research: also non-commercial licences",
    "any": "no licence filter: every image is taken and its licence recorded (check them before using the dataset)",
}


def check_use(use: str) -> str:
    u = str(use or "").strip().lower()
    if u not in USES:
        from .errors import FelixError
        raise FelixError(f"export: use={use!r} is not known; use one of " + ", ".join(f"'{k}'" for k in USES)
                         + " ('commercial', the default, is the safest)")
    return u


def refuse(license_name: Optional[str], use: str) -> Optional[str]:
    """Why an image with this licence is not taken for ``use`` (None: it is)."""
    if use == "any":
        return None
    c = classify(license_name)
    if c["kind"] == "own":
        return None
    if c["kind"] == "unknown":
        return "licence unknown"
    if c["redistribute"] is False:
        return "all rights reserved"
    if use == "research":
        return None
    if c["noncommercial"]:
        return "non-commercial only"
    if c["noderivatives"]:
        return "no derivatives (crops, boxes and copies change it)"
    if use == "commercial" and c["sharealike"]:
        return "share-alike (what is built from it must be shared under the same licence)"
    return None


def resolve_dataset_license(license: Optional[str]):
    """(spdx or None, open?)  None / "proprietary" → closed; an open id (case-insensitive) → open; "auto" → decided later."""
    if license is None or str(license).lower() in CLOSED:
        return None, False
    if str(license).lower() == "auto":
        return "auto", True
    for k in OPEN:
        if k.lower() == str(license).lower().replace(" ", "-"):
            return k, True
    return str(license), True                                   # an open licence Felix does not know: taken as given


def problem(license_name: Optional[str], dataset_license: Optional[str], open_: bool, transformed: bool) -> Optional[str]:
    """Why an image with ``license_name`` does not fit the release (None if it does)."""
    c = classify(license_name)
    if c["kind"] == "own":                                  # your own photos / recordings
        return "your own files: confirm you hold the rights to publish them (and people's consent)" if open_ else None
    if c["kind"] == "unknown":
        return "licence unknown: check you may use (and, for an open dataset, share) it"
    if c["redistribute"] is False:
        return "all rights reserved"
    if c["noderivatives"] and transformed:
        return "no-derivatives licence, but the image was cropped/changed"
    if open_:
        spec = OPEN.get(dataset_license or "")
        if c["redistribute"] is None:
            return f"{c['name']}: redistributing it in a dataset may not be allowed"
        if c["noncommercial"] and spec and not spec[4]:
            return f"{c['name']} forbids commercial use, but {dataset_license} allows it"
        if c["sharealike"] and spec and not spec[3]:
            return f"{c['name']} is share-alike: the dataset would need a share-alike licence"
        if c["attribution"] and spec and not spec[2]:
            return f"{c['name']} requires attribution, which {dataset_license} does not carry"
    elif c["noncommercial"]:
        return f"{c['name']}: non-commercial use only"
    return None


def assess(images: List[Dict], dataset_license: Optional[str], open_: bool, transformed: bool):
    """Check each image's licence against how the dataset is released. ``images``: [{"id", "license", ...}].
    Returns (problems {id: reason}, summary counts, suggested open licence)."""
    problems, counts = {}, {}
    need_sa = need_by = any_nc = False
    for im in images:
        c = classify(im.get("license"))
        counts[c["name"]] = counts.get(c["name"], 0) + 1
        need_sa |= c["sharealike"]
        need_by |= c["attribution"]
        any_nc |= c["noncommercial"]
        reason = problem(im.get("license"), dataset_license, open_, transformed)
        if reason:
            problems[im["id"]] = reason
    suggest = ("CC-BY-NC-SA-4.0" if any_nc and need_sa else "CC-BY-NC-4.0" if any_nc else "CC-BY-SA-4.0" if need_sa
               else "CC-BY-4.0" if need_by else "CC0-1.0")
    return problems, counts, suggest


def license_text(title: str, dataset_license: Optional[str], open_: bool, owner: Optional[str], counts: Dict[str, int]) -> str:
    year = date.today().year
    lines = [f"{title}", ""]
    if open_:
        name, url = OPEN.get(dataset_license, (dataset_license, None))[:2]
        lines += [f"The annotations, metadata and compilation of this dataset are released under {name}"
                  + (f" ({url})." if url else "."), ""]
    else:
        lines += [f"Copyright (c) {year} {owner or 'the dataset owner'}. All rights reserved.",
                  "", "This dataset is not licensed for redistribution. Use is limited to what its owner permits.", ""]
    lines += ["The images keep their own licences, chosen by their authors; they are not changed by the licence above.",
              "Each image's licence, author and source is listed in ATTRIBUTIONS.md and in its annotation file.", "",
              "Image licences in this dataset:"]
    lines += [f"  {n}: {k} image(s)" for n, k in sorted(counts.items(), key=lambda kv: -kv[1])]
    lines += ["", "This summary is generated from the licence information the image sources report; it is not legal",
              "advice. Check the terms of each source before publishing or using the dataset commercially."]
    return "\n".join(lines) + "\n"


def attributions(rows: List[Dict], problems: Dict[str, str]) -> str:
    out = ["# Attributions", "", "Every image in this dataset, where it came from, its licence and who to credit.", "",
           "| image | source | licence | author / credit | link |", "|---|---|---|---|---|"]
    esc = lambda s: str(s or "").replace("|", "\\|").replace("\n", " ")[:300]
    for r in rows:
        link = r.get("page") or r.get("url") or r.get("path") or ""
        credit = r.get("attribution") or r.get("author") or ""
        flag = f" ⚠ {problems[r['id']]}" if r["id"] in problems else ""
        out.append(f"| {esc(r['file'])} | {esc(r.get('type'))} | {esc(r.get('license') or 'unknown')}{esc(flag)} | {esc(credit)} | {esc(link)} |")
    return "\n".join(out) + "\n"


REFERENCES = {
    "open_images": ("Open Images Dataset V7", "Kuznetsova, A. et al. The Open Images Dataset V4. IJCV 2020.",
                    "https://storage.googleapis.com/openimages/web/index.html"),
    "coco": ("Microsoft COCO: Common Objects in Context", "Lin, T.-Y. et al. ECCV 2014.", "https://cocodataset.org"),
    "wikimedia": ("Wikimedia Commons", None, "https://commons.wikimedia.org"),
    "inaturalist": ("iNaturalist", None, "https://www.inaturalist.org"),
    "gbif": ("GBIF.org occurrence data", None, "https://www.gbif.org"),
    "openverse": ("Openverse", None, "https://openverse.org"),
    "smithsonian": ("Smithsonian Open Access", None, "https://www.si.edu/openaccess"),
    "artic": ("Art Institute of Chicago", None, "https://www.artic.edu/open-access/public-api"),
    "nasa": ("NASA Image and Video Library", None, "https://images.nasa.gov"),
    "mapillary": ("Mapillary", None, "https://www.mapillary.com"),
    "wikimedia_videos": ("Wikimedia Commons", None, "https://commons.wikimedia.org"),
    "nasa_videos": ("NASA Image and Video Library", None, "https://images.nasa.gov"),
    "archive_videos": ("Internet Archive", None, "https://archive.org"),
}


def citation_cff(title: str, authors: List[str], dataset_license: Optional[str], open_: bool, version: Optional[str],
                 description: Optional[str], sources: List[Dict]) -> str:
    def q(s):
        return '"' + str(s).replace('"', "'") + '"'
    lines = ["cff-version: 1.2.0", "message: If you use this dataset, please cite it as below.", "type: dataset",
             f"title: {q(title)}", "authors:"]
    for a in authors or ["Unknown"]:
        lines.append(f"  - name: {q(a)}")
    lines.append(f"date-released: {date.today().isoformat()}")
    if version:
        lines.append(f"version: {q(version)}")
    lines.append(f"license: {q(dataset_license if open_ else 'LicenseRef-Proprietary')}")
    if description:
        lines.append(f"abstract: {q(description)}")
    refs = []
    for s in sources:
        t = s.get("type")
        if t in REFERENCES:
            name, note, url = REFERENCES[t]
            refs.append((name, note, url))
        elif t == "roboflow" and s.get("dataset"):
            refs.append((f"Roboflow dataset {s['dataset']}", None, s.get("url")))
        elif t == "huggingface" and s.get("dataset"):
            refs.append((f"Hugging Face dataset {s['dataset']}", None, f"https://huggingface.co/datasets/{s['dataset']}"))
        elif t == "kaggle" and s.get("dataset"):
            refs.append((f"Kaggle dataset {s['dataset']}", None, f"https://www.kaggle.com/datasets/{s['dataset']}"))
    if refs:
        lines.append("references:")
        for name, note, url in dict.fromkeys(refs):
            lines += ["  - type: dataset", f"    title: {q(name)}", "    authors:", f"      - name: {q(name.split(':')[0])}"]
            if url:
                lines.append(f"    url: {q(url)}")
            if note:
                lines.append(f"    notes: {q(note)}")
    return "\n".join(lines) + "\n"
