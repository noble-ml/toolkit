"""Which frames of a video (or camera) to keep: ``fx.sampling.auto()``, ``interval(seconds=)``, ``random(count=, seed=)``."""
from __future__ import annotations

import random as _random
from typing import Optional

from .errors import FelixError


class Sampling:
    kind = ""

    def describe(self) -> dict:
        return {"sampling": self.kind, **{k: v for k, v in vars(self).items() if v is not None}}


class auto(Sampling):
    """Keep a frame when the scene has changed enough since the last kept frame.

    Frames are looked at ``check_fps`` times per second as small colour thumbnails; a frame is kept when its mean
    absolute difference from the last kept one is at least ``threshold`` (0–1 of the brightness range, default 4%) and at least
    ``min_gap`` seconds have passed, so a still scene gives one frame, not hundreds. ``max_gap`` (seconds) forces a
    frame now and then even without change; ``limit`` caps the number of frames."""

    kind = "auto"

    def __init__(self, threshold: float = 0.04, min_gap: float = 0.5, max_gap: Optional[float] = None,
                 check_fps: float = 4.0, limit: Optional[int] = None):
        if not 0 < threshold < 1:
            raise FelixError("sampling.auto: threshold must be between 0 and 1 (0.04 = 4% of the brightness range)")
        if min_gap < 0 or check_fps <= 0 or (max_gap is not None and max_gap <= 0):
            raise FelixError("sampling.auto: min_gap must be >= 0, check_fps and max_gap > 0")
        self.threshold, self.min_gap, self.max_gap, self.check_fps, self.limit = threshold, min_gap, max_gap, check_fps, limit

    def keeper(self):
        """A function (time, thumbnail) -> bool that decides frame by frame."""
        state = {"thumb": None, "t": None}

        def keep(t, thumb) -> bool:
            last = state["thumb"]
            if last is None:
                ok = True
            else:
                dt = t - state["t"]
                diff = sum(abs(a - b) for a, b in zip(thumb, last)) / (255.0 * len(thumb))
                ok = dt >= self.min_gap and (diff >= self.threshold or (self.max_gap is not None and dt >= self.max_gap))
            if ok:
                state["thumb"], state["t"] = thumb, t
            return ok
        return keep


class interval(Sampling):
    """One frame every ``seconds`` seconds (the first at ``start`` seconds)."""

    kind = "interval"

    def __init__(self, seconds: float, start: float = 0.0, limit: Optional[int] = None):
        if not seconds or seconds <= 0:
            raise FelixError("sampling.interval: seconds must be positive")
        self.seconds, self.start, self.limit = float(seconds), float(start), limit


class random(Sampling):
    """``count`` frames picked at random over the whole video, reproducibly with ``seed``. Not for live cameras."""

    kind = "random"

    def __init__(self, count: int, seed: int = 0):
        if not isinstance(count, int) or count < 1:
            raise FelixError("sampling.random: count must be a positive whole number")
        self.count, self.seed = count, seed

    def pick(self, total_frames: int):
        n = min(self.count, total_frames)
        return sorted(_random.Random(self.seed).sample(range(total_frames), n))
