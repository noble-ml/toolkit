Bundled weights (used before any download): yolo26n.pt (YOLO26 nano), yoloe-26s-seg.pt (YOLOE-26 small, text
prompts) and yoloe-11s-seg-pf.pt (YOLOE-11 small, prompt-free; YOLOE-26's prompt-free weights give nonsense under
current Ultralytics). Fetched with Ultralytics' downloader (attempt_download_asset).
They are Ultralytics models: AGPL-3.0 unless you hold an Ultralytics Enterprise licence.
