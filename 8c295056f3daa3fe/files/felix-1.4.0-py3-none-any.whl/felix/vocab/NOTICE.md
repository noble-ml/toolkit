`ram_plus_tags.txt` is the tag list of Recognize Anything (RAM / RAM++), https://github.com/xinyu1205/recognize-anything
(`ram/data/ram_tag_list.txt`), Copyright the Recognize Anything authors, licensed under the Apache License 2.0
(https://www.apache.org/licenses/LICENSE-2.0). Felix uses it unchanged as a search vocabulary.

Zhang et al., "Recognize Anything: A Strong Image Tagging Model" (2023); Huang et al., "Open-Set Image Tagging with
Multi-Grained Text Supervision" (RAM++, 2023).
