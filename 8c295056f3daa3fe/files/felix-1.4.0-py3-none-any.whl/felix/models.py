"""``fx.models``: ready-made annotation models, run through Ultralytics (``pip install ultralytics``).

    fx.models.yolo26n          YOLO26 nano detector: the 80 COCO classes (closed set)
    fx.models.yolo26s          YOLO26 small (more accurate, slower);  also yolo26m / yolo26l / yolo26x
    fx.models.yoloe            YOLOE-26 small: open vocabulary. Finds the classes of classes.yml by their prompts;
                               without a class file it uses the prompt-free model (about 4,600 classes)
    fx.models.sam              SAM 2.1 base: turns existing boxes into segmentation masks (needs boxes first)

Your own Workflow model is used directly: ``fx.annotate(model=wf.load("model.nbm"))``.

Bundled in the package (felix/model_weights/): yolo26n.pt, yoloe-26s-seg.pt and the prompt-free yoloe-11s-seg-pf.pt.
(YOLOE-26's own prompt-free weights give nonsense under current Ultralytics, every box at confidence 1.0, so the
prompt-free mode uses YOLOE-11's, which reads scenes correctly.)
Other weights are downloaded once by Ultralytics into ~/.cache/felix/models. YOLOE's text prompts also need
Ultralytics' CLIP text encoder (~254 MB, too large to bundle), which it downloads into the same cache on first use. Ultralytics code and weights are AGPL-3.0 (or an Ultralytics Enterprise licence): check that this fits how
you distribute your work.
"""
from __future__ import annotations

import os
from typing import List, Optional

from . import _http
from . import _use
from .errors import FelixError

PACKAGED = os.path.join(os.path.dirname(os.path.abspath(__file__)), "model_weights")


def _ultralytics():
    try:
        import ultralytics
    except ImportError:
        raise FelixError("built-in models run through Ultralytics: pip install ultralytics "
                         "(or annotate with your own Workflow model: fx.annotate(model=wf.load(...)))") from None
    return ultralytics


class _InCache:
    """Run with the model cache as the working folder: Ultralytics downloads what it needs (weights, YOLOE's CLIP text
    encoder) next to where it runs, which should be Felix's cache, not the user's project folder."""

    def __enter__(self):
        self.cwd = os.getcwd()
        os.chdir(_http.cache_dir("models"))

    def __exit__(self, *exc):
        os.chdir(self.cwd)


def weights_path(name: str) -> str:
    """Where ``name`` is (or will be downloaded to)."""
    for d in (PACKAGED, _http.cache_dir("models")):
        p = os.path.join(d, name)
        if os.path.isfile(p):
            return p
    return os.path.join(_http.cache_dir("models"), name)


def _prompt_free(weights: str) -> str:
    """The prompt-free weights for a YOLOE model: the YOLOE-11 ones of the same size for YOLOE-26 (see above)."""
    import re
    m = re.match(r"yoloe-(?:26|11)([nsmlx])-seg\.pt$", os.path.basename(weights))
    return f"yoloe-11{m.group(1) if m.group(1) != 'n' else 's'}-seg-pf.pt" if m else weights.replace("-seg.pt", "-seg-pf.pt")


def _merge_same_class(objs, iou_threshold: float = 0.6):
    """Keep the most confident of boxes of the same class that overlap by more than ``iou_threshold``."""
    from ._images import iou
    kept = []
    for o in sorted(objs, key=lambda o: -o.get("confidence", 0)):
        if not any(k["class"] == o["class"] and iou(k["bbox"], o["bbox"]) > iou_threshold for k in kept):
            kept.append(o)
    return kept


class Model:
    """A built-in model (loaded on first use). Call it to pick other weights: ``fx.models.yolo26n("yolo26s.pt")``.

    ``default_confidence``: the minimum score used when neither ``fx.annotate(confidence=)`` nor classes.yml sets one.
    Open-vocabulary (prompted) scores run lower than a closed-set detector's, so YOLOE uses 0.1."""

    def __init__(self, name: str, weights: str, kind: str, about: str, device: Optional[str] = None, imgsz: int = 640):
        self.name, self.weights, self.kind, self.about, self.device, self.imgsz = name, weights, kind, about, device, imgsz
        self.default_confidence = 0.1 if kind == "yoloe" else 0.25
        self._net = None
        self._prompted = None

    def __call__(self, weights: Optional[str] = None, device: Optional[str] = None, imgsz: Optional[int] = None):
        """Other weights (e.g. "yolo26s.pt"), a device ("cpu", "cuda", "mps", "0"; default: Ultralytics picks) or an
        inference size."""
        return Model(self.name, weights or self.weights, self.kind, self.about, device or self.device, imgsz or self.imgsz)

    def __repr__(self):
        return f"fx.models.{self.name} ({self.weights}: {self.about})"

    def describe(self) -> dict:
        u = None
        try:
            import ultralytics
            u = ultralytics.__version__
        except ImportError:
            pass
        return {"name": self.name, "weights": self.weights, "framework": f"ultralytics {u}" if u else "ultralytics",
                "kind": self.kind}

    def _load(self, weights=None):
        ul = _ultralytics()
        path = weights_path(weights or self.weights)          # bundled, cached, or downloaded into the cache
        with _InCache():
            if self.kind == "sam":
                return ul.SAM(path)
            if self.kind == "yoloe":
                return ul.YOLOE(path)
            return ul.YOLO(path)

    # ---- detection / open-vocabulary detection
    def detect(self, images, conf: float, classes: Optional[List[dict]]):
        """Per image: [{"class", "bbox" [x, y, w, h], "confidence", "segmentation"?}] in pixels."""
        if self.kind == "yoloe":
            prompts = [p for c in classes for p in (c.get("prompts") or [c["prompt"]])] if classes else None
            if self._net is None or self._prompted != prompts:
                self._net = self._load(self.weights if prompts else _prompt_free(self.weights))
                if prompts:
                    with _InCache():                         # the first prompt downloads the text encoder (~254 MB)
                        try:
                            self._net.set_classes(prompts)
                        except TypeError:                    # older Ultralytics: the text embeddings must be passed
                            self._net.set_classes(prompts, self._net.get_text_pe(prompts))
                self._prompted = prompts
            names_by_prompt = {p: c["name"] for c in classes for p in (c.get("prompts") or [c["prompt"]])} if classes else None
            ids = None
        else:
            if self._net is None:
                self._net = self._load()
            names_by_prompt = None
            known = {v.lower(): k for k, v in self._net.names.items()}
            ids = None
            if classes:                                      # closed set: only ask for the configured classes it has
                ids = sorted({known[n.lower()] for c in classes for n in [c["name"]] + c.get("aliases", []) if n.lower() in known})
                if not ids:
                    raise FelixError(f"{self.name} does not detect any of the classes in classes.yml "
                                     f"(it knows: {', '.join(list(self._net.names.values())[:20])}, …); use fx.models.yoloe "
                                     "for other classes, or add aliases with its class names")
        out = []
        for im in images:                                    # one image at a time: the documented input form
            dev = _use.resolve(self.device)[0]
            extra = {"device": dev} if dev else {}
            if self.kind == "yoloe":
                extra["agnostic_nms"] = False                 # YOLOE's default would let one prompt hide another's box
            r = self._net.predict(im, conf=conf, classes=ids, verbose=False, imgsz=self.imgsz, **extra)[0]
            objs = []
            boxes = r.boxes
            polys = r.masks.xy if getattr(r, "masks", None) is not None else None
            for k in range(len(boxes)):
                x1, y1, x2, y2 = (float(v) for v in boxes.xyxy[k].tolist())
                name = r.names[int(boxes.cls[k])]
                if names_by_prompt:
                    name = names_by_prompt.get(name, name)
                o = {"class": name, "bbox": [x1, y1, x2 - x1, y2 - y1], "confidence": round(float(boxes.conf[k]), 4)}
                if polys is not None and k < len(polys) and len(polys[k]) >= 3:
                    o["segmentation"] = [[round(float(v), 2) for p in polys[k] for v in p]]
                objs.append(o)
            if names_by_prompt and len(names_by_prompt) > len(set(names_by_prompt.values())):
                objs = _merge_same_class(objs)               # two prompts of one class boxing the same object
            out.append(objs)
        return out

    # ---- SAM: boxes → masks
    def segment(self, image, objects):
        if self._net is None:
            self._net = self._load()
        if not objects:
            return objects
        boxes = [[o["bbox"][0], o["bbox"][1], o["bbox"][0] + o["bbox"][2], o["bbox"][1] + o["bbox"][3]] for o in objects]
        dev = _use.resolve(self.device)[0]
        r = self._net(image, bboxes=boxes, verbose=False, **({"device": dev} if dev else {}))[0]
        polys = r.masks.xy if getattr(r, "masks", None) is not None else []
        out = []
        for k, o in enumerate(objects):
            n = dict(o)
            if k < len(polys) and len(polys[k]) >= 3:
                n["segmentation"] = [[round(float(v), 2) for p in polys[k] for v in p]]
            out.append(n)
        return out


yolo26n = Model("yolo26n", "yolo26n.pt", "detect", "YOLO26 nano, 80 COCO classes")
yolo26s = Model("yolo26s", "yolo26s.pt", "detect", "YOLO26 small, 80 COCO classes")
yolo26m = Model("yolo26m", "yolo26m.pt", "detect", "YOLO26 medium, 80 COCO classes")
yolo26l = Model("yolo26l", "yolo26l.pt", "detect", "YOLO26 large, 80 COCO classes")
yolo26x = Model("yolo26x", "yolo26x.pt", "detect", "YOLO26 extra large, 80 COCO classes")
yolo26n_seg = Model("yolo26n_seg", "yolo26n-seg.pt", "detect", "YOLO26 nano with masks, 80 COCO classes")
yoloe = Model("yoloe", "yoloe-26s-seg.pt", "yoloe", "YOLOE-26 small, open vocabulary with masks")
sam = Model("sam", "sam2.1_b.pt", "sam", "SAM 2.1 base: masks for existing boxes")

__all__ = ["yolo26n", "yolo26s", "yolo26m", "yolo26l", "yolo26x", "yolo26n_seg", "yoloe", "sam", "Model", "weights_path"]
