"""``felix library``: every Felix call, source, transform, model and command, with the cookbook's explanations, in a
searchable browser. Entries come from the docs shipped in the package and from the code (signatures, docstrings)."""
from __future__ import annotations

import os
import re
from typing import Dict, List

from . import _tui
from ._tui import Entry, key, plain, ticks
from ._version import __version__

_HERE = os.path.dirname(os.path.abspath(__file__))
GROUPS = ("Pipeline", "Sources", "Sampling", "Transforms", "Models", "Datasets", "Commands", "Guides")


def _read(name: str) -> str:
    for path in (os.path.join(_HERE, "docs", name), os.path.join(_HERE, "..", "..", "docs", name)):
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                return f.read()
    return ""


def _obj(name: str):
    import felix
    m = re.fullmatch(r"(?:fx|felix)\.([\w.]+)", name)
    if not m:
        return None
    obj = felix
    for part in m.group(1).split("."):
        obj = getattr(obj, part, None)
        if obj is None:
            return None
    return obj


def _sections(md: str, level: str):
    parts = re.split(rf"^({level} .+)$", md, flags=re.M)
    return [(parts[i][len(level) + 1:].strip(), parts[i + 1].strip()) for i in range(1, len(parts) - 1, 2)]


def _first(md: str) -> str:
    t = plain(re.split(r"\n\s*\n|```|\n\|", md.strip())[0])
    return t.split(". ")[0].rstrip(".") if len(t) > 110 else t


def _sig(head: str):
    """`fx.sources.local(path, recursive=True)` → ("fx.sources.local", "path, recursive=True")."""
    t = (ticks(head) or [head])[0]
    m = re.match(r"([\w.]+)\((.*)\)", t)
    return (m.group(1), m.group(2)) if m else (t.split("(")[0], "")


def load() -> List[Entry]:
    entries: List[Entry] = []

    def add(e: Entry, ref: str = ""):
        if ref:
            e.add(ref, "Reference")
        entries.append(e)
        return e

    # ---- API page: the pipeline calls, transforms (table rows), dataset utilities (bullets)
    for head, body in _sections(_read("api.md"), "##"):
        if head.startswith("`fx.transform`"):
            for line in body.splitlines():
                if line.startswith("| `"):
                    cells = [c.strip() for c in line.strip().strip("|").split(" | ")]
                    for t in ticks(cells[0])[:1]:
                        name, args = _sig(f"`fx.transform.{t}`")
                        add(Entry(name, "Transforms", plain(cells[1]), args, obj=_obj(name)), cells[1])
            add(Entry("fx.transform", "Transforms", _first(body), obj=None), body)
            continue
        if head.startswith("`fx.sampling`"):
            for t in ticks(body):
                if re.match(r"\w+\(", t):
                    name, args = _sig(f"`fx.sampling.{t}`")
                    add(Entry(name, "Sampling", "", args, obj=_obj(name)), body)
            continue
        if head.startswith("Reading and managing"):
            for line in body.splitlines():
                if line.startswith("- `"):
                    name, args = _sig(line[2:])
                    add(Entry(name, "Datasets", _first(line.split(":", 1)[-1]), args, obj=_obj(name)), line[2:])
            continue
        if head.startswith("`fx."):
            name, args = _sig(head)
            add(Entry(name, "Pipeline", _first(body), args, obj=_obj(name)), body)
            if name == "fx.annotate":
                for t in sorted(set(re.findall(r"fx\.models\.\w+", body))):
                    add(Entry(t, "Models", getattr(_obj(t), "about", ""), obj=None))
        elif head == "Errors":
            add(Entry("fx.FelixError", "Guides", _first(body), obj=_obj("fx.FelixError")), body)

    # ---- sources page
    group = None
    for head, body in _sections(_read("sources.md"), "##"):
        subs = _sections(body, "###")
        for sh, sb in subs:
            names = [t for t in ticks(sh) if t.startswith("fx.sources.")]
            if head == "Sampling" or not names:
                continue
            for t in names:
                name, args = _sig(f"`{t}`")
                add(Entry(name, "Sources", _first(sb), args, obj=_obj(name)), sb)
        if head == "Sampling":
            for line in body.splitlines():
                for t in ticks(line):
                    if t.startswith("fx.sampling.") and not any(e.name == _sig(f"`{t}`")[0] for e in entries):
                        name, args = _sig(f"`{t}`")
                        add(Entry(name, "Sampling", _first(line.split(":", 1)[-1]), args, obj=_obj(name)), line)
        if head == "Credentials":
            add(Entry("Credentials", "Guides", "API keys for online sources: arguments, environment, credentials file"), body)

    # ---- commands
    cli = _read("cli.md")
    block = re.search(r"```\n(.*?)\n```", cli, re.S)
    cmd_sections = _sections(cli, "##")
    for line in (block.group(1).splitlines() if block else []):
        m = re.match(r"(felix \w+)\s+(.*?)\s{2,}(.+)$", line)
        if not m:
            continue
        name, args, what = m.groups()
        e = Entry(name, "Commands", what, args, keys=[name])
        word = name.split()[1]
        for head, body in cmd_sections:
            if f"`felix {word}`" in head:
                e.add(body, "Reference")
        entries.append(e)

    # ---- guides
    for page, title in (("getting-started.md", "Getting started"), ("licensing.md", "Licences"), ("formats.md", "Formats")):
        text = _read(page)
        for head, body in _sections(text, "##"):
            add(Entry(f"{title}: {plain(head)}", "Guides", _first(body), keys=[f"{title}: {head}".lower()]), body)

    # ---- the cookbook's Felix part: toddler words first
    by_key: Dict[str, List[Entry]] = {}
    for e in entries:
        for k in e.keys:
            by_key.setdefault(k, []).append(e)
    cook = []
    by_name = {e.name.lower(): e for e in entries}
    for head, body in _tui.cookbook_sections(_read("cookbook.md")):
        names, prefix = [], ""
        for n in ticks(head):                            # `fx.transform.map_classes`, `filter_classes` → full names
            n = n.split("(")[0]
            if "." in n or n.startswith("felix "):
                prefix = n.rsplit(".", 1)[0] + "." if "." in n else ""
            elif prefix:
                n = prefix + n
            names.append(n)
        title = re.sub(r"^#+\s*", "", head).strip()
        if not names and title.lower() in by_name:       # e.g. "### Credentials": the reference entry of that name
            e = by_name[title.lower()]
            e.sections.insert(0, (None, body))
            e.what = _tui.eli5(body)
            continue
        if not names:                                    # recipes and topic sections: their own guide entries
            if not title.startswith("Part "):
                cook.append(Entry(f"Cookbook: {plain(title)}", "Guides", _tui.eli5(body) if "Toddler" in body else _first(body),
                                  keys=[f"cookbook: {title}".lower()]))
                cook[-1].add(body, "Cookbook")
            continue
        hits = []
        for n in names:
            k = key(n)
            hits += by_key.get(k, [])
            if k.endswith(".*"):
                hits += [e for e in entries if e.name.startswith(k[:-1])]
            if k == "fx.sources.*" or "sources" in k:
                hits += [e for e in entries if e.group == "Sources" and "acquire" in head]
        for e in dict.fromkeys(hits):
            e.sections.insert(0, (None, body))
            if "Toddler words" in body:                  # the plain-words line is the summary everywhere
                e.what = _tui.eli5(body)
            elif not e.what or len(e.what) < 20:
                e.what = _tui.eli5(body)
    entries += cook
    order = {g: i for i, g in enumerate(GROUPS)}
    entries.sort(key=lambda e: order.get(e.group, len(GROUPS)))
    return entries


def run(query: str = "") -> int:
    return _tui.run(load(), "felix", __version__, "fx.", query)
