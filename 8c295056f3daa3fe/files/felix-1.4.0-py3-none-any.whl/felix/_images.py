"""Pillow helpers shared by sources, transforms, annotation and export: reading, saving, and moving annotations
through crops, resizes and padding."""
from __future__ import annotations

import io
import os
from typing import List, Optional, Sequence, Tuple

from .errors import FelixError

IMAGE_EXT = (".jpg", ".jpeg", ".png", ".bmp", ".webp", ".gif", ".tif", ".tiff")
KEEP_EXT = (".jpg", ".jpeg", ".png", ".webp")          # exported as they are; anything else becomes PNG


def pil():
    try:
        from PIL import Image
    except ImportError:                                  # Pillow is a dependency; this only happens in broken installs
        raise FelixError("Felix needs Pillow to read images: pip install Pillow") from None
    return Image


def is_image_name(name: str) -> bool:
    base = os.path.basename(name)
    return base.lower().endswith(IMAGE_EXT) and not base.startswith(".")


def probe(path_or_bytes) -> Tuple[int, int, int]:
    """(width, height, EXIF orientation) of an image without decoding all of it; raises FelixError if unreadable."""
    Image = pil()
    try:
        src = (lambda: io.BytesIO(path_or_bytes)) if isinstance(path_or_bytes, (bytes, bytearray)) else (lambda: path_or_bytes)
        with Image.open(src()) as im:
            im.verify()                                    # integrity check: must come first after opening
        with Image.open(src()) as im:
            w, h = im.size
            try:
                o = im.getexif().get(0x0112, 1)
            except Exception:
                o = 1
        return w, h, int(o or 1)
    except Exception as e:
        raise FelixError(f"not a readable image ({type(e).__name__}: {e})") from None


def open_rgb(path: str):
    Image = pil()
    im = Image.open(path)
    im.load()
    return im.convert("RGB") if im.mode != "RGB" else im


def upright(path: str):
    """The image with its EXIF rotation applied (cameras store portrait photos sideways)."""
    from PIL import ImageOps
    return ImageOps.exif_transpose(open_rgb_keep(path))


def open_rgb_keep(path: str):
    Image = pil()
    im = Image.open(path)
    im.load()
    return im


def save(im, path: str) -> None:
    ext = os.path.splitext(path)[1].lower()
    if ext in (".jpg", ".jpeg"):
        im.convert("RGB").save(path, quality=95, subsampling=0)
    elif ext == ".webp":
        im.save(path, quality=95)
    else:
        im.save(path)


def out_ext(ext: str) -> str:
    """Extension for a re-encoded image: photos stay JPEG, everything else PNG."""
    return ".jpg" if ext.lower() in (".jpg", ".jpeg") else ".png"


# ---------------------------------------------------------------------------------------------------------- geometry
def clip_box(b, W, H):
    """[x, y, w, h] clipped to the image; None if nothing is left."""
    x1, y1 = max(0.0, b[0]), max(0.0, b[1])
    x2, y2 = min(float(W), b[0] + b[2]), min(float(H), b[1] + b[3])
    if x2 - x1 < 1 or y2 - y1 < 1:
        return None
    return [x1, y1, x2 - x1, y2 - y1]


def clip_polygon(pts: Sequence[float], W: float, H: float) -> List[float]:
    """Sutherland–Hodgman clipping of a flat [x, y, x, y, ...] polygon to the rectangle [0, W] x [0, H]."""
    poly = [(pts[i], pts[i + 1]) for i in range(0, len(pts) - 1, 2)]
    for edge in range(4):
        inside = [lambda p: p[0] >= 0, lambda p: p[0] <= W, lambda p: p[1] >= 0, lambda p: p[1] <= H][edge]

        def cross(a, b, e=edge):
            (x1, y1), (x2, y2) = a, b
            if e < 2:
                xe = 0.0 if e == 0 else W
                t = (xe - x1) / (x2 - x1) if x2 != x1 else 0.0
                return (xe, y1 + t * (y2 - y1))
            ye = 0.0 if e == 2 else H
            t = (ye - y1) / (y2 - y1) if y2 != y1 else 0.0
            return (x1 + t * (x2 - x1), ye)
        out = []
        for i, cur in enumerate(poly):
            prev = poly[i - 1]
            if inside(cur):
                if not inside(prev):
                    out.append(cross(prev, cur))
                out.append(cur)
            elif inside(prev):
                out.append(cross(prev, cur))
        poly = out
        if not poly:
            return []
    return [round(v, 2) for p in poly for v in p]


def remap_objects(objects, crop: Tuple[float, float, float, float], scale: Tuple[float, float],
                  pad: Tuple[float, float], out_size: Tuple[int, int], min_visibility: float = 0.3):
    """Move annotations through: crop to ``crop`` = (x, y, w, h) of the source, scale by ``scale`` = (sx, sy), then
    offset by ``pad`` = (px, py) inside an ``out_size`` = (W, H) image. Boxes keeping less than ``min_visibility`` of
    their area are dropped. Returns (objects, dropped count)."""
    cx, cy, cw, ch = crop
    sx, sy = scale
    px, py = pad
    W, H = out_size
    kept, dropped = [], 0
    for o in objects:
        x, y, w, h = o["bbox"]
        vis = clip_box([x - cx, y - cy, w, h], cw, ch)
        if vis is None or (vis[2] * vis[3]) < min_visibility * max(1e-9, w * h):
            dropped += 1
            continue
        nb = [vis[0] * sx + px, vis[1] * sy + py, vis[2] * sx, vis[3] * sy]
        nb = clip_box(nb, W, H)
        if nb is None:
            dropped += 1
            continue
        n = dict(o, bbox=[round(v, 2) for v in nb])
        if o.get("segmentation"):
            segs = []
            for poly in o["segmentation"]:
                c = clip_polygon([v - (cx if i % 2 == 0 else cy) for i, v in enumerate(poly)], cw, ch)
                if len(c) >= 6:
                    segs.append([round(v * (sx if i % 2 == 0 else sy) + (px if i % 2 == 0 else py), 2) for i, v in enumerate(c)])
            if segs:
                n["segmentation"] = segs
            else:
                n.pop("segmentation", None)
        kept.append(n)
    return kept, dropped


def iou(a, b) -> float:
    """IoU of two [x, y, w, h] boxes."""
    ix = max(0.0, min(a[0] + a[2], b[0] + b[2]) - max(a[0], b[0]))
    iy = max(0.0, min(a[1] + a[3], b[1] + b[3]) - max(a[1], b[1]))
    inter = ix * iy
    return inter / max(1e-9, a[2] * a[3] + b[2] * b[3] - inter)


def intersects(a, b) -> bool:
    return min(a[0] + a[2], b[0] + b[2]) > max(a[0], b[0]) and min(a[1] + a[3], b[1] + b[3]) > max(a[1], b[1])


def fraction_inside(box, region) -> float:
    """How much of ``box`` lies inside ``region`` (both [x, y, w, h])."""
    ix = max(0.0, min(box[0] + box[2], region[0] + region[2]) - max(box[0], region[0]))
    iy = max(0.0, min(box[1] + box[3], region[1] + region[3]) - max(box[1], region[1]))
    return ix * iy / max(1e-9, box[2] * box[3])


def num(v):
    v = round(float(v), 2)
    return int(v) if v.is_integer() else v
