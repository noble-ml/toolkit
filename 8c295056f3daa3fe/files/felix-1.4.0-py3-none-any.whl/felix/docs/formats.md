# Dataset formats

## Folder

**Toddler words:** the dataset spread out in a folder: pictures in one drawer, their notes in another.

```
dataset/
├── images/IMG1.png ...        (JPEG, PNG or WebP, kept as they were)
├── annotations/IMG1.yml ...
└── metadata.yml
```

## Shards: a folder of `.sh_felix` files

**Toddler words:** a huge dataset split into many small boxes, so you only carry one at a time.

For datasets too big for one file, a folder holds many shards:

```
voc_shards/
├── voc_shards-00000.sh_felix
├── voc_shards-00001.sh_felix
└── …
```

Each shard is a complete dataset of its own (a zip like `.felix`: `images/`, `annotations/`, its own `metadata.yml`
with `shard: {index, of, dataset}`), plus `index.tsv` (stem, split and class id per line, so a folder of thousands of
shards loads without reading every annotation). `fx.load("voc_shards/")` reads the folder as one dataset; a single
shard also loads on its own. Shards open on demand, at most 64 at a time, and reads are thread-safe.

Make them with `felix shard` / `fx.shard(...)` from any dataset, or straight from generation with
`fx.export("name.sh_felix")`. Splits are the same as the unsharded dataset's. `felix pack voc_shards/ -o voc.felix`
puts them back into one file. All shards in a folder must come from the same dataset (same classes, no file in two
shards); Felix says which shard breaks that.

## Class folders (classification)

**Toddler words:** one folder per kind of thing: every picture in `cat/` is a cat.

An ImageNet-style folder is a dataset as it is: one folder per class with its images, optionally inside `train/`,
`val/` and `test/` (also `valid`, `validation`, `training`, `testing`).

```
animals/                      animals/
├── cat/001.jpg …             ├── train/cat/… dog/…
├── dog/…                     ├── val/cat/… dog/…
└── bird/…                    └── test/cat/… dog/…
```

`fx.load("animals/")` reads it without writing anything next to the images: the class names are the folder names (in
natural order, ids follow), each image is one pair, and its annotation is made up on the fly:

```yaml
image: cat/001.jpg
split: train
class: cat
class_id: 1
```

with `metadata.yml` holding `task: classification`, the classes and the split counts. Without split folders every class
is split 80 / 10 / 10 on its own (stratified, seed 0, the same every time). PNG, JPEG, BMP, WebP, GIF and TIFF are
read; hidden files and folders (`.` or `_` first) are skipped. `felix pack` turns it into a regular `.felix` file with
those annotations, and `felix info`, `split` and `partition` work on both.

## `.felix`

**Toddler words:** the whole folder zipped into one file, easy to copy and share.

```bash
felix pack ./leaves -o leaves.felix     # folder → one file
felix unpack leaves.felix -o ./leaves   # and back
unzip -l leaves.felix | head            # it's a normal zip
```

A single file for the same tree - a standard ZIP archive (PNG/JPEG stored, YAML deflated),
so `unzip` and Python's `zipfile` can open it. `felix pack` / `felix unpack` convert between
the two; `fx.export("x.felix")` writes it directly (via a `.part` file, so a crash never
leaves a half-written dataset).

## `annotations/<name>.yml`

**Toddler words:** the note next to each picture: what's in it, where the boxes are, and where the picture came from.

```yaml
image: leaf_0001.jpg
width: 640
height: 640
split: train                     # train / val / test
objects:
  - class: leaf
    class_id: 0
    bbox: [316, 163, 62, 62]     # x, y, width, height in pixels, top-left origin
    confidence: 0.91             # boxes from a model
    segmentation: [[316, 163, 378, 170, …]]   # optional polygons (x, y, x, y, …)
    origin: model                # dataset (came with the data) or model
annotation:
  status: model                  # dataset, model, negative (deliberately empty) or none (never annotated)
  model: leaf-detector
source:                          # where the image came from: see Licences and provenance
  type: wikimedia
  license: CC BY-SA 4.0
  author: …
  page: https://commons.wikimedia.org/wiki/File:…
history: [center_crop 640x640, annotated by leaf-detector]
```

Classification datasets have `class` and `class_id` at the top instead of `objects`.

## `metadata.yml`

**Toddler words:** the label on the outside of the box: what's in the dataset, how many pictures, which classes.

```yaml
felix_version: "1.0.0"
created: "2026-11-21T08:17:58Z"
title: leaves
pairs: 4210
task: detection                  # or classification
bbox_format: xywh
classes:
  - {id: 0, name: leaf, prompt: a green plant leaf}
splits: {train: 3368, val: 421, test: 421}
sources: [{type: local, label: …, images: 812, skipped: 3}, {type: wikimedia, query: plant leaves, …}]
steps: [{step: center_crop, size: [640, 640]}, {step: annotate, model: {…}, confidence: 0.25}]
license: {dataset: CC-BY-4.0, access: open, images: {CC BY-SA 4.0: 230, …}, issues: 12, files: [LICENSE.txt, ATTRIBUTIONS.md, CITATION.cff]}
excluded: {annotation_failed: 2, licence: 0}
```

Exported datasets also hold `LICENSE.txt`, `ATTRIBUTIONS.md` and `CITATION.cff` next to `metadata.yml`.
