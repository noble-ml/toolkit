# Licences and provenance

Publicly visible images are not automatically free to reuse. Felix records what each provider says about an image,
checks it against how you release the dataset, and writes the files that go with it. This is guidance from the
licence names providers report, **not legal advice**: check the terms before publishing or using a dataset
commercially.

## What every image records

**Toddler words:** every picture carries a little note: where it came from, who made it, and the rules for using it.

Its annotation file holds a `source` block, for example:

```yaml
source:
  type: wikimedia
  title: "File:Sawtooth Oak Leaves.jpg"
  url: https://upload.wikimedia.org/…/1024px-….jpg
  page: https://commons.wikimedia.org/wiki/File:…
  license: CC BY-SA 3.0
  license_url: https://creativecommons.org/licenses/by-sa/3.0
  author: Derek Ramsey
  attribution: "Sawtooth Oak Leaves.jpg by Derek Ramsey, CC BY-SA 3.0, via Wikimedia Commons (https://…)"
  query: plant leaves
  acquired: "2026-11-21T09:15:02Z"
```

Depending on the source: original URL and file name, dataset id, licence and its URL, author and their page,
attribution text, the provider's usage terms, acquisition time, and for video frames the video file, frame number and
time. Transforms and annotation add `history`; face blurring adds `privacy`.

## What the dataset is for: `use`

**Toddler words:** before Felix picks up any picture, it reads the picture's rules. If the rules say "not for
selling" or "share whatever you make from me", and you're making something you'll sell and keep to yourself,
Felix doesn't pick it up at all.

**Why you'd use it:** you never end up with pictures you aren't allowed to use. The default is the safest case, a
**closed-source commercial** product, so a dataset made without thinking about licences is still safe to use
commercially.

```python
fx.export("packages.felix")                        # use="commercial" (default)
fx.export("packages.felix", use="open")            # also share-alike: for a dataset you'll release openly
fx.export("packages.felix", use="research")        # also non-commercial
fx.export("packages.felix", use="any")             # everything (licences are still recorded and checked)
```

| `use` | takes | leaves out |
|---|---|---|
| `"commercial"` (default) | public domain, CC0, CC BY (credit kept), Pexels / Pixabay / Unsplash licences, your own files | non-commercial, no-derivatives, share-alike, unknown, all rights reserved |
| `"open"` | as above, plus share-alike (CC BY-SA) | non-commercial, no-derivatives, unknown, all rights reserved |
| `"research"` | as above, plus non-commercial and no-derivatives | unknown, all rights reserved |
| `"any"` | everything | nothing |

Pictures that are left out are never downloaded. The export notes how many each source left out and why (e.g.
`wikimedia: 30 left out for use='commercial': share-alike (CC BY-SA 4.0) ×30`), and the summary has
`licence_skipped`. Search sources that can filter by licence ask only for fitting ones (Openverse). A picture whose
licence you know but the source doesn't (`fx.sources.urls`, a video URL) can be given one with `license=`.

**Watch out:** share-alike is left out by default because anything built from it (the dataset) would have to be
shared under the same licence, which a closed product can't do. Use `use="open"` with `license="auto"` to publish a
share-alike dataset.

## Open or closed

**Toddler words:** decide whether everyone may use your dataset (open) or only you (closed); Felix checks every picture's rules against that.

```python
fx.export("leaves.felix")                          # closed (default)
fx.export("leaves.felix", license="CC-BY-4.0")     # open, under this licence
fx.export("leaves.felix", license="auto")          # open, under the most permissive licence every image allows
fx.export("leaves.felix", license="CC-BY-4.0", strict=True)   # leave out images that do not fit
```

- **Closed**: the compilation and annotations are all rights reserved (LICENSE.txt says so, naming `authors` as the
  owner). Third-party images keep their licences and are still credited. Felix flags images with unknown licences,
  all-rights-reserved images, non-commercial images (in case you use the data commercially) and no-derivatives
  images that were cropped.
- **Open**: everything above, plus conflicts with the chosen licence: non-commercial images under a licence that allows
  commercial use, share-alike images under a licence without share-alike, attribution-required images under CC0, your
  own files (confirm you hold the rights and people's consent), and photos whose licence does not clearly allow
  redistribution in a dataset (Unsplash, Pexels). `"auto"` picks CC0 if every image is free of conditions, CC BY 4.0
  if some need credit, CC BY-SA 4.0 with share-alike images, and the NC variants if any image is non-commercial.

Problems never stop the export (unless `strict=True` leaves those images out). They are listed in ATTRIBUTIONS.md
(marked ⚠) and counted in `metadata.yml` under `license`.

## The files

**Toddler words:** three notes that travel in the box: the rules for the whole dataset, a thank-you list for every photographer, and how to cite it.

```bash
unzip -p leaves.felix ATTRIBUTIONS.md | head -20      # read the credits inside a .felix file
unzip -p leaves.felix LICENSE.txt
```

| File | Contents |
|---|---|
| `LICENSE.txt` | the dataset's licence (or the closed notice), that images keep their own licences, and a count per image licence |
| `ATTRIBUTIONS.md` | every image: file, source, licence (with any ⚠ issue), author / credit, link |
| `CITATION.cff` | how to cite the dataset (title, authors, date, licence), plus the datasets and collections it draws on (Open Images, COCO, Wikimedia Commons, iNaturalist, …) |

They sit next to the data: inside a `.felix` file, at the top of a dataset folder, or beside the shards.

## Faces

**Toddler words:** put a fuzzy sticker over people's faces, so nobody can be recognised.

```python
fx.acquire([fx.sources.local("./street-photos")], blur_faces=True)   # blur before anything else
fx.transform.blur_faces(strength=1.0, min_size=20)                    # or as a step of its own
```

`fx.transform.blur_faces()` (or `fx.acquire(..., blur_faces=True)`) blurs faces found by OpenCV's frontal and
profile face detectors, and records how many in each image. It is best effort: small, turned, partly hidden or unusual
faces can be missed. Do not rely on it alone for sensitive data.
