# Sources

Pass any mix to `fx.acquire([...])`. Every image keeps a `source` record in its annotation: where it came from,
its licence, who to credit and when it was collected. `limit=None` (the default for online sources) means "as many as
the provider gives": with `fx.export(..., pairs=N)` the export simply stops asking once it has N pairs.

**Several searches.** Every search argument also takes a list: `query=[...]` (Wikimedia, Openverse, Flickr, Unsplash,
Pexels, NASA, the Art Institute, the Smithsonian), `taxon=[...]` (iNaturalist), `scientific_name=[...]` (GBIF). The
searches run side by side, share `limit` equally (`limit=900` with three queries: 300 each), and a picture found by
two is taken once. Each picture's `source` records the search that found it.

**No target, no problem.** The query, taxon or class of the search sources is optional: `fx.sources.wikimedia()`
gives random Commons files, `openverse()` / `nasa()` / `smithsonian()` / `gbif()` / `inaturalist()` whatever they
list, `unsplash()` the newest photos, `pexels()` the curated ones, `flickr()` recent uploads (licence-filtered), and
`open_images()` the classes of your classes.yml (all 600 box classes without one). Pair it with `fx.annotate` to
label what comes in.

A source with no "anything" feed of its own (the Art Institute), or whose feed runs dry (Openverse stops after 240),
goes on with a **vocabulary**: by default about 4,600 subjects, the Recognize Anything (RAM++) tag list (Apache-2.0,
bundled) plus everyday subjects, asked in shuffled order, at most 25 pictures each. Choose another with
`.using(vocabulary="general")` (~150 everyday subjects), `"ram++"`, or your own list, and `per_term=` for the number
of pictures per subject. Pictures found by two subjects are taken once.

Online sources send a User-Agent naming Felix. Set `FELIX_CONTACT` (an email or URL) or `contact:` in
`~/.config/felix/credentials.yml` to include a way to reach you. **Wikimedia requires it**: without it, its image
server refuses Felix, and Felix stops with a message saying so.

### Speed
- **Parallel downloads.** Each source downloads up to 16 images at once, over kept-alive connections (no new
  handshake per image). Image hosts built for it (S3 buckets, CDNs) take up to 16 at a time; others take 2–4.
  Different sources run side by side.
- **Polite APIs.** Search APIs are still asked one page at a time, spaced as their rules ask (iNaturalist about one
  request a second, Pexels 200 an hour, …).
- **Slow-downs.** A server that answers "too many requests" (429 / 503) pauses only that server, for as long as it
  asks; everything else carries on.
- **Download cache.** Downloaded images are kept in `~/.cache/felix/images` (most recently used first, up to
  `FELIX_IMAGE_CACHE_GB`, default 10). Re-running an export after changing a transform or the model needs no network.
  `FELIX_IMAGE_CACHE=0` turns it off.
- **Limits are met.** A failed download frees its place, so `limit=` and `pairs=` still get their full count.

Measured on a home connection, 48 images, cache off: Open Images 0.5 → 9.4 img/s (Felix 1.1 → 1.2); iNaturalist
0.3 → 6.2 img/s; a cached re-run 40–60 img/s.

## Credentials

Keys go in the call (`api_key=...`), in an environment variable, or in `~/.config/felix/credentials.yml`:

```yaml
contact: you@example.com
roboflow_api_key: ...
unsplash_access_key: ...
pexels_api_key: ...          # also pexels_videos
pixabay_api_key: ...         # pixabay_videos
flickr_api_key: ...
api_data_gov_key: ...        # Smithsonian
mapillary_token: ...
huggingface_token: hf_...    # only for gated / private datasets
```

| Source | Environment variable | Where to get it |
|---|---|---|
| roboflow | `ROBOFLOW_API_KEY` | Roboflow → Settings → API Keys |
| unsplash | `UNSPLASH_ACCESS_KEY` | unsplash.com/oauth/applications (Access Key) |
| pexels, pexels_videos | `PEXELS_API_KEY` | pexels.com/api |
| pixabay_videos | `PIXABAY_API_KEY` | pixabay.com/api/docs (sign in; the key is shown there) |
| flickr | `FLICKR_API_KEY` | flickr.com/services/api/keys |
| smithsonian | `API_DATA_GOV_KEY` | api.data.gov/signup (works without, on a shared demo key) |
| mapillary | `MAPILLARY_TOKEN` | mapillary.com/dashboard/developers (client token) |
| huggingface | `HF_TOKEN` | huggingface.co/settings/tokens |
| kaggle | `KAGGLE_USERNAME` + `KAGGLE_KEY` | Kaggle → Settings → API (or `~/.kaggle/kaggle.json`) |

## On this computer

### `fx.sources.local(path, recursive=True, labels=None, license=None)`
- An image file, a folder of images (any nesting; `recursive=False` for the top level only) or an archive (`.zip`,
  `.tar`, `.tar.gz`, …, unpacked safely into a working folder).
- Existing datasets are recognised and bring their labels and splits: **Felix** (`.felix`, folders, `.sh_felix`
  shards), **COCO** (any `*.json` with `images` / `annotations` / `categories`, e.g. Roboflow's
  `_annotations.coco.json` in `train/ valid/ test/`), **YOLO** (`data.yaml` with `names` and `images/` + `labels/`).
- `labels="folders"`: a folder of class folders (`cat/`, `dog/`, …) becomes image labels (classification).
- Photos stored sideways by a camera (EXIF rotation) are turned upright.
- `license`: the images' licence if you know it; otherwise they are recorded as your own files.

### `fx.sources.video(path, sampling=fx.sampling.auto(), license=None, attribution=None)`
Frames of a video file or a video URL (OpenCV: `pip install opencv-python`). Each frame records the video, frame
number and time. A local file counts as your own recording; for a URL, say its `license` (otherwise it is unknown,
which the default `use="commercial"` leaves out). Downloaded videos are cached. See [Sampling](#sampling).

### `fx.sources.camera(device=0, sampling=fx.sampling.interval(seconds=1), count=None, duration=None)`
A webcam / USB camera (`device=0, 1, …`) or a stream URL (`"rtsp://…"`, `"http://…/video.mjpg"`). Runs until `count`
frames, `duration` seconds, the export's `pairs`, or Ctrl+C. `random` sampling is not available for live cameras.

### Sampling
- `fx.sampling.auto(threshold=0.04, min_gap=0.5, max_gap=None, check_fps=4, limit=None)`: keep a frame when it differs
  from the last kept one by at least `threshold` (mean colour difference of small thumbnails), at least `min_gap`
  seconds apart. A still scene gives one frame, not hundreds. `max_gap` forces a frame every so often.
- `fx.sampling.interval(seconds=2, start=0, limit=None)`: one frame every `seconds`.
- `fx.sampling.random(count=1000, seed=42)`: `count` frames spread at random over the whole video, reproducibly.

## On the web

### `fx.sources.urls(source, license=None, attribution=None)`
One URL, a list, or a text file with one URL per line (`#` comments allowed). Their licences are unknown unless you
say (`license=`, `attribution=`); export then reminds you to check your rights.

### `fx.sources.wikimedia(query=None, limit=None, licenses=None, max_side=2048, min_side=256)`
Wikimedia Commons (MediaWiki API, File namespace, bitmap images). Records licence, author, credit and the file page,
and builds the attribution line. `licenses=["CC0", "Public domain", "CC BY 4.0"]` keeps only those (by the start of
Commons' short licence name). Downloads a scaled copy up to `max_side`, not 50-megapixel originals. No
query: random files.

### `fx.sources.openverse(query=None, limit=None, licenses=None, commercial=True, source=None)`
Openverse: openly licensed images from Flickr, Wikimedia and many museums, in one search (no key). `commercial=True`
keeps licences that allow commercial use; `licenses=["cc0", "by", "by-sa"]` to choose; `source="flickr"` for one
provider. Openverse supplies the attribution text.

### `fx.sources.flickr(query=None, limit=None, licenses=(4, 5, 7, 8, 9, 10, 11, 12), api_key=None)`
Flickr search filtered by licence id (default: CC BY, CC BY-SA, CC0, public domain and "no known copyright", i.e.
commercial use and changes allowed). Flickr's API is for non-commercial use unless you arrange otherwise with
Flickr, and returns at most 4,000 results per search. No query: recent uploads with those licences.

### `fx.sources.unsplash(query=None, limit=None, size="regular", orientation=None, api_key=None)`
Unsplash (Unsplash License). As Unsplash's API guidelines require, each download is reported to Unsplash. Demo
apps are limited to 50 requests an hour. No query: the newest photos.

### `fx.sources.pexels(query=None, limit=None, size="large2x", orientation=None, api_key=None)`
Pexels (Pexels License; 200 requests an hour, so Felix waits ~18 s between result pages). The "Photo by … on Pexels"
credit is recorded. No query: Pexels' curated photos.

Unsplash and Pexels photos are free to use, but both licences forbid compiling their photos into a similar or
competing service; export flags them when you release a dataset openly.


## Videos on the web

Each of these searches a video site, downloads the videos whose licence fits `fx.export(use=...)` (the others are
skipped before downloading) and samples them into frames like `fx.sources.video`. Shared options:

- `limit`: frames in total; `per_video=20`: at most this many frames from one video, spread over its whole length;
- `sampling`: `fx.sampling.auto()` (default: only when the scene changes), `interval(seconds=)` or `random(count=)`;
- `max_height=720`: the version to download (the tallest one no taller than this); `max_seconds=600`: skip longer
  videos (when the site says how long they are); `max_mb=150`: skip bigger files (checked before downloading); a
  download slower than 3 minutes is skipped too, so one huge file never holds the source up.

Videos are cached in `~/.cache/felix/videos` (`FELIX_VIDEO_CACHE_GB`, default 20): a re-run downloads nothing.

### `fx.sources.pexels_videos(query=None, limit=None, sampling=None, per_video=20, max_seconds=600, max_height=720, orientation=None, api_key=None)`
Stock footage from Pexels, with the same key as `fx.sources.pexels`. Without a query: popular videos. Pexels License
(free, commercial use allowed); the credit "Video by … on Pexels" is recorded.

### `fx.sources.pixabay_videos(query=None, limit=None, sampling=None, per_video=20, max_seconds=600, max_height=720, api_key=None)`
Stock footage from Pixabay (key: `PIXABAY_API_KEY`). Without a query: popular videos. Pixabay Content License (free,
commercial use allowed, no credit required; it is recorded anyway). The API pages through at most 500 videos per
search.

### `fx.sources.wikimedia_videos(query=None, limit=None, sampling=None, per_video=20, max_seconds=600, max_height=720)`
Videos from Wikimedia Commons, using Commons' own WebM versions. Freely licensed, but many are share-alike (left out
by the default `use="commercial"`; `use="open"` takes them). Set `FELIX_CONTACT` first, as for `fx.sources.wikimedia`.
Without a query: Felix's general vocabulary, a few videos per subject.

### `fx.sources.nasa_videos(query=None, limit=None, sampling=None, per_video=20, max_seconds=600, max_height=720)`
Videos from the NASA Image and Video Library: generally not copyrighted in the US (some items are third-party; see
NASA's media guidelines). NASA doesn't say how long a video is, so `max_mb` is what keeps long ones out.

### `fx.sources.archive_videos(query=None, limit=None, sampling=None, per_video=20, max_seconds=600, max_height=720, max_mb=150)`
Videos from the Internet Archive that state a licence (public domain or Creative Commons), most downloaded first;
its MPEG-4 versions are used. The query is Internet Archive search syntax (`"delivery truck"`,
`title:(parcel) AND year:[1950 TO 1970]`). Its servers can be slow: slow downloads are skipped and reported.

## Open collections

### `fx.sources.inaturalist(taxon=None, limit=None, licenses=("cc0", "cc-by", "cc-by-sa"), size="large", quality="research", label=False, place_id=None)`
Research-grade iNaturalist observation photos for a taxon (scientific or common name), with each photo's own licence
and attribution. `label=True` labels each image with its species (classification). Pages stop at 10,000 results. No taxon: any species. The
name is looked up first and means exactly that taxon and everything under it ("Pinus": all pines, not the pine
siskin *Spinus pinus*; common names work: "red oak" is *Quercus rubra*).

### `fx.sources.gbif(scientific_name=None, query=None, limit=None, licenses=("CC0_1_0", "CC_BY_4_0"), country=None)`
Occurrence images from GBIF, with the publishing institution's licence and rights holder. Neither name nor
query: any occurrence with an image.

### `fx.sources.nasa(query=None, limit=None, size="large")`
The NASA Image and Video Library. NASA imagery is generally not copyrighted in the US, but some items are third-party
or show people and logos: check NASA's media guidelines.

### `fx.sources.artic(query=None, limit=None)` · `fx.sources.smithsonian(query=None, limit=None, api_key=None)`
Public-domain (CC0) images from the Art Institute of Chicago (843 px IIIF images, as the museum asks) and the
Smithsonian's Open Access. The Art Institute's API sits behind a bot check that sometimes
refuses programs for a while; Felix then says so instead of failing silently.

Not included, on purpose: **Pixabay** (its terms forbid automated collection and machine-learning use without
permission), **The Met** and the **Library of Congress** (their servers only serve browsers: automated requests get a
bot check, and Felix does not work around those).

## Dataset hubs

### `fx.sources.roboflow(project, version, workspace=None, api_key=None)`
A Roboflow dataset version (your workspace or Universe: `project="workspace/project"`), downloaded as a COCO export
and imported with boxes and splits. Cached in `~/.cache/felix/roboflow`. A Universe project without a licence means
all rights reserved.

### `fx.sources.open_images(classes=None, split="validation", limit=None, seed=0, group_of=True)`
Open Images V7 images containing any of `classes` (display names: "Car", "Person", …), with all their boxes of those
classes. Without `classes`: your classes.yml's classes that Open Images has (names or aliases), or all 600
box classes. The annotation CSVs are cached in `~/.cache/felix/open_images` (validation ~40 MB, test ~120 MB, train
several GB). Each image keeps its own licence, author and Flickr page; annotations are CC BY 4.0 (Google). Images that
Open Images lists as rotated are skipped, as their boxes may not line up.

### `fx.sources.coco(split="val2017", limit=None)`
COCO 2017 from the official files (val2017: 5k images, ~1 GB with annotations; train2017: 118k images, ~18 GB),
cached in `~/.cache/felix/coco`. With a class file only images containing those classes are kept. Each image keeps
its Flickr licence from COCO's metadata.

### `fx.sources.huggingface(dataset, split="train", config=None, limit=None, label_column=None, bbox_format="xywh", token=None)`
A Hugging Face image dataset through the Dataset Viewer API (only the rows you take are downloaded). A class-label
column becomes the image label; an `objects` column with `bbox` and `category` gives boxes. The dataset card's licence
is recorded.

### `fx.sources.kaggle(dataset, labels=None)`
A Kaggle dataset (`"owner/name"`), downloaded and imported like `local` (format detected automatically).

### `fx.sources.mapillary(bbox, limit=None, access_token=None)`
Street-level images inside a map area smaller than 0.01° on each side (Mapillary's limit), CC BY-SA 4.0.

## Your own source

Subclass `fx.sources.Source` with `collect(self, collector, progress)` and call
`collector.add(path=... or data=..., name=..., source={...}, objects=None, label=None)` for each image.
