# CLI

`felix` (or `python -m felix`). Output is a minimal monochrome ("noir") panel built on rich, redrawn in place on a terminal (colour unless
`NO_COLOR` is set); piped or on CI it prints just the final frame.

```
felix run SCRIPT [args...]            run a Felix script (load_class, acquire, transform, annotate, export)
felix pack FOLDER [-o OUT.felix]      folder -> single compressed .felix
felix unpack FILE.felix [-o FOLDER]   .felix -> folder
felix info PATH                       summary + per-class box counts (or images per class and split for class folders)
felix partition SRC (--parts N | ...)  split a dataset into several smaller datasets
felix shard SRC [--size N|--shards N]  a folder of .sh_felix shards, for very large datasets
felix split SRC 0.5 [-o OUT]          a smaller copy (here half) for quick experiments; SRC is unchanged
                                      (classification: every class keeps its share in every split)
felix convert SRC [-o OUT]            any dataset or image folder (COCO, YOLO, class folders, images) -> Felix
felix library [SEARCH]                browse every function and command; type to search
felix --version
```

All writing commands refuse to overwrite existing output unless `--overwrite` is given.


## Browsing the library: `felix library`

```
felix library                 # every function and command, grouped; ↑↓ to move
felix library split           # start with a search
```

A full-screen browser in the same look as the rest of the CLI. On the left, everything you can use, grouped,
with its arguments under each name; type anywhere to search (every word must match; name matches come first). On
the right, the whole entry: what it does, the toddler-words explanation, why you'd use it, examples, the catch,
and the exact signature from the code.

| Key | Does |
|---|---|
| ↑ ↓ | move through the list (or scroll the entry, after Tab) |
| Tab / → / Enter | read the entry: ↑ ↓ then scroll it; Shift+Tab / ← goes back |
| PgUp / PgDn | scroll the entry |
| Home / End | first / last entry |
| typing, Backspace | search |
| Esc | back to the list, then clear the search, then quit (Ctrl+C quits at once) |

It needs a terminal (not a notebook or a pipe). The content is the same as the docs, shipped inside the package,
so it works offline and always matches the installed version.

## Partitioning a dataset

`felix partition` splits one dataset into several smaller ones. Every piece is a complete dataset (images,
annotations, `metadata.yml`), so it can be loaded, packed, inspected or partitioned again on its own.

```
felix partition data.felix --parts 4                     # 4 equal pieces: part1 … part4
felix partition data.felix --ratio 80,10,10 --names train,val,test
felix partition ./data --size 1000                       # pieces of at most 1000 pairs
felix partition data.felix --by-split                    # one piece per train / val / test split
```

Choose exactly one way to split:

| Option | Pieces |
|---|---|
| `--parts N` | N equal pieces (sizes differ by at most one pair) |
| `--ratio A,B,...` | proportional pieces; any positive numbers, they need not sum to 100 |
| `--size K` | as many pieces of K pairs as needed; the last one may be smaller |
| `--by-split` | one piece per non-empty split (`train`, `val`, `test`), using the dataset's own splits |

Other options:

| Option | Meaning |
|---|---|
| `-o, --output DIR` | folder that receives the pieces (default `<source>_parts`) |
| `--names A,B,...` | piece names, one per piece (default `part1`, `part2`, ...) |
| `--shuffle`, `--seed S` | shuffle before splitting, reproducibly (default: keep the dataset's order) |
| `--pack` / `--folders` | write `.felix` files or folders (default: the same kind as the source) |
| `--overwrite` | replace existing pieces |

Every pair lands in exactly one piece. Files keep their names (`IMG42.png` stays `IMG42.png`), and each piece's
`metadata.yml` records where it came from (`partition: {source, name, index, of}`). With `--ratio`, leftover pairs
go to the pieces with the largest remainders.

## A smaller copy for experiments: `felix split`

```
felix split voc.felix 0.5                 # → voc_split_50.felix, half the pairs; voc.felix is unchanged
felix split voc.felix 0.1 --seed 2        # → voc_split_10.felix, another random tenth
felix split voc.felix --size 1000         # → voc_split_1000.felix, exactly 1000 pairs
felix split ./data 0.25 -o small          # a folder dataset → folder copy "small"
```

The copy is a complete dataset like any other. Every train / val / test split keeps the same share (half of train,
half of val, half of test), and every pair stays in the split it was in, so test pictures never become training
pictures. Which pairs are picked is random but repeatable: the same `--seed` (default 0) gives the same subset.
A split that had pairs keeps at least one. `metadata.yml` records where it came from
(`split_from: {source, pairs, seed, fraction}`).

| Option | Meaning |
|---|---|
| `fraction` | share to keep, above 0 and at most 1 (`0.5` = half; `50` is refused with a hint) |
| `--size N` | keep N pairs instead of a fraction |
| `-o OUT` | output path (default `<name>_split_<percent>.felix`, or a folder for a folder source) |
| `--seed S` | which random subset |
| `--overwrite` | replace an existing output (never the source) |

## Shards for very large datasets: `felix shard`

```
felix shard voc.felix                    # → voc_shards/ with 1000 pairs per shard
felix shard voc.felix --size 5000        # 5000 pairs per shard
felix shard ./imagenet --shards 256 -o imagenet_shards
felix pack voc_shards -o voc.felix       # back to one file
```

Every shard is a complete `.sh_felix` file; the folder loads as one dataset (`fx.load("voc_shards")`), with the same
pairs and splits as the source, which stays unchanged. Workflow trains from it one shard at a time. `felix info`,
`split` and `partition` work on shard folders too.

## Converting a dataset: `felix convert`

```
felix convert ./roboflow-export                    # COCO export (folder or .zip) → roboflow-export.felix
felix convert ./yolo-dataset -o data.felix         # YOLO (data.yaml + images/ + labels/)
felix convert ./animals --labels folders           # class folders → a classification dataset
felix convert ./photos -o photos.sh_felix          # plain images (no labels yet), as shards
felix convert ./export.zip --license CC-BY-4.0     # released openly, with licence files
```

The same as `fx.acquire([fx.sources.local(SRC)])` followed by `fx.export(OUT)`: labels and splits come along, the
files are copied as they are, and LICENSE.txt, ATTRIBUTIONS.md and CITATION.cff are written.
