"""Full-screen library browser shared by ``workflow library`` and ``felix library`` (the same file in both packages).

Left: every entry, grouped, each name with its arguments underneath; typing searches. Right: the whole entry.
Drawn with rich in the CLI's noir look (bone on black, one blood-red accent); keys are read straight from the
terminal (termios / msvcrt), so there is no extra dependency."""
from __future__ import annotations

import inspect
import os
import re
import sys
import time
from typing import Iterable, List, Optional, Tuple

from rich.console import Console
from rich.text import Text

from . import _ui

BONE, ASH, SOOT, BLOOD = _ui.BONE, _ui.ASH, _ui.SOOT, _ui.BLOOD


# ---------------------------------------------------------------------------------------------------------- content
class Entry:
    """One thing you can look up. ``sections`` are (label, markdown) pairs shown in order; label None = no heading."""

    def __init__(self, name: str, group: str, what: str = "", args: str = "", example: str = "", keys: Iterable[str] = (),
                 obj=None):
        self.name, self.group, self.what, self.args, self.example, self.obj = name, group, what, args, example, obj
        self.keys = set(keys) or {key(name)}
        self.sections: List[Tuple[Optional[str], str]] = []
        self._hay = None

    def add(self, md: str, label: Optional[str] = None):
        if md and (label, md) not in self.sections:
            self.sections.append((label, md))
            self._hay = None

    @property
    def hay(self) -> str:
        if self._hay is None:
            self._hay = " ".join([self.name, self.args, self.what, self.example, *(m for _, m in self.sections),
                                  doc(self.obj) or ""]).lower()
        return self._hay


def key(name: str) -> str:
    """`model.save(path)` -> model.save; `wf.Conv2D` -> wf.conv2d."""
    return re.sub(r"\(.*", "", name.strip().strip("`")).strip().lower()


def ticks(s: str) -> List[str]:
    return re.findall(r"`([^`]+)`", s)


def plain(s: str) -> str:
    s = re.sub(r"\[([^\]]+)\]\([^)]*\)", r"\1", s)
    return re.sub(r"\s+", " ", s.replace("`", "").replace("**", "")).strip()


def doc(obj) -> Optional[str]:
    return inspect.getdoc(obj) if obj is not None and not inspect.ismodule(obj) else None


def signature(obj, prefix: str, name: str = "") -> Optional[str]:
    if obj is None or inspect.ismodule(obj):
        return None
    try:
        sig = inspect.signature(obj.__init__ if inspect.isclass(obj) else obj)
    except (TypeError, ValueError):
        return None
    params = [str(p) for p in sig.parameters.values() if p.name != "self"]
    shown = name if re.fullmatch(r"[A-Za-z_][\w.]*", name or "") else f"{prefix}{getattr(obj, '__name__', '')}"
    return f"{shown}({', '.join(params)})"


def cookbook_sections(text: str):
    """(heading, body) for every ``###`` section (and ``##`` sections without subsections) of a cookbook page."""
    out, head = [], None
    for chunk in re.split(r"^(#{2,3} .+)$", text, flags=re.M):
        if re.match(r"#{2,3} ", chunk):
            head = chunk
            continue
        body = chunk.strip().strip("-").strip()
        if head and body:
            out.append((head, body))
    return out


def eli5(md: str) -> str:
    """The first sentence of the toddler-words paragraph (a one-line summary)."""
    m = re.search(r"\*\*Toddler words:\*\*\s*(.+?)(?:\n\n|$)", md, re.S)
    t = plain((m.group(1) if m else md.split("\n\n")[0]).replace("*", ""))
    return t.split(". ")[0].rstrip(".") if len(t) > 90 else t


def search(entries: List[Entry], query: str) -> List[Entry]:
    """Every word must appear somewhere; hits in the name rank first, then in the summary, then anywhere."""
    words = query.lower().split()
    if not words:
        return entries
    scored = []
    for i, e in enumerate(entries):
        if not all(w in e.hay for w in words):
            continue
        name, short = e.name.lower(), (e.name + " " + e.args + " " + e.what).lower()
        words_in_name = re.sub(r"[^a-z0-9]+", " ", name).split()
        score = sum(4 if w in words_in_name else 3 if any(n.startswith(w) for n in words_in_name) else
                    2 if w in name else 1 if w in short else 0 for w in words)
        scored.append((-score, i, e))
    return [e for *_, e in sorted(scored, key=lambda t: (t[0], t[1]))]


# -------------------------------------------------------------------------------------------------------- rendering
_INLINE = re.compile(r"`([^`]+)`|\*\*([^*]+)\*\*|\*([^*\s][^*]*)\*|\[([^\]]+)\]\([^)]*\)")
_LABELS = {"toddler words": "ELI5", "why you'd use it": "Why you'd use it", "why it matters": "Why it matters",
           "watch out": "Watch out"}


def inline(s: str, style: str = BONE) -> Text:
    t, pos = Text(), 0
    for m in _INLINE.finditer(s):
        t.append(s[pos:m.start()], style=style)
        code, bold, ital, link = m.groups()
        if code is not None:
            t.append(code, style=f"bold {BONE}")
        elif bold is not None:
            t.append(bold, style=f"bold {style}")
        elif ital is not None:
            t.append(ital, style=f"italic {style}")
        else:
            t.append(link, style=style)
        pos = m.end()
    t.append(s[pos:], style=style)
    return t


def code_line(line: str) -> Text:
    """Code in bone, the names you call in bold, comments in ash."""
    t = Text(no_wrap=True, overflow="ellipsis")
    code, comment, quote = line, "", None
    for i, ch in enumerate(line):
        if quote:
            quote = None if ch == quote else quote
        elif ch in "\"'":
            quote = ch
        elif ch == "#":
            code, comment = line[:i], line[i:]
            break
    t.append("  ")
    for part in re.split(r"(\b(?:wf|fx|model|felix|workflow)\.[\w.]+|^\s*(?:felix|workflow)\b)", code):
        t.append(part, style=f"bold {BONE}" if re.match(r"\s*(wf|fx|model|felix|workflow)\b", part) else BONE)
    t.append(comment, style=ASH)
    return t


def code_lines(line: str, width: int) -> List[Text]:
    """One code line, wrapped (never cut): breaks after a comma or space, continuation lines indented."""
    t = code_line(line)
    if t.cell_len <= width:
        return [t]
    width = max(12, width)
    indent = min(len(t.plain) - len(t.plain.lstrip()) + 4, width // 3)
    out, rest, room = [], t, width
    while rest.cell_len > room:                     # rest never carries the indent, so every pass shortens it
        s = rest.plain[:room]
        cut = max(s.rfind(", ") + 2, s.rfind(" ") + 1)
        if cut <= room // 3:
            cut = room
        head, rest = rest.divide([cut])
        out.append(head if not out else Text(" " * indent) + head)
        n = len(rest.plain) - len(rest.plain.lstrip(" "))
        rest, room = rest[n:], width - indent
    if rest.plain:
        out.append(Text(" " * indent) + rest)
    return out


def label(name: str) -> Text:
    return Text(name.upper(), style=f"bold {BLOOD}")


def wrap(t: Text, width: int) -> List[Text]:
    con = Console(width=max(10, width), highlight=False, emoji=False, markup=False)
    return list(t.wrap(con, max(10, width)))


def markdown(md: str, width: int) -> List[Text]:
    """The docs' small markdown subset (paragraphs, **Label:** lead-ins, lists, tables, code) → wrapped lines."""
    out: List[Text] = []
    for block in re.split(r"(```[^\n]*\n.*?\n```)", md, flags=re.S):
        if block.startswith("```"):
            body = block.split("\n", 1)[1].rsplit("\n```", 1)[0]
            out.append(Text())
            for l in body.split("\n"):
                out += code_lines(l, width)
            out.append(Text())
            continue
        for para in re.split(r"\n\s*\n", block.strip()):
            para = para.strip()
            if not para or para == "---":
                continue
            m = re.match(r"\*\*([^*]+?)\*\*:?\s*", para)
            if m and m.group(1).endswith((":", ".")) or (m and m.group(1).lower() in _LABELS):
                name = m.group(1).rstrip(":.")
                out += [Text(), label(_LABELS.get(name.lower(), name))]
                para = para[m.end():]
            lines = para.split("\n")
            if all(l.lstrip().startswith("|") for l in lines):
                out += _table(lines, width)
            elif lines[0].lstrip().startswith(("- ", "* ")):
                items, cur = [], ""
                for l in lines:
                    if re.match(r"\s*[-*] ", l):
                        if cur:
                            items.append(cur)
                        cur = re.sub(r"^\s*[-*] ", "", l)
                    else:
                        cur += " " + l.strip()
                items.append(cur)
                for item in items:
                    w = wrap(inline(item.strip()), width - 2)
                    out += [Text("· ", style=BLOOD) + w[0]] + [Text("  ") + x for x in w[1:]]
            else:
                out += wrap(inline(re.sub(r"\s*\n\s*", " ", para)), width)
            out.append(Text())
    while out and not out[-1].plain:
        out.pop()
    return out


def _table(lines: List[str], width: int) -> List[Text]:
    rows = [[c.strip() for c in l.strip().strip("|").split(" | ")] for l in lines]
    rows = [r for r in rows if not all(re.fullmatch(r":?-+:?", c) for c in r)]
    if not rows:
        return []
    head, body = rows[0], rows[1:]
    first = min(28, max(len(plain(r[0])) for r in body) if body else 10)
    out = [Text("  ".join([plain(head[0]).ljust(first)] + [plain(c) for c in head[1:]]), style=ASH)]
    for r in body:
        cell = inline(r[0])
        cell.truncate(first, overflow="ellipsis")
        cell.pad_right(first - cell.cell_len)
        rest = wrap(inline("  ·  ".join(r[1:])), max(10, width - first - 2))
        out.append(cell + Text("  ") + (rest[0] if rest else Text()))
        out += [Text(" " * (first + 2)) + x for x in rest[1:]]
    return out


def detail(e: Entry, width: int, prefix: str, query: str = "") -> List[Text]:
    out: List[Text] = []
    title = Text()
    title.append(e.name, style=f"bold {BONE}")
    title.append(f"   {e.group.lower()}", style=ASH)
    out += wrap(title, width)
    told = plain(" ".join(md for _, md in e.sections)).replace("*", "")
    if e.what and plain(e.what).rstrip(".") not in told:          # not already the first line of the ELI5
        out += [Text()] + wrap(inline(e.what), width)
    if e.args:
        out += [Text(), label("You choose")] + wrap(inline(e.args), width)
    if e.example:
        out += [Text(), label("Example")] + code_lines(e.example, width)
    for name, md in e.sections:
        out.append(Text())
        if name:
            out += [Text("─" * min(width, 60), style=SOOT), label(name)]
        out += markdown(md, width)
    sig, d = signature(e.obj, prefix, e.name), doc(e.obj)
    if sig or d:
        out += [Text(), Text("─" * min(width, 60), style=SOOT), label("Signature")]
        if sig:
            out += wrap(Text(sig, style=f"bold {BONE}"), width)
        if d:
            for para in d.split("\n\n"):
                out += [Text()] + wrap(inline(re.sub(r"\s*\n\s*", " ", para.strip()).replace("``", "`"), ASH), width)
    words = query.split()
    if words:
        for t in out:
            t.highlight_words(words, style=f"underline {BLOOD}", case_sensitive=False)
    tidy: List[Text] = []
    for t in out:                                   # never two blank lines in a row
        if t.plain.strip() or (tidy and tidy[-1].plain.strip()):
            tidy.append(t)
    while tidy and not tidy[-1].plain.strip():
        tidy.pop()
    return tidy


def _fit(t: Text, width: int) -> Text:
    t = t.copy()
    t.no_wrap, t.overflow = True, "ellipsis"
    if t.cell_len > width:
        t.truncate(width, overflow="ellipsis")
    t.pad_right(max(0, width - t.cell_len))
    return t


# -------------------------------------------------------------------------------------------------------------- keys
_SEQ = sorted({"[A": "up", "[B": "down", "[C": "right", "[D": "left", "[5~": "pgup", "[6~": "pgdn", "[H": "home",
               "[F": "end", "[1~": "home", "[4~": "end", "OA": "up", "OB": "down", "OC": "right", "OD": "left",
               "OH": "home", "OF": "end", "[Z": "backtab"}.items(), key=lambda kv: -len(kv[0]))
_CTRL = {"\t": "tab", "\r": "enter", "\n": "enter", "\x7f": "backspace", "\x08": "backspace", "\x1b": "esc",
         "\x03": "quit", "\x04": "quit", "\x15": "clear"}


def parse_keys(s: str) -> List[str]:
    keys, i = [], 0
    while i < len(s):
        if s[i] == "\x1b" and i + 1 < len(s):
            for seq, name in _SEQ:
                if s.startswith(seq, i + 1):
                    keys.append(name)
                    i += 1 + len(seq)
                    break
            else:
                m = re.match(r"[\[O][0-9;]*[A-Za-z~]", s[i + 1:])      # a sequence we don't use (F-keys, …)
                if m:
                    i += 1 + m.end()
                else:
                    keys.append("esc")
                    i += 1
            continue
        keys.append(_CTRL.get(s[i], s[i]))
        i += 1
    return keys


class _Keys:
    def __enter__(self):
        if os.name == "nt":
            import msvcrt
            self._ms = msvcrt
        else:
            import termios
            import tty
            self.fd = sys.stdin.fileno()
            self._old = termios.tcgetattr(self.fd)
            tty.setcbreak(self.fd)
        return self

    def __exit__(self, *exc):
        if os.name != "nt":
            import termios
            termios.tcsetattr(self.fd, termios.TCSADRAIN, self._old)

    def read(self, timeout: float = 0.25) -> List[str]:
        if os.name == "nt":
            end, keys = time.time() + timeout, []
            while time.time() < end and not keys:
                while self._ms.kbhit():
                    ch = self._ms.getwch()
                    if ch in ("\x00", "\xe0"):
                        keys.append({"H": "up", "P": "down", "K": "left", "M": "right", "I": "pgup", "Q": "pgdn",
                                     "G": "home", "O": "end"}.get(self._ms.getwch(), ""))
                    else:
                        keys.append(_CTRL.get(ch, ch))
                time.sleep(0.01)
            return keys
        import select
        if not select.select([self.fd], [], [], timeout)[0]:
            return []
        return parse_keys(os.read(self.fd, 256).decode("utf-8", "replace"))


# ---------------------------------------------------------------------------------------------------------- the app
class Browser:
    def __init__(self, entries: List[Entry], prog: str, version: str, prefix: str):
        self.all, self.prog, self.version, self.prefix = entries, prog, version, prefix
        self.query, self.items = "", entries
        self.sel = self.top = self.scroll = 0
        self.focus = "list"
        self._lines, self._for = [], None

    def set_query(self, q: str):
        self.query, self.items = q, search(self.all, q)
        self.sel = self.top = self.scroll = 0

    def select(self, name: str) -> bool:
        for i, e in enumerate(self.items):
            if e.name == name:
                self.sel, self.scroll = i, 0
                return True
        return False

    def key(self, k: str, page: int) -> bool:
        """Apply one key; False means quit."""
        if k == "quit":
            return False
        if k == "esc":
            if self.focus == "detail":
                self.focus = "list"
            elif self.query:
                self.set_query("")
            else:
                return False
        elif k in ("tab", "right", "enter"):
            self.focus = "detail"
        elif k in ("backtab", "left"):
            self.focus = "list"
        elif k in ("up", "down"):
            d = -1 if k == "up" else 1
            if self.focus == "list":
                if self.items:
                    self.sel, self.scroll = max(0, min(len(self.items) - 1, self.sel + d)), 0
            else:
                self.scroll = max(0, self.scroll + d)
        elif k in ("pgup", "pgdn"):
            self.scroll = max(0, self.scroll + (page if k == "pgdn" else -page))
        elif k in ("home", "end"):
            if self.focus == "list":
                self.sel, self.scroll = (0 if k == "home" else max(0, len(self.items) - 1)), 0
            else:
                self.scroll = 0 if k == "home" else 10 ** 9
        elif k == "backspace":
            self.set_query(self.query[:-1])
        elif k == "clear":
            self.set_query("")
        elif len(k) == 1 and k.isprintable():
            self.focus = "list"
            self.set_query(self.query + k)
        return True

    def _list(self, width: int):
        rows, at, last = [], 0, None
        for i, e in enumerate(self.items):
            if not self.query and e.group != last:
                if last is not None:
                    rows.append(Text())
                rows.append(Text(e.group.upper(), style=f"bold {BLOOD}"))
                last = e.group
            on = i == self.sel
            name = Text()
            name.append("› " if on else "  ", style=f"bold {BLOOD}")
            name.append(e.name, style=f"bold {BONE}" if on else BONE)
            if on:
                at = len(rows)
            rows.append(name)
            rows.append(Text("  " + (plain(e.args) or plain(e.what)), style=BONE if on else ASH))
        return rows, at

    def frame(self, width: int, height: int) -> Text:
        width, height = max(50, width), max(12, height)
        lw = max(28, min(48, width * 2 // 5))
        rw = width - lw - 3
        body = height - 4

        head = Text()
        head.append(f"{self.prog} ", style=f"bold {BONE}")
        head.append("library ", style=BONE)
        head.append(self.version, style=ASH)
        head.append(f"   {len(self.items)} of {len(self.all)}" if self.query else f"   {len(self.all)} entries", style=ASH)

        box = Text()
        box.append("/ ", style=f"bold {BLOOD}")
        if self.query:
            box.append(self.query, style=f"bold {BONE}")
            box.append("▏", style=BLOOD)
        else:
            box.append("type to search", style=SOOT)

        rows, at = self._list(lw)
        if not self.items:
            rows, at = [Text("  nothing matches", style=ASH), Text("  esc clears the search", style=SOOT)], 0
        if at < self.top + 1:                                   # keep the selection (and its group title) visible
            self.top = max(0, at - (2 if not self.query else 0))
        elif at + 2 > self.top + body:
            self.top = at + 2 - body
        left = rows[self.top:self.top + body]

        right, pos = [], Text()
        if self.items:
            e = self.items[self.sel]
            if self._for != (e.name, rw, self.query):
                self._lines, self._for = detail(e, rw, self.prefix, self.query), (e.name, rw, self.query)
            lines = self._lines
            self.scroll = max(0, min(self.scroll, len(lines) - body))
            right = lines[self.scroll:self.scroll + body]
            if len(lines) > body:
                end = min(len(lines), self.scroll + body)
                pos = Text(f"{self.scroll + 1}–{end} of {len(lines)}", style=SOOT, justify="right")

        active = self.focus == "detail"
        sep = Text(" ┃ " if active else " │ ", style=BLOOD if active else SOOT)
        out = Text()
        for line in (_fit(head, width), _fit(Text(), width)):
            out.append_text(line)
            out.append("\n")
        out.append_text(_fit(box, lw))
        out.append_text(sep.copy())
        p = _fit(Text(), rw - pos.cell_len)
        out.append_text(p + pos)
        out.append("\n")
        for i in range(body):
            out.append_text(_fit(left[i] if i < len(left) else Text(), lw))
            out.append_text(sep.copy())
            out.append_text(_fit(right[i] if i < len(right) else Text(), rw))
            out.append("\n")
        foot = Text()
        for k, what in (("↑↓", "scroll" if active else "move"), ("tab", "list" if active else "read"),
                        ("pgup pgdn", "scroll"), ("type", "search"), ("esc", "back · clear · quit")):
            foot.append(k, style=BONE)
            foot.append(f" {what}    ", style=ASH)
        out.append_text(_fit(foot, width))
        return out


def run(entries: List[Entry], prog: str, version: str, prefix: str, query: str = "") -> int:
    """Open the browser in the terminal (alternate screen; the shell is left as it was)."""
    if not (sys.stdin.isatty() and sys.stdout.isatty()) or _ui.in_notebook():
        _ui.error(f"{prog} library needs a terminal: run it in a shell, not a notebook or a pipe (the same content is "
                  f"in the docs).")
        return 1
    b = Browser(entries, prog, version, prefix)
    if query:
        b.set_query(query)
    con = Console(highlight=False, emoji=False, markup=False, force_terminal=True)
    out = sys.stdout
    out.write("\x1b[?1049h\x1b[?25l")
    try:
        with _Keys() as keys:
            shown = None
            while True:
                w, h = os.get_terminal_size()
                frame = b.frame(w, h)
                state = (frame.plain, w, h, b.focus)
                if state != shown:
                    with con.capture() as cap:
                        con.print(frame, end="", width=w, no_wrap=True, crop=True, overflow="crop")
                    out.write("\x1b[H" + cap.get().replace("\n", "\x1b[K\n") + "\x1b[K\x1b[J")
                    out.flush()
                    shown = state
                if not all(b.key(k, max(1, h - 6)) for k in keys.read() if k):
                    break
    except KeyboardInterrupt:
        pass
    finally:
        out.write("\x1b[?25h\x1b[?1049l")
        out.flush()
    return 0
