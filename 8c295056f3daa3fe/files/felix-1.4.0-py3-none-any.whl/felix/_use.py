"""``fx.use(device)``: the device Felix's models run on when they do not name one.

First match wins: the model's own ``device=`` (``fx.models.yoloe(device="cuda")``), then ``fx.use(...)`` (for the
session, or inside ``with fx.use(...):``), then the ``FELIX_DEVICE`` environment variable, then automatic (what
Ultralytics picks for its models; a Workflow model's own choice for Workflow models)."""
from __future__ import annotations

import os
from typing import Optional, Tuple

from .errors import FelixError

_set = {"device": None}


def _check(device) -> Optional[str]:
    if device is None:
        return None
    d = str(device).strip().lower()
    if d == "auto":
        return None
    if d.partition(":")[0] == "modal":
        raise FelixError(f"fx.use({device!r}): Felix runs its models on this machine; Modal is a Workflow training "
                         "device (wf.use('modal:A100')). Use 'cpu', 'cuda', 'cuda:N', 'mps' or 'auto' here")
    kind = d.partition(":")[0]
    if kind not in ("cpu", "cuda", "mps") and not d.replace(",", "").isdigit():
        raise FelixError(f"fx.use: unknown device {device!r}; Felix's models run on 'cpu', 'cuda', 'cuda:N' (or 'N'), "
                         "'mps' or 'auto'")
    try:
        import torch
    except ImportError:                    # no models installed yet: they will say so themselves
        return d
    if kind == "cuda" or d[0].isdigit():
        if not torch.cuda.is_available():
            raise FelixError(f"fx.use: device {device!r} is not available (PyTorch sees no CUDA GPU on this machine); "
                             "use 'cpu' (or 'mps' on an Apple-silicon Mac), or install a CUDA build of PyTorch")
    elif kind == "mps" and not (getattr(torch.backends, "mps", None) and torch.backends.mps.is_available()):
        raise FelixError(f"fx.use: device {device!r} is not available (PyTorch sees no Apple GPU on this machine); use 'cpu'")
    return d


class use:
    """``fx.use("cuda")`` · ``fx.use("mps")`` · ``fx.use(None)`` (back to automatic). Takes effect at once; as
    ``with fx.use(...):`` only inside the block. ``fx.use()`` changes nothing and shows the current choice."""

    def __init__(self, device=...):
        self._before = dict(_set)
        if device is not ...:
            _set["device"] = _check(device)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        _set.update(self._before)
        return False

    @property
    def device(self):
        return resolve()[0]

    def __repr__(self):
        d, src = resolve()
        return f"fx.use({d or 'auto'!r} ({src}))"


def resolve(own=None) -> Tuple[Optional[str], str]:
    """(device or None for automatic, where it came from)."""
    if own:
        return str(own), "model"
    if _set["device"]:
        return _set["device"], "fx.use"
    env = os.environ.get("FELIX_DEVICE", "").strip()
    if env and env.lower() != "auto":
        return env, "FELIX_DEVICE"
    return None, "auto"
