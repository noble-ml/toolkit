"""``wf.use(device)``: the device Workflow uses when a call does not name one.

Which device a call runs on, first match wins:

1. the call's own ``device=`` argument
2. ``model.device(...)``, or a ``device=`` passed to an earlier call on the same model
3. ``wf.use(...)`` (for the whole session, or inside ``with wf.use(...):``)
4. the environment variables ``WORKFLOW_TRAIN_DEVICE`` (training only) and ``WORKFLOW_DEVICE``
5. ``"auto"``: CUDA if there is one, else the CPU

Two settings: ``train`` (``model.train``, ``wf.fine_tune``) and ``run`` (predict, evaluate, inference).
``wf.use("cuda")`` sets both. A Modal device (``"modal:A100"``) sets only ``train``, because Modal is for training:
predictions keep running here instead of each becoming a paid cloud call."""
from __future__ import annotations

import os
from typing import Optional, Tuple

from .errors import DeviceError

_set = {"train": None, "run": None}


def _is_modal(device) -> bool:
    from . import cloud
    return cloud.wants(device)


def _check(device, what):
    """Fail now, not halfway through a notebook, if the device does not exist here (or the Modal GPU is unknown)."""
    if device is None:
        return None
    if _is_modal(device):
        if what == "run":
            raise DeviceError(f"run={device!r}: Modal is for training only.",
                              "predictions and evaluations run on this machine.",
                              f"use wf.use(train={str(device)!r}) and a local run device ('auto', 'cpu', 'cuda', 'mps').")
        from . import cloud
        return cloud.Modal.parse(device)
    from .core import device as _device
    _device.get(device)                    # raises DeviceError when it is not available here
    return str(device)


class use:
    """``wf.use("cuda")`` · ``wf.use("modal:A100")`` · ``wf.use(train="modal:H100", run="mps")`` · ``wf.use(None)``
    (back to the defaults). Takes effect at once; as ``with wf.use(...):`` only inside the block. ``wf.use()``
    without arguments changes nothing and shows the current choice (``.train``, ``.run``, and where each comes from)."""

    def __init__(self, device=..., *, train=..., run=...):
        self._before = dict(_set)
        new = dict(_set)
        if device is not ...:
            if device is None:
                new = {"train": None, "run": None}
            elif _is_modal(device):
                new["train"] = _check(device, "train")
            else:
                new["train"] = new["run"] = _check(device, "run")
        if train is not ...:
            new["train"] = _check(train, "train")
        if run is not ...:
            new["run"] = _check(run, "run")
        _set.update(new)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        _set.update(self._before)
        return False

    @property
    def train(self):
        return resolve("train")[0]

    @property
    def run(self):
        return resolve("run")[0]

    def __repr__(self):
        (t, ts), (r, rs) = resolve("train"), resolve("run")
        return f"wf.use(train={str(t)!r} ({ts}), run={str(r)!r} ({rs}))"


def resolve(kind: str, given=None, model=None) -> Tuple[object, str]:
    """(device, where it came from) for ``kind`` "train" or "run"."""
    if given is not None:
        return given, "argument"
    if model is not None and getattr(model, "_device_chosen", False):
        return model.device(), "model.device"
    if _set[kind] is not None:
        return _set[kind], "wf.use"
    for var in (("WORKFLOW_TRAIN_DEVICE", "WORKFLOW_DEVICE") if kind == "train" else ("WORKFLOW_DEVICE",)):
        value = os.environ.get(var, "").strip()
        if value:
            if kind == "run" and _is_modal(value):
                continue                   # WORKFLOW_DEVICE=modal:… means training; predictions stay here
            return value, var
    return "auto", "auto"


def place(model, kind: str, given=None) -> Tuple[object, str]:
    """Move ``model`` to the device a ``kind`` call should use, without counting as the user's own
    ``model.device(...)``. Returns (device, source); a Modal device is returned as is (the model stays here)."""
    dev, source = resolve(kind, given, model)
    if _is_modal(dev):
        return dev, source
    if source == "argument":           # a device= you pass sticks to the model, as model.device(...) would
        model.device(dev)
    elif source != "model.device":
        chosen = model._device_chosen
        model.device(dev)
        model._device_chosen = chosen
    return model.device(), source


def label(dev, source: Optional[str]) -> str:
    """``cuda`` or ``cuda (from wf.use)``: the panel says where a device came from when it was not this call's own."""
    if source in (None, "argument", "auto", "model.device"):
        return str(dev)
    return f"{dev} (from {source})"
