"""``wf.eval(model)`` and ``wf.eval(model, dataset=val)``."""
from __future__ import annotations

import csv
import json
import os
import time
from typing import Dict, List, Optional

from . import _ui, data
from .core import Tensor, no_grad
from .errors import DataError, WorkflowError


class Evaluation:
    """Result of ``wf.eval``. Architecture numbers are always present; accuracy numbers only with a dataset."""

    def __init__(self, **fields):
        self.__dict__.update(fields)

    def to_dict(self) -> Dict:
        return dict(self.__dict__)

    def save(self, path) -> str:
        path = os.fspath(path)
        ext = os.path.splitext(path)[1].lower()
        if ext == ".json":
            with open(path, "w", encoding="utf-8") as f:
                json.dump(self.to_dict(), f, indent=1)
        elif ext == ".csv":
            with open(path, "w", newline="", encoding="utf-8") as f:
                w = csv.writer(f)
                w.writerow(["metric", "value"])
                for k, v in self.to_dict().items():
                    if isinstance(v, (int, float, str)):
                        w.writerow([k, v])
                for name, pc in (self.to_dict().get("per_class") or {}).items():
                    w.writerow([f"ap50[{name}]", pc["ap50"]])
                    w.writerow([f"ap50_95[{name}]", pc["ap50_95"]])
        else:
            raise WorkflowError(f"cannot save an evaluation as {ext or path!r}.", "evaluations are saved as JSON or CSV.", "use a .json or .csv file name.")
        return path

    def show(self) -> None:
        c = _ui.console()
        c.print(_ui._line(("Evaluation", f"bold {_ui.BONE}"), (f"  {self.device} · input {self.img_size[1]}x{self.img_size[0]} · {self.precision}", _ui.ASH)))
        c.print()
        rows = [("parameters", f"{self.parameters:,}"), ("trainable", f"{self.trainable:,}"), ("model size", f"{self.size_mb:,.1f} MB"),
                ("FLOPs", f"{self.flops / 1e9:,.2f} G"), ("latency", f"{self.latency_ms:,.2f} ms (batch 1, forward pass)"),
                ("FPS", f"{self.fps:,.1f}"), ("throughput", f"{self.throughput:,.1f} img/s (batch {self.batch_size})"),
                ("memory", f"{self.memory_mb:,.1f} MB (weights + one image of activations)")]
        if getattr(self, "map50", None) is not None:
            rows += [("images", f"{self.images:,}"), ("mAP50", f"{self.map50:.3f}"), ("mAP50-95", f"{self.map50_95:.3f}"),
                     ("precision", f"{self.precision_score:.3f}"), ("recall", f"{self.recall:.3f}"), ("F1", f"{self.f1:.3f}")]
        if getattr(self, "top1", None) is not None:
            rows += [("images", f"{self.images:,}"), ("top-1 accuracy", f"{self.top1:.3f}"),
                     ("top-5 accuracy", f"{self.top5:.3f}"), ("cross-entropy", f"{self.cross_entropy:.3f}")]
        _ui.table(["metric", "value"], rows, console_=c)
        if getattr(self, "top1", None) is not None and getattr(self, "per_class", None):
            c.print()
            _ui.table(["class", "accuracy", "images"],
                      [(v["class"], "–" if v["accuracy"] is None else f"{v['accuracy']:.3f}", f"{v['images']:,}") for v in self.per_class],
                      right=(1, 2), console_=c)
        elif getattr(self, "per_class", None):
            c.print()
            _ui.table(["class", "AP50", "AP50-95", "instances"],
                      [(n, f"{v['ap50']:.3f}", f"{v['ap50_95']:.3f}", f"{v['instances']:,}") for n, v in self.per_class.items()],
                      right=(1, 2, 3), console_=c)

    def __repr__(self):
        acc = (f", mAP50={self.map50:.3f}, mAP50-95={self.map50_95:.3f}" if getattr(self, "map50", None) is not None else
               f", top1={self.top1:.3f}, top5={self.top5:.3f}" if getattr(self, "top1", None) is not None else "")
        return f"Evaluation(params={self.parameters:,}, FLOPs={self.flops / 1e9:.2f}G, FPS={self.fps:.1f}{acc})"


def _activation_bytes(model) -> int:
    def walk(records):
        total = 0
        for _, layer, _, out, _ in records:
            shapes = out if isinstance(out[0], (tuple, list)) else [out]
            total += sum(s[0] * s[1] * s[2] for s in shapes) * 4
        return total
    return walk(model._records)


def evaluate(model, dataset=None, device: Optional[str] = None, img_size=None, batch_size: int = 8,
             confidence: float = 0.001, iou: float = 0.6, show: bool = True) -> Evaluation:
    """Without a dataset: parameters, model size, FLOPs, latency, FPS/throughput and memory.
    With a dataset (a Felix split): additionally mAP50, mAP50-95, precision, recall, F1 and per-class AP.
    Works before and after training and never changes the model's weights or training state."""
    from .train import run_eval
    model._ensure()
    from . import _use
    dev, _ = _use.place(model, "run", device)
    size = (img_size, img_size) if isinstance(img_size, int) else tuple(img_size) if img_size else (model.input[1], model.input[2])
    model.check((model.input[0], *size))
    saved_input = model.input
    model.build((model.input[0], *size))                       # FLOPs for the evaluated size
    tr, fr = model.count_parameters()
    macs, act = model._macs, _activation_bytes(model)
    model.build(saved_input)

    def timed(bs, iters=10, warm=2):
        x = Tensor.zeros((bs, model.input[0], *size), dev)
        done = getattr(dev.be, "flush", lambda ts: None)       # lazy backends: make each pass really run

        def once():
            out = model(x)
            done(out if isinstance(out, (list, tuple)) else [out])

        with no_grad():
            for _ in range(warm):
                once()
            dev.be.sync()
            t = time.perf_counter()
            for _ in range(iters):
                once()
            dev.be.sync()
        return (time.perf_counter() - t) / iters

    t1, tb = timed(1), timed(batch_size)
    fields = dict(device=str(dev), img_size=tuple(size), precision=model.precision, parameters=tr + fr, trainable=tr,
                  size_mb=(tr + fr) * {"fp32": 4, "fp16": 2, "int8": 1}.get(model.precision, 4) / 2**20,
                  macs=macs, flops=2 * macs, latency_ms=1000 * t1, fps=1 / t1, batch_size=batch_size,
                  throughput=batch_size / tb, memory_mb=((tr + fr) * 4 + act) / 2**20)
    if dataset is not None:
        ds = data.as_dataset(dataset)
        if hasattr(ds, "splits"):
            ds = ds.val if len(ds.val) else ds.test if len(ds.test) else ds
        if len(ds) == 0:
            raise DataError("the dataset to evaluate is empty.", "it has no image/annotation pairs.", "pass a split with images, e.g. dataset.val.")
        head = model.head()
        names = ds.classes or model.class_names or [str(i) for i in range(head.classes)]
        if len(names) != head.classes:
            raise DataError("the dataset and the model disagree on the number of classes.",
                            f"the dataset has {len(names)} classes but the model ends with wf.head(classes={head.classes}).",
                            "evaluate on a dataset with the model's classes.")
        panel = _ui.Panel("", quiet=not show)
        panel.title = panel.join("Workflow eval", f"{len(ds):,} images", str(dev))
        row = panel.row("evaluate", len(ds))
        if head.type == "cls":
            from .train import run_eval_cls
            with panel:
                m, ms = run_eval_cls(model, data.Batches(ds, size, batch_size, dev, task="classify"), names,
                                     progress=(panel, row), with_loss=False)
                row.done()
                row.stats = panel.join(f"top-1 {m['top1']:.3f}", f"top-5 {m['top5']:.3f}")
            fields.update(images=len(ds), top1=m["top1"], top5=m["top5"], cross_entropy=m["ce"], per_class=m["per_class"],
                          confusion_matrix=m["confusion_matrix"], class_names=list(names), eval_latency_ms=ms)
        else:
            with panel:
                m, ms = run_eval(model, data.Batches(ds, size, batch_size, dev), size, names, confidence, iou, progress=(panel, row))
                row.done()
                row.stats = panel.join(f"mAP50 {m['map50']:.3f}", f"mAP50-95 {m['map50_95']:.3f}")
            fields.update(images=len(ds), map50=m["map50"], map50_95=m["map50_95"], precision_score=m["precision"],
                          recall=m["recall"], f1=m["f1"], conf_threshold=m["conf"], per_class=m["per_class"],
                          confusion_matrix=m["confusion_matrix"], class_names=list(names), eval_latency_ms=ms)
    res = Evaluation(**fields)
    if show:
        res.show()
    return res
