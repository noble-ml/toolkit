"""Inference: load → letterbox → forward → decode + NMS → results on disk and in memory."""
from __future__ import annotations

import os
from typing import List

from . import _stale
_stale.check()      # an upgraded install inside an old session stops here, clearly

from . import classify, data, detect
from .core import no_grad
from .results import ClassResult, Predictions, Results, write_json


def predict(model, source, device, confidence, iou, img_size, output, max_detections):
    single = not isinstance(source, (list, tuple))
    sources = [source] if single else list(source)
    cls = model.head().type == "cls"
    from . import _use
    dev, _ = _use.place(model, "run", device)
    size = (img_size, img_size) if isinstance(img_size, int) else tuple(img_size) if img_size else (model.input[1], model.input[2])
    model.check((model.input[0], *size))
    from .core import device as _device
    cpu = _device.get("cpu")
    results: List[Results] = []
    with no_grad():                                           # no gradients, no weight updates
        for i in range(0, len(sources), 16):
            loaded = [data.load_image(s) for s in sources[i:i + 16]]
            batch = cpu.be.empty((len(loaded), 3, size[0], size[1]))
            geo = [data.fill(batch, j, rgb, w, h) for j, (rgb, w, h, _) in enumerate(loaded)]
            if cls:                                           # one label per image
                for (rgb, w, h, path), (probs, top) in zip(loaded, classify.decode(model(batch.to(dev), train=False))):
                    results.append(ClassResult(rgb, w, h, probs, top, model.class_names, path))
                continue
            dets = detect.decode(model(batch.to(dev), train=False), size, confidence, iou, max_detections)
            for (rgb, w, h, path), (s, px, py), rows in zip(loaded, geo, dets):
                clip = lambda v, hi: max(0.0, min(float(hi), v))
                rows = [[clip((r[0] - px) / s, w), clip((r[1] - py) / s, h), clip((r[2] - px) / s, w), clip((r[3] - py) / s, h), r[4], r[5]]
                        for r in rows]
                results.append(Results(rgb, w, h, rows, model.class_names, path))
    if output is not None:
        os.makedirs(output, exist_ok=True)
        used = set()
        for k, r in enumerate(results):
            stem = os.path.splitext(os.path.basename(r.path))[0] if r.path else f"image_{k + 1}"
            name, n = stem, 1
            while name in used:
                n += 1
                name = f"{stem}_{n}"
            used.add(name)
            r.saved_to = r.save(os.path.join(output, name + ".png"))
        write_json(results, os.path.join(output, "predictions.json"))
    return results[0] if single else Predictions(results)
