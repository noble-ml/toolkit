"""Training on Modal's cloud GPUs: ``model.train(data, device="modal")`` (or ``"modal:A100"``, or ``wf.Modal(...)``).

The dataset goes up once to a Modal Volume (named ``workflow`` unless chosen otherwise) and is reused by every later
run while it is unchanged; the model goes up as a ``.nbm``; training runs remotely on ``cuda`` with exactly the same
code, maths and fp32 as a local run, and saves its checkpoints on the Volume as it goes (so a dropped connection,
a time-out or Ctrl+C never loses them). At the end (however it ends) the checkpoints come back into ``output`` and
the local model holds the trained weights, just as after a local run.

Needs ``pip install modal`` and ``modal token new`` once. Modal bills the GPU time to your Modal account."""
from __future__ import annotations

import hashlib
import os
import secrets
import sys
import tempfile
import time
from typing import Optional

from .errors import DeviceError

#: Modal GPU types (lower-case alias → Modal name)
GPUS = {"t4": "T4", "l4": "L4", "a10": "A10G", "a10g": "A10G", "l40s": "L40S", "a100": "A100", "a100-40gb": "A100-40GB",
        "a100-80gb": "A100-80GB", "h100": "H100", "h200": "H200", "b200": "B200", "cpu": "cpu"}
DEFAULT_GPU = "L4"
VOLUME = "workflow"
MOUNT = "/vol"


class Modal:
    """``wf.Modal(gpu="A100", hours=24, volume="workflow")``: where ``model.train(device=...)`` runs on Modal.

    ``gpu``: T4, L4 (default), A10G, L40S, A100, A100-80GB, H100, H200 or B200; ``"cpu"`` trains on Modal CPU cores
    instead (no GPU, Workflow's native C core). ``cpus``: CPU cores reserved (default 8 next to a GPU, enough to decode
    pictures as fast as the GPU learns from them; 16 for ``"cpu"``). ``hours``: the longest a run may take
    (Modal's limit is 24); a run that hits it still keeps its checkpoints, and training again continues from them.
    ``volume``: the Modal Volume that keeps datasets and runs. The string ``"modal:A100"`` is the same as
    ``wf.Modal(gpu="A100")``."""

    def __init__(self, gpu: str = DEFAULT_GPU, hours: float = 24, volume: str = VOLUME, cpus: Optional[int] = None):
        key = str(gpu).lower().strip()
        if key not in GPUS:
            raise DeviceError(f"unknown Modal GPU {gpu!r}.", "Modal offers " + ", ".join(sorted(set(GPUS.values()))) + ".",
                              f"pass one of those, e.g. device='modal:{DEFAULT_GPU}'.")
        if not 0 < float(hours) <= 24:
            raise DeviceError(f"hours={hours} is out of range.", "a Modal function may run for at most 24 hours.",
                              "pass hours between 0 and 24; a longer training continues from its checkpoint when trained again.")
        self.gpu, self.hours, self.volume = GPUS[key], float(hours), str(volume)
        self.cpus = int(cpus) if cpus else (16 if self.gpu == "cpu" else 8)

    def __repr__(self):
        return f"modal:{self.gpu}"

    __str__ = __repr__

    @classmethod
    def parse(cls, device) -> Optional["Modal"]:
        """A Modal target for ``device``, or None when it is a local device."""
        if isinstance(device, Modal):
            return device
        if isinstance(device, str) and device.lower().strip().partition(":")[0] == "modal":
            gpu = device.strip().partition(":")[2]
            return cls(gpu or DEFAULT_GPU)
        return None


def wants(device) -> bool:
    return Modal.parse(device) is not None


# ---------------------------------------------------------------------------------------------- the Modal app
def _modal():
    try:
        import modal
    except ImportError:
        raise DeviceError("device='modal' needs the Modal client.", "the `modal` package is not installed.",
                          "run `pip install modal`, then `modal token new` once to sign in.") from None
    return modal


def _package_dir(name: str) -> Optional[str]:
    try:
        mod = __import__(name)
    except ImportError:
        return None
    return os.path.dirname(os.path.abspath(mod.__file__))


def _image(modal):
    """Python like the local one, Workflow's two dependencies, and the local workflow (and felix) packages as they are
    installed here, so the remote code is exactly the code that runs locally. Workflow's prebuilt Linux core and its
    CUDA kernels ship inside the package; Modal's GPU machines bring the NVIDIA driver."""
    image = (modal.Image.debian_slim(python_version=f"{sys.version_info[0]}.{sys.version_info[1]}")
             .pip_install("rich>=13", "Pillow>=9.1")
             .env({"PYTHONPATH": "/opt/wf", "PYTHONUNBUFFERED": "1"}))
    skip = ["**/__pycache__", "**/__pycache__/**", "**/*.pyc"]
    image = image.add_local_dir(_package_dir("workflow"), "/opt/wf/workflow", ignore=skip)
    felix_dir = _package_dir("felix")
    if felix_dir:      # Felix reads the datasets; its bundled YOLO weights are not needed for training
        image = image.add_local_dir(felix_dir, "/opt/wf/felix", ignore=skip + ["model_weights/*.pt"])
    return image


def _app(modal, target, volume):
    """The app with one function, made for this run's GPU, time limit and Volume. ``serialized``: the container gets
    the function by reference to this module, which is on its PYTHONPATH."""
    app = modal.App("workflow-train")
    on_cpu = target.gpu == "cpu"
    fn = app.function(image=_image(modal), gpu=None if on_cpu else target.gpu, cpu=float(target.cpus),
                      timeout=int(target.hours * 3600), volumes={MOUNT: volume},
                      name="train", serialized=True)(_remote_train)
    return app, fn


class _Relay:
    """Inside the container: sends the training panel and printed lines to the machine that started the run (through
    a Modal Queue, a few times a second), and turns a "stop" from there into a Ctrl+C-style stop of the training."""

    def __init__(self, queue):
        import threading
        self.q, self.buf, self.lock, self.panel = queue, [], threading.Lock(), None
        self.ids, self.last, self.done, self.stops = {}, 0.0, threading.Event(), 0
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def mirror(self, panel, force, final):
        now = time.time()
        if not (force or final or now - self.last >= 0.5):
            return
        self.last, self.panel = now, panel
        pid = self.ids.setdefault(id(panel), len(self.ids))
        with self.lock:
            self.buf = [m for m in self.buf if not (m[0] == "panel" and m[1] == pid and not m[3])]  # only the newest
            self.buf.append(("panel", pid, panel.snapshot(), final))

    def write(self, text):
        if text:
            with self.lock:
                self.buf.append(("print", text))
        return len(text)

    def flush(self):
        pass

    def _send(self):
        with self.lock:
            batch, self.buf = self.buf, []
        if batch:
            try:
                self.q.put_many(batch, partition="out")
            except Exception:              # the viewer went away: training goes on, the Volume keeps the checkpoints
                pass

    def _loop(self):
        from . import train as _train
        while not self.done.is_set():
            self.done.wait(0.4)
            self._send()
            try:
                if self.q.get(block=False, partition="stop") is not None:
                    _train.REMOTE_STOP.set()
                    if self.panel is not None:
                        self.panel.note("stopping after this step and saving… (Ctrl+C again to stop at once)")
                        self.mirror(self.panel, True, False)
            except Exception:
                pass

    def close(self):
        self.done.set()
        self.thread.join(timeout=5)
        self._send()


def _remote_train(model_bytes: bytes, train_ref, val_ref, options: dict, run: str, queue=None):
    """Runs on the Modal machine."""
    import modal
    from . import _ui, nbm, train as _train
    from .core import device as _device
    relay = _Relay(queue) if queue is not None else None
    real_stdout = sys.stdout
    if relay is not None:
        _ui.MIRROR = relay.mirror
        sys.stdout = relay
    volume = modal.Volume.from_name(options.pop("_volume"))
    try:
        on_cpu = options.pop("_cpu")
        if not on_cpu:
            ok, why = _device.cuda_status()
            if not ok:
                raise DeviceError("the Modal machine has no usable GPU.", why, "try another gpu type.")
            print(f"Modal: {why}", flush=True)
        path = os.path.join(tempfile.mkdtemp(), "start.nbm")
        with open(path, "wb") as f:
            f.write(model_bytes)
        model = nbm.load(path)
        options = dict(options, device="cpu" if on_cpu else "cuda", output=f"{MOUNT}/runs/{run}")
        local = {}
        return _train.fit(model, _open(train_ref, local), _open(val_ref, local), **options)
    finally:
        volume.commit()
        sys.stdout, _ui.MIRROR = real_stdout, None
        if relay is not None:
            relay.close()


def _open(ref, local):
    if ref is None:
        return None
    import felix
    ds = felix.load(_to_local_disk(ref["path"], local))
    if ref.get("stems") is None:
        return ds
    from felix.store import Subset
    return Subset(ds, ref.get("name") or "subset", ref["stems"])


def _to_local_disk(path: str, done: dict) -> str:
    """Copy a dataset from the Volume to the machine's own disk before training: every epoch then reads it at local
    speed instead of over the network. Stays on the Volume if the disk is too small for it."""
    import shutil
    if path in done:
        return done[path]
    top = path[len(MOUNT) + 1:].split("/")
    src = f"{MOUNT}/{top[0]}/{top[1]}"           # datasets/NAME-FINGERPRINT
    files = _files(src)
    size = sum(os.path.getsize(f) for _, f in files)
    dst = os.path.join("/tmp/workflow-data", top[1])
    if shutil.disk_usage("/tmp").free < size * 1.2 + 2**30:
        print(f"Modal: reading the dataset from the Volume ({size / 2**20:,.0f} MB is too big for the local disk)", flush=True)
        done[path] = path
        return path
    t = time.time()
    if not os.path.exists(os.path.join(dst, ".workflow-complete")):
        shutil.copytree(src, dst + ".part", dirs_exist_ok=True)
        os.replace(dst + ".part", dst)
    print(f"Modal: dataset copied to the machine's own disk ({size / 2**20:,.1f} MB in {time.time() - t:.1f} s)", flush=True)
    done[path] = os.path.join(dst, *top[2:])
    return done[path]


# ---------------------------------------------------------------------------------------------- datasets
def _where(ds):
    """(local path, stems or None, split name) of a dataset, split or dataset path."""
    if ds is None:
        return None
    if isinstance(ds, (str, os.PathLike)):
        return os.fspath(ds), None, None
    parent = getattr(ds, "parent", None)
    if parent is not None and hasattr(parent, "path"):
        return os.fspath(parent.path), list(ds.stems), getattr(ds, "name", None)
    if hasattr(ds, "path") and os.path.exists(os.fspath(ds.path)):
        return os.fspath(ds.path), None, None
    raise DeviceError(f"cannot send {type(ds).__name__} to Modal.", "training on Modal uploads the dataset's files, and this "
                      "dataset has no folder or .felix file behind it.",
                      "export it with Felix first (fx.export(...)) and pass fx.load(path) or the path.")


def _files(path):
    if os.path.isfile(path):
        return [(os.path.basename(path), path)]
    out = []
    for d, dirs, names in os.walk(path):
        dirs[:] = sorted(x for x in dirs if not x.startswith(".") and x != "__pycache__")
        for n in sorted(names):
            if not n.startswith(".") and not n.endswith(".part"):
                full = os.path.join(d, n)
                out.append((os.path.relpath(full, path).replace(os.sep, "/"), full))
    return out


def _fingerprint(files) -> str:
    h = hashlib.sha256()
    for rel, full in files:
        st = os.stat(full)
        h.update(f"{rel}\0{st.st_size}\0{st.st_mtime_ns}\n".encode())
    return h.hexdigest()[:16]


def _upload(modal, volume, path, quiet):
    """The dataset's folder on the Volume, uploading it only if this exact version is not there yet."""
    path = os.path.abspath(path)
    if not os.path.exists(path):
        raise DeviceError(f"dataset not found: {path!r}.", "the path does not exist.", "check the path.")
    files = _files(path)
    name = os.path.basename(path.rstrip(os.sep)) or "dataset"
    key = f"datasets/{name}-{_fingerprint(files)}"
    remote = f"{key}/{name}" if os.path.isfile(path) else key
    try:
        if any(e.path.rstrip("/").endswith(".workflow-complete") for e in volume.listdir(key)):
            if not quiet:
                print(f"Modal: dataset {name} is already on the Volume", flush=True)
            return f"{MOUNT}/{remote}"
    except Exception:            # not there yet
        pass
    size = sum(os.path.getsize(f) for _, f in files)
    from . import _ui
    panel = _ui.Panel("", quiet=quiet)
    panel.title = panel.join("Modal upload", name, f"{len(files):,} file{'s' * (len(files) != 1)}", f"{size / 2**20:,.1f} MB")
    panel.sub = "only once: later runs reuse it while the dataset is unchanged"
    bar = _UploadBar(panel.row("upload", size))
    with panel:
        with _uploader(modal, volume, bar) as up:
            if os.path.isfile(path):
                up.put_file(path, f"{key}/{name}")
            else:
                up.put_directory(path, key)
        with volume.batch_upload(force=True) as up:       # last, so a half-finished upload is never taken as done
            up.put_file(_marker(), f"{key}/.workflow-complete")
        bar.row.done()
        bar.row.label = f"{size / 2**20:,.1f} MB in {panel.elapsed:.0f} s"
    return f"{MOUNT}/{remote}"


class _UploadBar:
    """Modal's upload progress callback (the one ``modal volume put`` uses) → a Workflow bar in bytes."""

    def __init__(self, row):
        self.row, self.files, self.t0 = row, {}, time.time()
        row.status, row.label = "running", "checking the files…"

    def __call__(self, task_id=None, *, name=None, size=None, advance=None, complete=False, **_):
        if name is not None:                     # a new file
            tid = len(self.files) + 1
            self.files[tid] = [int(size or 0), 0]
            return tid
        f = self.files.get(task_id)
        if f is None:
            return None
        step = int(advance or 0)
        if complete:
            step = max(step, f[0] - f[1])
        step = min(step, f[0] - f[1])
        if step > 0:
            f[1] += step
            self.row.n += step
            rate = self.row.n / max(1e-6, time.time() - self.t0)
            self.row.label = f"{self.row.n / 2**20:,.0f} / {self.row.total / 2**20:,.0f} MB · {rate / 2**20:,.1f} MB/s"
            self.row.advance(0)
        return None


def _uploader(modal, volume, bar):
    """A batch upload that reports progress, or the plain one if this Modal version changed the private hook."""
    try:
        from modal.volume import AbstractVolumeUploadContextManager
        from modal._utils.async_utils import synchronizer
        volume.hydrate()
        version = synchronizer._translate_in(volume)._metadata.version
        return AbstractVolumeUploadContextManager.resolve(version, volume.object_id, volume.client,
                                                          progress_cb=bar, force=True)
    except Exception:
        bar.row.label = "uploading (this Modal version gives no progress)…"
        return volume.batch_upload(force=True)


def _marker():
    import io
    return io.BytesIO(b"complete\n")


def _ref(modal, volume, ds, quiet, sent):
    """``sent``: paths already uploaded in this run (train and validation are usually one dataset)."""
    w = _where(ds)
    if w is None:
        return None
    path, stems, name = w
    if path not in sent:
        sent[path] = _upload(modal, volume, path, quiet)
    return {"path": sent[path], "stems": stems, "name": name}


# ---------------------------------------------------------------------------------------------- local side
def fit(a: dict):
    """``train.fit`` for a Modal device. ``a``: the arguments of ``train._fit`` by name."""
    from . import nbm
    modal = _modal()
    target = Modal.parse(a["device"])
    model, quiet, output = a["model"], a["quiet"], a["output"]
    volume = modal.Volume.from_name(target.volume, create_if_missing=True)
    try:
        sent = {}
        train_ref = _ref(modal, volume, a["train"], quiet, sent)
        val_ref = _ref(modal, volume, a["validation"], quiet, sent)
    except DeviceError:
        raise
    except Exception as e:
        raise DeviceError("Modal could not be reached.", f"{type(e).__name__}: {e}",
                          "check the connection and that you are signed in (`modal token new`).") from None
    run = time.strftime("%Y%m%d-%H%M%S") + "-" + secrets.token_hex(3)
    with tempfile.TemporaryDirectory() as tmp:
        start = os.path.join(tmp, "start.nbm")
        model._ensure()
        model.save(start)
        with open(start, "rb") as f:
            model_bytes = f.read()
    options = {k: v for k, v in a.items() if k not in ("model", "train", "validation", "device", "output")}
    options["_volume"], options["_cpu"] = target.volume, target.gpu == "cpu"
    if not quiet:
        where = f"{target.cpus} CPU cores" if target.gpu == "cpu" else f"a {target.gpu} + {target.cpus} CPU cores"
        print(f"Modal: training on {where} · run {run} (checkpoints also kept on the Volume under runs/{run})",
              flush=True)
    app, fn = _app(modal, target, volume)
    interrupted = None
    try:
        _watch(modal, app, fn, (model_bytes, train_ref, val_ref, options, run), quiet, target,
               rename=(f"{MOUNT}/runs/{run}", output))
    except KeyboardInterrupt as e:
        interrupted = e
        print("\nModal: stopped at once; fetching the last checkpoint", flush=True)
    except Exception as e:
        interrupted = e
        if "payment method" in str(e).lower():
            raise DeviceError(f"Modal will not start a {target.gpu} for this account.", str(e).strip(),
                              "add a payment method at https://modal.com/settings (Modal's free monthly credit "
                              "covers small runs once one is on file), then train again.") from None
    got = _download(volume, run, output)
    last = os.path.join(output, "last.nbm")
    if os.path.exists(last):
        classes = nbm.read_meta(last).get("classes")
        if classes and list(classes) != list(model.class_names or []):
            model.set_classes(list(classes))     # wf.fine_tune for new classes rebuilt the head remotely
        nbm.restore(model, last)
    if interrupted is not None and not isinstance(interrupted, KeyboardInterrupt):
        if got:
            print(f"Modal: the run ended with an error; its checkpoints are in {output}", flush=True)
        raise interrupted
    if not quiet and got:
        print(f"Modal: {len(got)} checkpoint(s) saved in {output}", flush=True)
    return model.history


def _watch(modal, app, fn, args, quiet, target, rename=None):
    """Start the run and show it here: the remote training panel is redrawn locally (terminal or notebook), printed
    lines appear as they are printed. Ctrl+C asks the remote training to save and stop after its step, as it would
    locally; a second Ctrl+C stops it at once (the autosaved checkpoint is still kept)."""
    from . import _ui
    timeouts = tuple({TimeoutError, getattr(modal.exception, "TimeoutError", TimeoutError)})
    panels = {}

    def show(msgs):
        for m in msgs:
            if m[0] == "print":
                if not quiet:
                    sys.stdout.write(m[1].replace(*rename) if rename else m[1])   # remote paths → where they land here
                    sys.stdout.flush()
                continue
            _, pid, snap, final = m
            p = panels.get(pid)
            if p is None:
                p = panels[pid] = _ui.Panel("", quiet=quiet)
                p.restore(snap)
                p.__enter__()
            else:
                p.restore(snap)
                p.refresh(force=True)
            if final:
                p.__exit__(None, None, None)
                del panels[pid]

    import queue as _queue

    def take(q, block):
        try:
            return q.get_many(1000, block=block, timeout=0.5 if block else None, partition="out")
        except _queue.Empty:
            return []

    with modal.Queue.ephemeral() as q:
        with app.run():
            if not quiet:
                print(f"Modal: starting the machine (the first run also builds its image, about a minute) · "
                      f"{app.get_dashboard_url()}", flush=True)
            call = fn.spawn(*args, q)
            presses = _CtrlC()
            sent = False
            with presses:
                while True:
                    try:
                        if presses.count and not sent:
                            sent = True
                            q.put("stop", partition="stop")
                            if not quiet:
                                print("\nModal: stopping after this step and saving… (Ctrl+C again to stop at once)",
                                      flush=True)
                        show(take(q, True))
                        try:
                            result = call.get(timeout=0)
                            break
                        except timeouts:
                            continue
                    except KeyboardInterrupt:            # the second Ctrl+C
                        for p in panels.values():
                            p.__exit__(KeyboardInterrupt, None, None)
                        raise
                    except Exception:
                        show(take(q, False))
                        for p in panels.values():
                            p.__exit__(RuntimeError, None, None)
                        raise
            show(take(q, False))
            for p in list(panels.values()):
                p.__exit__(None, None, None)
            return result


class _CtrlC:
    """While a Modal run is watched: the first Ctrl+C is only counted (the loop then asks the remote training to stop
    and save), so it never lands inside a Modal call, which would cancel the run at once; the second raises."""

    def __init__(self):
        self.count, self.old = 0, None

    def _handle(self, sig, frame):
        self.count += 1
        if self.count >= 2:
            raise KeyboardInterrupt

    def __enter__(self):
        import signal
        import threading
        if threading.current_thread() is threading.main_thread():
            self.old = signal.signal(signal.SIGINT, self._handle)
        return self

    def __exit__(self, *exc):
        import signal
        if self.old is not None:
            signal.signal(signal.SIGINT, self.old)
        return False


def _download(volume, run, output):
    try:
        entries = [e for e in volume.listdir(f"runs/{run}") if e.path.endswith(".nbm")]
    except Exception:
        return []
    os.makedirs(output, exist_ok=True)
    got = []
    for e in entries:
        dst = os.path.join(output, os.path.basename(e.path))
        with open(dst + ".part", "wb") as f:
            volume.read_file_into_fileobj(e.path, f)
        os.replace(dst + ".part", dst)
        got.append(dst)
    return got


def pull(run: str, output: str = "runs/train", volume: str = VOLUME):
    """``wf.Modal.pull("20261123-101500-a1b2c3")``: copy a Modal run's checkpoints into ``output`` (for a run whose
    connection dropped before they came back). Returns the files."""
    modal = _modal()
    got = _download(modal.Volume.from_name(volume), run, output)
    if not got:
        raise DeviceError(f"no checkpoints for Modal run {run!r}.", f"the Volume {volume!r} has nothing under runs/{run}.",
                          "check the run name (`modal volume ls workflow runs`).")
    return got


Modal.pull = staticmethod(pull)
