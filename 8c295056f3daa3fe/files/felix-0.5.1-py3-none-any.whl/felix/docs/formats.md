# Dataset formats

## Folder

```
dataset/
├── images/IMG1.png ...        (converted datasets may keep .jpg)
├── annotations/IMG1.yml ...
└── metadata.yml
```

## `.felix`

A single file for the same tree - a standard ZIP archive (PNG/JPEG stored, YAML deflated),
so `unzip` and Python's `zipfile` can open it. `felix pack` / `felix unpack` convert between
the two; `fx.make(output="x.felix")` writes it directly (via a `.part` file, so a crash never
leaves a half-written dataset).

## `annotations/IMG1.yml`

```yaml
image: IMG1.png
width: 640
height: 640
step: step-1          # generated datasets
split: train          # converted datasets only
objects:
  - class: cat
    class_id: 0
    class_set: animals
    bbox: [316, 163, 62, 62]   # x, y, width, height in pixels, top-left origin
```

## `metadata.yml`

```yaml
felix_version: "0.1.0"
created: "2026-11-10T08:17:58Z"
pairs: 200
seed: 1                 # generated datasets: re-run with the same seed to reproduce
image_format: png
bbox_format: xywh
steps:
  - name: step-1
    size: [640, 640]
classes:
  - id: 0
    name: cat
    set: animals
```

Splits are not stored for generated datasets: `ds.train` / `ds.val` / `ds.test` derive them deterministically from
the seed (see the API page), and converted datasets keep their `split` field.

The YAML is plain and valid; any YAML parser reads it. Felix itself uses a tiny built-in
reader so it needs no dependencies.
