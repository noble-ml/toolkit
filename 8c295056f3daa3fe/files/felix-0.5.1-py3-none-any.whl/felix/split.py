"""Make a smaller copy of a dataset for quick experiments; the original is never touched."""
from __future__ import annotations

import os
import random
from typing import Optional

from . import _yaml
from ._ui import Panel, fmt_n
from .errors import FelixError
from .store import EXT, Dataset, open_writer

SPLITS = ("train", "val", "test")


def _pct(fraction: float) -> str:
    p = fraction * 100
    return f"{p:.0f}" if abs(p - round(p)) < 1e-9 else f"{p:.4g}"


def choose(ds: Dataset, fraction: Optional[float] = None, size: Optional[int] = None, seed: int = 0):
    """The pairs to keep: the same share of every train / val / test split, picked at random (reproducible with
    ``seed``) and kept in their original order. Returns (stems, {split: (kept, of)})."""
    if (fraction is None) == (size is None):
        raise FelixError("give either a fraction (0.5 keeps half) or size=N (keep N pairs), not both")
    n = len(ds)
    if n == 0:
        raise FelixError("the dataset is empty")
    if size is not None:
        if not isinstance(size, int) or size < 1:
            raise FelixError(f"size must be a positive whole number, got {size!r}")
        if size > n:
            raise FelixError(f"size={size} is more than the {fmt_n(n)} pairs in the dataset")
        fraction = size / n
    else:
        try:
            fraction = float(fraction)
        except (TypeError, ValueError):
            raise FelixError(f"the fraction must be a number such as 0.5, got {fraction!r}") from None
        if not 0 < fraction <= 1:
            hint = f" (for {fraction:g}% write {fraction / 100:g})" if 1 < fraction <= 100 else ""
            raise FelixError(f"the fraction must be above 0 and at most 1, got {fraction:g}{hint}")
    rng = random.Random(seed)
    groups = [(k, list(getattr(ds, k).stems)) for k in SPLITS if ds.splits.get(k)]
    if not groups:                                          # no splits: sample the whole dataset
        groups = [(None, list(ds.stems))]
    want = [g for _, g in groups]
    total = size if size is not None else None
    exact = [len(g) * fraction for g in want]
    counts = [max(1, int(e)) for e in exact]                # every split that existed keeps at least one pair
    if total is not None:                                   # size=N: hand out the remainder by largest fraction
        for i in sorted(range(len(want)), key=lambda i: exact[i] - int(exact[i]), reverse=True):
            if sum(counts) >= total:
                break
            if counts[i] < len(want[i]):
                counts[i] += 1
        while sum(counts) > total:                          # max(1, ...) overshot on tiny splits
            i = max(range(len(counts)), key=lambda i: counts[i])
            counts[i] -= 1
    else:
        counts = [min(len(g), max(1, round(e))) for g, e in zip(want, exact)]
    order = {s: i for i, s in enumerate(ds.stems)}
    kept, report = [], {}
    for (name, g), c in zip(groups, counts):
        pick = rng.sample(g, c)
        kept += pick
        report[name or "all"] = (c, len(g))
    kept.sort(key=order.get)
    return kept, report


def split(source, fraction: Optional[float] = None, output: Optional[str] = None, *, size: Optional[int] = None,
          seed: int = 0, overwrite: bool = False, quiet: bool = False) -> str:
    """Copy a share of ``source`` into a new dataset and return its path. The source stays as it is.

    ``split("voc.felix", 0.5)`` writes ``voc_split_50.felix`` next to it with half the pairs: the same share of each
    train / val / test split, chosen at random (``seed`` makes it repeatable; another seed gives another subset).
    ``size=1000`` keeps 1000 pairs instead of a fraction. ``output`` picks the path (a ``.felix`` file, or a folder
    name for an unpacked dataset); by default the copy is the same kind as the source."""
    ds = source if isinstance(source, Dataset) else Dataset(source)
    try:
        stems, report = choose(ds, fraction, size, seed)
        src = ds.path.rstrip("/\\")
        packed = src.lower().endswith(EXT)
        base = src[:-len(EXT)] if packed else src
        tag = str(size) if size is not None else _pct(float(fraction))
        path = str(output) if output else f"{base}_split_{tag}{EXT if packed else ''}"
        if os.path.abspath(path) == os.path.abspath(src):
            raise FelixError("the output would replace the source; split writes a new copy, choose another path")
        panel = Panel("", quiet=quiet)
        panel.title = panel.join("Felix split", os.path.basename(src), f"{fmt_n(len(ds))} pairs",
                                 f"keeping {fmt_n(len(stems))}" + (f" ({_pct(len(stems) / len(ds))}%)" if len(ds) else ""))
        panel.sub = panel.join("Worker running", f"seed {seed}",
                               " · ".join(f"{k} {fmt_n(a)}/{fmt_n(b)}" for k, (a, b) in report.items()))
        row = panel.row(os.path.basename(path), len(stems))
        # Every pair keeps the split it has in the source. Datasets whose splits are worked out from their seed get
        # them written into the copied annotations, so the smaller copy cannot reshuffle val/test images into train.
        member = {s: k for k in SPLITS for s in getattr(ds, k).stems}
        stored = bool(ds.metadata.get("splits"))
        w = open_writer(path, overwrite)
        try:
            with panel:
                counts = {}
                for stem in stems:
                    raw = ds._r.read(f"annotations/{stem}.yml")
                    ann = _yaml.loads(raw.decode("utf-8"))
                    w.write(f"images/{ann['image']}", ds._r.read("images/" + ann["image"]))
                    if not stored:
                        ann["split"] = member[stem]
                        raw = _yaml.dumps(ann).encode("utf-8")
                    w.write(f"annotations/{stem}.yml", raw)
                    counts[member[stem]] = counts.get(member[stem], 0) + 1
                    row.advance()
                meta = dict(ds.metadata)
                meta["pairs"] = len(stems)
                meta["splits"] = {k: counts[k] for k in SPLITS if k in counts}
                meta["split_from"] = {"source": os.path.basename(src), "pairs": len(ds), "seed": seed,
                                      **({"size": size} if size is not None else {"fraction": float(fraction)})}
                w.write("metadata.yml", _yaml.dumps(meta).encode("utf-8"))
                w.close()
                row.done()
                row.foot = f"written to {path}  ·  {os.path.basename(src)} is unchanged"
        except BaseException:
            w.abort()
            raise
        return path
    finally:
        if not isinstance(source, Dataset):
            ds.close()
