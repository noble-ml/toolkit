# API reference

`import felix as fx`

## Classes

### `fx.class_set(name)`
Context manager. Shapes created inside become classes of the set `name`. Re-using a name adds
to the same set. Class names must be unique across the whole project.

### `fx.toolkit` shapes
All return a shape; all accept `position=(x, y)` (default placement), `name=` (override the
inferred class name) and, except `image`, `color=` (hex, CSS name or RGB tuple).

| Function | Parameters |
|---|---|
| `circle` | `radius` |
| `rectangle` | `width`, `height` |
| `polygon` | `vertices=[(x, y), ...]` (≥ 3) |
| `image` | `source` path, optional `width` / `height` (keeps aspect if only one). Use PNGs with transparency for tight boxes. Relative paths resolve against the working directory, then the calling script's folder. |

### `fx.stack(*parts, position=None, color=None, name=None)`
One object built from several shapes:

```python
with fx.class_set("animals"):
    cat = fx.stack(
        fx.toolkit.polygon(vertices=[(0, 14), (7, 0), (14, 14)], position=(-13, -22)),   # left ear
        fx.toolkit.polygon(vertices=[(0, 14), (7, 0), (14, 14)], position=(13, -22)),    # right ear
        fx.toolkit.circle(radius=22),                                                     # head
        fx.toolkit.circle(radius=3, position=(-8, -4), color="black"),                    # eyes
        fx.toolkit.circle(radius=3, position=(8, -4), color="black"),
        color="#e8a33d",
    )
```

- Inside `fx.class_set` the stack is **one class**, named after its variable (`cat`); its parts are not classes.
- Each part's `position` is where *its centre* sits relative to the stack's centre (default `(0, 0)`); later parts
  are drawn on top of earlier ones.
- Parts without a `color` take the stack's colour (or the class colour from the palette); parts with one keep it.
- The stack is painted, transformed (rotation, scale, hue, ...) and boxed as a whole: its box covers every visible
  part. `fx.paint(cat, position=...)` places the centre of the stack's overall extent.
- Stacks can contain stacks. Any shape works as a part: circles, rectangles, polygons, images.
- A shape that is already a registered class can't be reused as a part (create the part in the call instead).

## Steps

### `fx.step(size=(640, 640), name=None)`
Context manager; see [Getting started](getting-started.md). Several steps may be defined; `make`
splits `pairs` evenly between them. Steps cannot be nested.

### `fx.canvas.background(color=None, image=None)`
`color` is a colour (or random node). `image` is a file, or a folder (one image picked at
random per sample); it is cover-fitted to the canvas. Default is white.

### `fx.paint(target, position=None)` → handle
`target` can be a random class node, a class variable, a class name string, `None` (no-op), or
a plain shape that is *not* a class (drawn but never annotated). `position` is the object's
centre in pixels (value or random node). Default: the shape's `position`, else canvas centre.

### `fx.toolkit.transformation(handle, hue=None, brightness=None, rotation=None, scale=None, opacity=None)`
- `hue`: degrees added to the hue (-180..180 covers everything)
- `brightness`: multiplier (1 = unchanged)
- `rotation`: degrees, counter-clockwise (the sprite grows so nothing is clipped)
- `scale`: multiplier, > 0
- `opacity`: multiplier 0-1

Repeated calls accumulate (hue/rotation add; the rest multiply). Any parameter may be a random
node. Ignored once `fx.gen()` has annotated the object.

### `fx.gen()`
Annotate all not-yet-annotated objects painted so far. See [Getting started](getting-started.md).

## Random (`fx.random`)

| Function | Produces |
|---|---|
| `uniform(lo, hi)` / `value` | float; `lo`/`hi` may be tuples (per component) |
| `integer(lo, hi)` | int, inclusive |
| `choice(*options)` | one option (options may be random nodes) |
| `position(margin=0)` | random `(x, y)` on the canvas |
| `color()` | random `#rrggbb` |
| `class_set(*names)` | a class set (optionally only among `names`) |
| `class_(from_=None)` / `cls` | a class from a set node, a set name, or any class if `None` |

All take `threshold=` (0-1, default 1). `class` is a Python keyword, hence `class_`.

## Output

### `fx.make(pairs, output, seed=None, overwrite=False, quiet=False, shard_size=None)`
Writes `pairs` images + annotations. `output` ending in `.felix` writes a compiled file,
otherwise a folder. With `shard_size=N` the folder holds `.sh_felix` shards of N pairs each (see [Formats](formats.md)). Refuses to overwrite an existing dataset unless `overwrite=True`. Prints a
live progress panel (disable with `quiet=True`). Returns `{"pairs", "seed", "boxes", "output"}`.

### `fx.load(path)` → `Dataset`
Read a dataset folder, a `.felix` file, or an ImageNet-style folder of class folders (see [Formats](formats.md);
`ds.task` is then `"classification"`, otherwise `"detection"`): `len(ds)`, `ds.metadata`, `ds.stems`, `ds.classes` (names ordered by class id),
`ds.annotation(stem)`, `ds.image(stem)` (a Felix `Image`, see below), `ds.image_bytes(stem)`, iteration yields
`(stem, annotation)`. Use as a context manager or call `ds.close()`. Datasets are picklable (each
DataLoader worker re-opens its own file handle).

**Splits.** `ds.train`, `ds.val` (alias `ds.valid`) and `ds.test` are lightweight `Subset` views with the same
read API (`len`, `stems`, `annotation`, `image`, iteration, `classes`, `metadata`); `ds.splits` gives the counts.

- If the annotations carry a `split` field (converted datasets), it is used (`valid`/`validation` count as `val`).
- Otherwise the dataset is split **deterministically 80/10/10**: shuffled with the dataset's `seed`, so the
  same file always gives the same splits. Datasets with fewer than 10 pairs are not split (all `train`).

### `fx.partition(source, output=None, parts=None, ratio=None, size=None, by_split=False, names=None, shuffle=False, seed=0, pack=None, overwrite=False, quiet=False)` → list of paths
Split a dataset into several complete datasets; the Python form of [`felix partition`](cli.md). Give exactly one of
`parts=N`, `ratio=(80, 10, 10)`, `size=K` or `by_split=True`. `source` is a path or a loaded `Dataset`.

### `fx.shard(source, output=None, *, size=None, shards=None, overwrite=False, quiet=False)` → folder
Store a dataset as a folder of `.sh_felix` shards: `size` pairs each (default 1000) or `shards` of equal size. Default
output `<name>_shards`; the source is unchanged. Pairs keep their names, order and splits. A sharded dataset has
`ds.shards` (how many), `ds.shard_of` (`{stem: shard number}`), `ds.shard_bytes` (largest shard file) and
`ds.load_shard(i)` / `ds.release_shard(i)` (read one shard into memory at once, then drop it).

### `fx.split(source, fraction=None, output=None, *, size=None, seed=0, overwrite=False, quiet=False)` → path
A smaller copy of a dataset for quick experiments; the Python form of [`felix split`](cli.md). `fx.split("voc.felix",
0.5)` writes `voc_split_50.felix` with half the pairs (the same share of each split, each pair in its original split)
and leaves the source unchanged. `size=N` keeps N pairs instead; `seed` picks which subset.

### `felix.raster.Image`
What `ds.image(stem)` returns: an RGB or RGBA image backed by a NumPy array. `.size`, `.width`, `.height`,
`.mode`, `.array` (uint8, height × width × channels), `.convert("RGB" | "RGBA")`, `.getpixel((x, y))`, `.tobytes()`,
`.save("x.png")` (other formats via Pillow), `.to_pil()`, `.show()`. `Image.open(path)` reads PNG natively and
other formats through Pillow.

### `fx.reset()`
Clear all classes and steps (tests, notebooks).

## Errors
All user-facing problems raise `fx.FelixError`.
