"""Dataset storage: a folder or a single compiled ``.felix`` file (a zip)."""
from __future__ import annotations

import io
import os
import random
import re
import zipfile
from pathlib import Path

from . import _yaml
from .errors import FelixError

EXT = ".felix"
_STORED = (".png", ".jpg", ".jpeg", ".webp")


def _safe(name):
    parts = name.split("/")
    if name.startswith("/") or "\\" in name or ".." in parts or ":" in parts[0] or "" in parts:
        raise FelixError(f"unsafe path in dataset: {name!r}")


class DirWriter:
    def __init__(self, root, overwrite=False):
        self.root = Path(root)
        img = self.root / "images"
        if img.is_dir() and any(img.iterdir()) and not overwrite:
            raise FelixError(f"{root} already holds a dataset (pass overwrite=True / --overwrite)")
        self._made = set()

    def write(self, name, data):
        _safe(name)
        p = self.root.joinpath(*name.split("/"))
        if p.parent not in self._made:
            p.parent.mkdir(parents=True, exist_ok=True)
            self._made.add(p.parent)
        p.write_bytes(data)

    def close(self):
        self.root.mkdir(parents=True, exist_ok=True)

    def abort(self):
        pass


class ZipWriter:
    def __init__(self, path, overwrite=False):
        self.path = Path(path)
        if self.path.exists() and not overwrite:
            raise FelixError(f"{path} already exists (pass overwrite=True / --overwrite)")
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.tmp = self.path.with_name(self.path.name + ".part")
        self.z = zipfile.ZipFile(self.tmp, "w")

    def write(self, name, data):
        _safe(name)
        comp = zipfile.ZIP_STORED if name.lower().endswith(_STORED) else zipfile.ZIP_DEFLATED
        self.z.writestr(name, data, compress_type=comp)

    def close(self):
        self.z.close()
        os.replace(self.tmp, self.path)

    def abort(self):
        self.z.close()
        try:
            self.tmp.unlink()
        except OSError:
            pass


SHARD_EXT = ".sh_felix"
SHARD_SIZE = 1000                                   # pairs per shard by default


def shard_files(folder):
    """The shard files of a shard folder, in natural order."""
    try:
        return sorted((p for p in Path(folder).iterdir() if p.is_file() and p.name.lower().endswith(SHARD_EXT)),
                      key=lambda p: _nat(p.name))
    except OSError:
        return []


class ShardWriter:
    """Writes a dataset as a folder of ``.sh_felix`` shards, ``size`` pairs each. Every shard is a complete zip (images,
    annotations, its own ``metadata.yml``) plus ``index.tsv`` (stem, split, class id per line) so a large sharded
    dataset loads without reading every annotation. Shards are written as ``.part`` files and renamed at the end."""

    def __init__(self, folder, size=SHARD_SIZE, overwrite=False, prefix=None):
        self.root = Path(folder)
        if self.root.exists() and not self.root.is_dir():
            raise FelixError(f"{folder} is a file; shards are written into a folder")
        old = shard_files(self.root)
        if old and not overwrite:
            raise FelixError(f"{folder} already holds {len(old)} shards (pass overwrite=True / --overwrite)")
        if int(size) < 1:
            raise FelixError(f"shard size must be at least 1 pair, got {size!r}")
        self.size, self.prefix = int(size), prefix or self.root.name or "shard"
        self.overwrite, self.old = overwrite, old
        self.root.mkdir(parents=True, exist_ok=True)
        self.meta, self.done, self.z, self.rows = None, [], None, []

    def _open(self):
        tmp = self.root / f"{self.prefix}-{len(self.done):05d}{SHARD_EXT}.part"
        self.z = zipfile.ZipFile(tmp, "w")
        self.tmp, self.rows = tmp, []

    def _finish(self):
        if self.z is not None:
            self.z.close()
            self.done.append((self.tmp, self.rows))
            self.z = None

    def write(self, name, data):
        if name == "metadata.yml":                  # every shard gets its own copy at close()
            self.meta = _yaml.loads(data.decode("utf-8")) or {}
            return
        _safe(name)
        if self.z is None:
            self._open()
        comp = zipfile.ZIP_STORED if name.lower().endswith(_STORED) else zipfile.ZIP_DEFLATED
        self.z.writestr(name, data, compress_type=comp)
        if name.startswith("annotations/") and name.endswith(".yml"):
            ann = _yaml.loads(data.decode("utf-8")) or {}
            self.rows.append((name[12:-4], ann.get("split"), ann.get("class_id")))
            if len(self.rows) >= self.size:        # the image always comes first, so a pair never straddles shards
                self._finish()

    def close(self):
        self._finish()
        meta, n = dict(self.meta or {}), len(self.done)
        meta.pop("shard", None)
        if self.overwrite:
            for p in self.old:
                p.unlink()
        for i, (tmp, rows) in enumerate(self.done):
            m = dict(meta, pairs=len(rows), shard={"index": i, "of": n, "dataset": self.prefix})
            splits = [_SPLIT_ALIASES.get(str(r[1]).lower()) for r in rows]
            if rows and all(splits):
                m["splits"] = {k: splits.count(k) for k in ("train", "val", "test") if k in splits}
            else:
                m.pop("splits", None)
            index = "".join(f"{stem}\t{sp or ''}\t{'' if c is None else c}\n" for stem, sp, c in rows)
            with zipfile.ZipFile(tmp, "a") as z:
                z.writestr("metadata.yml", _yaml.dumps(m).encode("utf-8"), compress_type=zipfile.ZIP_DEFLATED)
                z.writestr("index.tsv", index.encode("utf-8"), compress_type=zipfile.ZIP_DEFLATED)
        for tmp, _ in self.done:
            os.replace(tmp, tmp.with_name(tmp.name[:-5]))

    def abort(self):
        if self.z is not None:
            self.z.close()
            self.done.append((self.tmp, self.rows))
        for tmp, _ in self.done:
            try:
                tmp.unlink()
            except OSError:
                pass


def open_writer(output, overwrite=False, shard_size=None):
    out = str(output)
    if shard_size:
        return ShardWriter(out, shard_size, overwrite)
    return ZipWriter(out, overwrite) if out.lower().endswith(EXT) else DirWriter(out, overwrite)


class DirReader:
    def __init__(self, root):
        self.root = Path(root)

    def names(self):
        out = []
        for d, _, files in os.walk(self.root):
            rel = Path(d).relative_to(self.root).as_posix()
            out += [f if rel == "." else f"{rel}/{f}" for f in files]
        return sorted(out)

    def read(self, name):
        _safe(name)
        return self.root.joinpath(*name.split("/")).read_bytes()

    def close(self):
        pass


class ZipReader:
    def __init__(self, path):
        self.z = zipfile.ZipFile(path)

    def names(self):
        return [n for n in self.z.namelist() if not n.endswith("/")]

    def read(self, name):
        return self.z.read(name)

    def close(self):
        self.z.close()


IMAGE_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".webp", ".gif", ".tif", ".tiff")


def _is_image(name: str) -> bool:
    return name.lower().endswith(IMAGE_EXT) and not name.startswith(".")


def _image_files(folder: Path):
    """Images anywhere under ``folder`` (relative POSIX paths, natural order); hidden files and folders skipped."""
    out = []
    for d, dirs, files in os.walk(folder):
        dirs[:] = sorted((x for x in dirs if not x.startswith(".")), key=_nat)
        rel = Path(d).relative_to(folder).as_posix()
        out += [f if rel == "." else f"{rel}/{f}" for f in sorted(files, key=_nat) if _is_image(f)]
    return out


def _subdirs(p: Path):
    try:
        return sorted((d for d in p.iterdir() if d.is_dir() and not d.name.startswith((".", "_"))), key=lambda d: _nat(d.name))
    except OSError:
        return []


def class_folder_layout(path):
    """How an ImageNet-style folder is organised, or None if it isn't one:
    ``("split", {split: folder})`` for train/ val/ test/ each holding class folders, ``("flat", root)`` for class
    folders directly inside."""
    p = Path(path)
    if not p.is_dir() or (p / "annotations").is_dir() or (p / "metadata.yml").is_file():
        return None
    dirs = _subdirs(p)
    splits = {}
    for d in dirs:
        name = _SPLIT_ALIASES.get(d.name.lower())
        if name and _subdirs(d):
            if name in splits:
                raise FelixError(f"{path} has two folders for the {name} split ({splits[name].name}/ and {d.name}/)")
            splits[name] = d
    if splits:
        return ("split", splits)
    if dirs and any(any(_is_image(f.name) for f in d.iterdir() if f.is_file()) or _subdirs(d) for d in dirs):
        return ("flat", p)
    return None


class ClassFolderReader:
    """An ImageNet-style folder seen as a Felix classification dataset: one sub-folder per class with its images
    (optionally inside train/ val/ test/). The annotations and metadata are made up on the fly; nothing is written
    next to the images. Without split folders every class is split 80/10/10 on its own (stratified, seed 0)."""

    def __init__(self, root, layout, seed: int = 0):
        self.root = Path(root)
        kind, where = layout
        items = []                                          # (image path relative to root, class, split or None)
        if kind == "split":
            for split, d in where.items():
                for c in _subdirs(d):
                    base = f"{d.name}/{c.name}"
                    items += [(f"{base}/{f}", c.name, split) for f in _image_files(c)]
        else:
            for c in _subdirs(where):
                items += [(f"{c.name}/{f}", c.name, None) for f in _image_files(c)]
        if not items:
            raise FelixError(f"{root} has class folders but no images in them ({', '.join(IMAGE_EXT)})")
        names = sorted({c for _, c, _ in items}, key=_nat)
        self.classes = names
        ids = {c: i for i, c in enumerate(names)}
        if kind == "flat":
            items = self._stratify(items, seed)
        self.items, used = {}, set()
        for rel, c, split in items:
            stem = rel.rsplit(".", 1)[0]
            if stem in used:                                # cat/1.jpg and cat/1.png: keep both
                stem = rel.replace(".", "_")
            used.add(stem)
            self.items[stem] = (rel, c, ids[c], split)
        counts = {k: 0 for k in ("train", "val", "test")}
        for _, _, _, split in self.items.values():
            counts[split] += 1
        self.split_of = {stem: v[3] for stem, v in self.items.items()}
        self.metadata = {"felix_version": _version(), "task": "classification", "source": "class folders",
                         "layout": "train/val/test folders" if kind == "split" else "class folders", "pairs": len(self.items),
                         "seed": seed, "splits": {k: n for k, n in counts.items() if n},
                         "classes": [{"id": i, "name": n} for i, n in enumerate(names)]}

    @staticmethod
    def _stratify(items, seed):
        """80/10/10 inside every class, so each split has every class in the same proportion."""
        if len(items) < 10:
            return [(r, c, "train") for r, c, _ in items]
        by = {}
        for r, c, _ in items:
            by.setdefault(c, []).append(r)
        out = []
        for c, files in by.items():
            order = list(files)
            random.Random(f"{seed}:{c}").shuffle(order)
            k = round(0.1 * len(order))
            test, val = set(order[:k]), set(order[k:2 * k])
            out += [(r, c, "test" if r in test else "val" if r in val else "train") for r in files]
        return out

    def names(self):
        return (["metadata.yml"] + [f"annotations/{s}.yml" for s in self.items]
                + [f"images/{v[0]}" for v in self.items.values()])

    def annotation(self, stem):
        rel, c, cid, split = self.items[stem]
        return {"image": rel, "split": split, "class": c, "class_id": cid}

    def read(self, name):
        if name == "metadata.yml":
            return _yaml.dumps(self.metadata).encode("utf-8")
        if name.startswith("annotations/") and name.endswith(".yml"):
            stem = name[12:-4]
            if stem not in self.items:
                raise KeyError(name)
            return _yaml.dumps(self.annotation(stem)).encode("utf-8")
        if name.startswith("images/"):
            _safe(name[7:])
            return self.root.joinpath(*name[7:].split("/")).read_bytes()
        raise KeyError(name)

    def close(self):
        pass


class ShardReader:
    """A folder of ``.sh_felix`` shards read as one dataset. Shards open on demand (at most ``MAX_OPEN`` at a time),
    reads are thread-safe, and a whole shard can be loaded into memory at once (``load_shard``), which is how
    Workflow streams a sharded dataset during training."""

    MAX_OPEN = 64

    def __init__(self, folder):
        import threading
        self.root = Path(folder)
        self.files = shard_files(self.root)
        if not self.files:
            raise FelixError(f"{folder} has no {SHARD_EXT} shards")
        self.where, self.shard_of, metas, index_rows = {}, {}, [], []
        for i, f in enumerate(self.files):
            try:
                with zipfile.ZipFile(f) as z:
                    names = [n for n in z.namelist() if not n.endswith("/")]
                    metas.append((_yaml.loads(z.read("metadata.yml").decode("utf-8")) or {}) if "metadata.yml" in names else {})
                    rows = None
                    if "index.tsv" in names:
                        rows = [l.split("\t") for l in z.read("index.tsv").decode("utf-8").splitlines() if l]
                    index_rows.append(rows)
            except zipfile.BadZipFile:
                raise FelixError(f"shard {f.name} is damaged (not a valid zip); re-create it or remove it from {folder}") from None
            for n in names:
                if n in ("metadata.yml", "index.tsv"):
                    continue
                if n in self.where:
                    raise FelixError(f"{n} is in two shards ({self.files[self.where[n]].name} and {f.name}); "
                                     "shards of one dataset must not overlap")
                self.where[n] = i
                if n.startswith("annotations/") and n.endswith(".yml"):
                    self.shard_of[n[12:-4]] = i
        base = metas[0]
        for f, m in zip(self.files[1:], metas[1:]):
            if m.get("classes") != base.get("classes"):
                raise FelixError(f"shard {f.name} has different classes from {self.files[0].name}; "
                                 "all shards in a folder must come from the same dataset")
        meta = {k: v for k, v in base.items() if k != "shard"}
        meta["pairs"] = len(self.shard_of)
        if all(m.get("splits") for m in metas):
            total = {}
            for m in metas:
                for k, v in m["splits"].items():
                    total[k] = total.get(k, 0) + v
            meta["splits"] = total
        else:
            meta.pop("splits", None)
        self.metadata = meta
        self.split_of = None                       # fast split lookup when every shard indexed its splits
        if meta.get("splits") and all(r is not None for r in index_rows):
            split_of = {}
            for rows in index_rows:
                for r in rows:
                    split_of[r[0]] = _SPLIT_ALIASES.get(r[1].lower() if len(r) > 1 else "", "train")
            if set(split_of) == set(self.shard_of):
                self.split_of = split_of
        self._open, self._lock, self._cache = {}, threading.Lock(), {}
        self._locks = [threading.Lock() for _ in self.files]

    def names(self):
        return ["metadata.yml"] + list(self.where)

    def _zip(self, i):
        with self._lock:
            z = self._open.pop(i, None)
            if z is None:
                while len(self._open) >= self.MAX_OPEN:          # close the least recently used shard
                    j = next(iter(self._open))
                    with self._locks[j]:
                        self._open.pop(j).close()
                z = zipfile.ZipFile(self.files[i])
            self._open[i] = z                                    # most recently used last
            return z

    def read(self, name):
        if name == "metadata.yml":
            return _yaml.dumps(self.metadata).encode("utf-8")
        i = self.where.get(name)
        if i is None:
            raise KeyError(name)
        cached = self._cache.get(i)
        if cached is not None:                                  # a shard loaded whole
            return cached[name]
        for _ in range(2):
            z = self._zip(i)
            with self._locks[i]:
                try:
                    return z.read(name)
                except ValueError:                              # closed by another thread in between: open it again
                    continue
        raise OSError(f"could not read {name} from {self.files[i].name}")

    def load_shard(self, i):
        """Read shard ``i`` into memory in one sequential pass; later reads of its files need no disk access."""
        if i in self._cache:
            return
        with zipfile.ZipFile(self.files[i]) as z:
            data = {n: z.read(n) for n in z.namelist() if n in self.where}
        self._cache[i] = data

    def release_shard(self, i):
        self._cache.pop(i, None)

    def close(self):
        with self._lock:
            for z in self._open.values():
                z.close()
            self._open = {}
        self._cache = {}


def dataset_kind(path):
    """What ``path`` holds: "felix" (a .felix or .sh_felix file), "folder", "shards", "classes" (class folders) or None."""
    p = Path(path)
    if p.is_file():
        return "felix" if zipfile.is_zipfile(p) else None
    if not p.is_dir():
        return None
    if (p / "metadata.yml").is_file() or (p / "annotations").is_dir():
        return "folder"
    if shard_files(p):
        return "shards"
    try:
        if class_folder_layout(p) is not None:
            return "classes"
    except FelixError:
        return None
    return None


def _version():
    from ._version import __version__
    return __version__


def open_reader(path):
    p = Path(path)
    if p.is_dir() and not (p / "metadata.yml").is_file() and shard_files(p):
        return ShardReader(p)
    if p.is_dir():
        layout = class_folder_layout(p)
        if layout is not None:
            return ClassFolderReader(p, layout)
        return DirReader(p)
    if p.is_file() and zipfile.is_zipfile(p):
        return ZipReader(p)
    raise FelixError(f"{path} is not a Felix dataset folder or .felix file")


def _decode(data, name):
    from .raster import decode
    return decode(data, name)


def _nat(s):
    return [int(t) if t.isdigit() else t for t in re.split(r"(\d+)", s)]


_SPLIT_ALIASES = {"train": "train", "training": "train", "val": "val", "valid": "val",
                  "validation": "val", "test": "test", "testing": "test"}


class Dataset:
    """Read access to a dataset folder or ``.felix`` file.

    Splits: ``ds.train``, ``ds.val`` and ``ds.test`` are lightweight views with the same read API.
    Annotations that carry a ``split`` field (converted datasets) are honoured; otherwise the
    dataset is split deterministically 80/10/10 (shuffled with the dataset's seed). Datasets with
    fewer than 10 pairs are not split (everything is ``train``).
    """

    def __init__(self, path):
        self.path = str(path)
        self._r = open_reader(path)
        try:
            self.metadata = _yaml.loads(self._r.read("metadata.yml").decode("utf-8")) or {}
        except (KeyError, OSError):
            self.metadata = {}
        self.stems = sorted((n[12:-4] for n in self._r.names()
                             if n.startswith("annotations/") and n.endswith(".yml")), key=_nat)
        self._splits = None

    # -- pickling (DataLoader workers re-open their own file handle)
    def __getstate__(self):
        return {"path": self.path}

    def __setstate__(self, state):
        self.__init__(state["path"])

    def __len__(self):
        return len(self.stems)

    def __iter__(self):
        for s in self.stems:
            yield s, self.annotation(s)

    @property
    def classes(self):
        """Class names ordered by class id (None if the dataset has no class table)."""
        table = self.metadata.get("classes")
        if not table:
            return None
        return [c["name"] for c in sorted(table, key=lambda c: c["id"])]

    @property
    def shard_of(self):
        """{stem: shard number} for a folder of shards, else None."""
        return getattr(self._r, "shard_of", None)

    @property
    def shards(self):
        """How many shards the dataset is stored in (1 for a single file or folder)."""
        r = self._r
        return len(r.files) if isinstance(r, ShardReader) else 1

    @property
    def shard_bytes(self):
        """Size of the largest shard file (0 unless stored as shards): what loading one shard costs in memory."""
        r = self._r
        return max(f.stat().st_size for f in r.files) if isinstance(r, ShardReader) else 0

    def load_shard(self, i):
        """Read shard ``i`` into memory at once (folders of shards only; elsewhere nothing to do)."""
        if isinstance(self._r, ShardReader):
            self._r.load_shard(i)

    def release_shard(self, i):
        if isinstance(self._r, ShardReader):
            self._r.release_shard(i)

    @property
    def task(self):
        """"classification" (one label per image) or "detection" (boxes)."""
        return "classification" if self.metadata.get("task") == "classification" else "detection"

    def annotation(self, stem):
        if hasattr(self._r, "annotation"):                 # class folders: no YAML round trip
            return self._r.annotation(stem)
        return _yaml.loads(self._r.read(f"annotations/{stem}.yml").decode("utf-8"))

    def image_bytes(self, stem):
        return self._r.read("images/" + self.annotation(stem)["image"])

    def image(self, stem):
        """The image as a ``felix.raster.Image`` (RGB/RGBA; ``.size``, ``.convert``, ``.tobytes``, ``.save``)."""
        from .raster import Image
        return Image(_decode(self.image_bytes(stem), stem))

    # -- splits
    def _compute_splits(self):
        if self._splits is not None:
            return self._splits
        out = {"train": [], "val": [], "test": []}
        has_field = bool(self.metadata.get("splits"))
        known = getattr(self._r, "split_of", None)
        if known is not None:
            for stem in self.stems:
                out[known[stem]].append(stem)
        elif has_field:
            for stem in self.stems:
                name = _SPLIT_ALIASES.get(str(self.annotation(stem).get("split", "")).lower())
                out[name or "train"].append(stem)
        n = len(self.stems)
        if not has_field and known is None:
            if n < 10:
                out["train"] = list(self.stems)
            else:
                k = max(1, round(0.1 * n))
                order = list(range(n))
                random.Random(self.metadata.get("seed", 0)).shuffle(order)
                pick = lambda idx: sorted((self.stems[i] for i in idx), key=_nat)
                out["test"], out["val"], out["train"] = pick(order[:k]), pick(order[k:2 * k]), pick(order[2 * k:])
        self._splits = out
        return out

    @property
    def splits(self):
        """{'train': n, 'val': n, 'test': n}"""
        return {k: len(v) for k, v in self._compute_splits().items()}

    @property
    def train(self):
        return Subset(self, "train", self._compute_splits()["train"])

    @property
    def val(self):
        return Subset(self, "val", self._compute_splits()["val"])

    valid = val

    @property
    def test(self):
        return Subset(self, "test", self._compute_splits()["test"])

    def close(self):
        self._r.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def __repr__(self):
        return f"<felix.Dataset {self.path!r}: {len(self)} pairs>"


class Subset:
    """A named subset (split) of a Dataset; same read API as Dataset."""

    def __init__(self, parent, name, stems):
        self.parent, self.name, self.stems = parent, name, list(stems)

    @property
    def metadata(self):
        return self.parent.metadata

    @property
    def classes(self):
        return self.parent.classes

    @property
    def task(self):
        return self.parent.task

    @property
    def shard_of(self):
        return self.parent.shard_of

    @property
    def shards(self):
        return self.parent.shards

    @property
    def shard_bytes(self):
        return self.parent.shard_bytes

    def load_shard(self, i):
        self.parent.load_shard(i)

    def release_shard(self, i):
        self.parent.release_shard(i)

    def __len__(self):
        return len(self.stems)

    def __iter__(self):
        for s in self.stems:
            yield s, self.parent.annotation(s)

    def annotation(self, stem):
        return self.parent.annotation(stem)

    def image_bytes(self, stem):
        return self.parent.image_bytes(stem)

    def image(self, stem):
        return self.parent.image(stem)

    def __repr__(self):
        return f"<felix.Subset {self.name!r}: {len(self)} pairs of {self.parent.path!r}>"


def load(path):
    return Dataset(path)
