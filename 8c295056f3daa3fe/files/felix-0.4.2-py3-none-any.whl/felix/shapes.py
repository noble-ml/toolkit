"""Shapes (class templates) and per-sample instances with transformations."""
from __future__ import annotations

import math
import os

import numpy as np

from . import raster

from .errors import FelixError

_AA = 4  # supersampling factor for smooth edges
_ALPHA_MIN = 16 / 255.0

PALETTE = (
    "#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#46c8c8",
    "#f032e6", "#9acd32", "#008080", "#9a6324", "#800000", "#808000",
)


def rgba(c):
    return raster.parse_color(c)


class Shape:
    """A drawable template. Becomes a class when defined inside fx.class_set()."""

    def __init__(self, kind, params, color=None, position=None, name=None):
        if position is not None:
            if len(position) != 2:
                raise FelixError("position must be an (x, y) pair")
            position = (float(position[0]), float(position[1]))
        self.kind, self.params, self.color, self.position = kind, params, color, position
        self.name, self.set, self.id = name, None, None
        self._sprites = {}

    def __repr__(self):
        return f"<Shape {self.kind} {self.name or ''}>"

    def sprite(self, fallback=None):
        """The rendered sprite. ``fallback`` is the colour used when the shape has none (a stack's colour)."""
        key = self.color if self.color is not None else fallback
        if key not in self._sprites:
            self._sprites[key] = self._build(key)
        return self._sprites[key]

    def _build(self, color=None):
        """The shape's sprite: float32 premultiplied RGBA."""
        k, p = self.kind, self.params
        if k == "stack":
            return _compose(p["parts"], color)
        if k == "image":
            im = raster.to_premul(raster.Image.open(p["source"]).convert("RGBA").array)
            w, h = p.get("width"), p.get("height")
            if w or h:
                w = w or max(1, round(im.shape[1] * h / im.shape[0]))
                h = h or max(1, round(im.shape[0] * w / im.shape[1]))
                im = raster.resize(im, int(w), int(h))
            return im
        col = np.array(rgba(color if color is not None else "#808080"), np.float32) / 255.0
        if k == "circle":
            w = h = max(1, round(2 * p["radius"]))
        elif k == "rectangle":
            w, h = max(1, round(p["width"])), max(1, round(p["height"]))
        else:
            xs, ys = [v[0] for v in p["vertices"]], [v[1] for v in p["vertices"]]
            ox, oy = min(xs), min(ys)
            w, h = max(1, math.ceil(max(xs) - ox)), max(1, math.ceil(max(ys) - oy))
        # coverage from _AA x _AA samples per pixel
        sy, sx = (np.mgrid[0:h * _AA, 0:w * _AA].astype(np.float32) + 0.5) / _AA
        if k == "circle":
            inside = (sx - w / 2) ** 2 + (sy - h / 2) ** 2 <= (w / 2) ** 2
        elif k == "rectangle":
            inside = np.ones(sx.shape, bool)
        else:
            vs = [(x - ox, y - oy) for x, y in p["vertices"]]
            inside = np.zeros(sx.shape, bool)
            for (x1, y1), (x2, y2) in zip(vs, vs[1:] + vs[:1]):      # even-odd rule
                if y1 == y2:
                    continue
                cross = ((y1 > sy) != (y2 > sy)) & (sx < (x2 - x1) * (sy - y1) / (y2 - y1) + x1)
                inside ^= cross
        cover = inside.reshape(h, _AA, w, _AA).mean(axis=(1, 3)).astype(np.float32)
        a = cover * col[3]
        return np.dstack([col[0] * a, col[1] * a, col[2] * a, a]).astype(np.float32)


def _compose(parts, color):
    """Draw stack parts into one sprite. Each part's ``position`` is its centre relative to the stack's centre
    (default (0, 0)); later parts are drawn on top. The result is cropped to the parts' combined extent."""
    placed = []
    for part in parts:
        sp = part.sprite(color)
        dx, dy = part.position or (0.0, 0.0)
        placed.append((sp, round(dx - sp.shape[1] / 2), round(dy - sp.shape[0] / 2)))
    x0 = min(x for _, x, _ in placed)
    y0 = min(y for _, _, y in placed)
    x1 = max(x + sp.shape[1] for sp, x, _ in placed)
    y1 = max(y + sp.shape[0] for sp, _, y in placed)
    out = np.zeros((y1 - y0, x1 - x0, 4), np.float32)
    for sp, x, y in placed:
        region = out[y - y0:y - y0 + sp.shape[0], x - x0:x - x0 + sp.shape[1]]
        region *= 1 - sp[:, :, 3:4]                     # premultiplied "over"
        region += sp
    return out


class Inst:
    """One painted object in one sample."""

    __slots__ = ("shape", "pos", "hue", "brightness", "rotation", "scale", "opacity", "frozen", "_sp")

    def __init__(self, shape, pos):
        self.shape, self.pos = shape, pos
        self.hue, self.brightness, self.rotation, self.scale, self.opacity = 0.0, 1.0, 0.0, 1.0, 1.0
        self.frozen, self._sp = False, None

    def apply(self, hue=None, brightness=None, rotation=None, scale=None, opacity=None):
        if self.frozen:  # already annotated by fx.gen(): changes are ignored
            return
        if hue is not None:
            self.hue += hue
        if brightness is not None:
            self.brightness *= max(0.0, brightness)
        if rotation is not None:
            self.rotation += rotation
        if scale is not None:
            if scale <= 0:
                raise FelixError("scale must be > 0")
            self.scale *= scale
        if opacity is not None:
            self.opacity *= min(1.0, max(0.0, opacity))
        self._sp = None

    def sprite(self):
        if self._sp is None:
            im = self.shape.sprite()
            if self.scale != 1:
                im = raster.resize(im, max(1, round(im.shape[1] * self.scale)), max(1, round(im.shape[0] * self.scale)))
            if self.hue % 360 or self.brightness != 1:
                im = raster.shift_color(im, self.hue, self.brightness)
            if self.rotation % 360:
                im = raster.rotate(im, self.rotation)
            if self.opacity < 1:
                im = im * self.opacity
            self._sp = im
        return self._sp

    def origin(self):
        sp = self.sprite()
        return round(self.pos[0] - sp.shape[1] / 2), round(self.pos[1] - sp.shape[0] / 2)

    def bbox(self, size):
        """Tight xywh box of visible (non-transparent) pixels, clipped to the canvas."""
        alpha = self.sprite()[:, :, 3] > _ALPHA_MIN
        rows, cols = np.flatnonzero(alpha.any(axis=1)), np.flatnonzero(alpha.any(axis=0))
        if not len(rows):
            return None
        bb = (int(cols[0]), int(rows[0]), int(cols[-1]) + 1, int(rows[-1]) + 1)
        ox, oy = self.origin()
        x0, y0 = max(0, ox + bb[0]), max(0, oy + bb[1])
        x1, y1 = min(size[0], ox + bb[2]), min(size[1], oy + bb[3])
        if x1 <= x0 or y1 <= y0:
            return None
        return [x0, y0, x1 - x0, y1 - y0]
