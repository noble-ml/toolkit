"""Felix's own raster backend (NumPy): images, PNG encode/decode, colours, resampling, rotation, compositing.

Pillow is optional: it is only used to read JPEG and other non-PNG files.
"""
from __future__ import annotations

import io
import math
import os
import struct
import zlib
from typing import Optional, Tuple

import numpy as np

from .errors import FelixError

PNG_SIG = b"\x89PNG\r\n\x1a\n"

# ----------------------------------------------------------------- colours
NAMED = {
    "black": "#000000", "white": "#ffffff", "red": "#ff0000", "green": "#008000", "lime": "#00ff00", "blue": "#0000ff",
    "yellow": "#ffff00", "cyan": "#00ffff", "aqua": "#00ffff", "magenta": "#ff00ff", "fuchsia": "#ff00ff",
    "gray": "#808080", "grey": "#808080", "silver": "#c0c0c0", "lightgray": "#d3d3d3", "lightgrey": "#d3d3d3",
    "darkgray": "#a9a9a9", "darkgrey": "#a9a9a9", "orange": "#ffa500", "purple": "#800080", "pink": "#ffc0cb",
    "brown": "#a52a2a", "navy": "#000080", "teal": "#008080", "maroon": "#800000", "olive": "#808000",
    "gold": "#ffd700", "beige": "#f5f5dc", "violet": "#ee82ee", "indigo": "#4b0082", "transparent": "#00000000",
}


def parse_color(c) -> Tuple[int, int, int, int]:
    """'#rgb', '#rgba', '#rrggbb', '#rrggbbaa', a CSS name, or an (r, g, b[, a]) tuple → (r, g, b, a)."""
    if isinstance(c, (tuple, list)):
        t = tuple(int(v) for v in c)
        if len(t) in (3, 4) and all(0 <= v <= 255 for v in t):
            return t + (255,) if len(t) == 3 else t
        raise FelixError(f"bad color {c!r}: use (r, g, b) or (r, g, b, a) with values 0-255")
    s = NAMED.get(str(c).strip().lower(), str(c).strip())
    if s.startswith("#") and len(s) in (4, 5, 7, 9):
        h = s[1:]
        if len(h) in (3, 4):
            h = "".join(ch * 2 for ch in h)
        try:
            v = [int(h[i:i + 2], 16) for i in range(0, len(h), 2)]
            return tuple(v) + (255,) if len(v) == 3 else tuple(v)
        except ValueError:
            pass
    raise FelixError(f"unknown color {c!r}: use a hex value like '#ff8800' or a basic name like 'red'")


# ----------------------------------------------------------------- PNG
def encode_png(a: np.ndarray, level: int = 3) -> bytes:
    """uint8 (H, W), (H, W, 3) or (H, W, 4) → PNG bytes (Sub filter, zlib ``level``)."""
    if a.ndim == 2:
        a = a[:, :, None]
    h, w, c = a.shape
    ctype = {1: 0, 3: 2, 4: 6}[c]
    flat = np.ascontiguousarray(a, dtype=np.uint8).reshape(h, w * c)
    filt = flat.copy()
    filt[:, c:] = flat[:, c:] - flat[:, :-c]                       # Sub filter (uint8 wraps)
    raw = np.concatenate([np.ones((h, 1), np.uint8), filt], axis=1).tobytes()

    def chunk(t, body):
        return struct.pack(">I", len(body)) + t + body + struct.pack(">I", zlib.crc32(t + body) & 0xFFFFFFFF)

    return (PNG_SIG + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, ctype, 0, 0, 0))
            + chunk(b"IDAT", zlib.compress(raw, level)) + chunk(b"IEND", b""))


class _Unsupported(Exception):
    pass


def _unfilter(rows: np.ndarray, bpp: int) -> np.ndarray:
    h, stride = rows.shape[0], rows.shape[1] - 1
    ftypes, data = rows[:, 0], rows[:, 1:]
    out = np.empty((h, stride), np.uint8)
    prev = np.zeros(stride, np.uint8)
    for y in range(h):
        f, line = ftypes[y], data[y]
        if f == 0:
            cur = line
        elif f == 1:
            if stride % bpp:
                raise _Unsupported("odd stride")
            cur = np.cumsum(line.reshape(-1, bpp), axis=0, dtype=np.uint8).reshape(-1)
        elif f == 2:
            cur = line + prev
        elif f in (3, 4):                                         # sequential filters: pure-Python byte loop
            cur_b, ln, pv = bytearray(stride), line.tobytes(), prev.tobytes()
            for i in range(stride):
                a = cur_b[i - bpp] if i >= bpp else 0
                b = pv[i]
                if f == 3:
                    cur_b[i] = (ln[i] + ((a + b) >> 1)) & 255
                else:
                    c = pv[i - bpp] if i >= bpp else 0
                    p = a + b - c
                    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
                    cur_b[i] = (ln[i] + (a if pa <= pb and pa <= pc else b if pb <= pc else c)) & 255
            cur = np.frombuffer(bytes(cur_b), np.uint8)
        else:
            raise FelixError(f"corrupt PNG: unknown row filter {f}")
        out[y] = cur
        prev = out[y]
    return out


def decode_png(data: bytes) -> np.ndarray:
    """PNG bytes → uint8 (H, W, 3) or (H, W, 4)."""
    if data[:8] != PNG_SIG:
        raise _Unsupported("not a PNG")
    pos, idat, plte, trns, ihdr = 8, [], None, None, None
    while pos + 8 <= len(data):
        n, typ = struct.unpack(">I4s", data[pos:pos + 8])
        body = data[pos + 8:pos + 8 + n]
        pos += 12 + n
        if typ == b"IHDR":
            ihdr = struct.unpack(">IIBBBBB", body)
        elif typ == b"PLTE":
            plte = np.frombuffer(body, np.uint8).reshape(-1, 3)
        elif typ == b"tRNS":
            trns = body
        elif typ == b"IDAT":
            idat.append(body)
        elif typ == b"IEND":
            break
    if ihdr is None:
        raise FelixError("corrupt PNG: no header")
    w, h, depth, ctype, _, _, interlace = ihdr
    if interlace:
        raise _Unsupported("interlaced PNG")
    channels = {0: 1, 2: 3, 3: 1, 4: 2, 6: 4}.get(ctype)
    if channels is None or depth not in (1, 2, 4, 8, 16) or (depth < 8 and ctype not in (0, 3)):
        raise _Unsupported(f"PNG color type {ctype}, depth {depth}")
    bits = channels * depth
    stride = (w * bits + 7) // 8
    try:
        raw = zlib.decompress(b"".join(idat))
    except zlib.error as e:
        raise FelixError(f"corrupt PNG data ({e})") from None
    rows = np.frombuffer(raw, np.uint8)[: h * (stride + 1)].reshape(h, stride + 1)
    px = _unfilter(rows, max(1, bits // 8))
    if depth == 16:
        px = px.reshape(h, w * channels, 2)[:, :, 0]               # keep the high byte
    elif depth < 8:
        px = np.unpackbits(px, axis=1).reshape(h, -1, depth)[:, :w, :]
        px = (px * (1 << np.arange(depth - 1, -1, -1))).sum(axis=2).astype(np.uint8)
        if ctype == 0:
            px = (px.astype(np.uint16) * 255 // ((1 << depth) - 1)).astype(np.uint8)
    px = px.reshape(h, w, channels)
    if ctype == 3:
        if plte is None:
            raise FelixError("corrupt PNG: palette image without a palette")
        rgb = plte[px[:, :, 0]]
        if trns is not None:
            alpha = np.full(len(plte), 255, np.uint8)
            alpha[: len(trns)] = np.frombuffer(trns, np.uint8)[: len(plte)]
            return np.dstack([rgb, alpha[px[:, :, 0]]])
        return rgb
    if ctype == 0:
        return np.repeat(px, 3, axis=2)
    if ctype == 4:
        return np.dstack([np.repeat(px[:, :, :1], 3, axis=2), px[:, :, 1:]])
    return px


def image_size(data: bytes) -> Optional[Tuple[int, int]]:
    """(width, height) from a PNG or JPEG header, without decoding. None if unknown."""
    if data[:8] == PNG_SIG and len(data) >= 24:
        return struct.unpack(">II", data[16:24])
    if data[:2] == b"\xff\xd8":
        i = 2
        while i + 9 < len(data):
            if data[i] != 0xFF:
                i += 1
                continue
            marker = data[i + 1]
            if marker in (0xD8, 0x01) or 0xD0 <= marker <= 0xD7:
                i += 2
                continue
            seg = struct.unpack(">H", data[i + 2:i + 4])[0]
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                hh, ww = struct.unpack(">HH", data[i + 5:i + 9])
                return ww, hh
            i += 2 + seg
    return None


def decode(data: bytes, name: str = "image") -> np.ndarray:
    """Image bytes → uint8 (H, W, 3|4). PNG natively; other formats through Pillow if it is installed."""
    try:
        return decode_png(data)
    except _Unsupported as why:
        try:
            from PIL import Image as _PIL
        except ImportError:
            kind = "JPEG" if data[:2] == b"\xff\xd8" else str(why)
            raise FelixError(f"cannot read {name}: {kind} files need Pillow (`pip install Pillow`); "
                             "Felix reads plain PNG on its own") from None
        try:
            im = _PIL.open(io.BytesIO(data))
            im = im.convert("RGBA" if im.mode in ("RGBA", "LA", "P", "PA") else "RGB")
            return np.asarray(im, dtype=np.uint8).copy()
        except Exception as e:
            raise FelixError(f"cannot read {name}: {e}") from None


# ----------------------------------------------------------------- the image type
class Image:
    """An RGB or RGBA image backed by a uint8 NumPy array (H, W, C). Small, Pillow-like API."""

    def __init__(self, array: np.ndarray):
        a = np.asarray(array)
        if a.dtype != np.uint8 or a.ndim != 3 or a.shape[2] not in (3, 4):
            raise FelixError("Image needs a uint8 array shaped (height, width, 3 or 4)")
        self.array = a

    @staticmethod
    def open(path) -> "Image":
        path = os.fspath(path)
        try:
            with open(path, "rb") as f:
                data = f.read()
        except OSError as e:
            raise FelixError(f"cannot read image {path!r}: {e}") from None
        return Image(decode(data, path))

    @staticmethod
    def frombytes(data: bytes) -> "Image":
        return Image(decode(data))

    @property
    def mode(self) -> str:
        return "RGB" if self.array.shape[2] == 3 else "RGBA"

    @property
    def size(self) -> Tuple[int, int]:
        return self.array.shape[1], self.array.shape[0]

    @property
    def width(self) -> int:
        return self.array.shape[1]

    @property
    def height(self) -> int:
        return self.array.shape[0]

    def convert(self, mode: str) -> "Image":
        if mode == self.mode:
            return Image(self.array.copy())
        if mode == "RGB":
            return Image(np.ascontiguousarray(self.array[:, :, :3]))
        if mode == "RGBA":
            return Image(np.dstack([self.array, np.full(self.array.shape[:2], 255, np.uint8)]))
        raise FelixError(f"unsupported mode {mode!r}; use 'RGB' or 'RGBA'")

    def copy(self) -> "Image":
        return Image(self.array.copy())

    def getpixel(self, xy):
        return tuple(int(v) for v in self.array[xy[1], xy[0]])

    def tobytes(self) -> bytes:
        return np.ascontiguousarray(self.array).tobytes()

    def to_png(self, level: int = 3) -> bytes:
        return encode_png(self.array, level)

    def save(self, path) -> str:
        path = os.fspath(path)
        if path.lower().endswith(".png"):
            with open(path, "wb") as f:
                f.write(self.to_png(6))
            return path
        try:
            from PIL import Image as _PIL
        except ImportError:
            raise FelixError(f"cannot save {os.path.basename(path)!r}: Felix writes PNG on its own; "
                             "other formats need Pillow (`pip install Pillow`)") from None
        _PIL.fromarray(self.array).save(path)
        return path

    def to_pil(self):
        from PIL import Image as _PIL
        return _PIL.fromarray(self.array)

    def show(self):
        self.to_pil().show()

    def __repr__(self):
        return f"<felix Image {self.mode} {self.width}x{self.height}>"


# ----------------------------------------------------------------- float RGBA operations (premultiplied alpha)
def to_premul(a: np.ndarray) -> np.ndarray:
    """uint8 (H, W, 3|4) → float32 premultiplied RGBA in [0, 1]."""
    f = a.astype(np.float32) / 255.0
    if f.shape[2] == 3:
        f = np.dstack([f, np.ones(f.shape[:2], np.float32)])
    f[:, :, :3] *= f[:, :, 3:4]
    return f


def unpremul(p: np.ndarray) -> np.ndarray:
    out = p.copy()
    a = p[:, :, 3:4]
    np.divide(p[:, :, :3], a, out=out[:, :, :3], where=a > 1e-6)
    out[:, :, :3] = np.clip(out[:, :, :3], 0, 1)
    return out


def _weights(n_in: int, n_out: int) -> np.ndarray:
    """(n_out, n_in) resampling matrix: triangle filter, widened when shrinking (anti-aliasing)."""
    scale = n_in / n_out
    support = max(1.0, scale)
    centers = (np.arange(n_out) + 0.5) * scale - 0.5
    w = np.maximum(0.0, 1.0 - np.abs((np.arange(n_in)[None, :] - centers[:, None]) / support)).astype(np.float32)
    s = w.sum(axis=1, keepdims=True)
    w /= np.where(s > 0, s, 1)
    return w


def resize(p: np.ndarray, w: int, h: int) -> np.ndarray:
    """Resample a (premultiplied) float image to w x h."""
    if p.shape[0] == h and p.shape[1] == w:
        return p
    t = np.einsum("oh,hwc->owc", _weights(p.shape[0], h), p)
    return np.einsum("pw,owc->opc", _weights(p.shape[1], w), t).astype(np.float32)


def rotate(p: np.ndarray, degrees: float) -> np.ndarray:
    """Rotate counter-clockwise, growing the canvas so nothing is cut (bilinear, premultiplied)."""
    h, w = p.shape[:2]
    th = math.radians(degrees)
    c, s = math.cos(th), math.sin(th)
    nw = max(1, int(math.ceil(abs(w * c) + abs(h * s) - 1e-6)))
    nh = max(1, int(math.ceil(abs(w * s) + abs(h * c) - 1e-6)))
    Y, X = np.mgrid[0:nh, 0:nw].astype(np.float32)
    dx, dy = X + 0.5 - nw / 2, Y + 0.5 - nh / 2
    sx = dx * c - dy * s + w / 2 - 0.5
    sy = dx * s + dy * c + h / 2 - 0.5
    x0, y0 = np.floor(sx).astype(np.int64), np.floor(sy).astype(np.int64)
    fx, fy = (sx - x0)[..., None], (sy - y0)[..., None]
    pad = np.zeros((h + 2, w + 2, 4), np.float32)
    pad[1:-1, 1:-1] = p
    xi, yi = np.clip(x0 + 1, 0, w + 1), np.clip(y0 + 1, 0, h + 1)
    xj, yj = np.clip(x0 + 2, 0, w + 1), np.clip(y0 + 2, 0, h + 1)
    out = (pad[yi, xi] * (1 - fx) * (1 - fy) + pad[yi, xj] * fx * (1 - fy)
           + pad[yj, xi] * (1 - fx) * fy + pad[yj, xj] * fx * fy)
    outside = (sx < -1) | (sx > w) | (sy < -1) | (sy > h)
    out[outside] = 0
    return out.astype(np.float32)


def shift_color(p: np.ndarray, hue_deg: float, brightness: float) -> np.ndarray:
    """Hue rotation (degrees) and brightness multiplier, applied to un-premultiplied colour."""
    u = unpremul(p)
    rgb = u[:, :, :3]
    if hue_deg % 360:
        r, g, b = rgb[:, :, 0], rgb[:, :, 1], rgb[:, :, 2]
        mx, mn = rgb.max(axis=2), rgb.min(axis=2)
        d = mx - mn
        hh = np.zeros_like(mx)
        nz = d > 1e-8
        rm, gm = nz & (mx == r), nz & (mx == g) & (mx != r)
        bm = nz & ~rm & ~gm
        hh[rm] = ((g - b)[rm] / d[rm]) % 6
        hh[gm] = (b - r)[gm] / d[gm] + 2
        hh[bm] = (r - g)[bm] / d[bm] + 4
        hh = (hh / 6 + hue_deg / 360.0) % 1.0
        sat = np.where(mx > 1e-8, d / np.maximum(mx, 1e-8), 0)
        i = np.floor(hh * 6).astype(np.int64) % 6
        f = hh * 6 - np.floor(hh * 6)
        pp, q, t = mx * (1 - sat), mx * (1 - f * sat), mx * (1 - (1 - f) * sat)
        sel = [np.stack(v, axis=-1) for v in ((mx, t, pp), (q, mx, pp), (pp, mx, t), (pp, q, mx), (t, pp, mx), (mx, pp, q))]
        rgb = np.choose(i[..., None], sel)
    if brightness != 1:
        rgb = np.clip(rgb * brightness, 0, 1)
    out = np.dstack([rgb, u[:, :, 3]]).astype(np.float32)
    out[:, :, :3] *= out[:, :, 3:4]
    return out


def composite(canvas: np.ndarray, p: np.ndarray, x: int, y: int) -> None:
    """Alpha-blend premultiplied ``p`` onto the float RGB ``canvas`` with its top-left at (x, y), clipped."""
    H, W = canvas.shape[:2]
    h, w = p.shape[:2]
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + w), min(H, y + h)
    if x1 <= x0 or y1 <= y0:
        return
    src = p[y0 - y:y1 - y, x0 - x:x1 - x]
    dst = canvas[y0:y1, x0:x1]
    dst *= 1 - src[:, :, 3:4]
    dst += src[:, :, :3]


def to_uint8(canvas: np.ndarray) -> np.ndarray:
    return np.clip(np.rint(canvas * 255.0), 0, 255).astype(np.uint8)
