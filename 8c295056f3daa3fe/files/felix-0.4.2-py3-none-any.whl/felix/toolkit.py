"""Shape constructors and the transformation call."""
from __future__ import annotations

import os
import sys

from .errors import FelixError
from .project import P, Obj, current_step
from .shapes import Shape


def _new(kind, params, color, position, name):
    sh = Shape(kind, params, color, position, name)
    if P.stack:
        P.stack[-1][1].append(sh)
    return sh


def circle(radius, position=None, color=None, name=None):
    if radius <= 0:
        raise FelixError("circle radius must be > 0")
    return _new("circle", {"radius": radius}, color, position, name)


def rectangle(width, height, position=None, color=None, name=None):
    if width <= 0 or height <= 0:
        raise FelixError("rectangle width/height must be > 0")
    return _new("rectangle", {"width": width, "height": height}, color, position, name)


def polygon(vertices, position=None, color=None, name=None):
    vertices = [(float(x), float(y)) for x, y in vertices]
    if len(vertices) < 3:
        raise FelixError("polygon needs at least 3 vertices")
    return _new("polygon", {"vertices": vertices}, color, position, name)


def image(source, width=None, height=None, position=None, name=None):
    """An image with transparency, e.g. a PNG. Relative paths are looked up in the
    working directory first, then next to the calling script."""
    cands = [os.path.abspath(source)]
    caller = sys._getframe(1).f_globals.get("__file__")
    if caller:
        cands.append(os.path.join(os.path.dirname(os.path.abspath(caller)), source))
    path = next((c for c in cands if os.path.isfile(c)), None)
    if path is None:
        raise FelixError(f"image not found: {source!r}")
    return _new("image", {"source": path, "width": width, "height": height}, None, position, name)


def stack(*parts: Shape, position=None, color=None, name=None) -> Shape:
    """Combine several shapes into one object: ``cat = fx.stack(head, ear_left, ear_right)``.

    Inside ``fx.class_set`` the stack is **one** class, named after its variable (``cat``); its parts are not classes
    of their own. Each part's ``position`` is where its centre sits relative to the stack's centre (default (0, 0)),
    and later parts are drawn on top. Parts without a colour use the stack's colour. The stack is painted,
    transformed and boxed as a whole; ``position`` here is the stack's own default placement on the canvas."""
    if not parts:
        raise FelixError("fx.stack needs at least one shape, e.g. fx.stack(fx.toolkit.circle(radius=20))")
    for i, p in enumerate(parts):
        if not isinstance(p, Shape):
            raise FelixError(f"fx.stack item {i + 1} is {p!r}; a stack is built from shapes such as "
                             "fx.toolkit.circle(...), fx.toolkit.rectangle(...), fx.toolkit.polygon(...), "
                             "fx.toolkit.image(...) or another fx.stack(...)")
        if p.id is not None:
            raise FelixError(f"fx.stack item {i + 1} is the class {p.name!r}, which is already registered; "
                             "create the part inside the stack call (or outside any class set) instead")
    if P.stack:                                      # parts are pieces of this object, not classes of their own
        pending = P.stack[-1][1]
        pending[:] = [s for s in pending if not any(s is p for p in parts)]
    return _new("stack", {"parts": list(parts)}, color, position, name)


def transformation(obj, hue=None, brightness=None, rotation=None, scale=None, opacity=None):
    """Modify a painted object. Calls accumulate. ``hue``/``rotation`` are in
    degrees (rotation counter-clockwise), ``brightness``/``scale``/``opacity``
    are multipliers. Objects already annotated by fx.gen() are not changed."""
    if not isinstance(obj, Obj):
        raise FelixError("transformation() expects the object returned by fx.paint()")
    kw = {k: v for k, v in dict(hue=hue, brightness=brightness, rotation=rotation,
                                scale=scale, opacity=opacity).items() if v is not None}
    current_step("fx.toolkit.transformation()").ops.append(("xform", obj.idx, kw))
