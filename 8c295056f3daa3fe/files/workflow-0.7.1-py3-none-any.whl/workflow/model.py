"""Model behaviour of the outermost ``wf.stack``: building, running, analysis, devices."""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from . import _ui
from .core import Tensor, device as _device, no_grad
from .errors import ShapeError, WorkflowError
from .layer import Ctx, fmt, is_pyramid

DEFAULT_INPUT = (3, 640, 640)


class ModelAPI:
    def _init_model(self):
        self._built = False
        self._dev = _device.get("cpu")
        self._device_chosen = False
        self.class_names: Optional[List[str]] = None
        self.history: List[dict] = []
        self._train_state = None
        self.quant = None                 # active quantisation scheme (QAT / PTQ), or None for fp32
        self.precision = "fp32"

    # ------------------------------------------------------------------ building
    def build(self, input: Optional[Tuple[int, int, int]] = None) -> "ModelAPI":
        """Validate the architecture and create its parameters for ``input`` = (channels, height, width).
        Called automatically on first use with the shape from ``wf.input(...)`` (default 3x640x640)."""
        shape = tuple(input) if input is not None else (self.input or DEFAULT_INPUT)
        ctx = Ctx()
        ctx.top = self
        out = self.infer(shape, ctx)
        self.input, self._out, self._macs, self._feature_shapes = shape, out, ctx.macs, dict(ctx.features)
        if not self._built:
            self._built = True
        self.to_device(self._dev)          # parameters created by this build follow the model's device
        return self

    def _ensure(self):
        if not self._built:
            self.build()

    def check(self, input: Tuple[int, int, int]):
        """Output shape for another input size (raises a ShapeError if the architecture does not accept it)."""
        self._ensure()
        ctx = Ctx()
        ctx.top = self
        return self.infer(tuple(input), ctx)

    @property
    def output_shape(self):
        self._ensure()
        return self._out

    # ------------------------------------------------------------------ running
    def __call__(self, x: Tensor, train: bool = False):
        """Forward pass on a (N, C, H, W) tensor. Returns a tensor, or a tuple of tensors for pyramids / heads."""
        self._ensure()
        if len(x.shape) != 4 or x.shape[1] != self.input[0]:
            raise ShapeError("the model received an input it cannot use.",
                             f"expected a batch shaped (N, {self.input[0]}, H, W) but got {tuple(x.shape)}.",
                             f"pass images as (batch, {self.input[0]}, height, width); model.predict(...) does this for you.")
        ctx = Ctx(train=train, quant=self.quant)
        if train and getattr(self, "_low_memory", False) and self.quant is None:
            ctx.checkpoint = self
        return self.run(x, ctx)

    # ------------------------------------------------------------------ device
    def device(self, name: Optional[str] = None):
        """``model.device()`` → current device. ``model.device("cuda" | "gpu" | "mps" | "cpu" | "auto")`` moves the model."""
        if name is None:
            return self._dev
        dev = _device.get(name)
        self._ensure()
        self.to_device(dev)
        self._dev, self._device_chosen = dev, True
        return self

    # ------------------------------------------------------------------ analysis
    def count_parameters(self) -> Tuple[int, int]:
        """(trainable, non-trainable) values."""
        self._ensure()
        tr = sum(t.size for _, l in self.walk() for t in l.P.values())
        fr = sum(t.size for _, l in self.walk() for t in l.Bf.values())
        return tr, fr

    def summary(self, input: Optional[Tuple[int, int, int]] = None, show: bool = True) -> Dict[str, object]:
        """Per-layer output shapes, parameters and MACs. Returns the totals."""
        if input is not None or not self._built:
            self.build(input)
        rows = []
        for i, layer, _, out, macs in self._records:
            n = sum(t.size for _, l in layer.walk() for store in (l.P, l.Bf) for t in store.values())
            rows.append((str(i + 1), layer.label(), fmt(out), f"{n:,}" if n else "–", f"{macs / 1e6:,.1f}M" if macs else "–"))
        tr, fr = self.count_parameters()
        totals = {"input": self.input, "output": self._out, "trainable": tr, "non_trainable": fr, "total": tr + fr,
                  "macs": self._macs, "flops": 2 * self._macs, "size_mb": (tr + fr) * 4 / 2**20}
        if show:
            c = _ui.console()
            c.print(_ui._line(("Model summary", f"bold {_ui.BONE}"), ("  input " + fmt(self.input), _ui.ASH)))
            c.print()
            _ui.table(["#", "layer", "output", "params", "MACs"], rows, right=(3, 4), console_=c)
            c.print()
            c.print(_ui._line((f"{tr + fr:,} params", f"bold {_ui.BONE}"), (f"  {tr:,} trainable · {fr:,} non-trainable · {totals['size_mb']:.1f} MB", _ui.ASH)))
            c.print(_ui._line((f"{2 * self._macs / 1e9:,.2f} GFLOPs", f"bold {_ui.BONE}"), (f"  ({self._macs / 1e9:,.2f} G MACs per image)", _ui.ASH)))
            if self._feature_shapes:
                c.print(_ui._line(("features ", _ui.ASH), (", ".join(f"{n} {fmt(s)}" for n, s in self._feature_shapes.items()), _ui.BONE)))
            c.print(_ui._line(("output ", _ui.ASH), (fmt(self._out), _ui.BONE)))
        return totals

    # ------------------------------------------------------------------ state
    def load_state(self, tensors: Dict[str, Tensor], source: str = "the given weights") -> None:
        """Replace parameters and buffers by name; shapes must match."""
        self._ensure()
        have = self.state()
        missing, extra = [k for k in have if k not in tensors], [k for k in tensors if k not in have]
        if missing or extra:
            from .errors import SerializationError
            raise SerializationError(f"{source} does not match this model's architecture.",
                                     f"{len(missing)} tensors are missing (e.g. {missing[:2]}) and {len(extra)} are unexpected (e.g. {extra[:2]}).",
                                     "load it with wf.load(path), which rebuilds the architecture stored in the file.")
        for k, t in tensors.items():
            if tuple(t.shape) != tuple(have[k].shape):
                from .errors import SerializationError
                raise SerializationError(f"{source} does not match this model's architecture.",
                                         f"tensor '{k}' is {tuple(t.shape)} in the file but {tuple(have[k].shape)} in the model.",
                                         "load it with wf.load(path) instead of model.load(path).")
        self.swap_state({k: t.to(self._dev) for k, t in tensors.items()})

    def swap_state(self, new: Dict[str, Tensor]) -> Dict[str, Tensor]:
        """Point the model at other tensors (same names/shapes); returns the previous ones."""
        old = {}
        for prefix, layer in self.walk():
            for store in (layer.P, layer.Bf):
                for k in list(store):
                    name = prefix + k
                    old[name] = store[k]
                    if name in new:
                        new[name].rg = store[k].rg
                        store[k] = new[name]
        return old

    # ------------------------------------------------------------------ detection
    def set_classes(self, names) -> "ModelAPI":
        """Re-target the model at other classes (a list of names, or a count): the head's last prediction layer starts
        afresh for them, every other weight is kept (``wf.fine_tune`` does this for you when the classes differ)."""
        names = [str(i) for i in range(names)] if isinstance(names, int) else [str(n) for n in names]
        head = self.head()
        if len(names) != head.classes or list(self.class_names or []) != names:
            head.set_classes(len(names))
            self._built = False
            self.build(self.input)
        self.class_names = names
        return self

    def labels(self) -> List[str]:
        """What the model detects (or classifies): its class names, in class-id order. A model that was never trained
        on named classes gives "0", "1", … for each output class."""
        names = list(self.class_names or [])
        try:
            n = self.head().classes
        except WorkflowError:
            return names
        return names if len(names) == n else [str(i) for i in range(n)]

    @property
    def task(self) -> Optional[str]:
        """"detect" (wf.head type="bbox"), "classify" (type="cls"), or None without a head."""
        from .compose import Head
        return self.layers[-1].task if self.layers and isinstance(self.layers[-1], Head) else None

    def head(self):
        """The model's head (``wf.head``), which must be its last layer."""
        from .compose import Head
        last = self.layers[-1]
        if not isinstance(last, Head):
            raise WorkflowError("this model has no head.",
                                f"its last layer is {type(last).__name__}; training, prediction and dataset evaluation need wf.head(...) at the end.",
                                "end the stack with wf.head(classes=N).")
        self._ensure()
        return last

    def detection_config(self):
        from .compose import Head
        if not isinstance(self.layers[-1], Head):
            return None
        head = self.layers[-1]
        if head.type == "cls":
            return {"task": "classify", "classes": head.classes, "output": "logits", "activation": "softmax"}
        return {"task": "detect", "classes": head.classes, "box": "ltrb-softplus-stride", "bbox_format": "xyxy"}

    def train(self, train, validation=None, epochs: int = 100, *, batch_size: int = 16, lr: float = 1e-3,
              device: Optional[str] = None, img_size=None, optimizer: str = "adamw", patience: Optional[int] = 30,
              save_every: Optional[int] = 5, output: str = "runs/train", quantization=None, augment: bool = True,
              ema: bool = True, loss_weights=(5.0, 1.0, 1.0), quiet: bool = False, low_memory: Optional[bool] = None,
              autosave: Optional[float] = 10):
        """Train the model. ``train`` / ``validation`` are Felix splits (or a whole Felix dataset, whose own splits
        are then used). ``epochs`` is the **total** target, so a loaded model continues towards it.

        Detection (``wf.head(type="bbox")``): GIoU + BCE loss, mAP50 / mAP50-95 on validation. Classification
        (``type="cls"``, class-folder datasets): cross-entropy with label smoothing 0.1, random-crop augmentation,
        top-1 / top-5 accuracy on validation.

        Defaults: AdamW, warm-up + cosine schedule, EMA weights, early stopping after
        ``patience`` epochs without improvement, ``.nbm`` saves in ``output`` (last, best, every ``save_every``).
        Ctrl+C stops safely and saves. Returns the history (one dict per epoch).

        ``low_memory``: ``True`` recomputes activations during backward instead of keeping them (same results, about
        30% slower, much less memory); ``None`` (default) turns it on by itself on CPU when the run would not
        otherwise fit in free RAM, and stops before training if even that is not enough.

        To adapt a trained model to new data or new classes, use ``wf.fine_tune(model, data)``.

        Crash protection: ``last.nbm`` is also saved every ``autosave`` minutes inside an epoch (``None`` turns it off),
        and on Ctrl+C, ``kill`` (SIGTERM) or an unexpected error; ``wf.load("…/last.nbm")`` then ``train`` continues
        at the exact step. Files are written atomically, so a power cut never leaves a broken checkpoint."""
        from . import train as _train
        self._ensure()
        return _train.fit(self, train, validation, epochs, batch_size, lr, device, img_size, optimizer, patience,
                          save_every, output, quantization, augment, ema, loss_weights, quiet, low_memory, autosave)

    def predict(self, source, device: Optional[str] = None, confidence: float = 0.25, iou: float = 0.45,
                img_size=None, output: Optional[str] = "results/", max_detections: int = 300):
        """Detect objects in an image (path, PIL image or RGB array) or a list of them.

        Annotated images and ``predictions.json`` are written to ``output`` (default ``results/``, created if
        needed; ``output=None`` writes nothing). Returns a ``Results`` (a list-like ``Predictions`` for a list)."""
        from . import predict as _predict
        return _predict.predict(self, source, device, confidence, iou, img_size, output, max_detections)

    # ------------------------------------------------------------------ files
    def save(self, path) -> str:
        """Write a ``.nbm``: architecture, weights, class names, quantisation and (if trained) training state."""
        from . import nbm
        self._ensure()
        st, train, tr = self._train_state, None, None
        if st:
            train = {f"opt.m.{k}": v for k, v in (st.get("m") or {}).items()}
            train.update({f"opt.v.{k}": v for k, v in (st.get("v") or {}).items()})
            train.update({f"raw.{k}": v for k, v in (st.get("raw") or {}).items()})
            tr = {k: st.get(k) for k in ("epoch", "epochs", "best_fitness", "best_epoch", "config", "step", "ema_updates", "resume")}
            tr["history"] = list(self.history)
        return nbm.save(self, path, train=train, precision=self.precision, classes=self.class_names,
                        detection=self.detection_config(), training=tr,
                        quantization=self.quant.meta(self) if self.quant else ({"precision": self.precision} if self.precision != "fp32" else None))

    def load(self, path):
        """Load weights, class names and training state from a ``.nbm`` into this (identical) architecture.
        ``wf.load(path)`` rebuilds the architecture from the file instead."""
        import json
        from . import nbm
        from .errors import SerializationError
        meta = nbm.read_meta(path)
        if meta["arch"] != json.loads(json.dumps(self.spec())):
            raise SerializationError(f"{path} holds a different architecture than this model.",
                                     "model.load only fills in weights; the layers must be the same.",
                                     "use wf.load(path) to rebuild the model stored in the file.")
        nbm.restore(self, path, meta)
        return self

    def export(self, format: str = "onnx", output: Optional[str] = None, precision: str = "fp32", calibration=None,
               img_size=None) -> str:
        """Export to ``format`` = "onnx" or "nbm" with ``precision`` = "fp32", "fp16" or "int8".
        INT8 needs quantisation ranges: train with ``quantization=wf.QAT()`` or pass ``calibration=`` data."""
        from . import export as _export
        return _export.export(self, format, output, precision, calibration, img_size)

    def quantize(self, precision: str = "int8", calibration=None):
        """Post-training quantisation in place. INT8 uses ``calibration`` (a Felix split) to fix activation ranges;
        without it only the weights are quantised. Saving afterwards writes a quantised ``.nbm``."""
        from . import quant
        self.precision = quant.check_precision(precision)
        self.quant = quant.calibrate(self, calibration) if self.precision == "int8" else None
        return self

    # ------------------------------------------------------------------ graph drawing
    def plot(self, detail: str = "layers", show: bool = True):
        """Draw the computation graph; returns a PIL image (opened in a viewer unless ``show=False`` or in a notebook)."""
        from . import diagram
        img = diagram.render_png(diagram.build(self, detail), scale=2)
        if show and "get_ipython" not in dir(__import__("builtins")):
            img.show()
        return img

    def export_graph(self, path, detail: str = "layers", scale: int = 2) -> str:
        """Write the computation graph as ``.png`` or ``.svg``. ``detail="compact"`` draws one row per layer, unexpanded."""
        from . import diagram
        return diagram.export(self, path, detail, scale)
