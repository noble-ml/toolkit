"""``wf.practice_dataset(path)``: a small detection dataset of circles, squares and triangles for trying Workflow out
(the starter notebook, tests, demos). Drawn with Pillow and stored through Felix (``fx.acquire`` + ``fx.export``)."""
from __future__ import annotations

import json
import math
import os
import random
import tempfile

SHAPES = ("circle", "square", "triangle")
COLORS = {"circle": (214, 39, 40), "square": (31, 119, 180), "triangle": (44, 160, 44)}


def _draw(rng, size, max_objects):
    from PIL import Image, ImageDraw
    im = Image.new("RGB", (size, size), tuple(rng.randint(215, 240) for _ in range(3)))
    d = ImageDraw.Draw(im)
    boxes = []
    for k in range(rng.randint(1, max_objects)):
        shape = rng.choice(SHAPES)
        r = rng.uniform(0.07, 0.15) * size
        cx, cy = rng.uniform(r + 4, size - r - 4), rng.uniform(r + 4, size - r - 4)
        a = rng.uniform(0, 2 * math.pi)
        col = tuple(max(0, min(255, c + rng.randint(-25, 25))) for c in COLORS[shape])
        if shape == "circle":
            pts = None
            d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=col)
            x1, y1, x2, y2 = cx - r, cy - r, cx + r, cy + r
        else:
            n = 4 if shape == "square" else 3
            pts = [(cx + r * math.cos(a + 2 * math.pi * i / n), cy + r * math.sin(a + 2 * math.pi * i / n)) for i in range(n)]
            d.polygon(pts, fill=col)
            xs, ys = [p[0] for p in pts], [p[1] for p in pts]
            x1, y1, x2, y2 = min(xs), min(ys), max(xs), max(ys)
        boxes.append((shape, [round(x1, 2), round(y1, 2), round(x2 - x1, 2), round(y2 - y1, 2)]))
    return im, boxes


def practice_dataset(path: str = "practice_shapes.felix", pairs: int = 400, img_size: int = 256, seed: int = 1,
                     max_objects: int = 2, overwrite: bool = False, quiet: bool = True) -> str:
    """Write ``pairs`` pictures of one to ``max_objects`` shapes (circle / square / triangle) with their boxes to
    ``path`` (a .felix file or a folder) and return the path. The same ``seed`` gives the same dataset."""
    try:
        import felix as fx
    except ImportError:
        raise ImportError("practice_dataset stores the dataset through Felix: install felix next to workflow") from None
    if os.path.exists(path) and not overwrite:
        return path
    rng = random.Random(seed)
    with tempfile.TemporaryDirectory(prefix="wf-practice-") as tmp:
        coco = {"images": [], "annotations": [], "categories": [{"id": i + 1, "name": n} for i, n in enumerate(SHAPES)],
                "licenses": [{"id": 1, "name": "CC0 1.0", "url": "https://creativecommons.org/publicdomain/zero/1.0/"}]}
        for i in range(pairs):
            im, boxes = _draw(rng, img_size, max_objects)
            name = f"shapes_{i + 1:05d}.png"
            im.save(os.path.join(tmp, name))
            coco["images"].append({"id": i, "file_name": name, "width": img_size, "height": img_size, "license": 1})
            for shape, b in boxes:
                coco["annotations"].append({"id": len(coco["annotations"]), "image_id": i, "bbox": b,
                                            "category_id": SHAPES.index(shape) + 1})
        with open(os.path.join(tmp, "practice.coco.json"), "w") as f:
            json.dump(coco, f)
        with open(os.path.join(tmp, "classes.yml"), "w") as f:
            f.write("classes: [" + ", ".join(SHAPES) + "]\n")
        fx.reset()
        fx.load_class(os.path.join(tmp, "classes.yml"))      # fixes the class ids: circle 0, square 1, triangle 2
        fx.acquire([fx.sources.local(tmp)])
        fx.export(path, overwrite=overwrite, license="CC0-1.0", title="Workflow practice shapes", quiet=quiet)
        fx.reset()
    return path
