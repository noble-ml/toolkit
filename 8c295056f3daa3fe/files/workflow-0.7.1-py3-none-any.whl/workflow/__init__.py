"""Workflow - Noble Engineering's CNN architecture and training framework."""
from ._version import __version__
from . import core
from .blocks import CBAM, CSP, SE, SPP, SPPF, Bottleneck, Focus
from .compose import FPN, PAN, Add, Concat, Feature, Head, Input, Parallel, Recurrent, Residual, Stack
from .errors import (BackendError, DataError, DeviceError, RoutingError, SerializationError, ShapeError,
                     WorkflowError, WorkflowWarning)
from .layer import Layer
from .layers import (AvgPool2D, BatchNorm2D, Conv2D, DepthwiseConv2D, DilatedConv2D, LeakyReLU, MaxPool2D, MinPool2D,
                     PointwiseConv2D, ReLU, SeparableConv2D, Sigmoid, SiLU, TransposeConv2D, Upsample)

# composition is written in lower case: wf.input(...), wf.stack(...), wf.feature("p3"), wf.head(classes=80)
stack, parallel, feature, concat, add, head, input, recurrent = Stack, Parallel, Feature, Concat, Add, Head, Input, Recurrent

from .evaluate import Evaluation, evaluate as eval      # wf.eval(model) / wf.eval(model, dataset=val)
from .inference import Inference, inference
from .nbm import labels, load
from .practice import practice_dataset
from .finetune import fine_tune
from .quant import QAT
from .results import Predictions, Results


def __getattr__(name):
    """A typo such as wf.Conv2d gets a "did you mean" instead of a bare AttributeError."""
    import difflib
    public = [n for n in globals() if not n.startswith("_")]
    match = [n for n in public if n.lower() == name.lower()] or difflib.get_close_matches(name, public, n=1, cutoff=0.6)
    hint = f" Did you mean {__name__}.{match[0]}?" if match else ""
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'.{hint}")
