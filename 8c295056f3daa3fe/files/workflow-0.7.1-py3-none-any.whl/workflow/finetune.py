"""``wf.fine_tune(model, data)``: adapt a trained model to new data or new classes."""
from __future__ import annotations

from typing import Optional


def fine_tune(model, train, validation=None, epochs: int = 30, *, lr: float = 3e-4, freeze=None,
              output: str = "runs/fine_tune", **kwargs):
    """Fine-tune ``model`` (a loaded model, or the path of a ``.nbm``) on ``train`` and return it.

    A new run starts from the model's weights: a fresh optimizer, learning-rate schedule and epoch count (``epochs``
    counts the fine-tuning epochs). If the dataset's classes differ from the model's, the head's last prediction layer
    is rebuilt for them and every other weight is kept. ``freeze=N`` keeps the first N layers after ``wf.input`` fixed
    (``freeze="backbone"``: everything before the first FPN / PAN / head): their weights do not change, their
    BatchNorm uses its stored statistics and no gradient flows through them (faster); they are released afterwards.
    Every other ``model.train`` option (batch_size, device, img_size, augment, ema, patience, …) can be passed too.
    The model's ``history`` holds the fine-tuning epochs; checkpoints go to ``output``."""
    from . import train as _train
    from .errors import WorkflowError
    from .nbm import load
    if isinstance(model, (str, bytes)) or hasattr(model, "__fspath__"):
        model = load(model)
    if not hasattr(model, "head"):
        raise WorkflowError(f"cannot fine-tune {type(model).__name__}.", "wf.fine_tune takes a Workflow model or a .nbm path.",
                            "pass wf.load(\"model.nbm\") or the path itself.")
    model._ensure()
    o = dict(batch_size=16, device=None, img_size=None, optimizer="adamw", patience=30, save_every=5, quantization=None,
             augment=True, ema=True, loss_weights=(5.0, 1.0, 1.0), quiet=False, low_memory=None, autosave=10)
    unknown = set(kwargs) - set(o)
    if unknown:
        raise WorkflowError(f"wf.fine_tune got unknown option(s): {', '.join(sorted(unknown))}.",
                            "it takes the same options as model.train, plus freeze.", f"use some of: {', '.join(sorted(o))}, freeze.")
    o.update(kwargs)
    _train.fit(model, train, validation, epochs, o["batch_size"], lr, o["device"], o["img_size"], o["optimizer"],
               o["patience"], o["save_every"], output, o["quantization"], o["augment"], o["ema"], o["loss_weights"],
               o["quiet"], o["low_memory"], o["autosave"], True, freeze)
    return model
