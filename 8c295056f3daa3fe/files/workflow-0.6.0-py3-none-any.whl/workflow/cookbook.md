# Cookbook

Every tool, explained like you're three, then *why* you'd reach for it and where it goes. Every example writes
out all the main arguments (with their defaults) so you can see every knob, even the ones you'd usually leave alone.

Felix collects and labels the pictures. Workflow is the brain that learns to find things in them.

How to read an entry:

- **Toddler words**: what it is.
- **Why you'd use it**: the reasoning, and where it usually sits.
- **Example**: every main argument shown.
- **Watch out**: the one mistake people make (when there is one).

---

## Part 1 · Felix: collecting the pictures

### `fx.load_class`

**Toddler words:** the shopping list. Before going out, write down what you're looking for: "leaves". Felix only keeps
boxes for things on the list.

**Why you'd use it:** it decides which classes the dataset has, what an open-vocabulary model is asked to find
(`prompt`), and which names in other datasets or a model's labels mean the same thing (`aliases`).

```python
fx.load_class("./classes.yml")
```
```yaml
classes:
  - name: leaf
    prompt: a green plant leaf
    aliases: [leaves, Leaf]
confidence: 0.3
```

**Watch out:** without a class file, everything is kept: a COCO import brings all 80 classes, and a built-in model
detects everything it knows.

### `fx.acquire` and `fx.sources.*`

**Toddler words:** the shopping trip. Point at the places pictures come from: your folder, a video, a website, a
museum. Felix fetches them when the dataset is built.

**Why you'd use it:** real datasets mix sources. A folder of photos needs no preparation; COCO, YOLO and Felix
datasets bring their boxes; online collections (Wikimedia, Openverse, iNaturalist, Open Images, Roboflow, …) bring
each picture's licence and who to credit.

```python
fx.acquire([
    fx.sources.local("./raw/leaves", recursive=True, labels=None, license=None),
    fx.sources.urls("./leaf_urls.txt", license=None),
    fx.sources.wikimedia(query="plant leaves", limit=1000, licenses=None, max_side=2048),
    fx.sources.open_images(classes=["Car", "Person"], split="validation", limit=None),
], blur_faces=False)
```

**Watch out:** "public on the internet" is not "free to use". URL lists have unknown licences; export reminds you.

### `fx.sources.video` and `fx.sampling`

**Toddler words:** a flip book. Felix keeps some pages, not all: when the picture changes (`auto`), every few seconds
(`interval`), or a random handful (`random`).

**Why you'd use it:** a minute of video is 1,800 frames, nearly all the same. `auto` keeps one frame of a still scene
and more when things move, so the dataset isn't 90% copies.

```python
fx.sources.video("./greenhouse.mp4", sampling=fx.sampling.auto(threshold=0.04, min_gap=0.5))
fx.sources.video("./street.mp4", sampling=fx.sampling.interval(seconds=2))
fx.sources.video("./street.mp4", sampling=fx.sampling.random(count=1000, seed=42))
fx.sources.camera(device=0, sampling=fx.sampling.interval(seconds=1), count=500)
```

### `fx.transform.center_crop`, `letterbox`

**Toddler words:** make every picture the same size. Center crop cuts the edges off; letterbox shrinks the whole
picture and adds grey bars.

**Why you'd use it:** center crop shrinks big photos before annotating (faster, and the subject is usually in the
middle); letterbox keeps every part of a scene, which suits general detectors. The boxes move with the pixels.

```python
fx.transform.center_crop(size=640, min_visibility=0.3)
fx.transform.letterbox(size=640, fill=(114, 114, 114))
```

### `fx.transform.consequential`

**Toddler words:** zoom in on each toy and take a photo of it, plus a few photos of empty floor so the brain learns
what "nothing" looks like.

**Why you'd use it:** in a 4,000-pixel photo a leaf may be 40 pixels: resized to 640 for training it nearly vanishes.
Crops around each object keep them big enough to learn, and `negative_rate` of the crops show no objects.

```python
fx.annotate(model=model)                                   # first: it needs the boxes
fx.transform.consequential(size=640, negative_rate=0.15, margin=0.25, min_visibility=0.3, overlap=0.6, seed=0)
```

**Watch out:** it must come after `fx.annotate`, and nothing that changes geometry may follow it. Felix stops you if
the order is wrong.

### `fx.annotate` and `fx.models`

**Toddler words:** a helper who looks at every picture and draws the boxes for you.

**Why you'd use it:** drawing boxes by hand takes forever. Use your own trained Workflow model, or a built-in one:
`yolo26n` knows 80 everyday things, `yoloe` finds whatever classes.yml describes, `sam` turns boxes into outlines.

```python
fx.annotate(model=wf.load("./models/leaf-detector.nbm"), confidence=0.25, replace=False, batch_size=8)
fx.annotate(model=fx.models.yolo26n)
fx.annotate(model=fx.models.yoloe)        # prompted with classes.yml
fx.annotate(model=fx.models.sam)          # masks for the boxes already there
```

**Watch out:** a picture the model chokes on is marked failed and left out, never saved as "nothing here".

### `fx.export`

**Toddler words:** pack the box and write the label on it: what's inside, where each picture came from, and who may
use it.

**Why you'd use it:** it runs everything above and writes the dataset Workflow trains from, plus LICENSE.txt,
ATTRIBUTIONS.md and CITATION.cff. `pairs=` stops at a number; without it, it keeps going until the sources run out
or you press Ctrl+C.

```python
fx.export("./datasets/leaves.felix", pairs=None, license=None, title=None, authors=None, strict=False)
fx.export("./datasets/leaves", license="CC-BY-4.0")        # a folder, released openly
fx.export("./datasets/leaves.sh_felix", shard_size=1000)   # a folder of shards
```

**Watch out:** `license=None` means closed (all rights reserved). For an open dataset, read the ⚠ lines in
ATTRIBUTIONS.md: some image licences don't fit some dataset licences.

### `fx.load` and its splits

**Toddler words:** open the box. It already has three piles: `train` (learn from these), `val` (check while
learning), `test` (the final exam).

**Why you'd use it:** you pass these piles straight to Workflow. Imported datasets keep their splits; everything else
is split 80/10/10, the same way every time.

```python
data = fx.load("./datasets/leaves.felix")
data.train, data.val, data.test, data.classes, data.splits
```

### `fx.split` / `felix split`

**Toddler words:** photocopy the pile, then keep only part of the copy. The big pile stays exactly as it was.

**Why you'd use it:** quick experiments on a tenth of the data. Every split and class keeps its share.

```python
fx.split("voc.felix", 0.5, output=None, size=None, seed=0)
```

### `fx.shard` / `felix shard`

**Toddler words:** a huge pile of photos goes into many small boxes, so you can carry one box at a time.

**Why you'd use it:** very large datasets. Workflow trains from a folder of shards one shard at a time.

```python
fx.shard("voc.felix", output=None, size=1000)
fx.export("./datasets/big.sh_felix")                       # or export straight into shards
```

### Other Felix commands

**Toddler words:** look inside a box, zip it up, unzip it, and turn someone else's box into yours.

```
felix info leaves.felix
felix pack ./leaves -o leaves.felix
felix unpack leaves.felix -o ./leaves
felix convert ./roboflow-export -o data.felix
felix library
```

---

## Part 2 · Workflow: the brain's building blocks

### `wf.input`

**Toddler words:** the front door of the brain. It says what kind of pictures come in: how many colour channels
(3 for red, green and blue) and how big.

**Why you'd use it:** Workflow builds the whole model from it. It works out how many channels reach every layer,
makes the weights the right size, and checks that every layer fits *before* anything trains. It is also the size
pictures are resized to for training and prediction, unless you ask for another. It always goes on the very first
line, because that's where the picture comes in.

```python
model = wf.stack(
    wf.input(channels=3, height=256, width=256),
    wf.Conv2D(16, kernel_size=3, stride=2, padding="same"),
    ...
)
```

**Watch out:** only one, only at the top of the outermost `wf.stack` (blocks like `wf.Residual` take their input from
the layer before them). Leave it out and Workflow assumes 3 × 640 × 640. A trained model can still predict at other
sizes with `img_size=`.

### `wf.stack`

**Toddler words:** line up blocks. The picture goes through them one after another, like a slide with bumps.

**Why you'd use it:** it's the model itself (the outermost one) and also any group of layers you want to treat as
one. Its first line is `wf.input(...)`, then one layer per line.

```python
model = wf.stack(
    wf.input(channels=3, height=640, width=640),

    wf.Conv2D(16, kernel_size=3, stride=1, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.feature("p1"),
)
```

**Watch out:** you never say how many channels go *in* to a layer. Workflow works that out.

### `padding` (used by every layer with a window)

**Toddler words:** a cushion of empty pixels around the picture so the edges don't get squished away. You pick one
of two words: `"same"` (put a cushion on, keep the picture the same size) or `"valid"` (no cushion, the picture
shrinks a little).

**Why you'd use it:** without a cushion, every 3×3 window eats one pixel from each edge, so the picture shrinks a
bit at every layer. `"same"` stops that, which keeps sizes easy to reason about: a stride-1 layer keeps the size, and a
stride-2 layer exactly halves it (rounding up). Almost every layer in a detector uses `"same"`. `"valid"` (the
default) is for when you *want* the picture to shrink, or want the window to only ever see real pixels.

```python
wf.Conv2D(32, kernel_size=3, stride=1, padding="same")    # 256×256 in → 256×256 out
wf.Conv2D(32, kernel_size=3, stride=2, padding="same")    # 256×256 in → 128×128 out
wf.Conv2D(32, kernel_size=3, stride=1, padding="valid")   # 256×256 in → 254×254 out
```

**Watch out:** numbers like `padding=1` are not accepted. The error tells you which word to use (`1` meant
`"same"` for a 3×3, `0` meant `"valid"`).

### `wf.Conv2D`

**Toddler words:** little magnifying glasses that slide over the picture, each looking for one kind of pattern (an
edge, a corner, a stripe). The first number is `out_channels`: how many different glasses, so how many channels come
*out*. `32` means 32 glasses, so 32 channels come out.

**Why you'd use it:** it's *the* building block. Early convs find edges; later ones find parts and whole objects.
`stride=2` takes big steps, halving the picture; that's how a backbone goes from big-and-shallow to small-and-deep.
You never write how many channels come *in*: Workflow reads that from the layer before.

```python
wf.Conv2D(32, kernel_size=3, stride=1, padding="same")    # 32 channels out, same size
wf.Conv2D(64, kernel_size=3, stride=2, padding="same")    # 64 channels out, half size: a "downsampling" step
wf.Conv2D(out_channels=64, kernel_size=3, stride=2, padding="same")   # the same, with the name written out
```

### `wf.DepthwiseConv2D`

**Toddler words:** one magnifying glass per colour channel, and each one only looks at its own channel.

**Why you'd use it:** it's very cheap. Mobile-style models use it to look around spatially for almost no cost,
then mix the channels with a pointwise conv.

```python
wf.DepthwiseConv2D(kernel_size=3, stride=1, padding="same")    # keeps the channel count
```

### `wf.PointwiseConv2D`

**Toddler words:** a 1×1 glass. It doesn't look around; it just mixes the channels at each spot.

**Why you'd use it:** changing the number of channels cheaply: squeezing before expensive work, or matching
channels before an `add`.

```python
wf.PointwiseConv2D(64)       # kernel 1, stride 1, padding 0 are fixed: that's what "pointwise" means
```

### `wf.SeparableConv2D`

**Toddler words:** depthwise, then pointwise: look around, then mix.

**Why you'd use it:** a drop-in for `Conv2D` that does nearly the same job for a fraction of the maths. Good for
small or fast models.

```python
wf.SeparableConv2D(64, kernel_size=3, stride=1, padding="same")
```

### `wf.DilatedConv2D`

**Toddler words:** a magnifying glass with gaps between its eyes, so it sees farther without costing more.

**Why you'd use it:** a bigger view (more context) without shrinking the picture or adding work. Useful late in
a network or for big objects.

```python
wf.DilatedConv2D(32, kernel_size=3, dilation=2, stride=1, padding="same")   # sees a 5×5 area, keeps the size
```

### `wf.TransposeConv2D`

**Toddler words:** a magnifying glass that makes the picture *bigger* (it un-squishes), and learns how.

**Why you'd use it:** growing a small, smart map back to a bigger size, for example in a neck. Unlike `Upsample`,
which just copies pixels, it *learns* how to fill in the new pixels.

```python
wf.TransposeConv2D(32, kernel_size=2, stride=2, padding="valid")   # exactly twice the height and width
wf.TransposeConv2D(32, kernel_size=4, stride=2, padding="same")    # also twice, blending neighbours more smoothly
```

Output size: with `"same"` it is exactly `size × stride`; with `"valid"` it is `(size − 1) × stride + kernel_size`.
With `kernel_size=2, stride=2` both give exactly double, which is why those are the defaults.

**Watch out:** `"same"` needs `kernel_size` at least as big as `stride` (the error says so). It stays float in int8
models (Workflow warns you); use `Upsample` + `Conv2D` if everything must be int8.

### `wf.BatchNorm2D`

**Toddler words:** keeps the numbers from getting too big or too small, so learning doesn't wobble.

**Why you'd use it:** almost always right after a convolution: `Conv2D → BatchNorm2D → activation`. Models train
faster and more reliably with it. The conv before it automatically drops its bias, which the BatchNorm would cancel
anyway.

```python
wf.BatchNorm2D()         # channels are worked out for you
```

### `wf.ReLU`, `wf.LeakyReLU`, `wf.SiLU`, `wf.Sigmoid`

**Toddler words:** mood filters. ReLU says "no sad numbers, make them zero". LeakyReLU says "a tiny bit of sad is
okay". SiLU is a smooth ReLU. Sigmoid squishes everything between 0 and 1.

**Why you'd use it:** without them, stacking layers is no smarter than one layer. SiLU is the modern default for
detectors; ReLU is the cheapest; Sigmoid is for gates and probabilities, not between layers.

```python
wf.ReLU()
wf.LeakyReLU(slope=0.1)
wf.SiLU()
wf.Sigmoid()
```

### `wf.MaxPool2D`, `wf.MinPool2D`, `wf.AvgPool2D`

**Toddler words:** shrink the picture by looking at little squares and keeping one number from each. Max keeps the
loudest pixel, Min keeps the quietest, Avg keeps the average.

**Why you'd use it:** a cheap way to make the picture smaller (or smoother) with no weights to learn.
- **Max** answers "is the pattern anywhere in here?". It is the usual choice, and what `SPPF` uses.
- **Min** answers "is anything *missing* or dark here?", for dark objects on light backgrounds, gaps or holes.
- **Avg** smooths things out and keeps the overall level.

```python
wf.MaxPool2D(kernel_size=2, stride=None, padding="valid")   # stride defaults to kernel_size: half the size
wf.MaxPool2D(kernel_size=5, stride=1, padding="same")       # same size: every pixel becomes its 5×5 neighbourhood's max
wf.MinPool2D(kernel_size=3, stride=2, padding="same")       # half the size, keeping the smallest values
wf.AvgPool2D(kernel_size=3, stride=1, padding="same")       # same size, just smoothed
```

**Watch out:** the cushion pixels from `"same"` never win a max or a min, but they count as zero in an average,
so averages at the very edge come out a little darker.

### `wf.Upsample`

**Toddler words:** make the picture bigger by copying each pixel.

**Why you'd use it:** cheap resizing with nothing to learn, usually before joining a small map to a big one.

```python
wf.Upsample(scale=2)
```

---

## Part 3 · Workflow: bigger blocks

### `wf.Bottleneck`

**Toddler words:** squeeze the picture thin (fewer channels), look around, puff it back up, then add the original
back so nothing gets lost.

**Why you'd use it:** to make a network deeper without making it slow. The expensive 3×3 look-around happens on
the thin version, and the added shortcut keeps learning stable in deep stacks.

```python
wf.Bottleneck(out_channels=None, kernel_size=3, stride=1, reduction=2, shortcut=True)   # same shape out as in
wf.Bottleneck(out_channels=128, kernel_size=3, stride=2, reduction=2, shortcut=True)    # 128 channels out, half size
```

**Watch out:** when `out_channels` or `stride` change the shape, the shortcut gets a 1×1 projection automatically,
so you never have to match the shapes yourself.

### `wf.CSP`

**Toddler words:** split into two paths. One does hard work (bottlenecks), one takes it easy. Then glue them
together.

**Why you'd use it:** most of the accuracy of a deep stack of bottlenecks at a lot less cost. It's the standard
backbone block after each downsampling conv.

```python
wf.CSP(out_channels=None, n=1, shortcut=True)      # n = how many bottlenecks on the busy path
```

### `wf.SPP`, `wf.SPPF`

**Toddler words:** look at the picture through small, medium and big windows at the same time, then glue what
you saw.

**Why you'd use it:** at the end of the backbone, so the brain sees both details and the big picture. SPPF gets
the same result faster with three chained small pools, so prefer it.

```python
wf.SPP(out_channels=None, kernels=(5, 9, 13))
wf.SPPF(out_channels=None, kernel_size=5)
```

### `wf.SE`

**Toddler words:** each channel asks "am I important for *this* picture?" and turns its own volume up or down.

**Why you'd use it:** a small, cheap accuracy boost, usually after a backbone block. It learns to pay more
attention to the channels that matter for the image at hand.

```python
wf.SE(reduction=16)       # how much the "am I important?" helper squeezes; 16 is the classic value
```

### `wf.CBAM`

**Toddler words:** SE, plus "which *spots* in the picture matter?": a spotlight for channels and places.

**Why you'd use it:** like SE, but it also helps with *where*, which suits detection. Costs a bit more.

```python
wf.CBAM(reduction=16, kernel_size=7)
```

### `wf.Focus`

**Toddler words:** cut the picture into 2×2 tiles and stack the tiles as channels: half the size, nothing thrown
away.

**Why you'd use it:** as the very first layer, a fast way to shrink a big input without losing pixels.

```python
wf.Focus(out_channels=32, kernel_size=3)
```

**Watch out:** the input height and width must be even.

---

## Part 4 · Workflow: wiring

### `wf.Residual`

**Toddler words:** do some stuff, then add what you started with. "Remember where you came from."

**Why you'd use it:** to build your own residual block. It lets very deep models train, because the brain can
learn "a small change to the input" instead of a whole new picture.

```python
wf.Residual(
    wf.Conv2D(64, kernel_size=3, stride=1, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    shortcut="auto",                                  # default: same shape in and out → add the input as it is
)

wf.Residual(
    wf.Conv2D(128, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    shortcut="auto",                                  # shape changes → a 1×1 Conv2D + BatchNorm2D is added to match
)

wf.Residual(
    wf.Conv2D(128, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    shortcut=wf.stack(                                # or design the shortcut yourself
        wf.AvgPool2D(2, stride=2),
        wf.Conv2D(128, kernel_size=1),
    ),
)
```

**Watch out:** both paths must end the same shape. If they don't, the error tells you the exact `shortcut=` to add.

### `wf.parallel`

**Toddler words:** give the same picture to several friends, then glue (or add up) their answers.

**Why you'd use it:** let the brain look at the same thing in different ways at once (small and big windows,
for example), Inception-style.

```python
wf.parallel(
    wf.Conv2D(16, kernel_size=1, stride=1, padding="valid"),
    wf.Conv2D(16, kernel_size=3, stride=1, padding="same"),
    merge="concat",                                   # or merge="add" (then the outputs must match)
)
```

### `wf.feature`

**Toddler words:** stick a note with a name on the current picture so you can grab it later.

**Why you'd use it:** detectors need maps from several depths (big and detailed, small and smart). You name them
in the backbone and use them in the neck.

```python
wf.feature("p3")
wf.feature(("n3", "n4", "n5"))        # after FPN/PAN: one name per map of the pyramid
```

### `wf.concat`, `wf.add`

**Toddler words:** grab named notes and glue them side by side (concat) or add them up (add).

**Why you'd use it:** to hand-build skip connections or necks. Concat keeps both sets of channels (more
information, more channels); add mixes them (same channels, cheaper).

```python
wf.concat("p3", "up")      # needs the same height and width; channels add up
wf.add("a", "b")           # needs identical shapes
```

### `wf.FPN`

**Toddler words:** big pictures see small details; small pictures know *what* things are. FPN passes the "what"
knowledge down into the big pictures.

**Why you'd use it:** so small objects (found on the big maps) are recognised as well as large ones. It takes your
named maps in any order, any channel counts, and handles the resizing and channel matching itself.

```python
wf.FPN("p3", "p4", "p5", channels=64)      # channels=None uses the smallest input's channel count
```

### `wf.PAN`

**Toddler words:** the other way round: it passes the sharp details back up to the small pictures.

**Why you'd use it:** right after FPN, so the maps that find big objects also get precise edges. FPN + PAN is the
classic modern neck.

```python
wf.PAN(channels=64)                        # works on the pyramid FPN just produced
```

### `wf.head`

**Toddler words:** the mouth. A box head (`type="bbox"`) says, for every spot, "there's a cat here, this big, and I'm
this sure". A class head (`type="cls"`) looks at the whole picture and says one word: "cat".

**Why you'd use it:** it's what turns features into answers. It must be the last layer, and `classes` must match your
dataset (Workflow checks). Box heads learn from datasets with boxes; class heads learn from folders of pictures, one
folder per class (see the Classification page).

```python
wf.head(classes=3, channels=None, type="bbox")    # detection; channels=None: as wide as each incoming map
wf.head(classes=10, channels=512, type="cls")     # classification; channels=512: widen to 512 before pooling
```

**Watch out:** a class head trained on a box dataset (or the other way round) stops with a message naming the right
`type`.

---

## Part 5 · Workflow: using the brain

### `model.summary()`

**Toddler words:** "tell me about yourself": every layer, how big, and how much work it does.

**Why you'd use it:** before training, to check the shapes come out as you expect and the model isn't accidentally
huge. It builds the model, so shape mistakes show up here, not halfway through training.

```python
model.summary(input=None, show=True)       # input=(3, 416, 416) checks another size
```

### `model.export_graph`

**Toddler words:** draw a picture of the brain.

**Why you'd use it:** to see your wiring (shortcuts, branches, which feature goes where) or to share it. SVG for
documents, PNG for quick looks.

```python
model.export_graph("brain.png", detail="layers", scale=2)     # detail="compact" for one row per layer
```

### `model.device`

**Toddler words:** pick which helper does the maths: the computer's own brain (`"cpu"`), a big NVIDIA graphics card
(`"cuda"`), any graphics card (`"gpu"`), or a Mac's graphics chip (`"mps"`, still learning to walk).

**Why you'd use it:** GPUs are much faster for training. Usually you just pass `device=` to `train` or `predict`
instead.

```python
model.device("cuda")      # or "cpu", "gpu", "mps", "auto"
model.device()            # which one am I on?
```

**Watch out:** if you ask for a GPU that isn't there, you get an error saying why, never a silent switch to CPU.

### `model.train`

**Toddler words:** look at lots of pictures and their answers, again and again, until you get good. Press Ctrl+C
and it saves before stopping. It also saves by itself every 10 minutes, so if the computer crashes or the power goes
out, you lose minutes, not hours: load `last.nbm` and train again, and it carries on from the same step.

**Why you'd use it:** this is learning. The defaults (optimizer, learning-rate schedule, loss, augmentation,
checkpoints) are sensible, so most of the time you only set the data and `epochs`.

```python
model.train(data.train, validation=data.val, epochs=50, batch_size=16, lr=1e-3, device="auto",
            img_size=None, optimizer="adamw", patience=30, save_every=5, output="runs/train",
            quantization=None, augment=True, ema=True, low_memory=None, autosave=10)
```

**Not enough memory?** On CPU it checks first. If the batch won't fit it turns on `low_memory` (it forgets the
in-between results and works them out again when it needs them: same answers, a bit slower), and if even that won't
fit it tells you the biggest `batch_size` that does, before wasting any time.

While it learns you see a bar, plus a table that gains a line every epoch: the training loss, the validation loss
(how wrong it is on pictures it doesn't learn from) and the mAP scores. If the training loss keeps falling but the
validation loss starts rising, the brain is memorising the training pictures instead of learning.

**Watch out:** `epochs` means "train *until* epoch N". To continue a model that reached 50, ask for `epochs=80` to get
30 more; `epochs=30` would do nothing.

### `wf.eval`

**Toddler words:** a report card. Without a test: "how big and how fast am I?". With a test: "how many do I get
right?".

**Why you'd use it:** before training to compare architectures (size, speed); after training to measure accuracy on
the test pile. It never changes the model.

```python
wf.eval(model, dataset=None, device=None, img_size=None, batch_size=8, show=True)
wf.eval(model, dataset=data.test)              # adds mAP50, mAP50-95, precision, recall
```

### `wf.QAT`

**Toddler words:** practise with smaller, rounder numbers while learning, so the brain still works after it's shrunk.

**Why you'd use it:** when you'll ship an int8 model (smaller, faster on small devices). Usually a short fine-tune
*after* normal training: it starts from your trained weights.

```python
model.train(data.train, validation=data.val, epochs=55, quantization=wf.QAT(precision="int8"))   # 5 epochs after 50
```

### `model.quantize` / `workflow quantize`

**Toddler words:** shrink a finished brain so it's small and fast. Show it some pictures first (calibration) so it
learns how big the numbers get.

**Why you'd use it:** the quick way to int8 or fp16 without retraining. Try it first; use QAT if accuracy drops
too much.

```python
model.quantize("int8", calibration=data.val)     # "fp16" needs no calibration
```
```
workflow quantize detector.nbm int8 --calibration shapes.felix
```

### `model.save`, `wf.load`, `model.load`

**Toddler words:** put the brain in a box (`.nbm`) and take it out again later.

**Why you'd use it:** keep a trained model, share it, or continue training it. The box holds the layers, weights,
class names and training progress.

```python
model.save("detector.nbm")
model = wf.load("detector.nbm")       # rebuilds everything from the box
model.load("detector.nbm")            # fills a model you already built the same way
```

### `model.export`

**Toddler words:** pack the brain for other programs (ONNX), or make a smaller box.

**Why you'd use it:** ONNX runs in many runtimes (ONNX Runtime, mobile, servers); an int8 `.nbm` is the smallest
Workflow file.

```python
model.export(format="onnx", output="detector.onnx", precision="fp32", calibration=None, img_size=None)
model.export(format="nbm", output="detector-int8.nbm", precision="int8", calibration=data.val)
```

### `wf.inference`

**Toddler words:** "go look at these and tell me what you see." Give it a picture, a video, a folder or a whole Felix
dataset, plus the brain, plus a folder for the answers. It figures out what you gave it by itself.

**Why you'd use it:** this is how you *use* a trained model. It keeps everything together in one folder: the
original pictures, the same pictures with boxes drawn on, and `predictions.json` with every box. Give it a Felix
dataset and it picks the test pile on its own (the pictures the model never trained on), unless you choose
another pile. From a big pile (a dataset or a folder) it looks at **one picture picked at random**, a quick spot
check. Say `all=True` when you want every picture done.

```python
model = wf.load("detector.nbm")
run = wf.inference("shapes.felix", model, "results/", all=False, split=None, confidence=0.25, iou=0.45,
                   img_size=None, device=None, batch_size=16)      # one random test picture
wf.inference("shapes.felix", model, "results/all/", all=True)       # every test picture
wf.inference("holiday.mp4", model, "results/video/")                # every frame, annotated video saved
wf.inference("photos/", model, "results/photos/", all=True)         # every image (and video) in the folder
wf.inference(data.val, model, "results/val/", all=True)             # you pick the pile
wf.inference("webcam", model)                                       # live, in a window (q to stop)
```

**Webcam:** `"webcam"` opens a window and detects live, with the FPS on the picture. Arrow keys or the number keys
switch camera (`1` is the second camera), `q` or `Esc` stops; the console lists the keys. Nothing is saved
unless `record=True`.

**Watch out:** videos and the webcam need `pip install opencv-python`. The folder can be reused: files are added, and names
never overwrite each other.

### `model.predict`

**Toddler words:** "what's in this picture?", answered straight back to you in Python.

**Why you'd use it:** inside your own code, when you want the boxes as data and not a folder of files (for example
in a camera loop). `wf.inference` is built on it.

```python
r = model.predict("photo.jpg", device=None, confidence=0.25, iou=0.45, img_size=None,
                  output="results/", max_detections=300)
r.classes, r.confidences, r.xyxy
r.show()
```

**Watch out:** raise `confidence` for fewer, surer boxes; lower `iou` if one object gets several boxes.
`output=None` saves nothing, which is handy for video.

### Errors

**Toddler words:** when something is wrong, Workflow tells you what broke, why, and how to fix it, like a kind
teacher.

**Why it matters:** you fix it from the message instead of digging through code. The first line also names the
layer.

```
layer 4 (Residual): Residual cannot add its two paths.
  why: the layers output (16, 15, 15) but the shortcut carries (8, 30, 30); addition needs identical shapes.
  fix: ... project the input with shortcut=wf.Conv2D(16, kernel_size=1, stride=2).
```

### `workflow init`

**Toddler words:** "give me a notebook that already works." It writes a Jupyter notebook with a small brain, a
report card before and after learning, and saving.

**Why you'd use it:** the fastest way to start a new detector, or to show someone how Workflow fits together.
Every step is a cell you can read and change; the model is a flat list of layers you can grow. Without a dataset it
makes a practice one, so the first run always works.

```
workflow init detector.ipynb --dataset data.felix --img-size 256 --epochs 30 --device auto
```

**Watch out:** the image size must be a multiple of 32 (the starter model halves the picture four times).

### Workflow commands

**Toddler words:** the same tools, typed in the terminal.

**Why you'd use it:** checking, converting and running models without writing Python.

```
workflow init my_detector.ipynb                     # a starter notebook
workflow info detector.nbm
workflow predict detector.nbm photo.jpg --confidence 0.25     # also videos, folders, datasets (--all for every image)
workflow eval detector.nbm --dataset shapes.felix --split test
workflow quantize detector.nbm int8 --calibration shapes.felix
workflow export detector.nbm --format onnx --precision fp32
workflow script detector.nbm --preset webcam         # writes a ready-to-run camera program
workflow devices
```

---

## Part 6 · Recipes: how the pieces fit

**A downsampling step** (the most common pattern in a backbone): three lines that halve the picture and add
channels. You'll see it again and again in the detector below.

```python
wf.Conv2D(64, kernel_size=3, stride=2, padding="same"),
wf.BatchNorm2D(),
wf.SiLU(),
```

**A small detector**: the backbone halves the picture five times, naming three depths with `wf.feature`; SPPF
widens the view; FPN + PAN mix the named maps; the head finds the boxes.

```python
model = wf.stack(
    wf.input(channels=3, height=256, width=256),

    # stem: 256 → 128
    wf.Conv2D(16, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),

    # 128 → 64
    wf.Conv2D(32, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.CSP(n=1),

    # 64 → 32: good for small objects
    wf.Conv2D(64, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.CSP(n=2),
    wf.feature("p3"),

    # 32 → 16: medium objects
    wf.Conv2D(128, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.CSP(n=2),
    wf.feature("p4"),

    # 16 → 8: large objects
    wf.Conv2D(256, kernel_size=3, stride=2, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.SPPF(kernel_size=5),
    wf.feature("p5"),

    # neck and head
    wf.FPN("p3", "p4", "p5", channels=64),
    wf.PAN(channels=64),
    wf.head(classes=3),
)
```

**Train, then shrink for deployment:**

```python
model.train(data.train, validation=data.val, epochs=50)
wf.eval(model, dataset=data.test)
model.train(data.train, validation=data.val, epochs=55, quantization=wf.QAT(precision="int8"))
model.export(format="nbm", output="detector-int8.nbm", precision="int8")
```

**A cheaper backbone block** (mobile-style): look around cheaply, mix, add back:

```python
wf.Residual(
    wf.DepthwiseConv2D(kernel_size=3, stride=1, padding="same"),
    wf.BatchNorm2D(),
    wf.SiLU(),
    wf.PointwiseConv2D(64),
    wf.BatchNorm2D(),
)
```
