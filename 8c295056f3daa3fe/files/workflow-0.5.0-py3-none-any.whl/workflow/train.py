"""The training loop behind ``model.train``."""
from __future__ import annotations

import math
import os
import random
import time
from typing import Dict, List, Optional

from . import _stale
_stale.check()      # an upgraded install inside an old session stops here, clearly

from . import _ui, classify, data, detect, nbm
from .core import Tensor, backward, clear_tape, no_grad
from .errors import DataError, WorkflowError
from .metrics import DetectionMetrics


class Optimizer:
    """AdamW (default) or SGD with momentum; weight decay applies to weights, not biases / BatchNorm."""

    def __init__(self, params: Dict[str, Tensor], kind: str = "adamw", weight_decay: float = 5e-4):
        if kind not in ("adamw", "sgd"):
            raise WorkflowError(f"unknown optimizer {kind!r}.", "Workflow ships 'adamw' and 'sgd'.", "use optimizer='adamw' or optimizer='sgd'.")
        self.kind, self.wd, self.t = kind, weight_decay, 0
        self.params = params
        self.m = {k: Tensor.zeros(p.shape, p.dev) for k, p in params.items()}
        self.v = {k: Tensor.zeros(p.shape, p.dev) for k, p in params.items()} if kind == "adamw" else {}

    def step(self, lr: float) -> None:
        self.t += 1
        for k, p in self.params.items():
            g, p.grad = p.grad, None
            if g is None:
                continue
            wd = self.wd if len(p.shape) > 1 else 0.0
            if self.kind == "adamw":
                p.dev.be.adamw(p, g, self.m[k], self.v[k], lr, 0.9, 0.999, 1e-8, wd, self.t)
            else:
                p.dev.be.sgd(p, g, self.m[k], lr, 0.937, wd)

    def load(self, m, v, step) -> bool:
        if set(m) != set(self.m) or any(tuple(m[k].shape) != tuple(self.m[k].shape) for k in m):
            return False
        for k in m:
            self.m[k] = m[k].to(self.params[k].dev)
            if k in v and k in self.v:
                self.v[k] = v[k].to(self.params[k].dev)
        self.t = step
        return True


def clip_gradients(params: Dict[str, Tensor], max_norm: float):
    grads = [p.grad for p in params.values() if p.grad is not None]
    be = grads[0].dev.be if grads else None
    if be is not None and hasattr(be, "clip_norm"):       # on the GPU, without waiting for it
        return be.clip_norm(grads, max_norm)
    total = math.sqrt(sum(p.dev.be.sumsq(p.grad) for p in params.values() if p.grad is not None))
    if total > max_norm:
        for p in params.values():
            if p.grad is not None:
                p.dev.be.scale(p.grad, max_norm / total)
    return total


class EMA:
    """Exponential moving average of all model state, with a ramped decay so short runs aren't held back."""

    def __init__(self, state: Dict[str, Tensor], params, decay=0.9999, tau=2000, updates=0):
        self.decay, self.tau, self.updates, self.trainable = decay, tau, updates, set(params)
        self.shadow = {k: t.clone() for k, t in state.items()}

    def update(self, state: Dict[str, Tensor]) -> None:
        self.updates += 1
        d = self.decay * (1 - math.exp(-self.updates / self.tau))
        for k, t in state.items():
            t.dev.be.ema(self.shadow[k], t, d if k in self.trainable else 0.0)     # buffers are copied


def split_targets(targets: List[float], n: int) -> List[List[List[float]]]:
    """Flat rows [image, class, x1, y1, x2, y2] → per image [[class, x1, y1, x2, y2], ...]."""
    out = [[] for _ in range(n)]
    for i in range(0, len(targets), 6):
        out[int(targets[i])].append(targets[i + 1:i + 6])
    return out


def run_eval(model, batches, size, names, conf=0.001, iou=0.6, progress=None, loss_weights=None):
    """Evaluate on batches of (images, targets). Returns (metrics, milliseconds per image). Never changes weights.
    ``progress`` is an optional (panel, row) to advance per batch. With ``loss_weights`` the metrics also hold the
    validation loss (``loss``, ``box``, ``obj``, ``cls``), computed exactly like the training loss."""
    metrics = DetectionMetrics(model.head().classes, names)
    t_total, n_img = 0.0, 0
    loss_sum, parts_sum, n_batches = 0.0, {"box": 0.0, "obj": 0.0, "cls": 0.0}, 0
    with no_grad():
        for x, targets in batches:
            if progress is not None:
                panel, row = progress
                row.n, row.status = n_img, "running"
                row.label = f"image {n_img:,}/{row.total:,}"
                panel.refresh()
            t0 = time.perf_counter()
            outs = model(x, train=False)
            dets = detect.decode(outs, size, conf, iou)
            t_total += time.perf_counter() - t0
            n_img += x.shape[0]
            for d, g in zip(dets, split_targets(targets, x.shape[0])):
                metrics.update(d, g)
            if loss_weights is not None:
                total, parts = detect.loss(outs, targets, size, loss_weights)
                for o in outs:
                    o.grad = None
                loss_sum += total
                n_batches += 1
                for k in parts_sum:
                    parts_sum[k] += parts[k]
    result = metrics.compute()
    if loss_weights is not None and n_batches:
        result["loss"] = loss_sum / n_batches
        result.update({k: v / n_batches for k, v in parts_sum.items()})
    return result, 1000 * t_total / max(1, n_img)


def run_eval_cls(model, batches, names, progress=None, with_loss=True):
    """Classification evaluation: top-1 / top-5 accuracy, per-class accuracy, confusion matrix and (with_loss) the
    training criterion on these images as ``loss``. Returns (metrics, milliseconds per image)."""
    metrics = classify.ClassificationMetrics(model.head().classes, names)
    t_total, n_img, loss_sum, n_batches = 0.0, 0, 0.0, 0
    with no_grad():
        for x, labels in batches:
            if progress is not None:
                panel, row = progress
                row.n, row.status = n_img, "running"
                row.label = f"image {n_img:,}/{row.total:,}"
                panel.refresh()
            t0 = time.perf_counter()
            out = model(x, train=False)
            x.dev.be.sync()
            t_total += time.perf_counter() - t0
            n_img += x.shape[0]
            metrics.update(out, labels)
            if with_loss:
                loss_sum += classify.loss(out, labels, grad=False)[0]
                n_batches += 1
    result = metrics.compute()
    if with_loss and n_batches:
        result["loss"] = loss_sum / n_batches
    return result, 1000 * t_total / max(1, n_img)


def _available_ram():
    """Bytes of RAM the system can still give us without swapping (Linux), else None."""
    try:
        with open("/proc/meminfo") as f:
            for line in f:
                if line.startswith("MemAvailable:"):
                    return int(line.split()[1]) * 1024
    except OSError:
        pass
    return None


def _step_bytes_per_image(model, size, dev, low):
    """Peak memory one training step needs per image, measured on one blank picture (forward + backward).
    BatchNorm statistics and gradients are restored afterwards, so the model is untouched."""
    be = dev.be
    state = model.state()
    saved = {k: t.clone() for k, t in state.items() if not t.rg}
    model._low_memory = low
    clear_tape()
    base = be.live
    be.peak = base
    x = be.zeros((1, model.input[0], size[0], size[1]))
    try:
        outs = model(x, train=True)
        for o in (outs if isinstance(outs, (tuple, list)) else [outs]):
            o.grad = be.zeros(o.shape)
        del outs
        backward()
    finally:
        clear_tape()
        for k, t in saved.items():
            state[k].buf = t.buf
        for t in state.values():
            t.grad = None
    return (be.peak - base) * 4


def plan_memory(model, size, batch_size, dev, low_memory, quantization):
    """Decide low-memory mode before training starts, so a run that cannot fit stops now with advice instead of
    being killed by the system halfway through an epoch. Returns (low, note)."""
    if low_memory is not None or quantization is not None:
        if low_memory and quantization is not None:
            return False, "low_memory is off: it is not combined with quantisation-aware training"
        return bool(low_memory), None
    avail = _available_ram()
    if avail is None or not hasattr(dev.be, "live"):
        return False, None                          # auto mode measures CPU memory on Linux; elsewhere: normal
    data_bytes = 3 * batch_size * model.input[0] * size[0] * size[1] * 4      # the current and the prefetched batch
    slack = 64 * 2**20 * 4 + 150 * 2**20                                       # the buffer pool, Python, the loader
    budget = 0.9 * avail
    normal = _step_bytes_per_image(model, size, dev, False)
    if normal * batch_size * 1.1 + data_bytes + slack <= budget:
        model._low_memory = False
        return False, None
    low = _step_bytes_per_image(model, size, dev, True)
    need_low = low * batch_size * 1.1 + data_bytes + slack
    if need_low <= budget:
        return True, (f"low-memory mode on: batch {batch_size} at {size[1]}px needs about "
                      f"{(normal * batch_size * 1.1 + data_bytes + slack) / 2**30:.1f} GB, {avail / 2**30:.1f} GB is free; "
                      f"recomputing activations (same results, ~30% slower) brings it to {need_low / 2**30:.1f} GB")
    per = low * 1.1 + 3 * model.input[0] * size[0] * size[1] * 4
    fits = int((budget - slack) // per) if budget > slack else 0
    model._low_memory = False
    raise WorkflowError(f"training would run out of memory: batch {batch_size} at {size[1]}px needs about "
                        f"{need_low / 2**30:.1f} GB even in low-memory mode, and {avail / 2**30:.1f} GB is free.",
                        "the system would kill the process partway through, losing the run.",
                        (f"use batch_size={fits} (the most that fits)" if fits >= 1 else "use a smaller img_size")
                        + ", a smaller img_size, or close other programs.")


class _Stop:
    """SIGINT / SIGTERM during training ask for a stop at the end of the current step (so the weights, optimizer and
    EMA are never saved half-updated). A second Ctrl+C stops at once."""

    def __init__(self, panel):
        self.asked, self.panel, self.old = False, panel, {}

    def __enter__(self):
        import signal
        import threading
        if threading.current_thread() is not threading.main_thread():
            return self
        for sig in (signal.SIGINT, getattr(signal, "SIGTERM", None)):
            if sig is not None:
                try:
                    self.old[sig] = signal.signal(sig, self._handle)
                except (ValueError, OSError):
                    pass
        return self

    def _handle(self, sig, frame):
        if self.asked:
            raise KeyboardInterrupt
        self.asked = True
        self.panel.note("stopping after this step and saving… (Ctrl+C again to stop at once)")

    def __exit__(self, *exc):
        import signal
        for sig, h in self.old.items():
            signal.signal(sig, h)
        return False


def fit(model, train, validation, epochs, batch_size, lr, device, img_size, optimizer, patience, save_every,
        output, quantization, augment, ema, loss_weights, quiet, low_memory=None, autosave=10):
    ds = data.as_dataset(train)
    if hasattr(ds, "splits"):                       # a whole Felix dataset: use its own splits
        val_ds = validation if validation is not None else (ds.val if len(ds.val) else None)
        ds = ds.train
    else:
        val_ds = validation
    if val_ds is not None:
        val_ds = data.as_dataset(val_ds)
    if len(ds) == 0:
        raise DataError("the training split is empty.", "there are no image/annotation pairs to learn from.",
                        "pass a dataset with images (Felix datasets under 10 pairs have no automatic splits).")
    head = model.head()
    task = head.task
    if data.is_classification(ds) != (task == "classify"):
        if task == "classify":
            raise DataError("this model classifies images, but the dataset has boxes.",
                            "wf.head(type='cls') learns one class per image from a classification dataset.",
                            "train on class folders (cat/, dog/, …) loaded with fx.load, or end the model with "
                            "wf.head(classes=N) (type='bbox') to detect objects.")
        raise DataError("this model detects objects, but the dataset is a classification dataset (one class per image).",
                        "wf.head(type='bbox') needs bounding boxes to learn from.",
                        f"end the model with wf.head(classes={head.classes}, type='cls') to classify the images.")
    names = ds.classes or model.class_names or [str(i) for i in range(head.classes)]
    if len(names) != head.classes:
        raise DataError("the dataset and the model disagree on the number of classes.",
                        f"the dataset has {len(names)} classes ({', '.join(names[:6])}{'…' if len(names) > 6 else ''}) "
                        f"but the model ends with wf.head(classes={head.classes}).",
                        f"build the model with wf.head(classes={len(names)}).")
    model.class_names = list(names)
    if device is not None:
        model.device(device)
    elif not model._device_chosen:
        model.device("auto")
    dev = model.device()
    size = (img_size, img_size) if isinstance(img_size, int) else tuple(img_size) if img_size else (model.input[1], model.input[2])
    model.check((model.input[0], *size))
    if quantization is not None:
        quantization.attach(model)

    tb = data.Batches(ds, size, batch_size, dev, shuffle=True, augment=augment, drop_last=len(ds) >= batch_size, task=task)
    vb = data.Batches(val_ds, size, batch_size, dev, task=task) if val_ds is not None and len(val_ds) else None
    cls = task == "classify"
    part_names = ("ce",) if cls else ("box", "obj", "cls")

    def step_loss(outs, targets):
        if cls:
            return classify.loss(outs, targets)
        return detect.loss(outs, targets, size, loss_weights)
    nb = len(tb)
    params = {k: t for k, t in model.state().items() if t.rg}
    opt = Optimizer(params, optimizer)
    st = model._train_state or {}
    start = int(st.get("epoch", 0))
    if epochs <= start:
        if not quiet:
            print(f"note: this model is already trained to epoch {start} (target {epochs}); nothing to do. "
                  f"Pass a larger epochs= to continue.")
        return model.history
    inference_state = dict(model.state())
    if st.get("raw"):                                # continue from the raw weights; the loaded ones are the EMA
        model.load_state({k: v for k, v in st["raw"].items()}, source="training state")
        params = {k: t for k, t in model.state().items() if t.rg}
        opt = Optimizer(params, optimizer)
    if st.get("m") and not opt.load(st["m"], st.get("v", {}), int(st.get("step", 0))) and not quiet:
        print("note: the saved optimizer state does not fit this model; starting a fresh optimizer")
    ema_m = None
    if ema:
        ema_m = EMA(model.state(), params, updates=int(st.get("ema_updates", 0)))
        if st.get("raw"):
            ema_m.shadow = {k: inference_state[k].to(dev).clone() for k in ema_m.shadow}

    low, mem_note = plan_memory(model, size, batch_size, dev, low_memory, quantization)
    model._low_memory = low
    if mem_note and not quiet:
        print("note: " + mem_note)

    best_fit, best_epoch = st.get("best_fitness") if st.get("best_fitness") is not None else float("-inf"), int(st.get("best_epoch") or start)
    os.makedirs(output, exist_ok=True)
    config = {"lr": lr, "batch_size": batch_size, "img_size": list(size), "optimizer": optimizer, "ema": bool(ema),
              "augment": bool(augment), "schedule": "warmup+cosine", "device": str(dev),
              "quantization": quantization.describe() if quantization is not None else None,
              "seed": int((st.get("config") or {}).get("seed") or random.randrange(1, 2**31))}
    seed = config["seed"]
    resume = st.get("resume") if st.get("resume") and int(st["resume"].get("epoch", -1)) == start else None
    history = model.history
    warm = min(max(100, 3 * nb), max(1, epochs * nb // 2))
    gstep = start * nb + (int(resume["step"]) if resume else 0)

    def checkpoint(epoch, is_best, at=None):
        weights = ema_m.shadow if ema_m else model.state()
        extra = {f"opt.m.{k}": v for k, v in opt.m.items()}
        extra.update({f"opt.v.{k}": v for k, v in opt.v.items()})
        if ema_m:
            extra.update({f"raw.{k}": v for k, v in model.state().items()})
        meta = {"epoch": epoch, "epochs": epochs, "best_fitness": best_fit if best_fit > float("-inf") else None,
                "best_epoch": best_epoch, "history": list(history), "config": config, "step": opt.t,
                "ema_updates": ema_m.updates if ema_m else 0, "resume": at}
        paths = [os.path.join(output, "last.nbm")] + ([os.path.join(output, "best.nbm")] if is_best else [])
        if at is None and save_every and epoch % save_every == 0:
            paths.append(os.path.join(output, f"epoch_{epoch}.nbm"))
        for p in paths:
            nbm.save(model, p, weights=weights, train=extra, classes=model.class_names, detection=model.detection_config(),
                     training=meta, precision=model.precision, quantization=model.quant.meta(model) if model.quant else None)

    panel = _ui.Panel("", quiet=quiet)
    panel.title = panel.join("Workflow train", f"{len(ds):,} train" + (f" / {len(val_ds):,} val" if vb else ""), str(dev))
    panel.sub = panel.join("Trainer running", f"epochs {start + 1}→{epochs}", f"batch {batch_size}", f"img {size[1]}",
                           quantization.describe() if quantization is not None else "fp32",
                           "low memory" if low else "")
    row = panel.row("train", epochs * nb)
    row.n = gstep
    panel.log_header = ("epoch   train loss   val loss   top-1   top-5" if cls and vb is not None else
                        "epoch   train loss   val loss   mAP50   mAP50-95" if vb is not None else "epoch   train loss")

    def log_epoch(r, best):
        line = f"{r['epoch']:>5}   {r['loss']:>10.3f}"
        if "val_loss" in r and "top1" in r:
            line += f"   {r['val_loss']:>8.3f}   {r['top1']:>5.3f}   {r['top5']:>5.3f}"
        elif "val_loss" in r:
            line += f"   {r['val_loss']:>8.3f}   {r['map50']:>5.3f}   {r['map50_95']:>8.3f}"
        panel.log.append((line + ("  ← best" if best else ""), best))

    for past in model.history:                     # continuing: show the epochs already trained
        log_epoch(past, False)
    completed, interrupted, rec = start, False, None
    pos = None                                     # where we are inside the current epoch (for autosave / resume)
    diverged, pre, live = False, None, None
    buffers = {k: t for k, t in model.state().items() if not t.rg}

    def undo_partial_step():
        """A step that died halfway may have updated BatchNorm statistics: put them back so the save matches ``pos``."""
        if live:                                   # stopped during validation: put the training weights back
            model.swap_state(live)
        if pre:
            cur = model.state()
            for k, t in pre.items():
                cur[k].buf = t.buf
    stop = _Stop(panel)
    last_save = time.time()
    if resume and not quiet:
        print(f"note: continuing epoch {start + 1} from step {int(resume['step']) + 1} of {nb} (saved mid-epoch)")
    try:
        with panel, stop:
            for epoch in range(start, epochs):
                t0, sums, seen, lr_t = time.time(), dict.fromkeys(("loss",) + part_names, 0.0), 0, lr
                first = 0
                if resume and epoch == start:
                    first, seen = int(resume["step"]), int(resume.get("seen", resume["step"]))
                    sums.update(resume.get("sums") or {})
                    t0 = time.time() - float(resume.get("seconds", 0.0))
                for it, (x, targets) in enumerate(tb.iterate(seed=seed * 1000003 + epoch, start=first), start=first):
                    pre = {k: t.clone() for k, t in buffers.items()}    # BatchNorm statistics before this step
                    prog = (epoch + it / nb) / epochs
                    lr_t = lr * (0.01 + 0.99 * (1 + math.cos(math.pi * prog)) / 2) * min(1.0, (gstep + 1) / warm)
                    clear_tape()
                    outs = model(x, train=True)
                    total, parts = step_loss(outs, targets)
                    if not math.isfinite(total):
                        diverged = True
                        raise WorkflowError("training stopped: the loss became NaN or infinite.",
                                            "the weights diverged, usually from a learning rate that is too high or broken boxes in the dataset.",
                                            f"lower lr (currently {lr}), and check the dataset with `felix info`.")
                    backward()
                    clip_gradients(params, 10.0)
                    opt.step(lr_t)
                    if ema_m:
                        ema_m.update(model.state())
                    if hasattr(dev.be, "flush"):            # lazy backends: run the whole step as one submission
                        dev.be.flush(list(model.state().values()) + list(opt.m.values()) + list(opt.v.values())
                                     + (list(ema_m.shadow.values()) if ema_m else []))
                    gstep += 1
                    seen += 1
                    sums["loss"] += total
                    for k in parts:
                        sums[k] += parts[k]
                    row.n, row.status = gstep, "running"
                    row.label = f"epoch {epoch + 1}/{epochs} · step {it + 1}/{nb}" if panel.uni else f"epoch {epoch + 1}/{epochs}"
                    row.stats = panel.join(f"loss {sums['loss'] / seen:.3f}",
                                           *(f"{k} {sums[k] / seen:.3f}" for k in part_names if k != "ce"), f"lr {lr_t:.1e}")
                    pos = {"epoch": epoch, "step": it + 1, "seen": seen, "sums": dict(sums), "seconds": time.time() - t0}
                    pre = None
                    if stop.asked:
                        raise KeyboardInterrupt
                    if autosave and it + 1 < nb and time.time() - last_save >= autosave * 60:
                        checkpoint(completed, False, at=pos)           # a crash or power cut loses minutes, not the epoch
                        last_save = time.time()
                        row.foot = panel.join(row.foot, f"autosaved at step {it + 1}") if row.foot else f"autosaved at step {it + 1}"
                    panel.refresh()
                rec = {"epoch": epoch + 1, "lr": lr_t, "seconds": time.time() - t0, **{k: v / max(1, seen) for k, v in sums.items()}}
                fitness = -rec["loss"]
                if vb is not None:
                    live = model.swap_state(ema_m.shadow) if ema_m else None
                    if cls:
                        m, _ = run_eval_cls(model, vb, names)
                    else:
                        m, _ = run_eval(model, vb, size, names, loss_weights=loss_weights)
                    if ema_m:
                        model.swap_state(live)
                    live = None
                    if cls:
                        rec.update({"top1": m["top1"], "top5": m["top5"], "val_loss": m["loss"]})
                        fitness = 0.9 * m["top1"] + 0.1 * m["top5"]
                    else:
                        rec.update({k: m[k] for k in ("map50", "map50_95", "precision", "recall", "f1")})
                        rec.update({"val_loss": m["loss"], "val_box": m["box"], "val_obj": m["obj"], "val_cls": m["cls"]})
                        fitness = 0.1 * m["map50"] + 0.9 * m["map50_95"]
                rec["fitness"] = fitness
                history.append(rec)
                completed = epoch + 1
                is_best = fitness >= best_fit
                if is_best:
                    best_fit, best_epoch = fitness, completed
                    panel.log = [(t.replace("  ← best", ""), False) for t, _ in panel.log]
                log_epoch(rec, is_best)
                checkpoint(completed, is_best)
                pos, last_save = None, time.time()
                if stop.asked:
                    raise KeyboardInterrupt
                row.foot = panel.join(
                    f"val loss {rec['val_loss']:.3f} · top-1 {rec['top1']:.3f} · top-5 {rec['top5']:.3f}" if "top1" in rec else
                    f"val loss {rec['val_loss']:.3f} · mAP50 {rec['map50']:.3f} · mAP50-95 {rec['map50_95']:.3f}"
                    if "map50" in rec else "no validation data", f"best epoch {best_epoch}",
                    f"{len(ds) / max(1e-9, rec['seconds']):,.0f} img/s", f"saved → {output}")
                if patience is not None and completed - best_epoch >= patience:
                    panel.note(f"early stopping: no improvement for {patience} epochs (best was epoch {best_epoch}).")
                    break
            row.done()
    except KeyboardInterrupt:
        interrupted = True
        clear_tape()
        undo_partial_step()
    except BaseException as e:
        if diverged:
            raise                                  # NaN / inf weights are not worth saving over the last good checkpoint
        clear_tape()
        undo_partial_step()
        try:
            checkpoint(completed, False, at=pos)
            where = f"epoch {completed + 1}, step {pos['step']}" if pos else f"end of epoch {completed}"
            print(f"\ntraining crashed ({type(e).__name__}: {e}); progress saved to {os.path.join(output, 'last.nbm')} "
                  f"({where}). Fix the cause, then wf.load that file and call train again to continue from there.")
        except Exception:
            pass
        raise
    if interrupted:
        checkpoint(completed, False, at=pos)
        where = f"epoch {completed + 1}, step {pos['step']}/{nb}" if pos else f"epoch {completed}"
        print(f"\ninterrupted: model state saved to {os.path.join(output, 'last.nbm')} ({where}); "
              f"wf.load it and train again to continue exactly there")
    model._train_state = {"epoch": completed, "epochs": epochs, "best_fitness": best_fit if best_fit > float("-inf") else None,
                          "best_epoch": best_epoch, "config": config, "step": opt.t, "m": opt.m, "v": opt.v,
                          "resume": pos if interrupted else None,
                          "ema_updates": ema_m.updates if ema_m else 0,
                          "raw": {k: t.clone() for k, t in model.state().items()} if ema_m else None}
    if ema_m:
        model.swap_state(ema_m.shadow)              # the model now holds the averaged (inference) weights
    return history
