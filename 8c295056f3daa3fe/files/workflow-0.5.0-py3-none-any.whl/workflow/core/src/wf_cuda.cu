// wf_cuda: Workflow's own CUDA kernels. Compiled once to PTX (nvcc --ptx) and loaded through the driver API.
// Every kernel uses a 1-D grid over its work items. Tensors are contiguous float32 NCHW.
#define K extern "C" __global__ void
#define IDX long i = (long)blockIdx.x * blockDim.x + threadIdx.x
typedef float f32;

__device__ inline f32 sig(f32 x) { return 1.f / (1.f + expf(-x)); }

K fill(f32 *x, long n, f32 v) { IDX; if (i < n) x[i] = v; }
K axpy(f32 *y, const f32 *x, long n, f32 a) { IDX; if (i < n) y[i] += a * x[i]; }
K scale(f32 *x, long n, f32 a) { IDX; if (i < n) x[i] *= a; }
K add(f32 *y, const f32 *a, const f32 *b, long n) { IDX; if (i < n) y[i] = a[i] + b[i]; }
K ema(f32 *s, const f32 *p, long n, f32 d) { IDX; if (i < n) s[i] = d * s[i] + (1.f - d) * p[i]; }
K adamw(f32 *p, const f32 *g, f32 *m, f32 *v, long n, f32 lr, f32 b1, f32 b2, f32 eps, f32 wd, f32 c1, f32 c2) {
    IDX; if (i >= n) return;
    f32 gi = g[i];
    m[i] = b1 * m[i] + (1.f - b1) * gi;
    v[i] = b2 * v[i] + (1.f - b2) * gi * gi;
    p[i] -= lr * ((m[i] / c1) / (sqrtf(v[i] / c2) + eps) + wd * p[i]);
}
K sgd(f32 *p, const f32 *g, f32 *m, long n, f32 lr, f32 mom, f32 wd) {
    IDX; if (i >= n) return;
    f32 gi = g[i] + wd * p[i]; m[i] = mom * m[i] + gi; p[i] -= lr * m[i];
}
// chunked reductions: out[i] covers elements [i*chunk, (i+1)*chunk)
K part_sumsq(const f32 *x, long n, f32 *out, long chunk) {
    IDX; long lo = i * chunk; if (lo >= n) return; long hi = lo + chunk < n ? lo + chunk : n;
    double s = 0; for (long j = lo; j < hi; j++) s += (double)x[j] * x[j]; out[i] = (f32)s;
}
K part_minmax(const f32 *x, long n, f32 *out, long chunk) {
    IDX; long lo = i * chunk; if (lo >= n) return; long hi = lo + chunk < n ? lo + chunk : n;
    f32 a = x[lo], b = x[lo]; for (long j = lo + 1; j < hi; j++) { a = fminf(a, x[j]); b = fmaxf(b, x[j]); }
    out[2 * i] = a; out[2 * i + 1] = b;
}
K plane_sum(const f32 *x, f32 *out, long planes, long HW) {      // out[plane] = sum of the plane
    IDX; if (i >= planes) return; const f32 *p = x + i * HW; double s = 0; for (long j = 0; j < HW; j++) s += p[j]; out[i] = (f32)s;
}
K reduce_n(const f32 *part, f32 *out, int N, long M) {           // out[m] += sum_n part[n*M + m]
    IDX; if (i >= M) return; double s = 0; for (int n = 0; n < N; n++) s += part[(long)n * M + i]; out[i] += (f32)s;
}

// ---------------------------------------------------------------- activations: 0 relu, 1 leaky, 2 silu, 3 sigmoid
K act_fwd(int kind, const f32 *x, f32 *y, long n, f32 s) {
    IDX; if (i >= n) return; f32 v = x[i];
    y[i] = kind == 0 ? (v > 0 ? v : 0) : kind == 1 ? (v > 0 ? v : s * v) : kind == 2 ? v * sig(v) : sig(v);
}
K act_bwd(int kind, const f32 *x, const f32 *y, const f32 *dy, f32 *dx, long n, f32 s) {
    IDX; if (i >= n) return; f32 v = x[i], g = dy[i];
    if (kind == 0) dx[i] = v > 0 ? g : 0;
    else if (kind == 1) dx[i] = v > 0 ? g : s * g;
    else if (kind == 2) { f32 q = sig(v); dx[i] = g * q * (1.f + v * (1.f - q)); }
    else dx[i] = g * y[i] * (1.f - y[i]);
}

// ---------------------------------------------------------------- convolution (direct, one thread per result element)
#define CV int N, int C, int H, int W, int OC, int KH, int KW, int sh, int sw, int pt, int pl, int dh, int dw, int G, int OH, int OW
K conv_fwd(const f32 *x, const f32 *w, const f32 *b, f32 *y, CV, int has_b) {
    IDX; if (i >= (long)N * OC * OH * OW) return;
    int ow = i % OW; long t = i / OW; int oh = t % OH; t /= OH; int oc = t % OC; int n = (int)(t / OC);
    int Cg = C / G, g = oc / (OC / G);
    f32 s = has_b ? b[oc] : 0.f;
    const f32 *wp = w + (long)oc * Cg * KH * KW;
    for (int c = 0; c < Cg; c++) {
        const f32 *xp = x + ((long)n * C + g * Cg + c) * H * W;
        for (int ki = 0; ki < KH; ki++) { int ih = oh * sh - pt + ki * dh; if (ih < 0 || ih >= H) continue;
            for (int kj = 0; kj < KW; kj++) { int iw = ow * sw - pl + kj * dw; if (iw < 0 || iw >= W) continue;
                s += xp[ih * W + iw] * wp[(c * KH + ki) * KW + kj]; } }
    }
    y[i] = s;
}
K conv_bwd_data(const f32 *dy, const f32 *w, f32 *dx, CV) {
    IDX; if (i >= (long)N * C * H * W) return;
    int iw = i % W; long t = i / W; int ih = t % H; t /= H; int c = t % C; int n = (int)(t / C);
    int Cg = C / G, OCg = OC / G, g = c / Cg, cl = c % Cg;
    f32 s = 0;
    for (int o = 0; o < OCg; o++) {
        const f32 *wp = w + ((long)(g * OCg + o) * Cg + cl) * KH * KW;
        const f32 *dp = dy + ((long)n * OC + g * OCg + o) * OH * OW;
        for (int ki = 0; ki < KH; ki++) { int a = ih + pt - ki * dh; if (a < 0 || a % sh) continue; int oh = a / sh; if (oh >= OH) continue;
            for (int kj = 0; kj < KW; kj++) { int b = iw + pl - kj * dw; if (b < 0 || b % sw) continue; int ow = b / sw; if (ow >= OW) continue;
                s += dp[oh * OW + ow] * wp[ki * KW + kj]; } }
    }
    dx[i] = s;
}
K conv_bwd_weight(const f32 *x, const f32 *dy, f32 *part, CV) {   // part[n, oc, c, ki, kj]; reduce over n afterwards
    int Cg = C / G; long M = (long)OC * Cg * KH * KW;
    IDX; if (i >= (long)N * M) return;
    int kj = i % KW; long t = i / KW; int ki = t % KH; t /= KH; int c = t % Cg; t /= Cg; int oc = t % OC; int n = (int)(t / OC);
    int g = oc / (OC / G);
    const f32 *xp = x + ((long)n * C + g * Cg + c) * H * W, *dp = dy + ((long)n * OC + oc) * OH * OW;
    f32 s = 0;
    for (int oh = 0; oh < OH; oh++) { int ih = oh * sh - pt + ki * dh; if (ih < 0 || ih >= H) continue;
        for (int ow = 0; ow < OW; ow++) { int iw = ow * sw - pl + kj * dw; if (iw < 0 || iw >= W) continue; s += dp[oh * OW + ow] * xp[ih * W + iw]; } }
    part[i] = s;
}
K add_ch(f32 *y, const f32 *b, int N, int C, long HW) { IDX; if (i < (long)N * C * HW) y[i] += b[(i / HW) % C]; }

// ---------------------------------------------------------------- batch norm
K plane_moments(const f32 *x, f32 *s1, f32 *s2, long planes, long HW) {
    IDX; if (i >= planes) return; const f32 *p = x + i * HW; double a = 0, b = 0;
    for (long j = 0; j < HW; j++) { a += p[j]; b += (double)p[j] * p[j]; }
    s1[i] = (f32)a; s2[i] = (f32)b;
}
K bn_stats(const f32 *s1, const f32 *s2, int N, int C, long HW, f32 *mean, f32 *istd, f32 *rm, f32 *rv, f32 mom, f32 eps) {
    IDX; if (i >= C) return; double a = 0, b = 0, m = (double)N * HW;
    for (int n = 0; n < N; n++) { a += s1[(long)n * C + i]; b += s2[(long)n * C + i]; }
    double mu = a / m, var = b / m - mu * mu; if (var < 0) var = 0;
    mean[i] = (f32)mu; istd[i] = (f32)(1.0 / sqrt(var + eps));
    rm[i] = (1.f - mom) * rm[i] + mom * (f32)mu;
    rv[i] = (1.f - mom) * rv[i] + mom * (f32)(m > 1 ? var * m / (m - 1) : var);
}
K istd_of(const f32 *rv, f32 *istd, int C, f32 eps) { IDX; if (i < C) istd[i] = 1.f / sqrtf(rv[i] + eps); }
K bn_apply(const f32 *x, f32 *y, const f32 *mean, const f32 *istd, const f32 *g, const f32 *b, int N, int C, long HW) {
    IDX; if (i >= (long)N * C * HW) return; int c = (i / HW) % C; y[i] = (x[i] - mean[c]) * istd[c] * g[c] + b[c];
}
K bn_bwd_sums(const f32 *x, const f32 *dy, const f32 *mean, const f32 *istd, f32 *s1, f32 *s2, long planes, int C, long HW) {
    IDX; if (i >= planes) return; int c = i % C; const f32 *xp = x + i * HW, *dp = dy + i * HW; double a = 0, b = 0; f32 mu = mean[c], is = istd[c];
    for (long j = 0; j < HW; j++) { a += dp[j]; b += (double)dp[j] * (xp[j] - mu) * is; }
    s1[i] = (f32)a; s2[i] = (f32)b;
}
K bn_bwd_apply(const f32 *x, const f32 *dy, const f32 *g, const f32 *mean, const f32 *istd, const f32 *dg, const f32 *db,
               f32 *dx, int N, int C, long HW, int train) {
    IDX; if (i >= (long)N * C * HW) return; int c = (i / HW) % C;
    if (!train) { dx[i] = dy[i] * g[c] * istd[c]; return; }
    f32 m = (f32)N * (f32)HW;
    dx[i] = g[c] * istd[c] / m * (m * dy[i] - db[c] - (x[i] - mean[c]) * istd[c] * dg[c]);
}

// ---------------------------------------------------------------- pooling / resize
K maxpool_fwd(const f32 *x, f32 *y, int *idx, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    const f32 *xp = x + p * H * W; f32 best = -INFINITY; int bi = -1;
    for (int ki = 0; ki < kh; ki++) { int ih = oh * sh - pt + ki; if (ih < 0 || ih >= H) continue;
        for (int kj = 0; kj < kw; kj++) { int iw = ow * sw - pl + kj; if (iw < 0 || iw >= W) continue; f32 v = xp[ih * W + iw]; if (v > best) { best = v; bi = ih * W + iw; } } }
    y[i] = best; idx[i] = bi;
}
K maxpool_bwd(const f32 *dy, const int *idx, f32 *dx, long planes, int H, int W, int OH, int OW) {
    IDX; if (i >= planes * OH * OW) return; long p = i / ((long)OH * OW); if (idx[i] >= 0) atomicAdd(dx + p * H * W + idx[i], dy[i]);
}
K avgpool_fwd(const f32 *x, f32 *y, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    const f32 *xp = x + p * H * W; f32 s = 0;
    for (int ki = 0; ki < kh; ki++) { int ih = oh * sh - pt + ki; if (ih < 0 || ih >= H) continue;
        for (int kj = 0; kj < kw; kj++) { int iw = ow * sw - pl + kj; if (iw >= 0 && iw < W) s += xp[ih * W + iw]; } }
    y[i] = s / (f32)(kh * kw);
}
K avgpool_bwd(const f32 *dy, f32 *dx, long planes, int H, int W, int OH, int OW, int kh, int kw, int sh, int sw, int pt, int pl) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    f32 g = dy[i] / (f32)(kh * kw); f32 *xp = dx + p * H * W;
    for (int ki = 0; ki < kh; ki++) { int ih = oh * sh - pt + ki; if (ih < 0 || ih >= H) continue;
        for (int kj = 0; kj < kw; kj++) { int iw = ow * sw - pl + kj; if (iw >= 0 && iw < W) atomicAdd(xp + ih * W + iw, g); } }
}
K upsample_fwd(const f32 *x, f32 *y, long planes, int H, int W, int OH, int OW) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    y[i] = x[p * H * W + ((long)oh * H / OH) * W + (long)ow * W / OW];
}
K upsample_bwd(const f32 *dy, f32 *dx, long planes, int H, int W, int OH, int OW) {
    IDX; if (i >= planes * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; long p = t / OH;
    atomicAdd(dx + p * H * W + ((long)oh * H / OH) * W + (long)ow * W / OW, dy[i]);
}

// ---------------------------------------------------------------- channel ops, broadcasting, reshuffles
K copy_ch(f32 *dst, int dC, int off, const f32 *src, int sC, int N, long HW) {     // dst[n, off+c] = src[n, c]
    IDX; if (i >= (long)N * sC * HW) return; long hw = i % HW; long t = i / HW; int c = t % sC; long n = t / sC;
    dst[(n * dC + off + c) * HW + hw] = src[i];
}
K slice_ch(const f32 *src, int sC, int off, f32 *dst, int dC, int N, long HW) {    // dst[n, c] = src[n, off+c]
    IDX; if (i >= (long)N * dC * HW) return; long hw = i % HW; long t = i / HW; int c = t % dC; long n = t / dC;
    dst[i] = src[(n * sC + off + c) * HW + hw];
}
K mul_bc(const f32 *x, const f32 *s, f32 *y, int N, int C, int H, int W, int sN, int sC, int sH, int sW) {
    IDX; if (i >= (long)N * C * H * W) return; int w = i % W; long t = i / W; int h = t % H; t /= H; int c = t % C; int n = (int)(t / C);
    y[i] = x[i] * s[(((long)(sN > 1 ? n : 0) * sC + (sC > 1 ? c : 0)) * sH + (sH > 1 ? h : 0)) * sW + (sW > 1 ? w : 0)];
}
K mul_reduce(const f32 *a, const f32 *b, f32 *out, int N, int C, int H, int W, int sN, int sC, int sH, int sW) {   // one thread per out element
    IDX; if (i >= (long)sN * sC * sH * sW) return; int w0 = i % sW; long t = i / sW; int h0 = t % sH; t /= sH; int c0 = t % sC; int n0 = (int)(t / sC);
    double s = 0;
    for (int n = (sN > 1 ? n0 : 0); n < (sN > 1 ? n0 + 1 : N); n++) for (int c = (sC > 1 ? c0 : 0); c < (sC > 1 ? c0 + 1 : C); c++)
        for (int h = (sH > 1 ? h0 : 0); h < (sH > 1 ? h0 + 1 : H); h++) for (int w = (sW > 1 ? w0 : 0); w < (sW > 1 ? w0 + 1 : W); w++) {
            long j = (((long)n * C + c) * H + h) * W + w; s += (double)a[j] * b[j]; }
    out[i] += (f32)s;
}
K chan_mean(const f32 *x, f32 *y, int N, int C, long HW) {
    IDX; if (i >= (long)N * HW) return; long hw = i % HW; long n = i / HW; f32 s = 0; for (int c = 0; c < C; c++) s += x[(n * C + c) * HW + hw]; y[i] = s / C;
}
K chan_mean_bwd(const f32 *dy, f32 *dx, int N, int C, long HW) {
    IDX; if (i >= (long)N * C * HW) return; long hw = i % HW; long n = i / (HW * C); dx[i] = dy[n * HW + hw] / C;
}
K chan_max(const f32 *x, f32 *y, int *idx, int N, int C, long HW) {
    IDX; if (i >= (long)N * HW) return; long hw = i % HW; long n = i / HW; f32 best = -INFINITY; int bi = 0;
    for (int c = 0; c < C; c++) { f32 v = x[(n * C + c) * HW + hw]; if (v > best) { best = v; bi = c; } }
    y[i] = best; idx[i] = bi;
}
K chan_max_bwd(const f32 *dy, const int *idx, f32 *dx, int N, int C, long HW) {    // dx zeroed
    IDX; if (i >= (long)N * HW) return; long hw = i % HW; long n = i / HW; dx[(n * C + idx[i]) * HW + hw] = dy[i];
}
K s2d(f32 *x, f32 *y, int N, int C, int H, int W, int inverse) {                   // one thread per y element
    int OH = H / 2, OW = W / 2;
    IDX; if (i >= (long)N * 4 * C * OH * OW) return; int ow = i % OW; long t = i / OW; int oh = t % OH; t /= OH; int ch = t % (4 * C); long n = t / (4 * C);
    int q = ch / C, c = ch % C; long j = ((n * C + c) * H + 2 * oh + (q & 1)) * W + 2 * ow + (q >> 1);
    if (inverse) x[j] = y[i]; else y[i] = x[j];
}
K fake_quant(const f32 *x, f32 *y, long n, f32 scale, f32 zp, f32 qmin, f32 qmax) {
    IDX; if (i >= n) return; f32 q = nearbyintf(x[i] / scale + zp); q = fminf(fmaxf(q, qmin), qmax); y[i] = (q - zp) * scale;
}
K fake_quant_bwd(const f32 *x, const f32 *dy, f32 *dx, long n, f32 scale, f32 zp, f32 qmin, f32 qmax) {
    IDX; if (i >= n) return; f32 q = x[i] / scale + zp; dx[i] = (q >= qmin - 0.5f && q <= qmax + 0.5f) ? dy[i] : 0.f;
}

// ---------------------------------------------------------------- GEMM-based convolution (groups == 1)
// C[M x N] (+)= A[M x Kd] * B[Kd x N], with strides so transposed operands need no copy:
//   A(i, k) = A[i*ars + k*acs],  B(k, j) = B[k*brs + j*bcs].
// Each block computes a 64x64 tile of C with 16x16 threads; every thread owns a 4x4 patch (register blocking), and
// the A / B tiles for 16 values of k live in shared memory, so each multiply-add costs ~0.5 shared reads.
#define GB 64
#define GK 16
// The sum over k can be split into segments of ``kseg`` (grid z): segment z writes its partial result to
// Cm + z*M*N, to be summed afterwards. That keeps the GPU busy when C is small but Kd is huge (weight gradients).
K gemm(const f32 *A, const f32 *B, f32 *Cm, int M, int N, int Kd, long ars, long acs, long brs, long bcs, int accumulate, int kseg) {
    __shared__ f32 As[GK][GB];
    __shared__ f32 Bs[GK][GB];
    int tx = threadIdx.x, ty = threadIdx.y, t = ty * 16 + tx;
    int row0 = blockIdx.y * GB, col0 = blockIdx.x * GB;
    f32 acc[4][4];
    for (int a = 0; a < 4; a++) for (int b = 0; b < 4; b++) acc[a][b] = 0.f;
    int kbeg = blockIdx.z * kseg, kend = kbeg + kseg < Kd ? kbeg + kseg : Kd;
    Cm += (long)blockIdx.z * M * N;
    for (int k0 = kbeg; k0 < kend; k0 += GK) {
        for (int e = 0; e < 4; e++) {
            int id = t * 4 + e, kk = id / GB, r = id % GB;
            int k = k0 + kk, row = row0 + r, col = col0 + r;
            As[kk][r] = (k < kend && row < M) ? A[(long)row * ars + (long)k * acs] : 0.f;
            Bs[kk][r] = (k < kend && col < N) ? B[(long)k * brs + (long)col * bcs] : 0.f;
        }
        __syncthreads();
#pragma unroll
        for (int kk = 0; kk < GK; kk++) {
            f32 a0 = As[kk][ty * 4], a1 = As[kk][ty * 4 + 1], a2 = As[kk][ty * 4 + 2], a3 = As[kk][ty * 4 + 3];
            f32 b0 = Bs[kk][tx * 4], b1 = Bs[kk][tx * 4 + 1], b2 = Bs[kk][tx * 4 + 2], b3 = Bs[kk][tx * 4 + 3];
            acc[0][0] += a0 * b0; acc[0][1] += a0 * b1; acc[0][2] += a0 * b2; acc[0][3] += a0 * b3;
            acc[1][0] += a1 * b0; acc[1][1] += a1 * b1; acc[1][2] += a1 * b2; acc[1][3] += a1 * b3;
            acc[2][0] += a2 * b0; acc[2][1] += a2 * b1; acc[2][2] += a2 * b2; acc[2][3] += a2 * b3;
            acc[3][0] += a3 * b0; acc[3][1] += a3 * b1; acc[3][2] += a3 * b2; acc[3][3] += a3 * b3;
        }
        __syncthreads();
    }
    for (int a = 0; a < 4; a++) { int row = row0 + ty * 4 + a; if (row >= M) continue;
        for (int b = 0; b < 4; b++) { int col = col0 + tx * 4 + b; if (col >= N) continue;
            if (accumulate) Cm[(long)row * N + col] += acc[a][b]; else Cm[(long)row * N + col] = acc[a][b]; } }
}
// (N, C, HW) <-> (C, N*HW)
K nchw_to_cn(const f32 *x, f32 *y, int N, int C, long HW) {
    IDX; if (i >= (long)N * C * HW) return; long hw = i % HW; long t = i / HW; int c = t % C; long n = t / C;
    y[((long)c * N + n) * HW + hw] = x[i];
}
K cn_to_nchw(const f32 *y, f32 *x, const f32 *b, int N, int C, long HW, int has_b) {
    IDX; if (i >= (long)N * C * HW) return; long hw = i % HW; long t = i / HW; int c = t % C; long n = t / C;
    x[i] = y[((long)c * N + n) * HW + hw] + (has_b ? b[c] : 0.f);
}
// col[(c, ki, kj), (n, oh, ow)]
K im2col(const f32 *x, f32 *col, int N, int C, int H, int W, int KH, int KW, int sh, int sw, int pt, int pl, int dh, int dw, int OH, int OW) {
    long NON = (long)N * OH * OW;
    IDX; if (i >= (long)C * KH * KW * NON) return;
    long q = i % NON; long k = i / NON; int ow = q % OW; long t = q / OW; int oh = t % OH; long n = t / OH;
    int kj = k % KW; long u = k / KW; int ki = u % KH; int c = (int)(u / KH);
    int ih = oh * sh - pt + ki * dh, iw = ow * sw - pl + kj * dw;
    col[i] = (ih >= 0 && ih < H && iw >= 0 && iw < W) ? x[((n * C + c) * H + ih) * W + iw] : 0.f;
}
K col2im(const f32 *col, f32 *dx, int N, int C, int H, int W, int KH, int KW, int sh, int sw, int pt, int pl, int dh, int dw, int OH, int OW) {
    long NON = (long)N * OH * OW;
    IDX; if (i >= (long)N * C * H * W) return;
    int iw = i % W; long t = i / W; int ih = t % H; t /= H; int c = t % C; long n = t / C;
    f32 s = 0;
    for (int ki = 0; ki < KH; ki++) { int a = ih + pt - ki * dh; if (a < 0 || a % sh) continue; int oh = a / sh; if (oh >= OH) continue;
        for (int kj = 0; kj < KW; kj++) { int b = iw + pl - kj * dw; if (b < 0 || b % sw) continue; int ow = b / sw; if (ow >= OW) continue;
            s += col[((long)(c * KH + ki) * KW + kj) * NON + (n * OH + oh) * OW + ow]; } }
    dx[i] = s;
}

// ================================================================ implicit-GEMM convolution (groups == 1)
// One kernel template computes C[M x Nn] = A[M x Kd] * B[Kd x Nn] where the operands are read straight out of the
// tensors (no im2col copy, no layout transposes) and the result is written in its final layout:
//   A: 0 = row-major A[m*lda + k] (weights),  1 = an NCHW gradient dy with k = (image, pixel),  2 = A[k*lda + m]
//   B: 0 = im2col of an NCHW input with n = (image, oh, ow),  1 = an NCHW gradient with k = channel, n = (image, pixel),
//      2 = im2col transposed: k = (image, oh, ow), n = (c, ki, kj)
//   C: 0 = NCHW output (+ bias) with n = (image, pixel),  1 = row-major C[z*zstride + m*ldc + n] (z = k segment)
// Tiles of BM x BN with BK = 8; 256 threads, each owning a (BM/16) x (BN/16) block of C in registers; the A / B tiles are
// double-buffered in shared memory (the next one loads from global memory while the current one is multiplied).
// ``tab`` holds, per im2col row (c, ki, kj): {c*H*W + ki*dh*W + kj*dw, (ki*dh << 16) | kj*dw}. Accumulation is plain
// fp32 FMA in k order inside a tile, like any GEMM.
#define TH 256
template <int BM, int BN, int AM, int BMD, int CM>
__device__ __forceinline__ void igemm(const f32 *__restrict__ A, const f32 *__restrict__ B, f32 *__restrict__ Cm,
        const f32 *__restrict__ bias, const int2 *__restrict__ tab, int M, int Nn, int Kd, int kseg, int lda,
        int C, int H, int W, int OH, int OW, int sh, int sw, int pt, int pl, long ldc, long zstride) {
    const int BK = 8, TM = BM / 16, TN = BN / 16;
    const int NA = (BM * BK + TH - 1) / TH, NB = (BK * BN + TH - 1) / TH;
    __shared__ __align__(16) f32 As[2][BK][BM + 4];
    __shared__ __align__(16) f32 Bs[2][BK][BN + 4];
    const int t = threadIdx.x, tx = t % 16, ty = t / 16;
    const int m0 = blockIdx.y * BM, n0 = blockIdx.x * BN;
    const int kbeg = blockIdx.z * kseg, kend = min(Kd, kbeg + kseg);
    const long OHW = (long)OH * OW, HW = (long)H * W, CHW = (long)C * HW;
    const int iOHW = OH * OW;              // index maths in 32 bits (64-bit division is slow on GPUs)
    f32 ra[NA], rb[NB];

    // B coordinates that stay fixed for this thread across k steps. Offsets are 32-bit (tensors under 2^31 values,
    // checked by the caller): fewer registers, so two blocks fit on each multiprocessor without spilling.
    int bbase[NB], bih[NB], biw[NB];                       // modes 0 / 1: per n;  mode 2: per n = (c, ki, kj)
    for (int r = 0; r < NB; r++) {
        int e = t + TH * r;
        if (BMD == 2) {                                     // n = (c, ki, kj): its table entry; bih = -1 marks "outside"
            int n = n0 + e / BK; bool ok = e < BK * BN && n < Nn;
            int2 q = ok ? tab[n] : make_int2(0, 0); bbase[r] = q.x; bih[r] = ok ? (q.y >> 16) : -(1 << 28); biw[r] = q.y & 0xffff;
        } else {
            int n = n0 + e % BN; bool ok = e < BK * BN && n < Nn;
            int img = ok ? n / iOHW : 0; int p = ok ? n - img * iOHW : 0;
            if (BMD == 0) { int oh = p / OW, ow = p - oh * OW;
                bih[r] = ok ? oh * sh - pt : -(1 << 28); biw[r] = ow * sw - pl; bbase[r] = img * (int)CHW + bih[r] * W + biw[r]; }
            else { bbase[r] = img * Kd * iOHW + p; bih[r] = ok ? 0 : -1; }
        }
    }
    int abase[NA];
    for (int r = 0; r < NA; r++) {
        int e = t + TH * r;
        int m = m0 + (AM == 2 ? e % BM : e / BK);
        abase[r] = (e < BM * BK && m < M) ? m : -1;
    }

    auto load = [&](int k0) {
        // shared (image, oh, ow) for modes that walk k over output pixels (A 1, B 2): k = k0 + t % BK for every r
        int jimg = 0, jp = 0, jih = 0, jiw = 0; bool jok = false;
        if (AM == 1 || BMD == 2) {
            int j = k0 + t % BK; jok = j < kend;
            if (jok) { jimg = j / iOHW; jp = j - jimg * iOHW; int oh = jp / OW, ow = jp - oh * OW;
                jih = oh * sh - pt; jiw = ow * sw - pl; }
        }
#pragma unroll
        for (int r = 0; r < NA; r++) {
            int e = t + TH * r, k = k0 + (AM == 2 ? e / BM : e % BK);
            f32 v = 0.f;
            if (abase[r] >= 0 && k < kend) {
                if (AM == 0) v = __ldg(A + abase[r] * lda + k);
                else if (AM == 1) { if (jok) v = __ldg(A + (jimg * M + abase[r]) * iOHW + jp); }
                else v = __ldg(A + k * lda + abase[r]);
            }
            ra[r] = v;
        }
#pragma unroll
        for (int r = 0; r < NB; r++) {
            int e = t + TH * r;
            f32 v = 0.f;
            if (BMD == 2) {
                if (jok) { int ih = jih + bih[r], iw = jiw + biw[r];
                    if (ih >= 0 && ih < H && iw >= 0 && iw < W) v = __ldg(B + jimg * (int)CHW + bbase[r] + jih * W + jiw); }
            } else {
                int k = k0 + e / BN;
                if (k < kend) {
                    if (BMD == 0) { int2 q = __ldg(tab + k); int ih = bih[r] + (q.y >> 16), iw = biw[r] + (q.y & 0xffff);
                        if (ih >= 0 && ih < H && iw >= 0 && iw < W) v = __ldg(B + bbase[r] + q.x); }
                    else if (bih[r] >= 0) v = __ldg(B + bbase[r] + k * iOHW);
                }
            }
            rb[r] = v;
        }
    };
    auto store = [&](int buf) {
        for (int r = 0; r < NA; r++) { int e = t + TH * r; if (e < BM * BK) {
            if (AM == 2) As[buf][e / BM][e % BM] = ra[r]; else As[buf][e % BK][e / BK] = ra[r]; } }
        for (int r = 0; r < NB; r++) { int e = t + TH * r; if (e < BK * BN) {
            if (BMD == 2) Bs[buf][e % BK][e / BK] = rb[r]; else Bs[buf][e / BN][e % BN] = rb[r]; } }
    };

    // Each thread owns rows {ty*HM + i} and {BM/2 + ty*HM + i} (HM = TM/2) and the same split for columns, so its
    // shared-memory reads are aligned vectors that neighbouring threads take from neighbouring addresses (no bank
    // conflicts), and its stores to C are runs of HN consecutive columns.
    const int HM = TM > 1 ? TM / 2 : 1, HN = TN > 1 ? TN / 2 : 1;
    f32 acc[TM][TN];
    for (int i = 0; i < TM; i++) for (int j = 0; j < TN; j++) acc[i][j] = 0.f;
    if (kbeg < kend) { load(kbeg); store(0); }
    __syncthreads();
    int buf = 0;
    for (int k0 = kbeg; k0 < kend; k0 += BK) {
        bool more = k0 + BK < kend;
        if (more) load(k0 + BK);
#pragma unroll
        for (int kk = 0; kk < BK; kk++) {
            f32 a[TM], b[TN];
            const f32 *ar = &As[buf][kk][0], *br = &Bs[buf][kk][0];
            if (HM == 4) { float4 u = *(const float4 *)(ar + ty * 4), v = *(const float4 *)(ar + BM / 2 + ty * 4);
                a[0] = u.x; a[1] = u.y; a[2] = u.z; a[3] = u.w; a[4] = v.x; a[5] = v.y; a[6] = v.z; a[7] = v.w; }
            else if (HM == 2) { float2 u = *(const float2 *)(ar + ty * 2), v = *(const float2 *)(ar + BM / 2 + ty * 2);
                a[0] = u.x; a[1] = u.y; a[2] = v.x; a[3] = v.y; }
            else if (TM == 2) { a[0] = ar[ty]; a[1] = ar[BM / 2 + ty]; }
            else a[0] = ar[ty];
            if (HN == 4) { float4 u = *(const float4 *)(br + tx * 4), v = *(const float4 *)(br + BN / 2 + tx * 4);
                b[0] = u.x; b[1] = u.y; b[2] = u.z; b[3] = u.w; b[4] = v.x; b[5] = v.y; b[6] = v.z; b[7] = v.w; }
            else if (HN == 2) { float2 u = *(const float2 *)(br + tx * 2), v = *(const float2 *)(br + BN / 2 + tx * 2);
                b[0] = u.x; b[1] = u.y; b[2] = v.x; b[3] = v.y; }
            else if (TN == 2) { b[0] = br[tx]; b[1] = br[BN / 2 + tx]; }
            else b[0] = br[tx];
#pragma unroll
            for (int i = 0; i < TM; i++)
#pragma unroll
                for (int j = 0; j < TN; j++) acc[i][j] = fmaf(a[i], b[j], acc[i][j]);
        }
        if (more) store(buf ^ 1);
        __syncthreads();
        buf ^= 1;
    }

    for (int i = 0; i < TM; i++) {
        int m = m0 + (TM == 1 ? ty : i < HM ? ty * HM + i : BM / 2 + ty * HM + i - HM);
        if (m >= M) continue;
        f32 bv = (CM == 0 && bias) ? bias[m] : 0.f;
        f32 *out = CM == 1 ? Cm + blockIdx.z * zstride + (long)m * ldc : Cm;
        for (int half = 0; half < (TN == 1 ? 1 : 2); half++) {
            int nb = n0 + (TN == 1 ? tx : half * (BN / 2) + tx * HN);
            int cnt = TN == 1 ? 1 : HN;
            if (CM == 0) {
                if (nb >= Nn) continue;
                long img = nb / iOHW, p = nb - (int)img * iOHW;
                for (int j = 0; j < cnt && nb + j < Nn; j++) {
                    Cm[(img * M + m) * OHW + p] = acc[i][half * HN + j] + bv;
                    if (++p == OHW) { p = 0; img++; }
                }
            } else {
                for (int j = 0; j < cnt; j++) { int n = nb + j; if (n < Nn) out[n] = acc[i][half * HN + j]; }
            }
        }
    }
}
#define IGARGS const f32 *A, const f32 *B, f32 *Cm, const f32 *bias, const int2 *tab, int M, int Nn, int Kd, int kseg, int lda, \
    int C, int H, int W, int OH, int OW, int sh, int sw, int pt, int pl, long ldc, long zstride
#define IGPASS A, B, Cm, bias, tab, M, Nn, Kd, kseg, lda, C, H, W, OH, OW, sh, sw, pt, pl, ldc, zstride
#define IG(name, BM_, BN_, AM_, BMD_, CM_) \
    extern "C" __global__ void __launch_bounds__(TH, 2) name(IGARGS) { igemm<BM_, BN_, AM_, BMD_, CM_>(IGPASS); }
// forward (and stride-1 input gradient through flipped weights): y = W * im2col(x)
IG(ig_fwd_16, 16, 128, 0, 0, 0) IG(ig_fwd_32, 32, 128, 0, 0, 0) IG(ig_fwd_64, 64, 128, 0, 0, 0) IG(ig_fwd_128, 128, 128, 0, 0, 0)
// weight gradient: dW = dy * im2col(x)^T, split over k segments
IG(ig_dw_16_32, 16, 32, 1, 2, 1) IG(ig_dw_32_32, 32, 32, 1, 2, 1) IG(ig_dw_64_32, 64, 32, 1, 2, 1) IG(ig_dw_128_32, 128, 32, 1, 2, 1)
IG(ig_dw_16_128, 16, 128, 1, 2, 1) IG(ig_dw_32_128, 32, 128, 1, 2, 1) IG(ig_dw_64_128, 64, 128, 1, 2, 1) IG(ig_dw_128_128, 128, 128, 1, 2, 1)
// input gradient columns (strided convolutions): dcol = W^T * dy, then col2im
IG(ig_dcol_64, 64, 128, 2, 1, 1) IG(ig_dcol_128, 128, 128, 2, 1, 1)

// w (OC, C, KH, KW) -> wt (C, OC, KH, KW) flipped in both spatial axes: the stride-1 input gradient is a convolution of dy with wt
K flip_t(const f32 *w, f32 *wt, int OC, int Cc, int KH, int KW) {
    IDX; if (i >= (long)OC * Cc * KH * KW) return;
    int kj = i % KW; long t = i / KW; int ki = t % KH; t /= KH; int c = t % Cc; int oc = (int)(t / Cc);
    wt[(((long)c * OC + oc) * KH + (KH - 1 - ki)) * KW + (KW - 1 - kj)] = w[i];
}
// sum over k segments: out[i] = sum_z part[z*n + i]  (fixed order: deterministic)
K seg_sum(const f32 *part, f32 *out, int Z, long n) { IDX; if (i >= n) return; f32 s = 0; for (int z = 0; z < Z; z++) s += part[(long)z * n + i]; out[i] = s; }

// ================================================================ batch norm (+ activation), parallel reductions
// Per channel sums over N*HW values: grid (S, C), 256 threads. Each thread adds at most ``per`` values in fp32, the
// block combines the threads in double, and bn_*_final adds the S block results in double (as the CPU core does).
__device__ __forceinline__ f32 dact(int kind, f32 z, f32 s) {        // d act / d z, from the pre-activation z
    if (kind == 0) return z > 0 ? 1.f : 0.f;
    if (kind == 1) return z > 0 ? 1.f : s;
    if (kind == 2) { f32 q = sig(z); return q * (1.f + z * (1.f - q)); }
    f32 q = sig(z); return q * (1.f - q);
}
__device__ __forceinline__ f32 actv(int kind, f32 z, f32 s) {
    return kind == 0 ? (z > 0 ? z : 0) : kind == 1 ? (z > 0 ? z : s * z) : kind == 2 ? z * sig(z) : sig(z);
}
// mode 0: (x, x*x)   mode 1: (dz, dz*xhat) with dz = dy * act'(z) (kind < 0: no activation)   mode 2: (x, -)
K chan_reduce(const f32 *x, const f32 *dy, const f32 *mean, const f32 *istd, const f32 *g, const f32 *b,
              double *p1, double *p2, int N, int Cc, long HW, long seg, int mode, int kind, f32 slope) {
    __shared__ double s1[TH], s2[TH];
    int c = blockIdx.y, s = blockIdx.x, t = threadIdx.x;
    long total = (long)N * HW, lo = (long)s * seg, hi = lo + seg < total ? lo + seg : total;
    f32 mu = mode == 1 ? mean[c] : 0.f, is = mode == 1 ? istd[c] : 0.f, gc = mode == 1 ? g[c] : 0.f, bc = mode == 1 ? b[c] : 0.f;
    f32 a = 0.f, q = 0.f;
    int iHW = (int)HW;
    for (long e = lo + t; e < hi; e += TH) {
        int ie = (int)e, n = ie / iHW, p = ie - n * iHW; long at = ((long)n * Cc + c) * HW + p;
        f32 v = x[at];
        if (mode == 0) { a += v; q += v * v; }
        else if (mode == 2) a += v;
        else { f32 xh = (v - mu) * is, d = dy[at]; if (kind >= 0) d *= dact(kind, xh * gc + bc, slope); a += d; q += d * xh; }
    }
    s1[t] = a; s2[t] = q;
    __syncthreads();
    for (int w = TH / 2; w > 0; w >>= 1) { if (t < w) { s1[t] += s1[t + w]; s2[t] += s2[t + w]; } __syncthreads(); }
    if (t == 0) { p1[(long)c * gridDim.x + s] = s1[0]; p2[(long)c * gridDim.x + s] = s2[0]; }
}
K bn_stats_final(const double *p1, const double *p2, int S, int Cc, double count, f32 *mean, f32 *istd, f32 *rm, f32 *rv, f32 mom, f32 eps) {
    IDX; if (i >= Cc) return; double a = 0, b = 0;
    for (int s = 0; s < S; s++) { a += p1[(long)i * S + s]; b += p2[(long)i * S + s]; }
    double mu = a / count, var = b / count - mu * mu; if (var < 0) var = 0;
    mean[i] = (f32)mu; istd[i] = (f32)(1.0 / sqrt(var + eps));
    rm[i] = (1.f - mom) * rm[i] + mom * (f32)mu;
    rv[i] = (1.f - mom) * rv[i] + mom * (f32)(count > 1 ? var * count / (count - 1) : var);
}
K sums_final(const double *p1, const double *p2, int S, int Cc, f32 *o1, f32 *o2) {      // o1 = sum p1, o2 = sum p2
    IDX; if (i >= Cc) return; double a = 0, b = 0;
    for (int s = 0; s < S; s++) { a += p1[(long)i * S + s]; if (o2) b += p2[(long)i * S + s]; }
    o1[i] = (f32)a; if (o2) o2[i] = (f32)b;
}
K bn_act_apply(const f32 *x, f32 *y, const f32 *mean, const f32 *istd, const f32 *g, const f32 *b, int N, int Cc, long HW, int kind, f32 slope) {
    IDX; if (i >= (long)N * Cc * HW) return; int c = (i / HW) % Cc;
    f32 z = (x[i] - mean[c]) * istd[c] * g[c] + b[c];
    y[i] = kind < 0 ? z : actv(kind, z, slope);
}
K bn_act_bwd_apply(const f32 *x, const f32 *dy, const f32 *g, const f32 *b, const f32 *mean, const f32 *istd, const f32 *dg, const f32 *db,
                   f32 *dx, int N, int Cc, long HW, int train, int kind, f32 slope) {
    IDX; if (i >= (long)N * Cc * HW) return; int c = (i / HW) % Cc;
    f32 xh = (x[i] - mean[c]) * istd[c], d = dy[i];
    if (kind >= 0) d *= dact(kind, xh * g[c] + b[c], slope);
    if (!train) { dx[i] = d * g[c] * istd[c]; return; }
    f32 m = (f32)N * (f32)HW;
    dx[i] = g[c] * istd[c] / m * (m * d - db[c] - xh * dg[c]);
}
