"""Images and Felix datasets as network input (letterboxed in the C core)."""
from __future__ import annotations

import ctypes as C
import os
import random
from concurrent.futures import ThreadPoolExecutor
from typing import List, Optional, Sequence, Tuple

from .core import Tensor, device as _device
from .core.cpu import lib
from .errors import DataError

IMAGE_EXT = (".png", ".jpg", ".jpeg", ".bmp", ".webp")


def load_image(src):
    """Anything image-like → (RGB bytes, width, height, source path or None)."""
    path = None
    if isinstance(src, (str, os.PathLike)):
        path = os.fspath(src)
        if not os.path.isfile(path):
            raise DataError(f"image not found: {path!r}.", "the path does not point to a file.",
                            "check the spelling and that the file exists.")
        if not path.lower().endswith(IMAGE_EXT):
            raise DataError(f"unsupported image format: {os.path.basename(path)!r}.",
                            f"Workflow reads {', '.join(IMAGE_EXT)}.", "convert the image to PNG or JPEG.")
        try:
            from PIL import Image
            with Image.open(path) as im:
                im = im.convert("RGB")
                return im.tobytes(), im.width, im.height, path
        except ImportError:
            raise DataError("reading image files needs Pillow.", "Pillow decodes PNG/JPEG for Workflow.", "run `pip install Pillow`.") from None
        except Exception as e:
            raise DataError(f"could not read the image {path!r}.", f"the file is damaged or not really an image ({e}).",
                            "open it in an image viewer to check, or re-export it as PNG/JPEG.") from None
    if hasattr(src, "convert") and hasattr(src, "tobytes") and hasattr(src, "size"):      # PIL / Felix image
        im = src.convert("RGB")
        return im.tobytes(), im.size[0], im.size[1], None
    if hasattr(src, "shape") and hasattr(src, "tobytes") and len(src.shape) == 3 and src.shape[2] == 3:   # HxWx3 uint8 array
        return bytes(src.tobytes()), int(src.shape[1]), int(src.shape[0]), None
    raise DataError(f"cannot use {type(src).__name__} as an image.",
                    "predict accepts a file path, a PIL image, or an RGB uint8 array shaped (height, width, 3).",
                    "pass one of those (convert OpenCV BGR frames with cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)).")


def geometry(w: int, h: int, size: Tuple[int, int]):
    """Letterbox placement of a w×h image in ``size`` = (H, W): (scale, new_w, new_h, pad_x, pad_y)."""
    th, tw = size
    s = min(tw / w, th / h)
    nw, nh = max(1, round(w * s)), max(1, round(h * s))
    return s, nw, nh, (tw - nw) // 2, (th - nh) // 2


def fill(batch: Tensor, i: int, rgb: bytes, w: int, h: int, flip=False, gain=1.0, bias=0.0):
    """Write image ``i`` of a CPU batch tensor (N, 3, H, W); returns the letterbox geometry."""
    _, _, th, tw = batch.shape
    s, nw, nh, px, py = geometry(w, h, (th, tw))
    dst = C.c_void_p(batch.h + i * 3 * th * tw * 4)
    lib().wf_letterbox(rgb, h, w, dst, th, tw, nh, nw, px, py, 114.0, int(flip), gain, bias)
    return s, px, py


def as_dataset(obj):
    """A Felix dataset / subset object, or the path of one."""
    if isinstance(obj, (str, os.PathLike)):
        try:
            import felix
        except ImportError:
            raise DataError("datasets need the Felix package.", "Workflow reads datasets through Felix.", "install `felix` next to workflow.") from None
        return felix.load(obj)
    if not all(hasattr(obj, a) for a in ("stems", "annotation", "image")):
        raise DataError(f"{type(obj).__name__} is not a dataset.", "training and evaluation take a Felix dataset or split.",
                        "pass fx.load('data.felix').train, a dataset object, or a dataset path.")
    return obj


def is_classification(ds) -> bool:
    """A classification dataset (one class per image: ImageNet-style class folders, or annotations with class_id)."""
    task = getattr(ds, "task", None)
    if task is not None:
        return task == "classification"
    md = getattr(ds, "metadata", None) or {}
    return md.get("task") == "classification"


def random_crop(w: int, h: int, rng=random):
    """A random crop for classification training: 25-100% of the area, aspect ratio 3:4 to 4:3. (x, y, cw, ch)."""
    import math
    area = w * h
    for _ in range(10):
        a = area * rng.uniform(0.25, 1.0)
        r = math.exp(rng.uniform(math.log(3 / 4), math.log(4 / 3)))
        cw, ch = int(round(math.sqrt(a * r))), int(round(math.sqrt(a / r)))
        if 0 < cw <= w and 0 < ch <= h:
            return rng.randint(0, w - cw), rng.randint(0, h - ch), cw, ch
    return 0, 0, w, h


class Batches:
    """Iterate a Felix split as (images tensor on ``dev``, targets). Decoding runs in a thread pool.

    Detection: targets are flat rows [image, class, x1, y1, x2, y2]. Classification (``task="classify"``): one class
    id per image, and training augmentation adds a random crop before the flip and colour jitter."""

    def __init__(self, ds, size: Tuple[int, int], batch_size: int, dev, shuffle=False, augment=False, drop_last=False,
                 threads: Optional[int] = None, task: str = "detect"):
        self.task = task
        self.ds, self.size, self.bs, self.dev = ds, size, batch_size, dev
        self.shuffle, self.augment, self.drop_last = shuffle, augment, drop_last
        self.stems = list(ds.stems)
        self.pool = ThreadPoolExecutor(threads or min(8, os.cpu_count() or 2))
        self.ahead = ThreadPoolExecutor(1)          # builds the next batch while the current one is on the device
        self.cpu = _device.get("cpu")

    def __len__(self):
        n = len(self.stems)
        return n // self.bs if self.drop_last else (n + self.bs - 1) // self.bs

    def _one(self, args):
        batch, i, stem = args
        ann = self.ds.annotation(stem)
        if self.task == "classify":
            return self._one_class(batch, i, stem, ann)
        rgb, w, h, _ = load_image(self.ds.image(stem))
        flip = self.augment and random.random() < 0.5
        gain, bias = (random.uniform(0.75, 1.25), random.uniform(-20, 20)) if self.augment and random.random() < 0.8 else (1.0, 0.0)
        s, px, py = fill(batch, i, rgb, w, h, flip, gain, bias)
        W = self.size[1]
        rows = []
        for o in ann.get("objects") or []:
            x, y, bw, bh = o["bbox"]
            x1, y1, x2, y2 = x * s + px, y * s + py, (x + bw) * s + px, (y + bh) * s + py
            if flip:
                x1, x2 = W - x2, W - x1
            rows += [float(i), float(o["class_id"]), x1, y1, x2, y2]
        return rows

    def _one_class(self, batch, i, stem, ann):
        if "class_id" not in ann:
            raise DataError(f"image {stem!r} has no class label.", "a classification model learns one class per image.",
                            "use a classification dataset: class folders (cat/, dog/, …), loaded with fx.load.")
        im = self.ds.image(stem)
        if self.augment:
            im = im.convert("RGB") if hasattr(im, "convert") else im
            arr = getattr(im, "array", None)
            if arr is not None:
                H, W = arr.shape[0], arr.shape[1]
                x, y, cw, ch = random_crop(W, H)
                im = arr[y:y + ch, x:x + cw, :3]
        rgb, w, h, _ = load_image(im)
        flip = self.augment and random.random() < 0.5
        gain, bias = (random.uniform(0.75, 1.25), random.uniform(-20, 20)) if self.augment and random.random() < 0.8 else (1.0, 0.0)
        fill(batch, i, rgb, w, h, flip, gain, bias)
        return [float(ann["class_id"])]

    def _build(self, chunk):
        batch = self.cpu.be.empty((len(chunk), 3, self.size[0], self.size[1]))
        targets: List[float] = []
        for rows in self.pool.map(self._one, [(batch, i, s) for i, s in enumerate(chunk)]):
            targets += rows
        return batch, targets

    def __iter__(self):
        return self.iterate()

    def iterate(self, seed=None, start=0):
        """Batches in order (shuffled when ``shuffle``; with ``seed`` the order is reproducible), from batch ``start``."""
        order = list(self.stems)
        if self.shuffle:
            (random.Random(seed) if seed is not None else random).shuffle(order)
        chunks = [order[b * self.bs:(b + 1) * self.bs] for b in range(len(self))][start:]
        nxt = self.ahead.submit(self._build, chunks[0]) if chunks else None
        for b in range(len(chunks)):
            batch, targets = nxt.result()
            nxt = self.ahead.submit(self._build, chunks[b + 1]) if b + 1 < len(chunks) else None
            yield batch.to(self.dev), targets
