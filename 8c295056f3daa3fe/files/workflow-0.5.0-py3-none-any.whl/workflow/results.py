"""Structured prediction results."""
from __future__ import annotations

import json
import os
from typing import Dict, Iterator, List, Optional, Sequence

from .errors import WorkflowError

_PALETTE = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#46c8c8",
            "#f032e6", "#9acd32", "#008080", "#9a6324", "#800000", "#808000"]


class Results:
    """Detections for one image: ``xyxy`` (pixel boxes [x1, y1, x2, y2] in the original image),
    ``confidences``, ``class_ids`` and ``classes`` (names), all plain Python lists."""

    def __init__(self, image_rgb: bytes, width: int, height: int, rows: List[List[float]],
                 names: Optional[Sequence[str]] = None, path: Optional[str] = None):
        self._rgb, self.width, self.height, self.path = image_rgb, width, height, path
        self.names = list(names) if names else None
        self.xyxy = [r[:4] for r in rows]
        self.confidences = [r[4] for r in rows]
        self.class_ids = [int(r[5]) for r in rows]
        self.saved_to: Optional[str] = None

    @property
    def classes(self) -> List[str]:
        return [self._name(i) for i in self.class_ids]

    @property
    def xywh(self) -> List[List[float]]:
        return [[b[0], b[1], b[2] - b[0], b[3] - b[1]] for b in self.xyxy]

    def _name(self, i: int) -> str:
        return self.names[i] if self.names and i < len(self.names) else str(i)

    def __len__(self) -> int:
        return len(self.xyxy)

    def __iter__(self) -> Iterator[Dict]:
        for b, c, k in zip(self.xyxy, self.confidences, self.class_ids):
            yield {"class_id": k, "class": self._name(k), "confidence": c, "xyxy": b}

    def to_dict(self) -> Dict:
        return {"image": self.path, "width": self.width, "height": self.height, "detections": list(self)}

    def __repr__(self) -> str:
        counts: Dict[str, int] = {}
        for c in self.classes:
            counts[c] = counts.get(c, 0) + 1
        return f"Results({len(self)} detections: {', '.join(f'{n} {k}' for k, n in counts.items()) or 'nothing'})"

    def plot(self):
        """The image with boxes and labels drawn (a PIL image)."""
        try:
            from PIL import Image, ImageDraw, ImageFont
        except ImportError:
            raise WorkflowError("drawing results needs Pillow.", "Pillow renders the boxes and labels.", "run `pip install Pillow`.") from None
        im = Image.frombytes("RGB", (self.width, self.height), self._rgb)
        d = ImageDraw.Draw(im)
        lw, size = max(2, round(min(im.size) / 200)), max(11, round(min(im.size) / 40))
        try:
            font = ImageFont.load_default(size)
        except TypeError:
            font = ImageFont.load_default()
        for b, c, k in zip(self.xyxy, self.confidences, self.class_ids):
            col = _PALETTE[k % len(_PALETTE)]
            d.rectangle(b, outline=col, width=lw)
            text = f"{self._name(k)} {c:.2f}"
            tb = d.textbbox((0, 0), text, font=font)
            tw, th = tb[2] - tb[0] + 6, tb[3] - tb[1] + 6
            y0 = b[1] - th if b[1] - th >= 0 else b[1]
            d.rectangle([b[0], y0, b[0] + tw, y0 + th], fill=col)
            d.text((b[0] + 3, y0 + 2 - tb[1]), text, fill="white", font=font)
        return im

    def show(self) -> None:
        self.plot().show()

    def save(self, path) -> str:
        path = os.fspath(path)
        if not path.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".webp")):
            raise WorkflowError(f"cannot save an image as {os.path.basename(path)!r}.", "the extension is not an image format Workflow writes.",
                                "use a .png or .jpg file name.")
        os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
        self.plot().save(path)
        return path


class ClassResult:
    """The label of one image (classification models): ``class_id``, ``class_name`` and ``confidence`` of the best
    guess, ``top`` (the five best as dicts) and ``probabilities`` (one per class). ``plot()`` draws the label."""

    kind = "classification"

    def __init__(self, image_rgb: bytes, width: int, height: int, probabilities: List[float], top, names=None,
                 path: Optional[str] = None):
        self._rgb, self.width, self.height, self.path = image_rgb, width, height, path
        self.names = list(names) if names else None
        self.probabilities = list(probabilities)
        self.top = [{"class_id": int(c), "class": self._name(int(c)), "confidence": float(p)} for c, p in top]
        self.class_id = self.top[0]["class_id"]
        self.class_name = self.top[0]["class"]
        self.confidence = self.top[0]["confidence"]
        self.saved_to: Optional[str] = None
        # the detection-style fields, so code written for either kind keeps working
        self.xyxy: List[List[float]] = []
        self.confidences = [self.confidence]
        self.class_ids = [self.class_id]

    @property
    def classes(self) -> List[str]:
        return [self.class_name]

    def _name(self, i: int) -> str:
        return self.names[i] if self.names and i < len(self.names) else str(i)

    def __len__(self) -> int:
        return 1

    def __iter__(self) -> Iterator[Dict]:
        return iter(self.top)

    def to_dict(self) -> Dict:
        return {"image": self.path, "width": self.width, "height": self.height, "class": self.class_name,
                "class_id": self.class_id, "confidence": self.confidence, "top": self.top}

    def __repr__(self) -> str:
        return f"ClassResult({self.class_name} {self.confidence:.2f})"

    def plot(self):
        """The image with its label (and the runner-up guesses) in the top-left corner (a PIL image)."""
        try:
            from PIL import Image, ImageDraw, ImageFont
        except ImportError:
            raise WorkflowError("drawing results needs Pillow.", "Pillow renders the labels.", "run `pip install Pillow`.") from None
        im = Image.frombytes("RGB", (self.width, self.height), self._rgb)
        d = ImageDraw.Draw(im)
        size = max(12, round(min(im.size) / 22))
        try:
            font, small = ImageFont.load_default(size), ImageFont.load_default(max(10, size * 2 // 3))
        except TypeError:
            font = small = ImageFont.load_default()
        x, y = max(4, size // 3), max(4, size // 3)
        for i, t in enumerate(self.top[:3]):
            f = font if i == 0 else small
            text = f"{t['class']} {t['confidence']:.2f}"
            tb = d.textbbox((0, 0), text, font=f)
            tw, th = tb[2] - tb[0] + 10, tb[3] - tb[1] + 8
            col = _PALETTE[t["class_id"] % len(_PALETTE)] if i == 0 else "#202020"
            d.rectangle([x, y, x + tw, y + th], fill=col)
            d.text((x + 5, y + 4 - tb[1]), text, fill="white", font=f)
            y += th + 3
        return im

    def show(self) -> None:
        self.plot().show()

    def save(self, path) -> str:
        return Results.save(self, path)


class Predictions(list):
    """Results for a batch of images (a list of ``Results``)."""

    def show(self) -> None:
        for r in self:
            r.show()

    def to_dict(self) -> List[Dict]:
        return [r.to_dict() for r in self]

    def __repr__(self) -> str:
        if self and isinstance(self[0], ClassResult):
            return f"Predictions({len(self)} images, labels: {', '.join(r.class_name for r in self[:6])}{'…' if len(self) > 6 else ''})"
        return f"Predictions({len(self)} images, {sum(len(r) for r in self)} detections)"


def write_json(results: Sequence[Results], path: str) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"predictions": [dict(r.to_dict(), annotated=r.saved_to) for r in results]}, f, indent=1)
