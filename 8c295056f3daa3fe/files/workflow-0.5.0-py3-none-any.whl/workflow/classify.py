"""Image classification: softmax cross-entropy (with label smoothing), top-1 / top-5 accuracy, decoded predictions.

The head (``wf.head(classes=N, type="cls")``) gives one logit per class, shaped (N, classes, 1, 1). The loss runs on
the host in double precision (a few thousand numbers per batch) and hands the gradient back to the device."""
from __future__ import annotations

import math
from typing import Dict, List, Optional, Sequence

from .core import Tensor, device as _device

SMOOTHING = 0.1                    # label smoothing for training; evaluation reports the plain cross-entropy


def _rows(logits: Tensor):
    h = logits.dev.be.host(logits)
    N, C = logits.shape[0], logits.shape[1]
    v = h.tolist()
    return N, C, [v[i * C:(i + 1) * C] for i in range(N)]


def _softmax(row):
    mx = max(row)
    ex = [math.exp(x - mx) for x in row]
    s = sum(ex)
    return [e / s for e in ex], mx + math.log(s)


def loss(logits: Tensor, labels: Sequence[float], smoothing: float = SMOOTHING, grad: bool = True):
    """Mean cross-entropy against ``labels`` (class ids) with ``smoothing``. Sets ``logits.grad`` (ready for
    ``backward()``) when ``grad``; returns (loss, {"ce": loss})."""
    N, C, rows = _rows(logits)
    if len(labels) != N:
        raise ValueError(f"{len(labels)} labels for {N} images")
    total, g = 0.0, []
    off = smoothing / C
    for row, y in zip(rows, labels):
        y = int(y)
        p, lse = _softmax(row)
        total += lse - ((1 - smoothing) * row[y] + smoothing * sum(row) / C)
        if grad:
            gi = [(pc - off) / N for pc in p]
            gi[y] -= (1 - smoothing) / N
            g += gi
    total /= max(1, N)
    if grad:
        logits.grad = Tensor.from_list(g, logits.shape, _device.get("cpu")).to(logits.dev)
    return total, {"ce": total}


def decode(logits: Tensor, top: int = 5):
    """Per image: (probabilities for every class, [(class id, probability), ...] best first, ``top`` long)."""
    N, C, rows = _rows(logits)
    out = []
    for row in rows:
        p, _ = _softmax(row)
        order = sorted(range(C), key=lambda c: -p[c])[:top]
        out.append((p, [(c, p[c]) for c in order]))
    return out


class ClassificationMetrics:
    """Top-1 / top-5 accuracy, cross-entropy, per-class accuracy and a confusion matrix (rows: true class)."""

    def __init__(self, classes: int, names: Optional[Sequence[str]] = None):
        self.nc = classes
        self.names = list(names) if names else [str(i) for i in range(classes)]
        self.n = self.top1 = self.top5 = 0
        self.ce = 0.0
        self.confusion = [[0] * classes for _ in range(classes)]

    def update(self, logits: Tensor, labels: Sequence[float]) -> None:
        N, C, rows = _rows(logits)
        for row, y in zip(rows, labels):
            y = int(y)
            p, lse = _softmax(row)
            order = sorted(range(C), key=lambda c: -row[c])
            self.top1 += order[0] == y
            self.top5 += y in order[:5]
            self.ce += lse - row[y]
            self.confusion[y][order[0]] += 1
            self.n += 1

    def compute(self) -> Dict:
        n = max(1, self.n)
        per = []
        for c in range(self.nc):
            seen = sum(self.confusion[c])
            per.append({"class": self.names[c], "images": seen, "accuracy": self.confusion[c][c] / seen if seen else None})
        return {"top1": self.top1 / n, "top5": self.top5 / n, "ce": self.ce / n, "images": self.n,
                "per_class": per, "confusion_matrix": [list(r) for r in self.confusion]}
