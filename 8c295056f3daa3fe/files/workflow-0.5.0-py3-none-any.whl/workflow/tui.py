"""``workflow library``: every layer, block and tool, with the cookbook's explanations, in a searchable browser.

The entries come from the library table (what it does, what you choose, an example), the cookbook (toddler words,
why, examples, the catch) and the code itself (signature, docstring), so the browser never disagrees with them."""
from __future__ import annotations

import os
import re
from typing import List

from . import _tui
from ._tui import Entry, key, plain, ticks
from ._version import __version__

_HERE = os.path.dirname(os.path.abspath(__file__))
GROUPS = ("Start", "Layers", "Blocks", "Composition", "Tools", "Guides")


def _cookbook() -> str:
    for path in (os.path.join(_HERE, "cookbook.md"), os.path.join(_HERE, "..", "..", "docs", "cookbook.md")):
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                text = f.read()
            i = text.find("## Part 2")
            return text[i:] if i >= 0 else text
    return ""


def load() -> List[Entry]:
    import workflow as wf
    from . import library
    entries, group = [], None
    for line in library.text().splitlines():
        if line.startswith("## "):
            group = line[3:].strip()
        elif group in GROUPS and line.startswith("| `"):
            cells = [c.strip() for c in line.strip().strip("|").split(" | ")]
            if len(cells) >= 4:
                names = ticks(cells[0])
                obj = next((getattr(wf, n[3:].split("(")[0], None) for n in names if n.startswith("wf.")), None)
                example = plain(cells[3])
                shown = " / ".join(re.sub(r"\(.*?\)", "", n) for n in names)
                entries.append(Entry(shown, group, plain(cells[1]), cells[2],
                                     "" if example.lower().startswith("see ") else example, [key(n) for n in names], obj))
    by_key = {k: e for e in entries for k in e.keys}
    for head, body in _tui.cookbook_sections(_cookbook()):
        if head.startswith("## ") and not head.startswith("## Part 6"):
            continue
        hits = list(dict.fromkeys(by_key[k] for k in map(key, ticks(head)) if k in by_key))
        for e in hits:
            e.add(body)
        if not hits:                            # cookbook topics without a table row: padding, errors, recipes, …
            title = "Recipes" if head.startswith("## Part 6") else plain(head.lstrip("#"))
            e = Entry(title, "Guides", _tui.eli5(body), keys=[key(n) for n in ticks(head)] or [title.lower()])
            e.add(body)
            entries.append(e)
    order = {g: i for i, g in enumerate(GROUPS)}
    entries.sort(key=lambda e: order.get(e.group, len(GROUPS)))
    return entries


def run(query: str = "") -> int:
    return _tui.run(load(), "workflow", __version__, "wf.", query)
