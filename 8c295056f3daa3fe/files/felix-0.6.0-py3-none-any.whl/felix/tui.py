"""``felix library``: every Felix function and command, with the cookbook's explanations, in a searchable browser.

Entries come from the API reference and CLI pages, the Felix part of the cookbook (toddler words, why, examples, the
catch) and the code itself (signature, docstring)."""
from __future__ import annotations

import os
import re
from typing import Dict, List

from . import _tui
from ._tui import Entry, key, plain, ticks
from ._version import __version__

_HERE = os.path.dirname(os.path.abspath(__file__))
GROUPS = ("Classes", "Steps", "Random", "Output", "Commands", "Formats", "Guides")


def _read(name: str) -> str:
    for path in (os.path.join(_HERE, "docs", name), os.path.join(_HERE, "..", "..", "docs", name)):
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                return f.read()
    return ""


def _obj(name: str):
    """felix object for `fx.toolkit.circle` / `felix.raster.Image` (None if it isn't one)."""
    import felix
    m = re.fullmatch(r"(?:fx|felix)\.([\w.]+)", name)
    if not m:
        return None
    obj = felix
    for part in m.group(1).split("."):
        obj = getattr(obj, part, None)
        if obj is None:
            return None
    return obj


def _sections(md: str, level: str):
    """(heading, body) pairs at one heading level."""
    parts = re.split(rf"^({level} .+)$", md, flags=re.M)
    return [(parts[i][len(level) + 1:].strip(), parts[i + 1].strip()) for i in range(1, len(parts) - 1, 2)]


def _first(md: str) -> str:
    t = plain(re.split(r"\n\s*\n|```", md.strip())[0])
    return t.split(". ")[0].rstrip(".") if len(t) > 100 else t


def _table_rows(md: str):
    return [[c.strip() for c in l.strip().strip("|").split(" | ")] for l in md.splitlines()
            if l.startswith("| `")]


def load() -> List[Entry]:
    entries: List[Entry] = []
    reference: Dict[int, str] = {}                  # id(entry) -> API text, added after the cookbook text

    def add(e: Entry, ref: str = ""):
        entries.append(e)
        if ref:
            reference[id(e)] = ref
        return e

    # API reference: one entry per function; the shapes and random tables give one entry per row
    for group_head, group_body in _sections(_read("api.md"), "##"):
        group = re.sub(r"\s*\(.*", "", group_head)
        if group == "Errors":
            add(Entry("fx.FelixError", "Guides", plain(group_body), obj=_obj("fx.FelixError")), group_body)
            continue
        intro = re.split(r"^### ", group_body, flags=re.M)[0]
        if group == "Random":
            note = plain(intro.split("\n\n")[-1]) if "threshold" in intro else ""
            for row in _table_rows(intro):
                names = ticks(row[0])
                full = [f"fx.random.{n.split('(')[0]}" for n in names]
                args = re.search(r"\((.*)\)", names[0])
                add(Entry(" / ".join(full), group, plain(row[1]),
                          ", ".join(x for x in ((args.group(1) if args else ""), "threshold=1" if note else "") if x), keys=[key(n) for n in full] + ["fx.random.*"],
                          obj=_obj(full[0])), "\n\n".join(x for x in (row[1], note) if x))
        for head, body in _sections(group_body, "###"):
            sig = (ticks(head) or [head])[0]
            if head.endswith("shapes") and "|" in body:          # fx.toolkit shapes: one entry per shape
                shared = body.split("\n\n")[0]
                for row in _table_rows(body):
                    name = f"fx.toolkit.{ticks(row[0])[0]}"
                    extra = "position=, name=" + (", color=" if not name.endswith("image") else "")
                    add(Entry(name, group, "", ", ".join(ticks(row[1]) + [extra]), obj=_obj(name)),
                        shared + "\n\n" + row[1])
                continue
            name = sig.split("(")[0]
            args = re.search(r"\((.*)\)", sig)
            ret = re.search(r"→\s*(.+)$", head)
            what = _first(body) + (f" Returns {plain(ret.group(1))}." if ret else "")
            add(Entry(name, group, what, args.group(1) if args else "", obj=_obj(name)), body)

    # commands: the overview block of the CLI page, plus each command's own section
    cli = _read("cli.md")
    block = re.search(r"```\n(.*?)\n```", cli, re.S)
    cmd_sections = _sections(cli, "##")
    for line in (block.group(1).splitlines() if block else []):
        m = re.match(r"(felix \w+)\s+(.*?)\s{2,}(.+)$", line)
        if not m:
            continue
        name, args, what = m.groups()
        e = add(Entry(name, "Commands", what, args, keys=[name]))
        word = name.split()[1]
        for head, body in cmd_sections:
            if re.search(rf"`felix {word}`|^{word.capitalize()}", head) or (word == "convert" and "Convert" in head):
                reference[id(e)] = plain(head) + "\n\n" + body if id(e) not in reference else reference[id(e)]
    note = cli.split("```")[-1].split("\n## ")[0].strip() if block else ""
    if note:
        for e in entries:
            if e.group == "Commands" and id(e) not in reference:
                reference[id(e)] = note

    # file formats and the walkthrough
    for head, body in _sections(_read("formats.md"), "##"):
        add(Entry(plain(head), "Formats", _first(body)), body)
    start = _read("getting-started.md")
    if start:
        add(Entry("Getting started", "Guides", _first(start.split("\n", 1)[1]), keys=["getting started"]),
            start.split("\n", 1)[1])

    # the cookbook's Felix part: toddler words first, then the reference text
    by_key: Dict[str, List[Entry]] = {}
    for e in entries:
        for k in e.keys:
            by_key.setdefault(k, []).append(e)
    for head, body in _tui.cookbook_sections(_read("cookbook.md")):
        names = ticks(head)
        if not names:
            hits = [e for e in entries if e.group == "Commands" and e.name.split()[1] in body and
                    e.name.split()[1] not in ("run", "partition", "split")]
        else:
            base = names[0].rsplit(".", 1)[0] if "." in names[0] else ""
            keys = [key(n if "." in n or " " in n or not base else f"{base}.{n}") for n in names]
            hits = [e for k in keys for e in by_key.get(k, [])]
        for e in dict.fromkeys(hits):
            e.add(body)
            if not e.what or len(e.what) > 120 or len(e.what) < 25 or e.what.endswith(":"):
                e.what = _tui.eli5(body)
    for e in entries:
        if id(e) in reference:
            e.add(reference[id(e)], "Reference" if e.sections else None)

    order = {g: i for i, g in enumerate(GROUPS)}
    entries.sort(key=lambda e: order.get(e.group, len(GROUPS)))
    return entries


def run(query: str = "") -> int:
    return _tui.run(load(), "felix", __version__, "fx.", query)
