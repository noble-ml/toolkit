"""Felix - a lightweight dataset pipeline generator."""
from ._version import __version__
from .errors import FelixError
from .project import class_set, step, paint, gen, reset
from . import toolkit, canvas
from .toolkit import stack
from . import rand as random
from .make import make
from .store import Dataset, load
from .partition import partition
from .split import split

__all__ = [
    "__version__", "FelixError", "class_set", "step", "paint", "gen", "reset",
    "toolkit", "canvas", "stack", "random", "make", "Dataset", "load", "partition", "split",
]


def __getattr__(name):
    """A typo such as fx.Conv2d gets a "did you mean" instead of a bare AttributeError."""
    import difflib
    public = [n for n in globals() if not n.startswith("_")]
    match = [n for n in public if n.lower() == name.lower()] or difflib.get_close_matches(name, public, n=1, cutoff=0.6)
    hint = f" Did you mean {__name__}.{match[0]}?" if match else ""
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'.{hint}")
