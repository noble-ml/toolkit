# Cookbook

Every tool, explained like you're three, then *why* you'd reach for it and where it goes. Every example writes
out all the main arguments (with their defaults) so you can see every knob, even the ones you'd usually leave alone.

Felix makes the pictures. Workflow is the brain that learns to find things in them.

How to read an entry:

- **Toddler words**: what it is.
- **Why you'd use it**: the reasoning, and where it usually sits.
- **Example**: every main argument shown.
- **Watch out**: the one mistake people make (when there is one).

---

## Part 1 · Felix: making the pictures

### `fx.class_set`

**Toddler words:** a toy box with a name. Every toy you make inside it is a *kind of thing* the brain must learn
to find.

**Why you'd use it:** the brain can only learn classes you define, and the boxes let you group them (animals,
vehicles) so you can later pick "any animal" or "any vehicle" at random. The class name comes from the variable
name, so `cat = ...` makes a class called `cat`.

```python
with fx.class_set("animals"):
    cat = fx.toolkit.circle(radius=30)              # class "cat"
    dog = fx.toolkit.rectangle(width=50, height=40) # class "dog"
```

**Watch out:** shapes made *outside* a class set are not classes: they get drawn but never labelled. That's how you
make decoys on purpose.

### `fx.toolkit.circle`, `rectangle`, `polygon`

**Toddler words:** a ball, a box, and a "connect the dots" shape.

**Why you'd use it:** quick synthetic objects for testing a pipeline, or for detecting simple things (signs,
markers, parts). `position` is only a default spot; usually `fx.paint` decides where it goes.

```python
ball = fx.toolkit.circle(radius=20, position=None, color="red", name=None)
box  = fx.toolkit.rectangle(width=40, height=30, position=None, color="#1f77b4", name=None)
tent = fx.toolkit.polygon(vertices=[(0, 40), (20, 0), (40, 40)], position=None, color="green", name=None)
```

**Watch out:** without `color`, each class gets its own colour from a palette. Set it when the colour matters.

### `fx.stack`

**Toddler words:** glue several shapes together into one toy. A big circle, two triangle ears and two dot eyes
make one cat, and the brain learns "cat", not "circle" and "triangle".

**Why you'd use it:** real objects are made of parts. A stack lets you build a recognisable object from simple
shapes and still get **one** class and **one** box around the whole thing. The class name is the variable name.
Each part's `position` says where its centre goes, measured from the middle of the stack.

```python
with fx.class_set("animals"):
    cat = fx.stack(
        fx.toolkit.polygon(vertices=[(0, 14), (7, 0), (14, 14)], position=(-13, -22), color=None),  # left ear
        fx.toolkit.polygon(vertices=[(0, 14), (7, 0), (14, 14)], position=(13, -22), color=None),   # right ear
        fx.toolkit.circle(radius=22, position=(0, 0), color=None),                                  # head
        fx.toolkit.circle(radius=3, position=(-8, -4), color="black"),                               # eyes
        fx.toolkit.circle(radius=3, position=(8, -4), color="black"),
        position=None, color="#e8a33d", name=None,
    )
```

**Watch out:** parts are drawn in order, so put the things that go *on top* (eyes, nose) last. Parts without a
colour use the stack's colour; parts with one keep it. Spinning or growing the stack moves all its parts together.

### `fx.toolkit.image`

**Toddler words:** use a real sticker as a toy. The see-through parts of the sticker don't count as the toy.

**Why you'd use it:** cut-out photos of real objects (PNG with transparency) look far more like real life than
plain shapes. The box is fitted to the visible pixels only, so transparent padding never makes boxes too big.

```python
bike = fx.toolkit.image(source="assets/bicycle.png", width=80, height=None, position=None, name=None)
```

**Watch out:** give only `width` *or* `height` to keep the proportions; give both to stretch. JPEG stickers need
Pillow, and have no see-through parts.

### `fx.step`

**Toddler words:** the recipe for one picture. Felix follows it again and again, rolling new dice each time.

**Why you'd use it:** everything you write inside it (background, painting, changes) happens once per image. Make
several steps (for example "busy street" and "empty street") and Felix shares the images between them.

```python
with fx.step(size=(640, 640), name=None):
    ...
```

### `fx.canvas.background`

**Toddler words:** the paper you draw on: one colour, or a photo.

**Why you'd use it:** a plain colour is easy to learn; real photos (a folder of them, one picked per image) teach the
brain to ignore clutter, which is what you want for real-world use.

```python
fx.canvas.background(color="#eeeeee", image=None)
fx.canvas.background(color=None, image="backgrounds/")    # a different photo each time, cropped to fit
```

### `fx.random.*`

**Toddler words:** dice. Every picture rolls them again.

**Why you'd use it:** variety. A brain that only ever sees a cat in the middle, upright and red will fail on
anything else. Randomness in position, size, angle and colour is what makes it robust.

```python
fx.random.uniform(0.5, 2.0, threshold=1.0)    # any number between 0.5 and 2
fx.random.integer(1, 6, threshold=1.0)        # a whole number, like a real die
fx.random.choice("red", "blue", threshold=1.0)
fx.random.position(margin=40, threshold=1.0)  # somewhere on the paper, at least 40 px from the edges
fx.random.color(threshold=1.0)
fx.random.class_set("animals", threshold=1.0) # pick a toy box (any box if no names)
fx.random.class_(None, threshold=1.0)         # pick a toy (from any box, or from the box you pass)
```

**Watch out:** `threshold=0.5` means "flip a coin first; if it says no, skip it". It's how you get a *varying number*
of objects. Each dice call is its own die: the same variable used twice gives the same roll within one picture.

### `fx.paint`

**Toddler words:** put a toy on the paper.

**Why you'd use it:** this is what actually places objects. Pass a class, a random class, or a plain shape.

```python
obj = fx.paint(fx.random.class_(None, threshold=1.0), position=fx.random.position(margin=40))
```

### `fx.toolkit.transformation`

**Toddler words:** change how the toy looks: spin it, grow it, recolour it, brighten it, fade it.

**Why you'd use it:** the same as dice: real objects come at all angles, sizes and lighting. Calls add up (two
rotations add, two scales multiply).

```python
fx.toolkit.transformation(obj, hue=fx.random.uniform(-20, 20), brightness=fx.random.uniform(0.8, 1.2),
                          rotation=fx.random.uniform(0, 360), scale=fx.random.uniform(0.7, 1.5), opacity=1.0)
```

**Watch out:** `hue` is in degrees around the colour wheel, `rotation` is in degrees counter-clockwise, and the
others are multipliers (1 = unchanged).

### `fx.gen`

**Toddler words:** take a photo of where every toy is (the answer key). Toys painted *after* the photo are in
the picture but not in the answers.

**Why you'd use it:** it writes the boxes. Painting things after it adds **decoys** the brain must learn to
ignore, which cuts false alarms.

```python
fx.gen()
fx.paint(fx.toolkit.circle(radius=8, color="gray"), position=fx.random.position(margin=0))   # a decoy
```

### `fx.make`

**Toddler words:** do the recipe lots of times and put everything in a folder (or one `.felix` file).

**Why you'd use it:** this is the moment the dataset is created. Same `seed` = the exact same dataset, which is
handy for comparing models fairly.

```python
fx.make(pairs=1000, output="shapes.felix", seed=7, overwrite=False, quiet=False)
```

### `fx.load` and its splits

**Toddler words:** open the dataset. It already has three piles: `train` (learn from these), `val` (check while
learning), and `test` (the final exam nobody peeks at).

**Why you'd use it:** you pass these piles straight to Workflow. Generated datasets are split 80/10/10, the same
way every time. Converted datasets keep their own splits.

```python
data = fx.load("shapes.felix")
data.train, data.val, data.test          # the piles
data.classes                             # ['circle', 'square', 'triangle']
data.image(data.stems[0]).save("look.png")
```

### `fx.partition` / `felix partition`

**Toddler words:** cut one big pile into smaller piles, each a complete dataset.

**Why you'd use it:** share work between machines, make a small dataset for quick tests, or split a converted
dataset your own way.

```python
fx.partition("shapes.felix", output=None, parts=4, ratio=None, size=None, by_split=False,
             names=None, shuffle=False, seed=0, pack=None, overwrite=False)
fx.partition("shapes.felix", ratio=(80, 10, 10), names=["train", "val", "test"], shuffle=True, seed=1)
```
```
felix partition shapes.felix --size 100
```

**Watch out:** choose exactly one of `parts`, `ratio`, `size` or `by_split`.

### `fx.split` / `felix split`

**Toddler words:** photocopy the pile, then keep only part of the copy. The big pile stays exactly as it was.

**Why you'd use it:** micro experiments. Trying an idea on half (or a tenth) of VOC is much faster, and you still have
the whole dataset for the real run. Each train / val / test pile keeps the same share, and every picture stays in the
pile it was in, so test pictures never sneak into training.

```python
fx.split("voc.felix", 0.5, output=None, size=None, seed=0, overwrite=False)     # → voc_split_50.felix
fx.split("voc.felix", size=1000, seed=0)                                        # → exactly 1000 pairs
```
```
felix split voc.felix 0.5
felix split voc.felix 0.1 --seed 2        # another random tenth
```

**Watch out:** the fraction is a share, not a percent: `0.5` keeps half; `50` is refused with a hint.

### Other Felix commands

**Toddler words:** look inside a box, zip it up, unzip it, and turn someone else's box into yours.

**Why you'd use it:** checking what you made, sending one file instead of thousands, and training on real
Roboflow datasets.

```
felix info shapes.felix
felix pack ./dataset -o dataset.felix
felix unpack dataset.felix -o ./dataset
felix convert coco ./roboflow-export -o data.felix
```

---

