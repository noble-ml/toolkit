# Dataset formats

## Folder

```
dataset/
├── images/IMG1.png ...        (converted datasets may keep .jpg)
├── annotations/IMG1.yml ...
└── metadata.yml
```

## Class folders (classification)

An ImageNet-style folder is a dataset as it is: one folder per class with its images, optionally inside `train/`,
`val/` and `test/` (also `valid`, `validation`, `training`, `testing`).

```
animals/                      animals/
├── cat/001.jpg …             ├── train/cat/… dog/…
├── dog/…                     ├── val/cat/… dog/…
└── bird/…                    └── test/cat/… dog/…
```

`fx.load("animals/")` reads it without writing anything next to the images: the class names are the folder names (in
natural order, ids follow), each image is one pair, and its annotation is made up on the fly:

```yaml
image: cat/001.jpg
split: train
class: cat
class_id: 1
```

with `metadata.yml` holding `task: classification`, the classes and the split counts. Without split folders every class
is split 80 / 10 / 10 on its own (stratified, seed 0, the same every time). PNG, JPEG, BMP, WebP, GIF and TIFF are
read; hidden files and folders (`.` or `_` first) are skipped. `felix pack` turns it into a regular `.felix` file with
those annotations, and `felix info`, `split` and `partition` work on both.

## `.felix`

A single file for the same tree - a standard ZIP archive (PNG/JPEG stored, YAML deflated),
so `unzip` and Python's `zipfile` can open it. `felix pack` / `felix unpack` convert between
the two; `fx.make(output="x.felix")` writes it directly (via a `.part` file, so a crash never
leaves a half-written dataset).

## `annotations/IMG1.yml`

```yaml
image: IMG1.png
width: 640
height: 640
step: step-1          # generated datasets
split: train          # converted datasets only
objects:
  - class: cat
    class_id: 0
    class_set: animals
    bbox: [316, 163, 62, 62]   # x, y, width, height in pixels, top-left origin
```

## `metadata.yml`

```yaml
felix_version: "0.1.0"
created: "2026-11-10T08:17:58Z"
pairs: 200
seed: 1                 # generated datasets: re-run with the same seed to reproduce
image_format: png
bbox_format: xywh
steps:
  - name: step-1
    size: [640, 640]
classes:
  - id: 0
    name: cat
    set: animals
```

Splits are not stored for generated datasets: `ds.train` / `ds.val` / `ds.test` derive them deterministically from
the seed (see the API page), and converted datasets keep their `split` field.

The YAML is plain and valid; any YAML parser reads it. Felix itself uses a tiny built-in
reader so it needs no dependencies.
