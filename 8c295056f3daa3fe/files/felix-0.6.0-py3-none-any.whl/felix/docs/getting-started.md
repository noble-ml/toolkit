# Getting started

A Felix pipeline has five parts: **class sets → step → random → paint/transformation → gen/make**.

## 1. Class sets

```python
with fx.class_set("animals"):
    cat  = fx.toolkit.circle(radius=30, position=(32, 32))
    dog  = fx.toolkit.rectangle(width=50, height=40)
    bird = fx.toolkit.polygon(vertices=[(0, 30), (20, 0), (40, 30)])
with fx.class_set("vehicles"):
    bicycle = fx.toolkit.image(source="assets/bicycle.png")
```

Every shape created inside a `class_set` becomes a **class**. Its name is the variable
name (`cat`, `dog`, ...), or pass `name="..."`. Class ids are assigned in definition order.
Colours default to a built-in palette; override with `color="#ff8800"`. A shape's
`position` is its default location if `fx.paint` is not given one.

## 2. Step

```python
with fx.step(size=(640, 640)):
    ...
```

**The body runs once** to record a recipe. Calls to `fx.random.*` don't produce numbers
right away - they're *lazy* and are re-sampled for every generated image. This means:

- plain Python `if`/`for` on a random value will not work (it isn't a number yet);
- loops that *build* the scene do work: `for _ in range(5): fx.paint(...)` paints five
  objects, each with its own independent random draws;
- the same random node used twice in one image gives the same value both times (e.g.
  `selected_set` feeding `class_`).

## 3. Random + threshold

`fx.random.class_set()`, `fx.random.class_(set)`, `uniform`, `integer`, `choice`,
`position`, `color`. All accept `threshold=p` (0-1): the probability the value is
produced at all. On a failed roll the value is `None`: painting `None` does nothing and a
`None` transformation parameter is ignored. So `fx.paint(fx.random.class_(threshold=0.5))`
adds an object to about half the images.

## 4. Paint and transformation

`fx.paint(cls, position=...)` places a class and returns a handle.
`fx.toolkit.transformation(handle, hue=, brightness=, rotation=, scale=, opacity=)` modifies it.
Transformations are applied to the handle's object when the image is rendered, so you can call
them after `paint`.

## 5. gen and make

`fx.gen()` takes every object painted **before** it, measures each one's tight bounding box
(pixels that are fully transparent don't count - ideal for PNG cut-outs) and records the
annotations. Objects painted after `gen` are still drawn but are not annotated (handy for
distractors). Objects annotated by `gen` are frozen: later transformations on them are
ignored, so image and annotation always agree. The image itself is saved when the step ends.

`fx.make(pairs=10_000, output="./dataset")` repeats the step and writes the dataset.
Pass a path ending in `.felix` for a single compressed file. `seed=` makes runs
reproducible; the seed used is stored in `metadata.yml`.

Note: an object partly covered by a later object keeps its full box (occlusion is not
subtracted); an object fully off-canvas is skipped and reported.

## Rendering backend

Felix draws everything itself with NumPy: shapes are rasterised with 4×4 supersampling for smooth edges;
scaling uses an anti-aliased triangle filter; rotation is bilinear and grows the sprite so nothing is clipped;
hue shifts work in HSV; layers are composited with premultiplied alpha; images are written as PNG by Felix's own
encoder. Bounding boxes come from the sprite's alpha channel (pixels above 16/255), so transparent padding in
image sprites never inflates a box. About 75 images/s at 640×640 on a laptop CPU.
